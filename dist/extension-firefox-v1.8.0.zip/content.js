"use strict";
(() => {
  // src/features/appearance/theme.ts
  var STYLE_ID = "av-theme-foundation";
  var themeFeature = {
    id: "appearance.theme",
    title: "Theme foundation",
    category: "appearance",
    defaultEnabled: true,
    init(ctx) {
      ensureThemeStyle();
      applyTheme(ctx.settings);
      ctx.diagnostics.info("Theme foundation applied", {
        theme: ctx.settings.appearance.theme
      });
    },
    apply(ctx) {
      ensureThemeStyle();
      applyTheme(ctx.settings);
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID)?.remove();
      for (const theme of ["dim", "lightsOut", "graphite", "plum", "midnight"]) {
        document.documentElement.classList.remove(`av-theme-${theme}`);
      }
      document.documentElement.classList.remove(
        "av-dense",
        "av-hide-counts",
        "av-hide-borders",
        "av-high-contrast",
        "av-reduce-motion"
      );
      delete document.documentElement.dataset.avTheme;
      document.documentElement.style.colorScheme = "";
      ctx.diagnostics.info("Theme foundation destroyed");
    }
  };
  function applyTheme(settings) {
    const root = document.documentElement;
    const theme = settings.appearance.theme;
    for (const value of ["dim", "lightsOut", "graphite", "plum", "midnight"]) {
      root.classList.toggle(`av-theme-${value}`, value === theme);
    }
    root.dataset.avTheme = theme;
    root.classList.toggle("av-dense", settings.appearance.denseMode);
    root.classList.toggle("av-hide-counts", settings.appearance.hideCounts);
    root.classList.toggle("av-hide-borders", settings.appearance.hideBorders);
    root.classList.toggle("av-high-contrast", settings.accessibility.highContrast);
    root.classList.toggle("av-reduce-motion", shouldReduceMotion(settings));
    root.style.colorScheme = "dark";
  }
  function shouldReduceMotion(settings) {
    if (settings.accessibility.reduceMotion === "always") return true;
    if (settings.accessibility.reduceMotion === "never") return false;
    return globalThis.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  }
  function ensureThemeStyle() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = THEME_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var themeVars = {
    dim: `
    --av-bg: rgb(0, 0, 0);
    --av-surface: rgb(15, 20, 25);
    --av-surface-raised: rgb(22, 24, 28);
    --av-border: rgb(47, 51, 54);
    --av-text: rgb(239, 243, 244);
    /* X's own secondary grey measures 3.96:1 on the panel row \u2014 below AA for the 12px
       descriptions and status line it carries. Lifted to the nearest value that clears 4.5. */
    --av-muted: rgb(132, 139, 145);
    --av-accent: rgb(29, 155, 240);
  `,
    lightsOut: `
    --av-bg: rgb(0, 0, 0);
    --av-surface: rgb(5, 6, 7);
    --av-surface-raised: rgb(14, 15, 17);
    --av-border: rgb(36, 39, 43);
    --av-text: rgb(245, 247, 248);
    --av-muted: rgb(132, 139, 145);
    --av-accent: rgb(29, 155, 240);
  `,
    graphite: `
    --av-bg: rgb(8, 9, 11);
    --av-surface: rgb(18, 20, 23);
    --av-surface-raised: rgb(27, 30, 34);
    --av-border: rgb(55, 60, 66);
    --av-text: rgb(241, 244, 246);
    --av-muted: rgb(150, 157, 164);
    --av-accent: rgb(91, 176, 255);
  `,
    plum: `
    --av-bg: rgb(9, 5, 12);
    --av-surface: rgb(21, 14, 27);
    --av-surface-raised: rgb(32, 22, 41);
    --av-border: rgb(62, 45, 73);
    --av-text: rgb(246, 241, 249);
    --av-muted: rgb(164, 148, 174);
    --av-accent: rgb(205, 142, 255);
  `,
    midnight: `
    --av-bg: rgb(2, 8, 16);
    --av-surface: rgb(9, 18, 30);
    --av-surface-raised: rgb(16, 31, 49);
    --av-border: rgb(38, 60, 82);
    --av-text: rgb(239, 246, 252);
    --av-muted: rgb(139, 160, 178);
    --av-accent: rgb(68, 171, 255);
  `
  };
  var THEME_CSS = `
html.av-theme-dim { ${themeVars.dim} }
html.av-theme-lightsOut { ${themeVars.lightsOut} }
html.av-theme-graphite { ${themeVars.graphite} }
html.av-theme-plum { ${themeVars.plum} }
html.av-theme-midnight { ${themeVars.midnight} }

html[data-av-theme] {
  color-scheme: dark;
}

html[data-av-theme] body {
  background: var(--av-bg, rgb(0, 0, 0));
}

html[data-av-theme] [data-testid="primaryColumn"] {
  background: var(--av-bg, rgb(0, 0, 0));
}

html[data-av-theme] [data-testid="sidebarColumn"] section,
html[data-av-theme] [aria-label="Timeline: Trending now"] {
  background-color: color-mix(in srgb, var(--av-surface) 92%, transparent);
  border-color: var(--av-border);
}

html.av-dense article[data-testid="tweet"] {
  padding-top: 8px;
  padding-bottom: 8px;
}

/* Engagement counts inside the action bar only \u2014 the buttons themselves stay operable and
   keep their aria-labels, which carry the number for screen readers. */
html.av-hide-counts article[data-testid="tweet"] [data-testid="reply"] [data-testid="app-text-transition-container"],
html.av-hide-counts article[data-testid="tweet"] [data-testid="retweet"] [data-testid="app-text-transition-container"],
html.av-hide-counts article[data-testid="tweet"] [data-testid="unretweet"] [data-testid="app-text-transition-container"],
html.av-hide-counts article[data-testid="tweet"] [data-testid="like"] [data-testid="app-text-transition-container"],
html.av-hide-counts article[data-testid="tweet"] [data-testid="unlike"] [data-testid="app-text-transition-container"] {
  display: none !important;
}

/* Row dividers live on the first child of the virtualizer cell, styled by a generated atomic
   class (r-qklmqi in the captured CSS). Anchor on the structure, not the generated name. The
   column's own left/right rules are the other half of the "borderless" look. Verified against
   _decoded/home.html with its captured stylesheets: 10/10 cells carry a 1px bottom border. */
html.av-hide-borders [data-testid="cellInnerDiv"] > div {
  border-bottom-width: 0 !important;
}

html.av-hide-borders [data-testid="primaryColumn"] {
  border-left-width: 0 !important;
  border-right-width: 0 !important;
}

html.av-high-contrast {
  --av-border: color-mix(in srgb, var(--av-text, rgb(239, 243, 244)) 42%, transparent);
  --av-muted: color-mix(in srgb, var(--av-text, rgb(239, 243, 244)) 76%, transparent);
}

html.av-reduce-motion *,
html.av-reduce-motion *::before,
html.av-reduce-motion *::after {
  animation-duration: 0.001ms !important;
  animation-iteration-count: 1 !important;
  scroll-behavior: auto !important;
  transition-duration: 0.001ms !important;
}
`;

  // src/platform/i18n-catalog.ts
  var PANEL_CATALOG = {
    es: {
      "Aviary": "Aviary",
      "Local controls for a quieter X.": "Controles locales para una X m\xE1s tranquila.",
      "Close": "Cerrar",
      "Search settings": "Buscar ajustes",
      "Saved locally": "Guardado localmente",
      "Settings sections": "Secciones de ajustes",
      "Start": "Inicio",
      "Presets": "Ajustes predefinidos",
      "Reading": "Lectura",
      "Appearance": "Apariencia",
      "Layout": "Dise\xF1o",
      "Filtering": "Filtros",
      "Hidden posts": "Publicaciones ocultas",
      "Data": "Datos",
      "Media": "Multimedia",
      "Export": "Exportaci\xF3n",
      "Library": "Biblioteca",
      "Snapshots & Archive": "Instant\xE1neas y archivo",
      "Advanced": "Avanzado",
      "Integrations": "Integraciones",
      "Backup & Audit": "Copia y auditor\xEDa",
      "Trust": "Privacidad",
      "Apply": "Aplicar",
      "Locale": "Idioma",
      "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.": "Traduce el panel y define la direcci\xF3n de lectura: de derecha a izquierda para \xE1rabe y hebreo. Privacidad indica qu\xE9 parte del idioma elegido est\xE1 completa; lo que falte permanece en ingl\xE9s.",
      "Theme value is not supported.": "Ese tema no es compatible.",
      "Theme updated": "Tema actualizado",
      "Density updated": "Densidad actualizada",
      "Contrast preference saved": "Preferencia de contraste guardada",
      "Motion preference saved": "Preferencia de movimiento guardada",
      "Sidebar preference saved": "Preferencia de barra lateral guardada",
      "Trend preference saved": "Preferencia de tendencias guardada",
      "Grok preference saved": "Preferencia de Grok guardada",
      "Could not apply preset.": "No se pudo aplicar el ajuste predefinido.",
      "Snapshot failed.": "La instant\xE1nea fall\xF3.",
      "Snapshots cleared": "Instant\xE1neas borradas",
      "Could not clear snapshots.": "No se pudieron borrar las instant\xE1neas.",
      "Reading archive \u2014 large files take a moment\u2026": "Leyendo el archivo: los ficheros grandes tardan un momento\u2026",
      "Archive import failed.": "Error al importar el archivo.",
      "Building report\u2026": "Generando el informe\u2026",
      "Report downloaded.": "Informe descargado.",
      "Could not build report.": "No se pudo generar el informe.",
      "Building cleanup preview\u2026": "Generando la vista previa de limpieza\u2026",
      "Could not enqueue cleanup.": "No se pudo encolar la limpieza.",
      "Cleanup queue cleared": "Cola de limpieza vaciada",
      "Could not clear queue.": "No se pudo vaciar la cola.",
      "Aria2 endpoint saved": "Endpoint de Aria2 guardado",
      "Aria2 secret saved": "Secreto de Aria2 guardado",
      "Aria2 sweep failed.": "Error al consultar Aria2.",
      "Bluesky service saved": "Servicio de Bluesky guardado",
      "Bluesky handle saved": "Usuario de Bluesky guardado",
      "Bluesky app password saved": "Contrase\xF1a de aplicaci\xF3n de Bluesky guardada",
      "Mastodon instance saved": "Instancia de Mastodon guardada",
      "Mastodon token saved": "Token de Mastodon guardado",
      "AI endpoint saved": "Endpoint de IA guardado",
      "AI model saved": "Modelo de IA guardado",
      "AI API key saved": "Clave de API de IA guardada",
      "Embedding endpoint saved": "Endpoint de embeddings guardado",
      "Embedding model saved": "Modelo de embeddings guardado",
      "Embedding API key saved": "Clave de API de embeddings guardada",
      "Rebuilding semantic index\u2026": "Reconstruyendo el \xEDndice sem\xE1ntico\u2026",
      "Embedding failed.": "Fallaron los embeddings.",
      "Semantic index cleared": "\xCDndice sem\xE1ntico borrado",
      "Account notes cleared": "Notas de cuentas borradas",
      "Could not clear notes.": "No se pudieron borrar las notas.",
      "Settings exported.": "Ajustes exportados.",
      "Could not export settings.": "No se pudieron exportar los ajustes.",
      "Could not import settings.": "No se pudieron importar los ajustes.",
      "Audit log cleared": "Registro de auditor\xEDa borrado",
      "Could not clear audit log.": "No se pudo borrar el registro de auditor\xEDa.",
      "Raw payload preference saved": "Preferencia de payloads sin procesar guardada",
      "Query discovery preference saved": "Preferencia de descubrimiento de consultas guardada",
      "Save folder hint saved": "Carpeta de guardado guardada",
      "Collecting visible posts\u2026": "Recopilando las publicaciones visibles\u2026",
      "Export failed. See diagnostics.": "La exportaci\xF3n fall\xF3. Consulta el diagn\xF3stico.",
      "Diagnostics copied to clipboard.": "Diagn\xF3stico copiado al portapapeles.",
      "Could not copy diagnostics.": "No se pudo copiar el diagn\xF3stico.",
      "Building WARC archive\u2026": "Generando el archivo WARC\u2026",
      "WARC export failed.": "Error en la exportaci\xF3n WARC.",
      "External export failed.": "La exportaci\xF3n externa fall\xF3.",
      "Records per ZIP saved": "Registros por ZIP guardados",
      "Export job retention saved": "Retenci\xF3n de trabajos guardada",
      "Record retention saved": "Retenci\xF3n de registros guardada",
      "Age-based retention saved": "Retenci\xF3n por antig\xFCedad guardada",
      "Original quality preference saved": "Preferencia de calidad original guardada",
      "Filename template saved": "Plantilla de nombre de archivo guardada",
      "Sensitive content preference saved": "Preferencia de contenido sensible guardada",
      "Media layout saved": "Disposici\xF3n multimedia guardada",
      "History cleared": "Historial borrado",
      "Could not clear history.": "No se pudo borrar el historial.",
      "Downloading media from this view\u2026": "Descargando el contenido de esta vista\u2026",
      "Batch download failed.": "La descarga por lotes fall\xF3.",
      "Premium filter saved": "Filtro Premium guardado",
      "Could not undo the last hide.": "No se pudo deshacer la \xFAltima ocultaci\xF3n.",
      "Could not restore the post.": "No se pudo restaurar la publicaci\xF3n.",
      "Could not clear hidden posts.": "No se pudieron borrar las publicaciones ocultas.",
      "Saving...": "Guardando...",
      "Could not save settings. Try again.": "No se pudieron guardar los ajustes. Int\xE9ntalo de nuevo.",
      "Theme": "Tema",
      "Dim": "Atenuado",
      "Lights out": "Luces apagadas",
      "Graphite": "Grafito",
      "Plum": "Ciruela",
      "Midnight": "Medianoche",
      "Dense mode": "Modo denso",
      "Tighten timeline spacing for scanning.": "Comprime el espaciado de la cronolog\xEDa para leer m\xE1s r\xE1pido.",
      "Hide engagement counts": "Ocultar contadores de interacci\xF3n",
      "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.": "Oculta los n\xFAmeros de respuestas, reposts y me gusta. Los botones siguen funcionando y los lectores de pantalla siguen anunciando los totales.",
      "Hide row borders": "Ocultar bordes de fila",
      "Remove the 1px divider under each timeline post and the primary column's side rules.": "Elimina el divisor de 1 px bajo cada publicaci\xF3n y las l\xEDneas laterales de la columna principal.",
      "High contrast": "Alto contraste",
      "Use stronger borders and text contrast.": "Usa bordes y contraste de texto m\xE1s marcados.",
      "Reduced motion": "Movimiento reducido",
      "Follow system setting": "Seguir la configuraci\xF3n del sistema",
      "Always reduce": "Reducir siempre",
      "Never reduce": "No reducir nunca",
      "Hide right sidebar": "Ocultar barra lateral derecha",
      "Reduce trends, recommendations, and footer noise.": "Reduce el ruido de tendencias, recomendaciones y pie de p\xE1gina.",
      "Hide trends": "Ocultar tendencias",
      "Remove trending topics and news modules.": "Elimina los temas del momento y los m\xF3dulos de noticias.",
      "Hide Grok surfaces": "Ocultar superficies de Grok",
      "Remove Grok drawer and composer buttons where detected.": "Elimina el panel de Grok y sus botones en el redactor cuando se detecten.",
      "Writer mode": "Modo escritura",
      "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.": "Mientras el foco est\xE1 en el redactor, aten\xFAa la barra lateral y la cronolog\xEDa detr\xE1s. Todo vuelve en cuanto haces clic fuera.",
      "Enable filters": "Activar filtros",
      "Master switch for keyword, regex, premium, and media filters.": "Interruptor general de los filtros de palabras clave, expresiones regulares, Premium y multimedia.",
      "Keyword rules": "Reglas de palabras clave",
      "One keyword or phrase per line. Case-insensitive substring match.": "Una palabra clave o frase por l\xEDnea. Coincidencia parcial sin distinguir may\xFAsculas.",
      "Save list": "Guardar lista",
      "Regex rules": "Reglas de expresiones regulares",
      "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).": "Un patr\xF3n por l\xEDnea. Usa /patr\xF3n/flags o un patr\xF3n simple (sin distinguir may\xFAsculas).",
      "Whitelist handles": "Cuentas en la lista blanca",
      "Handles (one per line, no @) that are never filtered.": "Cuentas (una por l\xEDnea, sin @) que nunca se filtran.",
      "Premium / verified posts": "Publicaciones Premium / verificadas",
      "Off": "Desactivado",
      "Hide": "Ocultar",
      "Hide posts with photos": "Ocultar publicaciones con fotos",
      "Filter posts containing photos.": "Filtra las publicaciones que contienen fotos.",
      "Hide posts with videos": "Ocultar publicaciones con v\xEDdeos",
      "Filter posts containing videos.": "Filtra las publicaciones que contienen v\xEDdeos.",
      "Hide posts with gifs": "Ocultar publicaciones con GIF",
      "Filter posts containing gifs.": "Filtra las publicaciones que contienen GIF.",
      "Active on": "Activo en",
      "Routes where filters run.": "Rutas en las que se ejecutan los filtros.",
      "Home": "Inicio",
      "Status": "Publicaci\xF3n",
      "Profile": "Perfil",
      "Search": "B\xFAsqueda",
      "Notifications": "Notificaciones",
      "Messages": "Mensajes",
      "Blocked accounts / self-reposts": "Cuentas bloqueadas / autorreposts",
      "Pending an authenticated fixture; controls stay disabled.": "Pendiente de una captura autenticada; los controles siguen desactivados.",
      "Hide dismissed posts": "Ocultar publicaciones descartadas",
      "Keep posts you hid collapsed so the next post rises to the top.": "Mantiene contra\xEDdas las publicaciones que ocultaste para que la siguiente suba al principio.",
      "Show hide buttons": "Mostrar botones de ocultar",
      "Adds a Hide control to every post next to the More menu.": "A\xF1ade un control Ocultar a cada publicaci\xF3n, junto al men\xFA M\xE1s.",
      "Routes where hiding and the Hide button apply.": "Rutas en las que se aplican el ocultado y el bot\xF3n Ocultar.",
      "Maximum remembered posts": "M\xE1ximo de publicaciones recordadas",
      "Oldest entries are dropped once the store passes this size (100-50000).": "Las entradas m\xE1s antiguas se descartan cuando el almac\xE9n supera este tama\xF1o (100-50000).",
      "Save": "Guardar",
      "Hidden posts stored": "Publicaciones ocultas guardadas",
      "Undo last hide": "Deshacer la \xFAltima ocultaci\xF3n",
      "Restores the most recently hidden post.": "Restaura la publicaci\xF3n ocultada m\xE1s recientemente.",
      "Restore": "Restaurar",
      "Clear hidden posts": "Borrar publicaciones ocultas",
      "Forgets every hidden post and brings them all back.": "Olvida todas las publicaciones ocultas y las restaura.",
      "Show download buttons": "Mostrar botones de descarga",
      "Inject Save and Thumb buttons over tweet photos and video thumbnails.": "A\xF1ade botones Guardar y Miniatura sobre las fotos y las miniaturas de v\xEDdeo.",
      "Prefer original quality": "Preferir calidad original",
      "Rewrite image URLs to name=orig before downloading.": "Reescribe las URL de imagen a name=orig antes de descargar.",
      "Filename template": "Plantilla de nombre de archivo",
      "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.": "Campos: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.",
      "Duplicate history": "Historial de duplicados",
      "Skip downloads of media you have already saved from this browser.": "Omite las descargas de contenido que ya guardaste desde este navegador.",
      "Sensitive content": "Contenido sensible",
      "Default (X choice)": "Predeterminado (elecci\xF3n de X)",
      "Always reveal": "Mostrar siempre",
      "Blur until hovered": "Difuminar hasta pasar el cursor",
      "Always hide": "Ocultar siempre",
      "Media layout": "Disposici\xF3n multimedia",
      "Default grid": "Cuadr\xEDcula predeterminada",
      "Stacked": "Apilado",
      "Strict grid": "Cuadr\xEDcula estricta",
      "Download status": "Estado de las descargas",
      "History entries": "Entradas del historial",
      "Clear download history": "Borrar historial de descargas",
      "Reset the local dedup index.": "Reinicia el \xEDndice local de duplicados.",
      "Download all visible media": "Descargar todo el contenido visible",
      "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.": "Recorre cada publicaci\xF3n de la p\xE1gina actual y encola cada foto, v\xEDdeo, GIF y miniatura en la cola de descargas existente.",
      "Capture visible tweets": "Capturar publicaciones visibles",
      "Accumulate tweets visible on the active page for the next export run.": "Acumula las publicaciones visibles en la p\xE1gina activa para la pr\xF3xima exportaci\xF3n.",
      "Export formats": "Formatos de exportaci\xF3n",
      "Comma-separated list. Supported: json, csv, html, markdown, xlsx.": "Lista separada por comas. Admitidos: json, csv, html, markdown, xlsx.",
      "Preserve raw payloads": "Conservar cargas \xFAtiles sin procesar",
      "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.": "Guarda tambi\xE9n las respuestas GraphQL sin procesar que X env\xEDa a esta pesta\xF1a, para poder reinterpretar los registros m\xE1s tarde. Los tokens de sesi\xF3n se eliminan antes de escribir nada.",
      "Auto-discover query IDs": "Detectar autom\xE1ticamente los ID de consulta",
      "Scan loaded scripts for X GraphQL operation IDs and cache them locally.": "Analiza los scripts cargados en busca de ID de operaciones GraphQL de X y los guarda localmente.",
      "Save folder hint": "Sugerencia de carpeta de guardado",
      "Folder name (or path) used as the export ZIP root and download prefix.": "Nombre de carpeta (o ruta) usado como ra\xEDz del ZIP de exportaci\xF3n y prefijo de descarga.",
      "Export status": "Estado de la exportaci\xF3n",
      "Export visible tweets": "Exportar publicaciones visibles",
      "Collect the currently rendered tweets and download a ZIP.": "Recopila las publicaciones visibles y descarga un ZIP.",
      "Copy diagnostics": "Copiar diagn\xF3stico",
      "Copy support diagnostics (version, route, recent log).": "Copia el diagn\xF3stico de soporte (versi\xF3n, ruta, registro reciente).",
      "Download as WARC": "Descargar como WARC",
      "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.": "Empaqueta los registros capturados en un archivo WARC ISO-28500 para herramientas de investigaci\xF3n y preservaci\xF3n.",
      "Copy as Markdown": "Copiar como Markdown",
      "Push a plain Markdown export onto the clipboard.": "Copia una exportaci\xF3n en Markdown simple al portapapeles.",
      "Save Obsidian Markdown": "Guardar Markdown para Obsidian",
      "Markdown with YAML frontmatter and Aviary tags.": "Markdown con frontmatter YAML y etiquetas de Aviary.",
      "Save Notion Markdown": "Guardar Markdown para Notion",
      "Heading-first Markdown that Notion imports cleanly.": "Markdown basado en encabezados que Notion importa sin problemas.",
      "Save records JSON": "Guardar registros en JSON",
      "Raw ExportRecord[] JSON without ZIP wrapping.": "JSON ExportRecord[] sin comprimir en ZIP.",
      "Records per ZIP": "Registros por ZIP",
      "Split a long export across several archives instead of one huge file (25-1000).": "Divide una exportaci\xF3n larga en varios archivos en lugar de uno enorme (25-1000).",
      "Maximum export jobs": "M\xE1ximo de trabajos de exportaci\xF3n",
      "Keep the newest jobs. Use 0 for unlimited.": "Conserva los trabajos m\xE1s recientes. Usa 0 para ilimitado.",
      "Maximum records per job": "M\xE1ximo de registros por trabajo",
      "Keep the newest records in each job. Use 0 for unlimited.": "Conserva los registros m\xE1s recientes de cada trabajo. Usa 0 para ilimitado.",
      "Maximum export age (days)": "Antig\xFCedad m\xE1xima de exportaci\xF3n (d\xEDas)",
      "Remove older jobs at boot. Use 0 to disable age-based cleanup.": "Elimina los trabajos antiguos al iniciar. Usa 0 para desactivar la limpieza por antig\xFCedad.",
      "Unshorten t.co links": "Expandir enlaces t.co",
      "Replace short `t.co` redirects with the destination from aria-labels and titles.": "Sustituye las redirecciones cortas `t.co` por el destino que aparece en aria-labels y t\xEDtulos.",
      "Clean tracking from links": "Limpiar el rastreo de los enlaces",
      "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.": "Elimina los tokens para compartir y los par\xE1metros de campa\xF1a (utm_*, fbclid y los propios t/s de X) de los enlaces del cronograma, de modo que lo que copias es la direcci\xF3n limpia.",
      "Account notes": "Notas de cuentas",
      "Format: handle: note. One per line. Empty notes remove the entry.": "Formato: usuario: nota. Una por l\xEDnea. Las notas vac\xEDas eliminan la entrada.",
      "Clear all account notes": "Borrar todas las notas de cuentas",
      "Drop every persisted note.": "Elimina todas las notas guardadas.",
      "Composer snippets": "Fragmentos del redactor",
      "One snippet per line. Reusable replies / templates (insertion landing in a later release).": "Un fragmento por l\xEDnea. Respuestas y plantillas reutilizables (la inserci\xF3n llegar\xE1 en una versi\xF3n posterior).",
      "Snapshots stored": "Instant\xE1neas guardadas",
      "Capture followers from this view": "Capturar seguidores desde esta vista",
      "Walks UserCell rows on the current page. Open a /handle/followers view first.": "Recorre las filas UserCell de la p\xE1gina actual. Abre primero una vista /usuario/followers.",
      "Capture following from this view": "Capturar seguidos desde esta vista",
      "Walks UserCell rows on the current page. Open a /handle/following view first.": "Recorre las filas UserCell de la p\xE1gina actual. Abre primero una vista /usuario/following.",
      "Clear all snapshots": "Borrar todas las instant\xE1neas",
      "Drop every stored follower/following snapshot.": "Elimina todas las instant\xE1neas de seguidores y seguidos.",
      "Download Markdown report": "Descargar informe en Markdown",
      "Audit log + snapshot diff + cleanup preview.": "Registro de auditor\xEDa, comparaci\xF3n de instant\xE1neas y vista previa de limpieza.",
      "Cleanup review queue": "Cola de revisi\xF3n de limpieza",
      "Destructive actions": "Acciones destructivas",
      "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log.": "Aviary nunca elimina publicaciones, me gusta ni seguimientos. La cola es una lista de revisi\xF3n; aprobar u omitir solo escribe en el registro de auditor\xEDa.",
      "Enqueue cleanup preview for review": "A\xF1adir la vista previa de limpieza a la cola",
      "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).": "A\xF1ade a la cola todos los candidatos no protegidos de la \xFAltima vista previa de limpieza (sin acciones destructivas).",
      "Clear cleanup queue": "Vaciar la cola de limpieza",
      "Drop every queued item without touching account data.": "Elimina todos los elementos de la cola sin tocar los datos de la cuenta.",
      "Aria2 handoff": "Traspaso a Aria2",
      "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.": "Env\xEDa las descargas grandes a un endpoint Aria2 JSON-RPC autoalojado.",
      "Aria2 endpoint": "Endpoint de Aria2",
      "http://localhost:6800 (no trailing slash needed)": "http://localhost:6800 (no hace falta barra final)",
      "Aria2 RPC secret": "Secreto RPC de Aria2",
      "Optional shared secret for token: auth.": "Secreto compartido opcional para la autenticaci\xF3n token:.",
      "Show": "Mostrar",
      "Test Aria2 connection": "Probar la conexi\xF3n con Aria2",
      "Sends a trivial JSON-RPC call.": "Env\xEDa una llamada JSON-RPC trivial.",
      "Refresh": "Actualizar",
      "Bluesky crosspost": "Publicaci\xF3n cruzada en Bluesky",
      "Post composer text to your Bluesky account on demand.": "Publica el texto del redactor en tu cuenta de Bluesky cuando lo pidas.",
      "Bluesky service URL": "URL del servicio de Bluesky",
      "Default: https://bsky.social": "Predeterminado: https://bsky.social",
      "Bluesky handle": "Cuenta de Bluesky",
      "Your handle (no @, e.g. you.bsky.social)": "Tu cuenta (sin @, p. ej. tu.bsky.social)",
      "Bluesky app password": "Contrase\xF1a de aplicaci\xF3n de Bluesky",
      "App password from your account settings \u2014 never your main password.": "Contrase\xF1a de aplicaci\xF3n de los ajustes de tu cuenta \u2014 nunca tu contrase\xF1a principal.",
      "Mastodon crosspost": "Publicaci\xF3n cruzada en Mastodon",
      "Post composer text to your Mastodon account on demand.": "Publica el texto del redactor en tu cuenta de Mastodon cuando lo pidas.",
      "Mastodon instance": "Instancia de Mastodon",
      "https://mastodon.social": "https://mastodon.social",
      "Mastodon access token": "Token de acceso de Mastodon",
      "Bearer token with write:statuses scope.": "Token Bearer con el \xE1mbito write:statuses.",
      "Attach last download": "Adjuntar la \xFAltima descarga",
      "Upload the last successful Aviary media download with the first post in an explicit crosspost.": "Adjunta la \xFAltima descarga correcta de Aviary a la primera publicaci\xF3n de una publicaci\xF3n cruzada expl\xEDcita.",
      "Crosspost composer \u2192 Bluesky": "Publicar el redactor en Bluesky",
      "Uses the current composer text.": "Usa el texto actual del redactor.",
      "Crosspost composer \u2192 Mastodon": "Publicar el redactor en Mastodon",
      "AI provider runs": "Ejecuciones del proveedor de IA",
      "Let the AI command menu POST prompts to your configured provider.": "Permite que el men\xFA de comandos de IA env\xEDe las indicaciones a tu proveedor.",
      "AI provider": "Proveedor de IA",
      "Anthropic Messages API": "Anthropic Messages API",
      "OpenAI Chat Completions": "OpenAI Chat Completions",
      "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)": "Compatible con OpenAI (LocalAI, proxy de Ollama, \u2026)",
      "AI endpoint (optional)": "Endpoint de IA (opcional)",
      "Override the default endpoint for the chosen provider.": "Sustituye el endpoint predeterminado del proveedor elegido.",
      "AI model": "Modelo de IA",
      "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b": "p. ej. claude-sonnet-4-6, gpt-4o, llama3.1:8b",
      "AI API key": "Clave de API de IA",
      "Stored locally only. Aviary never sends this except as the auth header to your provider.": "Se guarda solo en local. Aviary nunca la env\xEDa salvo como cabecera de autenticaci\xF3n a tu proveedor.",
      "Semantic search": "B\xFAsqueda sem\xE1ntica",
      "Embed CheckpointStore records via your provider for similarity search.": "Incrusta los registros del CheckpointStore con tu proveedor para la b\xFAsqueda por similitud.",
      "Embedding endpoint": "Endpoint de incrustaciones",
      "POST endpoint that returns {data: [{embedding: number[]}]}": "Endpoint POST que devuelve {data: [{embedding: number[]}]}",
      "Embedding model": "Modelo de incrustaciones",
      "e.g. text-embedding-3-small": "p. ej. text-embedding-3-small",
      "Embedding API key": "Clave de API de incrustaciones",
      "Stored locally; used only as the Authorization header.": "Se guarda en local; se usa solo como cabecera Authorization.",
      "Auto-embed every export": "Incrustar autom\xE1ticamente cada exportaci\xF3n",
      "After each export run, kick the embedding job in the background. Off by default.": "Tras cada exportaci\xF3n, lanza el trabajo de incrustaci\xF3n en segundo plano. Desactivado por defecto.",
      "Rebuild semantic index": "Reconstruir el \xEDndice sem\xE1ntico",
      "Embed every captured record. Re-running is cheap because cached entries are skipped.": "Genera embeddings de cada registro capturado. Repetirlo es barato porque se omiten las entradas en cach\xE9.",
      "Clear semantic index": "Borrar el \xEDndice sem\xE1ntico",
      "Forget every embedded record.": "Olvida todos los registros con embeddings.",
      "Integration status": "Estado de las integraciones",
      "Export settings": "Exportar ajustes",
      "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.": "Descarga tus preferencias en JSON. Las claves de API y las contrase\xF1as se sustituyen por un marcador, as\xED que el archivo es seguro de compartir; al importarlo aqu\xED se conservan las credenciales ya guardadas en este equipo.",
      "Import settings (JSON)": "Importar ajustes (JSON)",
      "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.": "Pega un archivo de ajustes exportado desde Aviary y pulsa Importar. Las credenciales ocultas conservan los valores ya guardados aqu\xED.",
      "Import": "Importar",
      "Keep a local action log": "Mantener un registro local de acciones",
      "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.": "Registra descargas, exportaciones y cambios de ajustes en este dispositivo para que puedas revisar lo que hizo Aviary. No se env\xEDa nada a ning\xFAn sitio. Al desactivarlo se dejan de a\xF1adir entradas de inmediato; las existentes se conservan hasta que las borres.",
      "Audit entries": "Entradas de auditor\xEDa",
      "Clear audit log": "Borrar el registro de auditor\xEDa",
      "Drop the local action log.": "Elimina el registro local de acciones.",
      "Storage": "Almacenamiento",
      "Settings stay in this browser.": "Los ajustes se quedan en este navegador.",
      "Local-only mode": "Modo solo local",
      "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.": "Bloquea todas las peticiones salientes, incluidas las integraciones que hayas configurado. Activado de forma predeterminada; activar una integraci\xF3n es lo que lo desactiva.",
      "Some changes could not be saved \u2014 the browser store may be full.": "No se pudieron guardar algunos cambios; el almacenamiento del navegador podr\xEDa estar lleno.",
      "Saving": "Guardado",
      "Telemetry": "Telemetr\xEDa",
      "Disabled": "Desactivada",
      "Panel language": "Idioma del panel",
      "Selector health": "Estado de los selectores",
      "Working \u2014 every change has been written.": "Correcto: se han guardado todos los cambios.",
      "Monitoring active": "Supervisi\xF3n activa",
      "Preset packs unavailable in this build.": "Los paquetes predefinidos no est\xE1n disponibles en esta compilaci\xF3n.",
      "Hidden post store unavailable in this build.": "El almac\xE9n de publicaciones ocultas no est\xE1 disponible en esta compilaci\xF3n.",
      "Cancel": "Cancelar"
    },
    pt: {
      "Aviary": "Aviary",
      "Local controls for a quieter X.": "Controles locais para um X mais tranquilo.",
      "Close": "Fechar",
      "Search settings": "Pesquisar defini\xE7\xF5es",
      "Saved locally": "Guardado localmente",
      "Settings sections": "Sec\xE7\xF5es de defini\xE7\xF5es",
      "Start": "In\xEDcio",
      "Presets": "Predefini\xE7\xF5es",
      "Reading": "Leitura",
      "Appearance": "Apar\xEAncia",
      "Layout": "Layout",
      "Filtering": "Filtros",
      "Hidden posts": "Posts ocultos",
      "Data": "Dados",
      "Media": "M\xEDdia",
      "Export": "Exporta\xE7\xE3o",
      "Library": "Biblioteca",
      "Snapshots & Archive": "Instant\xE2neos e arquivo",
      "Advanced": "Avan\xE7ado",
      "Integrations": "Integra\xE7\xF5es",
      "Backup & Audit": "Backup e auditoria",
      "Trust": "Privacidade",
      "Apply": "Aplicar",
      "Locale": "Idioma",
      "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.": "Traduz o painel e define a dire\xE7\xE3o de leitura: da direita para a esquerda em \xE1rabe e hebraico. Privacidade mostra quanto do idioma escolhido est\xE1 preenchido; o que faltar permanece em ingl\xEAs.",
      "Theme value is not supported.": "Esse tema n\xE3o \xE9 suportado.",
      "Theme updated": "Tema atualizado",
      "Density updated": "Densidade atualizada",
      "Contrast preference saved": "Prefer\xEAncia de contraste guardada",
      "Motion preference saved": "Prefer\xEAncia de movimento guardada",
      "Sidebar preference saved": "Prefer\xEAncia de barra lateral guardada",
      "Trend preference saved": "Prefer\xEAncia de tend\xEAncias guardada",
      "Grok preference saved": "Prefer\xEAncia do Grok guardada",
      "Could not apply preset.": "N\xE3o foi poss\xEDvel aplicar a predefini\xE7\xE3o.",
      "Snapshot failed.": "O instant\xE2neo falhou.",
      "Snapshots cleared": "Instant\xE2neos limpos",
      "Could not clear snapshots.": "N\xE3o foi poss\xEDvel limpar os instant\xE2neos.",
      "Reading archive \u2014 large files take a moment\u2026": "A ler o arquivo: ficheiros grandes demoram um momento\u2026",
      "Archive import failed.": "Falha ao importar o arquivo.",
      "Building report\u2026": "A gerar o relat\xF3rio\u2026",
      "Report downloaded.": "Relat\xF3rio transferido.",
      "Could not build report.": "N\xE3o foi poss\xEDvel gerar o relat\xF3rio.",
      "Building cleanup preview\u2026": "A gerar a pr\xE9-visualiza\xE7\xE3o de limpeza\u2026",
      "Could not enqueue cleanup.": "N\xE3o foi poss\xEDvel colocar a limpeza na fila.",
      "Cleanup queue cleared": "Fila de limpeza esvaziada",
      "Could not clear queue.": "N\xE3o foi poss\xEDvel esvaziar a fila.",
      "Aria2 endpoint saved": "Endpoint do Aria2 guardado",
      "Aria2 secret saved": "Segredo do Aria2 salvo",
      "Aria2 sweep failed.": "Falha ao consultar o Aria2.",
      "Bluesky service saved": "Servi\xE7o do Bluesky salvo",
      "Bluesky handle saved": "Utilizador do Bluesky guardado",
      "Bluesky app password saved": "Senha de aplicativo do Bluesky salva",
      "Mastodon instance saved": "Inst\xE2ncia do Mastodon guardada",
      "Mastodon token saved": "Token do Mastodon guardado",
      "AI endpoint saved": "Endpoint de IA guardado",
      "AI model saved": "Modelo de IA salvo",
      "AI API key saved": "Chave de API de IA salva",
      "Embedding endpoint saved": "Endpoint de embeddings guardado",
      "Embedding model saved": "Modelo de embeddings guardado",
      "Embedding API key saved": "Chave de API de embeddings guardada",
      "Rebuilding semantic index\u2026": "A reconstruir o \xEDndice sem\xE2ntico\u2026",
      "Embedding failed.": "Os embeddings falharam.",
      "Semantic index cleared": "\xCDndice sem\xE2ntico limpo",
      "Account notes cleared": "Notas de contas limpas",
      "Could not clear notes.": "N\xE3o foi poss\xEDvel limpar as notas.",
      "Settings exported.": "Defini\xE7\xF5es exportadas.",
      "Could not export settings.": "N\xE3o foi poss\xEDvel exportar as defini\xE7\xF5es.",
      "Could not import settings.": "N\xE3o foi poss\xEDvel importar as defini\xE7\xF5es.",
      "Audit log cleared": "Registro de auditoria limpo",
      "Could not clear audit log.": "N\xE3o foi poss\xEDvel limpar o registo de auditoria.",
      "Raw payload preference saved": "Prefer\xEAncia de payloads em bruto guardada",
      "Query discovery preference saved": "Prefer\xEAncia de descoberta de consultas guardada",
      "Save folder hint saved": "Pasta de destino guardada",
      "Collecting visible posts\u2026": "A reunir as publica\xE7\xF5es vis\xEDveis\u2026",
      "Export failed. See diagnostics.": "A exporta\xE7\xE3o falhou. Consulte o diagn\xF3stico.",
      "Diagnostics copied to clipboard.": "Diagn\xF3stico copiado para a \xE1rea de transfer\xEAncia.",
      "Could not copy diagnostics.": "N\xE3o foi poss\xEDvel copiar o diagn\xF3stico.",
      "Building WARC archive\u2026": "A gerar o arquivo WARC\u2026",
      "WARC export failed.": "Falha na exporta\xE7\xE3o WARC.",
      "External export failed.": "A exporta\xE7\xE3o externa falhou.",
      "Records per ZIP saved": "Registos por ZIP guardados",
      "Export job retention saved": "Reten\xE7\xE3o de trabalhos guardada",
      "Record retention saved": "Reten\xE7\xE3o de registos guardada",
      "Age-based retention saved": "Reten\xE7\xE3o por idade guardada",
      "Original quality preference saved": "Prefer\xEAncia de qualidade original guardada",
      "Filename template saved": "Modelo de nome de ficheiro guardado",
      "Sensitive content preference saved": "Prefer\xEAncia de conte\xFAdo sens\xEDvel guardada",
      "Media layout saved": "Layout de m\xEDdia salvo",
      "History cleared": "Hist\xF3rico limpo",
      "Could not clear history.": "N\xE3o foi poss\xEDvel limpar o hist\xF3rico.",
      "Downloading media from this view\u2026": "A transferir a m\xE9dia desta vista\u2026",
      "Batch download failed.": "A transfer\xEAncia em lote falhou.",
      "Premium filter saved": "Filtro Premium salvo",
      "Could not undo the last hide.": "N\xE3o foi poss\xEDvel desfazer a \xFAltima oculta\xE7\xE3o.",
      "Could not restore the post.": "N\xE3o foi poss\xEDvel restaurar a publica\xE7\xE3o.",
      "Could not clear hidden posts.": "N\xE3o foi poss\xEDvel limpar as publica\xE7\xF5es ocultas.",
      "Saving...": "A guardar...",
      "Could not save settings. Try again.": "N\xE3o foi poss\xEDvel guardar as defini\xE7\xF5es. Tente novamente.",
      "Theme": "Tema",
      "Dim": "Escurecido",
      "Lights out": "Luzes apagadas",
      "Graphite": "Grafite",
      "Plum": "Ameixa",
      "Midnight": "Meia-noite",
      "Dense mode": "Modo denso",
      "Tighten timeline spacing for scanning.": "Compacta o espa\xE7amento da linha do tempo para leitura r\xE1pida.",
      "Hide engagement counts": "Ocultar contadores de intera\xE7\xE3o",
      "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.": "Oculta os n\xFAmeros de respostas, reposts e curtidas. Os bot\xF5es continuam funcionando e os leitores de tela ainda anunciam os totais.",
      "Hide row borders": "Ocultar bordas das linhas",
      "Remove the 1px divider under each timeline post and the primary column's side rules.": "Remove o divisor de 1 px sob cada post e as linhas laterais da coluna principal.",
      "High contrast": "Alto contraste",
      "Use stronger borders and text contrast.": "Usa bordas e contraste de texto mais fortes.",
      "Reduced motion": "Movimento reduzido",
      "Follow system setting": "Seguir a configura\xE7\xE3o do sistema",
      "Always reduce": "Sempre reduzir",
      "Never reduce": "Nunca reduzir",
      "Hide right sidebar": "Ocultar barra lateral direita",
      "Reduce trends, recommendations, and footer noise.": "Reduz o ru\xEDdo de tend\xEAncias, recomenda\xE7\xF5es e rodap\xE9.",
      "Hide trends": "Ocultar tend\xEAncias",
      "Remove trending topics and news modules.": "Remove os t\xF3picos do momento e os m\xF3dulos de not\xEDcias.",
      "Hide Grok surfaces": "Ocultar superf\xEDcies do Grok",
      "Remove Grok drawer and composer buttons where detected.": "Remove o painel do Grok e os bot\xF5es no editor quando detectados.",
      "Writer mode": "Modo escrita",
      "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.": "Enquanto o foco est\xE1 no editor, esmaece a barra lateral e a linha do tempo atr\xE1s dele. Tudo volta assim que voc\xEA clica fora.",
      "Enable filters": "Ativar filtros",
      "Master switch for keyword, regex, premium, and media filters.": "Chave geral dos filtros de palavra-chave, regex, Premium e m\xEDdia.",
      "Keyword rules": "Regras de palavras-chave",
      "One keyword or phrase per line. Case-insensitive substring match.": "Uma palavra-chave ou frase por linha. Correspond\xEAncia parcial sem diferenciar mai\xFAsculas.",
      "Save list": "Salvar lista",
      "Regex rules": "Regras de express\xF5es regulares",
      "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).": "Um padr\xE3o por linha. Use /padr\xE3o/flags ou um padr\xE3o simples (sem diferenciar mai\xFAsculas).",
      "Whitelist handles": "Perfis na lista branca",
      "Handles (one per line, no @) that are never filtered.": "Perfis (um por linha, sem @) que nunca s\xE3o filtrados.",
      "Premium / verified posts": "Posts Premium / verificados",
      "Off": "Desligado",
      "Hide": "Ocultar",
      "Hide posts with photos": "Ocultar posts com fotos",
      "Filter posts containing photos.": "Filtra posts que cont\xEAm fotos.",
      "Hide posts with videos": "Ocultar posts com v\xEDdeos",
      "Filter posts containing videos.": "Filtra posts que cont\xEAm v\xEDdeos.",
      "Hide posts with gifs": "Ocultar posts com GIFs",
      "Filter posts containing gifs.": "Filtra posts que cont\xEAm GIFs.",
      "Active on": "Ativo em",
      "Routes where filters run.": "Rotas onde os filtros s\xE3o aplicados.",
      "Home": "In\xEDcio",
      "Status": "Publica\xE7\xE3o",
      "Profile": "Perfil",
      "Search": "Pesquisa",
      "Notifications": "Notifica\xE7\xF5es",
      "Messages": "Mensagens",
      "Blocked accounts / self-reposts": "Contas bloqueadas / reposts pr\xF3prios",
      "Pending an authenticated fixture; controls stay disabled.": "Aguardando uma captura autenticada; os controles permanecem desativados.",
      "Hide dismissed posts": "Ocultar posts dispensados",
      "Keep posts you hid collapsed so the next post rises to the top.": "Mant\xE9m recolhidos os posts que voc\xEA ocultou, para que o pr\xF3ximo suba ao topo.",
      "Show hide buttons": "Mostrar bot\xF5es de ocultar",
      "Adds a Hide control to every post next to the More menu.": "Adiciona um controle Ocultar a cada post, ao lado do menu Mais.",
      "Routes where hiding and the Hide button apply.": "Rotas onde o ocultamento e o bot\xE3o Ocultar se aplicam.",
      "Maximum remembered posts": "M\xE1ximo de posts lembrados",
      "Oldest entries are dropped once the store passes this size (100-50000).": "As entradas mais antigas s\xE3o descartadas quando o armazenamento passa deste tamanho (100-50000).",
      "Save": "Salvar",
      "Hidden posts stored": "Publica\xE7\xF5es ocultas guardadas",
      "Undo last hide": "Desfazer a \xFAltima oculta\xE7\xE3o",
      "Restores the most recently hidden post.": "Restaura a publica\xE7\xE3o ocultada mais recentemente.",
      "Restore": "Restaurar",
      "Clear hidden posts": "Limpar publica\xE7\xF5es ocultas",
      "Forgets every hidden post and brings them all back.": "Esquece todas as publica\xE7\xF5es ocultas e traz todas de volta.",
      "Show download buttons": "Mostrar bot\xF5es de download",
      "Inject Save and Thumb buttons over tweet photos and video thumbnails.": "Insere bot\xF5es Salvar e Miniatura sobre as fotos e miniaturas de v\xEDdeo.",
      "Prefer original quality": "Preferir qualidade original",
      "Rewrite image URLs to name=orig before downloading.": "Reescreve as URLs de imagem para name=orig antes de baixar.",
      "Filename template": "Modelo de nome de arquivo",
      "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.": "Campos: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.",
      "Duplicate history": "Hist\xF3rico de duplicados",
      "Skip downloads of media you have already saved from this browser.": "Ignora downloads de m\xEDdia que voc\xEA j\xE1 salvou neste navegador.",
      "Sensitive content": "Conte\xFAdo sens\xEDvel",
      "Default (X choice)": "Padr\xE3o (escolha do X)",
      "Always reveal": "Sempre revelar",
      "Blur until hovered": "Desfocar at\xE9 passar o cursor",
      "Always hide": "Sempre ocultar",
      "Media layout": "Layout de m\xEDdia",
      "Default grid": "Grade padr\xE3o",
      "Stacked": "Empilhado",
      "Strict grid": "Grade estrita",
      "Download status": "Estado das transfer\xEAncias",
      "History entries": "Entradas do hist\xF3rico",
      "Clear download history": "Limpar hist\xF3rico de transfer\xEAncias",
      "Reset the local dedup index.": "Reinicia o \xEDndice local de duplicados.",
      "Download all visible media": "Transferir toda a m\xE9dia vis\xEDvel",
      "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.": "Percorre cada publica\xE7\xE3o da p\xE1gina atual e coloca cada foto, v\xEDdeo, GIF e miniatura na fila de transfer\xEAncias existente.",
      "Capture visible tweets": "Capturar posts vis\xEDveis",
      "Accumulate tweets visible on the active page for the next export run.": "Acumula os posts vis\xEDveis na p\xE1gina ativa para a pr\xF3xima exporta\xE7\xE3o.",
      "Export formats": "Formatos de exporta\xE7\xE3o",
      "Comma-separated list. Supported: json, csv, html, markdown, xlsx.": "Lista separada por v\xEDrgulas. Suportados: json, csv, html, markdown, xlsx.",
      "Preserve raw payloads": "Preservar cargas brutas",
      "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.": "Tamb\xE9m guarda as respostas GraphQL brutas que o X envia a esta aba, para que os registros possam ser reprocessados depois. Os tokens de sess\xE3o s\xE3o removidos antes de qualquer grava\xE7\xE3o.",
      "Auto-discover query IDs": "Descobrir IDs de consulta automaticamente",
      "Scan loaded scripts for X GraphQL operation IDs and cache them locally.": "Varre os scripts carregados em busca de IDs de opera\xE7\xF5es GraphQL do X e os guarda localmente.",
      "Save folder hint": "Sugest\xE3o de pasta de destino",
      "Folder name (or path) used as the export ZIP root and download prefix.": "Nome da pasta (ou caminho) usado como raiz do ZIP de exporta\xE7\xE3o e prefixo de download.",
      "Export status": "Estado da exporta\xE7\xE3o",
      "Export visible tweets": "Exportar publica\xE7\xF5es vis\xEDveis",
      "Collect the currently rendered tweets and download a ZIP.": "Re\xFAne as publica\xE7\xF5es vis\xEDveis e transfere um ZIP.",
      "Copy diagnostics": "Copiar diagn\xF3stico",
      "Copy support diagnostics (version, route, recent log).": "Copia o diagn\xF3stico de suporte (vers\xE3o, rota, registo recente).",
      "Download as WARC": "Transferir como WARC",
      "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.": "Empacota os registos capturados num ficheiro WARC ISO-28500 para ferramentas de investiga\xE7\xE3o e preserva\xE7\xE3o.",
      "Copy as Markdown": "Copiar como Markdown",
      "Push a plain Markdown export onto the clipboard.": "Copia uma exporta\xE7\xE3o em Markdown simples para a \xE1rea de transfer\xEAncia.",
      "Save Obsidian Markdown": "Guardar Markdown para Obsidian",
      "Markdown with YAML frontmatter and Aviary tags.": "Markdown com frontmatter YAML e etiquetas do Aviary.",
      "Save Notion Markdown": "Guardar Markdown para Notion",
      "Heading-first Markdown that Notion imports cleanly.": "Markdown baseado em t\xEDtulos que o Notion importa sem problemas.",
      "Save records JSON": "Guardar registos em JSON",
      "Raw ExportRecord[] JSON without ZIP wrapping.": "JSON ExportRecord[] sem compress\xE3o ZIP.",
      "Records per ZIP": "Registos por ZIP",
      "Split a long export across several archives instead of one huge file (25-1000).": "Divide uma exporta\xE7\xE3o longa em v\xE1rios ficheiros em vez de um enorme (25-1000).",
      "Maximum export jobs": "M\xE1ximo de trabalhos de exporta\xE7\xE3o",
      "Keep the newest jobs. Use 0 for unlimited.": "Mant\xE9m os trabalhos mais recentes. Use 0 para ilimitado.",
      "Maximum records per job": "M\xE1ximo de registos por trabalho",
      "Keep the newest records in each job. Use 0 for unlimited.": "Mant\xE9m os registos mais recentes de cada trabalho. Use 0 para ilimitado.",
      "Maximum export age (days)": "Idade m\xE1xima da exporta\xE7\xE3o (dias)",
      "Remove older jobs at boot. Use 0 to disable age-based cleanup.": "Remove os trabalhos antigos no arranque. Use 0 para desativar a limpeza por idade.",
      "Unshorten t.co links": "Expandir links t.co",
      "Replace short `t.co` redirects with the destination from aria-labels and titles.": "Substitui os redirecionamentos curtos `t.co` pelo destino obtido de aria-labels e t\xEDtulos.",
      "Clean tracking from links": "Limpar o rastreio dos liga\xE7\xF5es",
      "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.": "Remove os tokens de partilha e os par\xE2metros de campanha (utm_*, fbclid e os pr\xF3prios t/s do X) das liga\xE7\xF5es na cronologia, para que o que copia seja o endere\xE7o simples.",
      "Account notes": "Notas de contas",
      "Format: handle: note. One per line. Empty notes remove the entry.": "Formato: utilizador: nota. Uma por linha. Notas vazias removem a entrada.",
      "Clear all account notes": "Limpar todas as notas de contas",
      "Drop every persisted note.": "Elimina todas as notas guardadas.",
      "Composer snippets": "Trechos do editor",
      "One snippet per line. Reusable replies / templates (insertion landing in a later release).": "Um trecho por linha. Respostas e modelos reutiliz\xE1veis (a inser\xE7\xE3o chega em uma vers\xE3o futura).",
      "Snapshots stored": "Instant\xE2neos guardados",
      "Capture followers from this view": "Capturar seguidores a partir desta vista",
      "Walks UserCell rows on the current page. Open a /handle/followers view first.": "Percorre as linhas UserCell da p\xE1gina atual. Abra primeiro uma vista /utilizador/followers.",
      "Capture following from this view": "Capturar seguidos a partir desta vista",
      "Walks UserCell rows on the current page. Open a /handle/following view first.": "Percorre as linhas UserCell da p\xE1gina atual. Abra primeiro uma vista /utilizador/following.",
      "Clear all snapshots": "Limpar todos os instant\xE2neos",
      "Drop every stored follower/following snapshot.": "Elimina todos os instant\xE2neos de seguidores e seguidos.",
      "Download Markdown report": "Transferir relat\xF3rio em Markdown",
      "Audit log + snapshot diff + cleanup preview.": "Registo de auditoria, compara\xE7\xE3o de instant\xE2neos e pr\xE9-visualiza\xE7\xE3o de limpeza.",
      "Cleanup review queue": "Fila de revis\xE3o de limpeza",
      "Destructive actions": "A\xE7\xF5es destrutivas",
      "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log.": "O Aviary nunca elimina publica\xE7\xF5es, gostos ou seguimentos. A fila \xE9 uma lista de revis\xE3o; aprovar ou ignorar apenas escreve no registo de auditoria.",
      "Enqueue cleanup preview for review": "Adicionar a pr\xE9-visualiza\xE7\xE3o de limpeza \xE0 fila",
      "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).": "Acrescenta \xE0 fila todos os candidatos n\xE3o protegidos da \xFAltima pr\xE9-visualiza\xE7\xE3o de limpeza (sem a\xE7\xF5es destrutivas).",
      "Clear cleanup queue": "Esvaziar a fila de limpeza",
      "Drop every queued item without touching account data.": "Elimina todos os itens da fila sem tocar nos dados da conta.",
      "Aria2 handoff": "Repasse para o Aria2",
      "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.": "Envia downloads grandes para um endpoint Aria2 JSON-RPC auto-hospedado.",
      "Aria2 endpoint": "Endpoint do Aria2",
      "http://localhost:6800 (no trailing slash needed)": "http://localhost:6800 (sem necessidade de barra final)",
      "Aria2 RPC secret": "Segredo RPC do Aria2",
      "Optional shared secret for token: auth.": "Segredo compartilhado opcional para a autentica\xE7\xE3o token:.",
      "Show": "Mostrar",
      "Test Aria2 connection": "Testar a liga\xE7\xE3o ao Aria2",
      "Sends a trivial JSON-RPC call.": "Envia uma chamada JSON-RPC trivial.",
      "Refresh": "Atualizar",
      "Bluesky crosspost": "Publica\xE7\xE3o cruzada no Bluesky",
      "Post composer text to your Bluesky account on demand.": "Publica o texto do editor na sua conta do Bluesky quando voc\xEA pedir.",
      "Bluesky service URL": "URL do servi\xE7o Bluesky",
      "Default: https://bsky.social": "Padr\xE3o: https://bsky.social",
      "Bluesky handle": "Perfil do Bluesky",
      "Your handle (no @, e.g. you.bsky.social)": "Seu perfil (sem @, ex.: voce.bsky.social)",
      "Bluesky app password": "Senha de aplicativo do Bluesky",
      "App password from your account settings \u2014 never your main password.": "Senha de aplicativo das configura\xE7\xF5es da sua conta \u2014 nunca a sua senha principal.",
      "Mastodon crosspost": "Publica\xE7\xE3o cruzada no Mastodon",
      "Post composer text to your Mastodon account on demand.": "Publica o texto do editor na sua conta do Mastodon quando voc\xEA pedir.",
      "Mastodon instance": "Inst\xE2ncia do Mastodon",
      "https://mastodon.social": "https://mastodon.social",
      "Mastodon access token": "Token de acesso do Mastodon",
      "Bearer token with write:statuses scope.": "Token Bearer com o escopo write:statuses.",
      "Attach last download": "Anexar o \xFAltimo download",
      "Upload the last successful Aviary media download with the first post in an explicit crosspost.": "Anexa o \xFAltimo download bem-sucedido do Aviary ao primeiro post de uma publica\xE7\xE3o cruzada expl\xEDcita.",
      "Crosspost composer \u2192 Bluesky": "Publicar o editor no Bluesky",
      "Uses the current composer text.": "Usa o texto atual do editor.",
      "Crosspost composer \u2192 Mastodon": "Publicar o editor no Mastodon",
      "AI provider runs": "Execu\xE7\xF5es do provedor de IA",
      "Let the AI command menu POST prompts to your configured provider.": "Permite que o menu de comandos de IA envie os prompts ao provedor configurado.",
      "AI provider": "Provedor de IA",
      "Anthropic Messages API": "Anthropic Messages API",
      "OpenAI Chat Completions": "OpenAI Chat Completions",
      "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)": "Compat\xEDvel com OpenAI (LocalAI, proxy do Ollama, \u2026)",
      "AI endpoint (optional)": "Endpoint de IA (opcional)",
      "Override the default endpoint for the chosen provider.": "Substitui o endpoint padr\xE3o do provedor escolhido.",
      "AI model": "Modelo de IA",
      "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b": "ex.: claude-sonnet-4-6, gpt-4o, llama3.1:8b",
      "AI API key": "Chave de API de IA",
      "Stored locally only. Aviary never sends this except as the auth header to your provider.": "Guardada apenas localmente. O Aviary s\xF3 a envia como cabe\xE7alho de autentica\xE7\xE3o para o seu provedor.",
      "Semantic search": "Busca sem\xE2ntica",
      "Embed CheckpointStore records via your provider for similarity search.": "Gera embeddings dos registros do CheckpointStore pelo seu provedor para busca por similaridade.",
      "Embedding endpoint": "Endpoint de embeddings",
      "POST endpoint that returns {data: [{embedding: number[]}]}": "Endpoint POST que retorna {data: [{embedding: number[]}]}",
      "Embedding model": "Modelo de embeddings",
      "e.g. text-embedding-3-small": "ex.: text-embedding-3-small",
      "Embedding API key": "Chave de API de embeddings",
      "Stored locally; used only as the Authorization header.": "Guardada localmente; usada apenas como cabe\xE7alho Authorization.",
      "Auto-embed every export": "Gerar embeddings a cada exporta\xE7\xE3o",
      "After each export run, kick the embedding job in the background. Off by default.": "Ap\xF3s cada exporta\xE7\xE3o, dispara o trabalho de embeddings em segundo plano. Desligado por padr\xE3o.",
      "Rebuild semantic index": "Reconstruir o \xEDndice sem\xE2ntico",
      "Embed every captured record. Re-running is cheap because cached entries are skipped.": "Gera embeddings de cada registo capturado. Repetir \xE9 barato porque as entradas em cache s\xE3o ignoradas.",
      "Clear semantic index": "Limpar o \xEDndice sem\xE2ntico",
      "Forget every embedded record.": "Esquece todos os registos com embeddings.",
      "Integration status": "Estado das integra\xE7\xF5es",
      "Export settings": "Exportar defini\xE7\xF5es",
      "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.": "Transfere as suas prefer\xEAncias em JSON. As chaves de API e as palavras-passe s\xE3o substitu\xEDdas por um marcador, por isso o ficheiro \xE9 seguro de partilhar; ao import\xE1-lo aqui, as credenciais j\xE1 guardadas nesta m\xE1quina s\xE3o mantidas.",
      "Import settings (JSON)": "Importar defini\xE7\xF5es (JSON)",
      "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.": "Cole um ficheiro de defini\xE7\xF5es exportado do Aviary e escolha Importar. As credenciais ocultadas mant\xEAm os valores j\xE1 guardados aqui.",
      "Import": "Importar",
      "Keep a local action log": "Manter um registo local de a\xE7\xF5es",
      "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.": "Regista transfer\xEAncias, exporta\xE7\xF5es e altera\xE7\xF5es de defini\xE7\xF5es neste dispositivo para poder rever o que o Aviary fez. Nada \xE9 enviado para lado nenhum. Ao desativar, deixam de ser criadas novas entradas; as existentes permanecem at\xE9 as limpar.",
      "Audit entries": "Entradas de auditoria",
      "Clear audit log": "Limpar o registo de auditoria",
      "Drop the local action log.": "Elimina o registo local de a\xE7\xF5es.",
      "Storage": "Armazenamento",
      "Settings stay in this browser.": "As configura\xE7\xF5es ficam neste navegador.",
      "Local-only mode": "Modo apenas local",
      "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.": "Bloqueia todos os pedidos de sa\xEDda, incluindo as integra\xE7\xF5es que configurou. Ativado por predefini\xE7\xE3o; ativar uma integra\xE7\xE3o \xE9 o que o desliga.",
      "Some changes could not be saved \u2014 the browser store may be full.": "N\xE3o foi poss\xEDvel gravar algumas altera\xE7\xF5es; o armazenamento do navegador pode estar cheio.",
      "Saving": "Grava\xE7\xE3o",
      "Telemetry": "Telemetria",
      "Disabled": "Desativada",
      "Panel language": "Idioma do painel",
      "Selector health": "Sa\xFAde dos seletores",
      "Working \u2014 every change has been written.": "Tudo certo: todas as altera\xE7\xF5es foram gravadas.",
      "Monitoring active": "Monitoramento ativo",
      "Preset packs unavailable in this build.": "Pacotes de predefini\xE7\xF5es indispon\xEDveis nesta compila\xE7\xE3o.",
      "Hidden post store unavailable in this build.": "Armazenamento de posts ocultos indispon\xEDvel nesta compila\xE7\xE3o.",
      "Cancel": "Cancelar"
    },
    fr: {
      "Aviary": "Aviary",
      "Local controls for a quieter X.": "Des commandes locales pour un X plus calme.",
      "Close": "Fermer",
      "Search settings": "Rechercher un r\xE9glage",
      "Saved locally": "Enregistr\xE9 localement",
      "Settings sections": "Sections des r\xE9glages",
      "Start": "D\xE9marrer",
      "Presets": "Pr\xE9r\xE9glages",
      "Reading": "Lecture",
      "Appearance": "Apparence",
      "Layout": "Mise en page",
      "Filtering": "Filtres",
      "Hidden posts": "Publications masqu\xE9es",
      "Data": "Donn\xE9es",
      "Media": "M\xE9dias",
      "Export": "Export",
      "Library": "Biblioth\xE8que",
      "Snapshots & Archive": "Instantan\xE9s et archive",
      "Advanced": "Avanc\xE9",
      "Integrations": "Int\xE9grations",
      "Backup & Audit": "Sauvegarde et audit",
      "Trust": "Confidentialit\xE9",
      "Apply": "Appliquer",
      "Locale": "Langue",
      "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.": "Traduit le panneau et d\xE9finit le sens de lecture : de droite \xE0 gauche pour l'arabe et l'h\xE9breu. Confiance indique la part de la langue choisie qui est renseign\xE9e ; ce qui manque reste en anglais.",
      "Theme value is not supported.": "Ce th\xE8me n'est pas pris en charge.",
      "Theme updated": "Th\xE8me mis \xE0 jour",
      "Density updated": "Densit\xE9 mise \xE0 jour",
      "Contrast preference saved": "Pr\xE9f\xE9rence de contraste enregistr\xE9e",
      "Motion preference saved": "Pr\xE9f\xE9rence d'animation enregistr\xE9e",
      "Sidebar preference saved": "Pr\xE9f\xE9rence de barre lat\xE9rale enregistr\xE9e",
      "Trend preference saved": "Pr\xE9f\xE9rence de tendances enregistr\xE9e",
      "Grok preference saved": "Pr\xE9f\xE9rence Grok enregistr\xE9e",
      "Could not apply preset.": "Impossible d'appliquer le pr\xE9r\xE9glage.",
      "Snapshot failed.": "L'instantan\xE9 a \xE9chou\xE9.",
      "Snapshots cleared": "Instantan\xE9s effac\xE9s",
      "Could not clear snapshots.": "Impossible d'effacer les instantan\xE9s.",
      "Reading archive \u2014 large files take a moment\u2026": "Lecture de l'archive : les gros fichiers prennent un instant\u2026",
      "Archive import failed.": "\xC9chec de l'import de l'archive.",
      "Building report\u2026": "G\xE9n\xE9ration du rapport\u2026",
      "Report downloaded.": "Rapport t\xE9l\xE9charg\xE9.",
      "Could not build report.": "Impossible de g\xE9n\xE9rer le rapport.",
      "Building cleanup preview\u2026": "G\xE9n\xE9ration de l'aper\xE7u du nettoyage\u2026",
      "Could not enqueue cleanup.": "Impossible d'ajouter le nettoyage \xE0 la file.",
      "Cleanup queue cleared": "File de nettoyage vid\xE9e",
      "Could not clear queue.": "Impossible de vider la file.",
      "Aria2 endpoint saved": "Point de terminaison Aria2 enregistr\xE9",
      "Aria2 secret saved": "Secret Aria2 enregistr\xE9",
      "Aria2 sweep failed.": "\xC9chec de l'interrogation d'Aria2.",
      "Bluesky service saved": "Service Bluesky enregistr\xE9",
      "Bluesky handle saved": "Identifiant Bluesky enregistr\xE9",
      "Bluesky app password saved": "Mot de passe d'application Bluesky enregistr\xE9",
      "Mastodon instance saved": "Instance Mastodon enregistr\xE9e",
      "Mastodon token saved": "Jeton Mastodon enregistr\xE9",
      "AI endpoint saved": "Point de terminaison IA enregistr\xE9",
      "AI model saved": "Mod\xE8le d'IA enregistr\xE9",
      "AI API key saved": "Cl\xE9 d'API d'IA enregistr\xE9e",
      "Embedding endpoint saved": "Point de terminaison d'embeddings enregistr\xE9",
      "Embedding model saved": "Mod\xE8le d'embeddings enregistr\xE9",
      "Embedding API key saved": "Cl\xE9 d'API d'embeddings enregistr\xE9e",
      "Rebuilding semantic index\u2026": "Reconstruction de l'index s\xE9mantique\u2026",
      "Embedding failed.": "Le calcul des embeddings a \xE9chou\xE9.",
      "Semantic index cleared": "Index s\xE9mantique effac\xE9",
      "Account notes cleared": "Notes de comptes effac\xE9es",
      "Could not clear notes.": "Impossible d'effacer les notes.",
      "Settings exported.": "R\xE9glages export\xE9s.",
      "Could not export settings.": "Impossible d'exporter les r\xE9glages.",
      "Could not import settings.": "Impossible d'importer les r\xE9glages.",
      "Audit log cleared": "Journal d'audit effac\xE9",
      "Could not clear audit log.": "Impossible d'effacer le journal d'audit.",
      "Raw payload preference saved": "Pr\xE9f\xE9rence de donn\xE9es brutes enregistr\xE9e",
      "Query discovery preference saved": "Pr\xE9f\xE9rence de d\xE9couverte des requ\xEAtes enregistr\xE9e",
      "Save folder hint saved": "Dossier d'enregistrement enregistr\xE9",
      "Collecting visible posts\u2026": "Collecte des publications visibles\u2026",
      "Export failed. See diagnostics.": "L'export a \xE9chou\xE9. Consultez le diagnostic.",
      "Diagnostics copied to clipboard.": "Diagnostic copi\xE9 dans le presse-papiers.",
      "Could not copy diagnostics.": "Impossible de copier le diagnostic.",
      "Building WARC archive\u2026": "G\xE9n\xE9ration de l'archive WARC\u2026",
      "WARC export failed.": "\xC9chec de l'export WARC.",
      "External export failed.": "L'export externe a \xE9chou\xE9.",
      "Records per ZIP saved": "Enregistrements par ZIP enregistr\xE9s",
      "Export job retention saved": "R\xE9tention des t\xE2ches enregistr\xE9e",
      "Record retention saved": "R\xE9tention des enregistrements enregistr\xE9e",
      "Age-based retention saved": "R\xE9tention par anciennet\xE9 enregistr\xE9e",
      "Original quality preference saved": "Pr\xE9f\xE9rence de qualit\xE9 d'origine enregistr\xE9e",
      "Filename template saved": "Mod\xE8le de nom de fichier enregistr\xE9",
      "Sensitive content preference saved": "Pr\xE9f\xE9rence de contenu sensible enregistr\xE9e",
      "Media layout saved": "Disposition des m\xE9dias enregistr\xE9e",
      "History cleared": "Historique effac\xE9",
      "Could not clear history.": "Impossible d'effacer l'historique.",
      "Downloading media from this view\u2026": "T\xE9l\xE9chargement des m\xE9dias de cette vue\u2026",
      "Batch download failed.": "Le t\xE9l\xE9chargement par lot a \xE9chou\xE9.",
      "Premium filter saved": "Filtre Premium enregistr\xE9",
      "Could not undo the last hide.": "Impossible d'annuler le dernier masquage.",
      "Could not restore the post.": "Impossible de restaurer la publication.",
      "Could not clear hidden posts.": "Impossible d'effacer les publications masqu\xE9es.",
      "Saving...": "Enregistrement...",
      "Could not save settings. Try again.": "Impossible d'enregistrer les r\xE9glages. R\xE9essayez.",
      "Theme": "Th\xE8me",
      "Dim": "Sombre",
      "Lights out": "Extinction des feux",
      "Graphite": "Graphite",
      "Plum": "Prune",
      "Midnight": "Minuit",
      "Dense mode": "Mode dense",
      "Tighten timeline spacing for scanning.": "Resserre l'espacement du fil pour parcourir plus vite.",
      "Hide engagement counts": "Masquer les compteurs d'engagement",
      "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.": "Masque le nombre de r\xE9ponses, de republications et de j'aime. Les boutons fonctionnent toujours et les lecteurs d'\xE9cran annoncent encore les totaux.",
      "Hide row borders": "Masquer les bordures de ligne",
      "Remove the 1px divider under each timeline post and the primary column's side rules.": "Supprime le trait de 1 px sous chaque publication ainsi que les filets lat\xE9raux de la colonne principale.",
      "High contrast": "Contraste \xE9lev\xE9",
      "Use stronger borders and text contrast.": "Utilise des bordures et un contraste de texte plus marqu\xE9s.",
      "Reduced motion": "Mouvement r\xE9duit",
      "Follow system setting": "Suivre le r\xE9glage du syst\xE8me",
      "Always reduce": "Toujours r\xE9duire",
      "Never reduce": "Ne jamais r\xE9duire",
      "Hide right sidebar": "Masquer la colonne de droite",
      "Reduce trends, recommendations, and footer noise.": "R\xE9duit le bruit des tendances, des recommandations et du pied de page.",
      "Hide trends": "Masquer les tendances",
      "Remove trending topics and news modules.": "Supprime les sujets tendance et les modules d'actualit\xE9.",
      "Hide Grok surfaces": "Masquer les surfaces Grok",
      "Remove Grok drawer and composer buttons where detected.": "Supprime le panneau Grok et ses boutons dans le r\xE9dacteur lorsqu'ils sont d\xE9tect\xE9s.",
      "Writer mode": "Mode \xE9criture",
      "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.": "Tant que le focus est dans le r\xE9dacteur, la colonne lat\xE9rale et le fil s'estompent. Tout revient d\xE8s que vous cliquez ailleurs.",
      "Enable filters": "Activer les filtres",
      "Master switch for keyword, regex, premium, and media filters.": "Interrupteur g\xE9n\xE9ral des filtres mots-cl\xE9s, regex, Premium et m\xE9dias.",
      "Keyword rules": "R\xE8gles de mots-cl\xE9s",
      "One keyword or phrase per line. Case-insensitive substring match.": "Un mot-cl\xE9 ou une expression par ligne. Correspondance partielle, insensible \xE0 la casse.",
      "Save list": "Enregistrer la liste",
      "Regex rules": "R\xE8gles d'expressions r\xE9guli\xE8res",
      "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).": "Un motif par ligne. Utilisez /motif/flags ou un motif simple (insensible \xE0 la casse).",
      "Whitelist handles": "Comptes sur liste blanche",
      "Handles (one per line, no @) that are never filtered.": "Comptes (un par ligne, sans @) qui ne sont jamais filtr\xE9s.",
      "Premium / verified posts": "Publications Premium / certifi\xE9es",
      "Off": "D\xE9sactiv\xE9",
      "Hide": "Masquer",
      "Hide posts with photos": "Masquer les publications avec photos",
      "Filter posts containing photos.": "Filtre les publications contenant des photos.",
      "Hide posts with videos": "Masquer les publications avec vid\xE9os",
      "Filter posts containing videos.": "Filtre les publications contenant des vid\xE9os.",
      "Hide posts with gifs": "Masquer les publications avec GIF",
      "Filter posts containing gifs.": "Filtre les publications contenant des GIF.",
      "Active on": "Actif sur",
      "Routes where filters run.": "Routes o\xF9 les filtres s'appliquent.",
      "Home": "Accueil",
      "Status": "Publication",
      "Profile": "Profil",
      "Search": "Recherche",
      "Notifications": "Notifications",
      "Messages": "Messages",
      "Blocked accounts / self-reposts": "Comptes bloqu\xE9s / republications de soi",
      "Pending an authenticated fixture; controls stay disabled.": "En attente d'une capture authentifi\xE9e ; les contr\xF4les restent d\xE9sactiv\xE9s.",
      "Hide dismissed posts": "Masquer les publications \xE9cart\xE9es",
      "Keep posts you hid collapsed so the next post rises to the top.": "Garde repli\xE9es les publications que vous avez masqu\xE9es, pour que la suivante remonte.",
      "Show hide buttons": "Afficher les boutons Masquer",
      "Adds a Hide control to every post next to the More menu.": "Ajoute un bouton Masquer \xE0 chaque publication, \xE0 c\xF4t\xE9 du menu Plus.",
      "Routes where hiding and the Hide button apply.": "Routes o\xF9 le masquage et le bouton Masquer s'appliquent.",
      "Maximum remembered posts": "Nombre maximal de publications m\xE9moris\xE9es",
      "Oldest entries are dropped once the store passes this size (100-50000).": "Les entr\xE9es les plus anciennes sont supprim\xE9es d\xE8s que le stock d\xE9passe cette taille (100-50000).",
      "Save": "Enregistrer",
      "Hidden posts stored": "Publications masqu\xE9es enregistr\xE9es",
      "Undo last hide": "Annuler le dernier masquage",
      "Restores the most recently hidden post.": "Restaure la publication masqu\xE9e la plus r\xE9cente.",
      "Restore": "Restaurer",
      "Clear hidden posts": "Effacer les publications masqu\xE9es",
      "Forgets every hidden post and brings them all back.": "Oublie toutes les publications masqu\xE9es et les r\xE9tablit.",
      "Show download buttons": "Afficher les boutons de t\xE9l\xE9chargement",
      "Inject Save and Thumb buttons over tweet photos and video thumbnails.": "Ajoute des boutons Enregistrer et Vignette sur les photos et les vignettes vid\xE9o.",
      "Prefer original quality": "Pr\xE9f\xE9rer la qualit\xE9 d'origine",
      "Rewrite image URLs to name=orig before downloading.": "R\xE9\xE9crit les URL d'image en name=orig avant le t\xE9l\xE9chargement.",
      "Filename template": "Mod\xE8le de nom de fichier",
      "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.": "Champs : {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.",
      "Duplicate history": "Historique des doublons",
      "Skip downloads of media you have already saved from this browser.": "Ignore les t\xE9l\xE9chargements de m\xE9dias d\xE9j\xE0 enregistr\xE9s depuis ce navigateur.",
      "Sensitive content": "Contenu sensible",
      "Default (X choice)": "Par d\xE9faut (choix de X)",
      "Always reveal": "Toujours afficher",
      "Blur until hovered": "Flouter jusqu'au survol",
      "Always hide": "Toujours masquer",
      "Media layout": "Disposition des m\xE9dias",
      "Default grid": "Grille par d\xE9faut",
      "Stacked": "Empil\xE9",
      "Strict grid": "Grille stricte",
      "Download status": "\xC9tat des t\xE9l\xE9chargements",
      "History entries": "Entr\xE9es de l'historique",
      "Clear download history": "Effacer l'historique des t\xE9l\xE9chargements",
      "Reset the local dedup index.": "R\xE9initialise l'index local de doublons.",
      "Download all visible media": "T\xE9l\xE9charger tous les m\xE9dias visibles",
      "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.": "Parcourt chaque publication affich\xE9e sur la page et place chaque photo, vid\xE9o, GIF et miniature dans la file de t\xE9l\xE9chargement existante.",
      "Capture visible tweets": "Capturer les publications visibles",
      "Accumulate tweets visible on the active page for the next export run.": "Accumule les publications visibles sur la page active pour le prochain export.",
      "Export formats": "Formats d'export",
      "Comma-separated list. Supported: json, csv, html, markdown, xlsx.": "Liste s\xE9par\xE9e par des virgules. Pris en charge : json, csv, html, markdown, xlsx.",
      "Preserve raw payloads": "Conserver les charges utiles brutes",
      "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.": "Conserve aussi les r\xE9ponses GraphQL brutes que X envoie \xE0 cet onglet, pour pouvoir r\xE9analyser les enregistrements plus tard. Les jetons de session sont retir\xE9s avant toute \xE9criture.",
      "Auto-discover query IDs": "D\xE9tecter automatiquement les ID de requ\xEAte",
      "Scan loaded scripts for X GraphQL operation IDs and cache them locally.": "Analyse les scripts charg\xE9s pour y trouver les ID d'op\xE9rations GraphQL de X et les met en cache localement.",
      "Save folder hint": "Dossier d'enregistrement sugg\xE9r\xE9",
      "Folder name (or path) used as the export ZIP root and download prefix.": "Nom de dossier (ou chemin) utilis\xE9 comme racine du ZIP d'export et pr\xE9fixe de t\xE9l\xE9chargement.",
      "Export status": "\xC9tat de l'export",
      "Export visible tweets": "Exporter les publications visibles",
      "Collect the currently rendered tweets and download a ZIP.": "Rassemble les publications affich\xE9es et t\xE9l\xE9charge une archive ZIP.",
      "Copy diagnostics": "Copier le diagnostic",
      "Copy support diagnostics (version, route, recent log).": "Copie le diagnostic d'assistance (version, route, journal r\xE9cent).",
      "Download as WARC": "T\xE9l\xE9charger au format WARC",
      "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.": "Encapsule les enregistrements captur\xE9s dans un fichier WARC ISO-28500 pour les outils de recherche et de pr\xE9servation.",
      "Copy as Markdown": "Copier en Markdown",
      "Push a plain Markdown export onto the clipboard.": "Copie un export Markdown simple dans le presse-papiers.",
      "Save Obsidian Markdown": "Enregistrer le Markdown Obsidian",
      "Markdown with YAML frontmatter and Aviary tags.": "Markdown avec en-t\xEAte YAML et \xE9tiquettes Aviary.",
      "Save Notion Markdown": "Enregistrer le Markdown Notion",
      "Heading-first Markdown that Notion imports cleanly.": "Markdown structur\xE9 par titres, import\xE9 proprement par Notion.",
      "Save records JSON": "Enregistrer les enregistrements en JSON",
      "Raw ExportRecord[] JSON without ZIP wrapping.": "JSON ExportRecord[] brut, sans archive ZIP.",
      "Records per ZIP": "Enregistrements par ZIP",
      "Split a long export across several archives instead of one huge file (25-1000).": "R\xE9partit un export volumineux sur plusieurs archives au lieu d'un seul \xE9norme fichier (25-1000).",
      "Maximum export jobs": "Nombre maximal de t\xE2ches d'export",
      "Keep the newest jobs. Use 0 for unlimited.": "Conserve les t\xE2ches les plus r\xE9centes. 0 pour illimit\xE9.",
      "Maximum records per job": "Nombre maximal d'enregistrements par t\xE2che",
      "Keep the newest records in each job. Use 0 for unlimited.": "Conserve les enregistrements les plus r\xE9cents de chaque t\xE2che. 0 pour illimit\xE9.",
      "Maximum export age (days)": "Anciennet\xE9 maximale des exports (jours)",
      "Remove older jobs at boot. Use 0 to disable age-based cleanup.": "Supprime les t\xE2ches anciennes au d\xE9marrage. 0 pour d\xE9sactiver le nettoyage par anciennet\xE9.",
      "Unshorten t.co links": "D\xE9velopper les liens t.co",
      "Replace short `t.co` redirects with the destination from aria-labels and titles.": "Remplace les redirections courtes `t.co` par la destination lue dans les aria-labels et les titres.",
      "Clean tracking from links": "Nettoyer le suivi des liens",
      "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.": "Supprime les jetons de partage et les param\xE8tres de campagne (utm_*, fbclid et les t/s propres \xE0 X) des liens du fil, pour que ce que vous copiez soit l'adresse brute.",
      "Account notes": "Notes de comptes",
      "Format: handle: note. One per line. Empty notes remove the entry.": "Format : identifiant : note. Une par ligne. Une note vide supprime l'entr\xE9e.",
      "Clear all account notes": "Effacer toutes les notes de comptes",
      "Drop every persisted note.": "Supprime toutes les notes enregistr\xE9es.",
      "Composer snippets": "Extraits du r\xE9dacteur",
      "One snippet per line. Reusable replies / templates (insertion landing in a later release).": "Un extrait par ligne. R\xE9ponses et mod\xE8les r\xE9utilisables (l'insertion arrive dans une version ult\xE9rieure).",
      "Snapshots stored": "Instantan\xE9s enregistr\xE9s",
      "Capture followers from this view": "Capturer les abonn\xE9s depuis cette vue",
      "Walks UserCell rows on the current page. Open a /handle/followers view first.": "Parcourt les lignes UserCell de la page actuelle. Ouvrez d'abord une vue /identifiant/followers.",
      "Capture following from this view": "Capturer les abonnements depuis cette vue",
      "Walks UserCell rows on the current page. Open a /handle/following view first.": "Parcourt les lignes UserCell de la page actuelle. Ouvrez d'abord une vue /identifiant/following.",
      "Clear all snapshots": "Effacer tous les instantan\xE9s",
      "Drop every stored follower/following snapshot.": "Supprime tous les instantan\xE9s d'abonn\xE9s et d'abonnements.",
      "Download Markdown report": "T\xE9l\xE9charger le rapport Markdown",
      "Audit log + snapshot diff + cleanup preview.": "Journal d'audit, comparaison d'instantan\xE9s et aper\xE7u du nettoyage.",
      "Cleanup review queue": "File de revue du nettoyage",
      "Destructive actions": "Actions destructrices",
      "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log.": "Aviary ne supprime jamais de publications, de mentions J'aime ni d'abonnements. La file est une liste de revue ; approuver ou ignorer n'\xE9crit que dans le journal d'audit.",
      "Enqueue cleanup preview for review": "Ajouter l'aper\xE7u du nettoyage \xE0 la file",
      "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).": "Ajoute \xE0 la file tous les candidats non prot\xE9g\xE9s du dernier aper\xE7u de nettoyage (aucune action destructrice).",
      "Clear cleanup queue": "Vider la file de nettoyage",
      "Drop every queued item without touching account data.": "Supprime tous les \xE9l\xE9ments de la file sans toucher aux donn\xE9es du compte.",
      "Aria2 handoff": "Transfert vers Aria2",
      "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.": "Envoie les t\xE9l\xE9chargements volumineux vers un point de terminaison Aria2 JSON-RPC auto-h\xE9berg\xE9.",
      "Aria2 endpoint": "Point de terminaison Aria2",
      "http://localhost:6800 (no trailing slash needed)": "http://localhost:6800 (barre finale inutile)",
      "Aria2 RPC secret": "Secret RPC Aria2",
      "Optional shared secret for token: auth.": "Secret partag\xE9 facultatif pour l'authentification token:.",
      "Show": "Afficher",
      "Test Aria2 connection": "Tester la connexion Aria2",
      "Sends a trivial JSON-RPC call.": "Envoie un appel JSON-RPC trivial.",
      "Refresh": "Actualiser",
      "Bluesky crosspost": "Republication vers Bluesky",
      "Post composer text to your Bluesky account on demand.": "Publie le texte du r\xE9dacteur sur votre compte Bluesky \xE0 la demande.",
      "Bluesky service URL": "URL du service Bluesky",
      "Default: https://bsky.social": "Par d\xE9faut : https://bsky.social",
      "Bluesky handle": "Compte Bluesky",
      "Your handle (no @, e.g. you.bsky.social)": "Votre compte (sans @, p. ex. vous.bsky.social)",
      "Bluesky app password": "Mot de passe d'application Bluesky",
      "App password from your account settings \u2014 never your main password.": "Mot de passe d'application issu des r\xE9glages de votre compte \u2014 jamais votre mot de passe principal.",
      "Mastodon crosspost": "Republication vers Mastodon",
      "Post composer text to your Mastodon account on demand.": "Publie le texte du r\xE9dacteur sur votre compte Mastodon \xE0 la demande.",
      "Mastodon instance": "Instance Mastodon",
      "https://mastodon.social": "https://mastodon.social",
      "Mastodon access token": "Jeton d'acc\xE8s Mastodon",
      "Bearer token with write:statuses scope.": "Jeton Bearer avec la port\xE9e write:statuses.",
      "Attach last download": "Joindre le dernier t\xE9l\xE9chargement",
      "Upload the last successful Aviary media download with the first post in an explicit crosspost.": "Joint le dernier t\xE9l\xE9chargement Aviary r\xE9ussi \xE0 la premi\xE8re publication d'une republication explicite.",
      "Crosspost composer \u2192 Bluesky": "Publier le brouillon sur Bluesky",
      "Uses the current composer text.": "Utilise le texte actuel du r\xE9dacteur.",
      "Crosspost composer \u2192 Mastodon": "Publier le brouillon sur Mastodon",
      "AI provider runs": "Ex\xE9cutions du fournisseur d'IA",
      "Let the AI command menu POST prompts to your configured provider.": "Autorise le menu de commandes IA \xE0 envoyer les invites \xE0 votre fournisseur.",
      "AI provider": "Fournisseur d'IA",
      "Anthropic Messages API": "Anthropic Messages API",
      "OpenAI Chat Completions": "OpenAI Chat Completions",
      "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)": "Compatible OpenAI (LocalAI, proxy Ollama, \u2026)",
      "AI endpoint (optional)": "Point de terminaison IA (facultatif)",
      "Override the default endpoint for the chosen provider.": "Remplace le point de terminaison par d\xE9faut du fournisseur choisi.",
      "AI model": "Mod\xE8le d'IA",
      "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b": "p. ex. claude-sonnet-4-6, gpt-4o, llama3.1:8b",
      "AI API key": "Cl\xE9 d'API d'IA",
      "Stored locally only. Aviary never sends this except as the auth header to your provider.": "Stock\xE9e en local uniquement. Aviary ne l'envoie que comme en-t\xEAte d'authentification vers votre fournisseur.",
      "Semantic search": "Recherche s\xE9mantique",
      "Embed CheckpointStore records via your provider for similarity search.": "Indexe les enregistrements du CheckpointStore via votre fournisseur pour la recherche par similarit\xE9.",
      "Embedding endpoint": "Point de terminaison des plongements",
      "POST endpoint that returns {data: [{embedding: number[]}]}": "Point de terminaison POST renvoyant {data: [{embedding: number[]}]}",
      "Embedding model": "Mod\xE8le de plongements",
      "e.g. text-embedding-3-small": "p. ex. text-embedding-3-small",
      "Embedding API key": "Cl\xE9 d'API des plongements",
      "Stored locally; used only as the Authorization header.": "Stock\xE9e en local ; utilis\xE9e uniquement comme en-t\xEAte Authorization.",
      "Auto-embed every export": "Indexer automatiquement chaque export",
      "After each export run, kick the embedding job in the background. Off by default.": "Apr\xE8s chaque export, lance la t\xE2che d'indexation en arri\xE8re-plan. D\xE9sactiv\xE9 par d\xE9faut.",
      "Rebuild semantic index": "Reconstruire l'index s\xE9mantique",
      "Embed every captured record. Re-running is cheap because cached entries are skipped.": "Calcule les embeddings de chaque enregistrement captur\xE9. Relancer co\xFBte peu car les entr\xE9es en cache sont ignor\xE9es.",
      "Clear semantic index": "Effacer l'index s\xE9mantique",
      "Forget every embedded record.": "Oublie tous les enregistrements vectoris\xE9s.",
      "Integration status": "\xC9tat des int\xE9grations",
      "Export settings": "Exporter les r\xE9glages",
      "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.": "T\xE9l\xE9charge vos pr\xE9f\xE9rences en JSON. Les cl\xE9s d'API et les mots de passe sont remplac\xE9s par un espace r\xE9serv\xE9, le fichier est donc s\xFBr \xE0 partager ; l'importer ici conserve les identifiants d\xE9j\xE0 enregistr\xE9s sur cette machine.",
      "Import settings (JSON)": "Importer des r\xE9glages (JSON)",
      "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.": "Collez un fichier de r\xE9glages export\xE9 depuis Aviary, puis choisissez Importer. Les identifiants masqu\xE9s conservent les valeurs d\xE9j\xE0 enregistr\xE9es ici.",
      "Import": "Importer",
      "Keep a local action log": "Conserver un journal local des actions",
      "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.": "Enregistre les t\xE9l\xE9chargements, les exports et les changements de r\xE9glages sur cet appareil afin que vous puissiez v\xE9rifier ce qu'Aviary a fait. Rien n'est envoy\xE9 nulle part. D\xE9sactiver cette option arr\xEAte imm\xE9diatement les nouvelles entr\xE9es ; les existantes restent jusqu'\xE0 ce que vous les effaciez.",
      "Audit entries": "Entr\xE9es d'audit",
      "Clear audit log": "Effacer le journal d'audit",
      "Drop the local action log.": "Supprime le journal local des actions.",
      "Storage": "Stockage",
      "Settings stay in this browser.": "Les r\xE9glages restent dans ce navigateur.",
      "Local-only mode": "Mode local uniquement",
      "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.": "Bloque toutes les requ\xEAtes sortantes, y compris les int\xE9grations que vous avez configur\xE9es. Activ\xE9 par d\xE9faut ; activer une int\xE9gration est ce qui le d\xE9sactive.",
      "Some changes could not be saved \u2014 the browser store may be full.": "Certaines modifications n'ont pas pu \xEAtre enregistr\xE9es ; le stockage du navigateur est peut-\xEAtre plein.",
      "Saving": "Enregistrement",
      "Telemetry": "T\xE9l\xE9m\xE9trie",
      "Disabled": "D\xE9sactiv\xE9e",
      "Panel language": "Langue du panneau",
      "Selector health": "\xC9tat des s\xE9lecteurs",
      "Working \u2014 every change has been written.": "Tout va bien : chaque modification a \xE9t\xE9 enregistr\xE9e.",
      "Monitoring active": "Surveillance active",
      "Preset packs unavailable in this build.": "Packs de pr\xE9r\xE9glages indisponibles dans cette version.",
      "Hidden post store unavailable in this build.": "Stock des publications masqu\xE9es indisponible dans cette version.",
      "Cancel": "Annuler"
    },
    de: {
      "Aviary": "Aviary",
      "Local controls for a quieter X.": "Lokale Steuerung f\xFCr ein ruhigeres X.",
      "Close": "Schlie\xDFen",
      "Search settings": "Einstellungen durchsuchen",
      "Saved locally": "Lokal gespeichert",
      "Settings sections": "Einstellungsbereiche",
      "Start": "Start",
      "Presets": "Voreinstellungen",
      "Reading": "Lesen",
      "Appearance": "Darstellung",
      "Layout": "Layout",
      "Filtering": "Filter",
      "Hidden posts": "Ausgeblendete Beitr\xE4ge",
      "Data": "Daten",
      "Media": "Medien",
      "Export": "Export",
      "Library": "Bibliothek",
      "Snapshots & Archive": "Momentaufnahmen & Archiv",
      "Advanced": "Erweitert",
      "Integrations": "Integrationen",
      "Backup & Audit": "Sicherung & Audit",
      "Trust": "Datenschutz",
      "Apply": "Anwenden",
      "Locale": "Sprache",
      "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.": "\xDCbersetzt das Panel und legt die Leserichtung fest \u2013 rechts nach links f\xFCr Arabisch und Hebr\xE4isch. Unter Vertrauen steht, wie vollst\xE4ndig die gew\xE4hlte Sprache ist; Fehlendes bleibt Englisch.",
      "Theme value is not supported.": "Dieses Design wird nicht unterst\xFCtzt.",
      "Theme updated": "Design aktualisiert",
      "Density updated": "Dichte aktualisiert",
      "Contrast preference saved": "Kontrast-Einstellung gespeichert",
      "Motion preference saved": "Bewegungs-Einstellung gespeichert",
      "Sidebar preference saved": "Seitenleisten-Einstellung gespeichert",
      "Trend preference saved": "Trend-Einstellung gespeichert",
      "Grok preference saved": "Grok-Einstellung gespeichert",
      "Could not apply preset.": "Voreinstellung konnte nicht angewendet werden.",
      "Snapshot failed.": "Momentaufnahme fehlgeschlagen.",
      "Snapshots cleared": "Momentaufnahmen gel\xF6scht",
      "Could not clear snapshots.": "Momentaufnahmen konnten nicht gel\xF6scht werden.",
      "Reading archive \u2014 large files take a moment\u2026": "Archiv wird gelesen \u2013 gro\xDFe Dateien dauern einen Moment\u2026",
      "Archive import failed.": "Archivimport fehlgeschlagen.",
      "Building report\u2026": "Bericht wird erstellt\u2026",
      "Report downloaded.": "Bericht heruntergeladen.",
      "Could not build report.": "Bericht konnte nicht erstellt werden.",
      "Building cleanup preview\u2026": "Bereinigungsvorschau wird erstellt\u2026",
      "Could not enqueue cleanup.": "Bereinigung konnte nicht eingereiht werden.",
      "Cleanup queue cleared": "Bereinigungsliste geleert",
      "Could not clear queue.": "Liste konnte nicht geleert werden.",
      "Aria2 endpoint saved": "Aria2-Endpunkt gespeichert",
      "Aria2 secret saved": "Aria2-Secret gespeichert",
      "Aria2 sweep failed.": "Aria2-Abfrage fehlgeschlagen.",
      "Bluesky service saved": "Bluesky-Dienst gespeichert",
      "Bluesky handle saved": "Bluesky-Name gespeichert",
      "Bluesky app password saved": "Bluesky-App-Passwort gespeichert",
      "Mastodon instance saved": "Mastodon-Instanz gespeichert",
      "Mastodon token saved": "Mastodon-Token gespeichert",
      "AI endpoint saved": "KI-Endpunkt gespeichert",
      "AI model saved": "KI-Modell gespeichert",
      "AI API key saved": "KI-API-Schl\xFCssel gespeichert",
      "Embedding endpoint saved": "Embedding-Endpunkt gespeichert",
      "Embedding model saved": "Embedding-Modell gespeichert",
      "Embedding API key saved": "Embedding-API-Schl\xFCssel gespeichert",
      "Rebuilding semantic index\u2026": "Semantischer Index wird neu aufgebaut\u2026",
      "Embedding failed.": "Embedding fehlgeschlagen.",
      "Semantic index cleared": "Semantischer Index gel\xF6scht",
      "Account notes cleared": "Konto-Notizen gel\xF6scht",
      "Could not clear notes.": "Notizen konnten nicht gel\xF6scht werden.",
      "Settings exported.": "Einstellungen exportiert.",
      "Could not export settings.": "Einstellungen konnten nicht exportiert werden.",
      "Could not import settings.": "Einstellungen konnten nicht importiert werden.",
      "Audit log cleared": "Auditprotokoll geleert",
      "Could not clear audit log.": "Pr\xFCfprotokoll konnte nicht gel\xF6scht werden.",
      "Raw payload preference saved": "Einstellung f\xFCr Rohdaten gespeichert",
      "Query discovery preference saved": "Einstellung zur Query-Erkennung gespeichert",
      "Save folder hint saved": "Zielordner gespeichert",
      "Collecting visible posts\u2026": "Sichtbare Beitr\xE4ge werden gesammelt\u2026",
      "Export failed. See diagnostics.": "Export fehlgeschlagen. Siehe Diagnose.",
      "Diagnostics copied to clipboard.": "Diagnose in die Zwischenablage kopiert.",
      "Could not copy diagnostics.": "Diagnose konnte nicht kopiert werden.",
      "Building WARC archive\u2026": "WARC-Archiv wird erstellt\u2026",
      "WARC export failed.": "WARC-Export fehlgeschlagen.",
      "External export failed.": "Externer Export fehlgeschlagen.",
      "Records per ZIP saved": "Datens\xE4tze pro ZIP gespeichert",
      "Export job retention saved": "Aufbewahrung der Export-Auftr\xE4ge gespeichert",
      "Record retention saved": "Aufbewahrung der Datens\xE4tze gespeichert",
      "Age-based retention saved": "Aufbewahrung nach Alter gespeichert",
      "Original quality preference saved": "Einstellung f\xFCr Originalqualit\xE4t gespeichert",
      "Filename template saved": "Dateinamen-Vorlage gespeichert",
      "Sensitive content preference saved": "Einstellung f\xFCr sensible Inhalte gespeichert",
      "Media layout saved": "Medienlayout gespeichert",
      "History cleared": "Verlauf geleert",
      "Could not clear history.": "Verlauf konnte nicht gel\xF6scht werden.",
      "Downloading media from this view\u2026": "Medien dieser Ansicht werden heruntergeladen\u2026",
      "Batch download failed.": "Stapel-Download fehlgeschlagen.",
      "Premium filter saved": "Premium-Filter gespeichert",
      "Could not undo the last hide.": "Das letzte Ausblenden konnte nicht r\xFCckg\xE4ngig gemacht werden.",
      "Could not restore the post.": "Der Beitrag konnte nicht wiederhergestellt werden.",
      "Could not clear hidden posts.": "Ausgeblendete Beitr\xE4ge konnten nicht gel\xF6scht werden.",
      "Saving...": "Wird gespeichert...",
      "Could not save settings. Try again.": "Einstellungen konnten nicht gespeichert werden. Bitte erneut versuchen.",
      "Theme": "Design",
      "Dim": "Gedimmt",
      "Lights out": "Lichter aus",
      "Graphite": "Graphit",
      "Plum": "Pflaume",
      "Midnight": "Mitternacht",
      "Dense mode": "Kompaktmodus",
      "Tighten timeline spacing for scanning.": "Verdichtet die Abst\xE4nde der Timeline zum schnellen \xDCberfliegen.",
      "Hide engagement counts": "Interaktionszahlen ausblenden",
      "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.": "Blendet die Zahlen f\xFCr Antworten, Reposts und Likes aus. Die Schaltfl\xE4chen funktionieren weiter, und Screenreader nennen die Summen weiterhin.",
      "Hide row borders": "Zeilentrenner ausblenden",
      "Remove the 1px divider under each timeline post and the primary column's side rules.": "Entfernt den 1-px-Trenner unter jedem Beitrag und die Seitenlinien der Hauptspalte.",
      "High contrast": "Hoher Kontrast",
      "Use stronger borders and text contrast.": "Verwendet kr\xE4ftigere R\xE4nder und st\xE4rkeren Textkontrast.",
      "Reduced motion": "Reduzierte Bewegung",
      "Follow system setting": "Systemeinstellung folgen",
      "Always reduce": "Immer reduzieren",
      "Never reduce": "Nie reduzieren",
      "Hide right sidebar": "Rechte Seitenleiste ausblenden",
      "Reduce trends, recommendations, and footer noise.": "Reduziert L\xE4rm durch Trends, Empfehlungen und Fu\xDFzeile.",
      "Hide trends": "Trends ausblenden",
      "Remove trending topics and news modules.": "Entfernt Trendthemen und Nachrichtenmodule.",
      "Hide Grok surfaces": "Grok-Oberfl\xE4chen ausblenden",
      "Remove Grok drawer and composer buttons where detected.": "Entfernt die Grok-Leiste und ihre Schaltfl\xE4chen im Verfasser, sofern erkannt.",
      "Writer mode": "Schreibmodus",
      "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.": "Solange der Fokus im Verfasser liegt, treten Seitenleiste und Timeline dahinter zur\xFCck. Alles kehrt zur\xFCck, sobald Sie daneben klicken.",
      "Enable filters": "Filter aktivieren",
      "Master switch for keyword, regex, premium, and media filters.": "Hauptschalter f\xFCr Stichwort-, Regex-, Premium- und Medienfilter.",
      "Keyword rules": "Stichwortregeln",
      "One keyword or phrase per line. Case-insensitive substring match.": "Ein Stichwort oder eine Wendung pro Zeile. Teiltreffer ohne Beachtung der Gro\xDF-/Kleinschreibung.",
      "Save list": "Liste speichern",
      "Regex rules": "Regex-Regeln",
      "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).": "Ein Muster pro Zeile. Verwenden Sie /muster/flags oder ein einfaches Muster (ohne Gro\xDF-/Kleinschreibung).",
      "Whitelist handles": "Konten auf der Positivliste",
      "Handles (one per line, no @) that are never filtered.": "Konten (eines pro Zeile, ohne @), die nie gefiltert werden.",
      "Premium / verified posts": "Premium-/verifizierte Beitr\xE4ge",
      "Off": "Aus",
      "Hide": "Ausblenden",
      "Hide posts with photos": "Beitr\xE4ge mit Fotos ausblenden",
      "Filter posts containing photos.": "Filtert Beitr\xE4ge mit Fotos.",
      "Hide posts with videos": "Beitr\xE4ge mit Videos ausblenden",
      "Filter posts containing videos.": "Filtert Beitr\xE4ge mit Videos.",
      "Hide posts with gifs": "Beitr\xE4ge mit GIFs ausblenden",
      "Filter posts containing gifs.": "Filtert Beitr\xE4ge mit GIFs.",
      "Active on": "Aktiv auf",
      "Routes where filters run.": "Routen, auf denen die Filter laufen.",
      "Home": "Startseite",
      "Status": "Beitrag",
      "Profile": "Profil",
      "Search": "Suche",
      "Notifications": "Mitteilungen",
      "Messages": "Nachrichten",
      "Blocked accounts / self-reposts": "Blockierte Konten / eigene Reposts",
      "Pending an authenticated fixture; controls stay disabled.": "Wartet auf eine authentifizierte Aufnahme; die Bedienelemente bleiben deaktiviert.",
      "Hide dismissed posts": "Verworfene Beitr\xE4ge ausblenden",
      "Keep posts you hid collapsed so the next post rises to the top.": "H\xE4lt von Ihnen ausgeblendete Beitr\xE4ge eingeklappt, damit der n\xE4chste nachr\xFCckt.",
      "Show hide buttons": "Ausblenden-Schaltfl\xE4chen anzeigen",
      "Adds a Hide control to every post next to the More menu.": "F\xFCgt jedem Beitrag neben dem Mehr-Men\xFC eine Ausblenden-Schaltfl\xE4che hinzu.",
      "Routes where hiding and the Hide button apply.": "Routen, auf denen das Ausblenden und die Ausblenden-Schaltfl\xE4che gelten.",
      "Maximum remembered posts": "Maximal gemerkte Beitr\xE4ge",
      "Oldest entries are dropped once the store passes this size (100-50000).": "Die \xE4ltesten Eintr\xE4ge entfallen, sobald der Speicher diese Gr\xF6\xDFe \xFCberschreitet (100-50000).",
      "Save": "Speichern",
      "Hidden posts stored": "Gespeicherte ausgeblendete Beitr\xE4ge",
      "Undo last hide": "Letztes Ausblenden r\xFCckg\xE4ngig machen",
      "Restores the most recently hidden post.": "Stellt den zuletzt ausgeblendeten Beitrag wieder her.",
      "Restore": "Wiederherstellen",
      "Clear hidden posts": "Ausgeblendete Beitr\xE4ge l\xF6schen",
      "Forgets every hidden post and brings them all back.": "Vergisst alle ausgeblendeten Beitr\xE4ge und stellt sie wieder her.",
      "Show download buttons": "Download-Schaltfl\xE4chen anzeigen",
      "Inject Save and Thumb buttons over tweet photos and video thumbnails.": "Blendet Speichern- und Vorschaubild-Schaltfl\xE4chen \xFCber Fotos und Video-Vorschaubildern ein.",
      "Prefer original quality": "Originalqualit\xE4t bevorzugen",
      "Rewrite image URLs to name=orig before downloading.": "Schreibt Bild-URLs vor dem Download auf name=orig um.",
      "Filename template": "Dateinamenvorlage",
      "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.": "Felder: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.",
      "Duplicate history": "Duplikatverlauf",
      "Skip downloads of media you have already saved from this browser.": "\xDCberspringt Downloads von Medien, die Sie in diesem Browser bereits gespeichert haben.",
      "Sensitive content": "Sensible Inhalte",
      "Default (X choice)": "Standard (Auswahl von X)",
      "Always reveal": "Immer anzeigen",
      "Blur until hovered": "Bis zum \xDCberfahren weichzeichnen",
      "Always hide": "Immer ausblenden",
      "Media layout": "Medienlayout",
      "Default grid": "Standardraster",
      "Stacked": "Gestapelt",
      "Strict grid": "Striktes Raster",
      "Download status": "Download-Status",
      "History entries": "Verlaufseintr\xE4ge",
      "Clear download history": "Download-Verlauf l\xF6schen",
      "Reset the local dedup index.": "Setzt den lokalen Duplikat-Index zur\xFCck.",
      "Download all visible media": "Alle sichtbaren Medien herunterladen",
      "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.": "Durchl\xE4uft jeden Beitrag auf der aktuellen Seite und stellt jedes Foto, Video, GIF und Vorschaubild in die bestehende Download-Warteschlange.",
      "Capture visible tweets": "Sichtbare Beitr\xE4ge erfassen",
      "Accumulate tweets visible on the active page for the next export run.": "Sammelt die auf der aktiven Seite sichtbaren Beitr\xE4ge f\xFCr den n\xE4chsten Exportlauf.",
      "Export formats": "Exportformate",
      "Comma-separated list. Supported: json, csv, html, markdown, xlsx.": "Kommagetrennte Liste. Unterst\xFCtzt: json, csv, html, markdown, xlsx.",
      "Preserve raw payloads": "Rohdaten aufbewahren",
      "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.": "Speichert zus\xE4tzlich die rohen GraphQL-Antworten, die X an diesen Tab sendet, damit Datens\xE4tze sp\xE4ter neu ausgewertet werden k\xF6nnen. Sitzungstoken werden vor dem Schreiben entfernt.",
      "Auto-discover query IDs": "Query-IDs automatisch ermitteln",
      "Scan loaded scripts for X GraphQL operation IDs and cache them locally.": "Durchsucht geladene Skripte nach GraphQL-Operations-IDs von X und legt sie lokal ab.",
      "Save folder hint": "Zielordner-Hinweis",
      "Folder name (or path) used as the export ZIP root and download prefix.": "Ordnername (oder Pfad) als Wurzel des Export-ZIP und Download-Pr\xE4fix.",
      "Export status": "Export-Status",
      "Export visible tweets": "Sichtbare Beitr\xE4ge exportieren",
      "Collect the currently rendered tweets and download a ZIP.": "Sammelt die aktuell angezeigten Beitr\xE4ge und l\xE4dt eine ZIP-Datei herunter.",
      "Copy diagnostics": "Diagnose kopieren",
      "Copy support diagnostics (version, route, recent log).": "Kopiert die Support-Diagnose (Version, Route, letztes Protokoll).",
      "Download as WARC": "Als WARC herunterladen",
      "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.": "Verpackt erfasste Datens\xE4tze in eine WARC-Datei nach ISO-28500 f\xFCr Forschungs- und Archivierungswerkzeuge.",
      "Copy as Markdown": "Als Markdown kopieren",
      "Push a plain Markdown export onto the clipboard.": "Kopiert einen einfachen Markdown-Export in die Zwischenablage.",
      "Save Obsidian Markdown": "Obsidian-Markdown speichern",
      "Markdown with YAML frontmatter and Aviary tags.": "Markdown mit YAML-Frontmatter und Aviary-Tags.",
      "Save Notion Markdown": "Notion-Markdown speichern",
      "Heading-first Markdown that Notion imports cleanly.": "\xDCberschriftenbasiertes Markdown, das Notion sauber importiert.",
      "Save records JSON": "Datens\xE4tze als JSON speichern",
      "Raw ExportRecord[] JSON without ZIP wrapping.": "Rohes ExportRecord[]-JSON ohne ZIP-Verpackung.",
      "Records per ZIP": "Datens\xE4tze pro ZIP",
      "Split a long export across several archives instead of one huge file (25-1000).": "Verteilt einen langen Export auf mehrere Archive statt auf eine riesige Datei (25-1000).",
      "Maximum export jobs": "Maximale Anzahl Export-Auftr\xE4ge",
      "Keep the newest jobs. Use 0 for unlimited.": "Beh\xE4lt die neuesten Auftr\xE4ge. 0 bedeutet unbegrenzt.",
      "Maximum records per job": "Maximale Datens\xE4tze pro Auftrag",
      "Keep the newest records in each job. Use 0 for unlimited.": "Beh\xE4lt die neuesten Datens\xE4tze jedes Auftrags. 0 bedeutet unbegrenzt.",
      "Maximum export age (days)": "Maximales Export-Alter (Tage)",
      "Remove older jobs at boot. Use 0 to disable age-based cleanup.": "Entfernt \xE4ltere Auftr\xE4ge beim Start. 0 deaktiviert die Bereinigung nach Alter.",
      "Unshorten t.co links": "t.co-Links aufl\xF6sen",
      "Replace short `t.co` redirects with the destination from aria-labels and titles.": "Ersetzt kurze `t.co`-Weiterleitungen durch das Ziel aus aria-labels und Titeln.",
      "Clean tracking from links": "Tracking aus Links entfernen",
      "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.": "Entfernt Share-Tokens und Kampagnenparameter (utm_*, fbclid und X' eigene t/s) aus Links in der Timeline, sodass du die blanke Adresse kopierst.",
      "Account notes": "Konto-Notizen",
      "Format: handle: note. One per line. Empty notes remove the entry.": "Format: Name: Notiz. Eine pro Zeile. Leere Notizen entfernen den Eintrag.",
      "Clear all account notes": "Alle Konto-Notizen l\xF6schen",
      "Drop every persisted note.": "Entfernt alle gespeicherten Notizen.",
      "Composer snippets": "Verfasser-Textbausteine",
      "One snippet per line. Reusable replies / templates (insertion landing in a later release).": "Ein Baustein pro Zeile. Wiederverwendbare Antworten und Vorlagen (das Einf\xFCgen folgt in einer sp\xE4teren Version).",
      "Snapshots stored": "Gespeicherte Momentaufnahmen",
      "Capture followers from this view": "Follower aus dieser Ansicht erfassen",
      "Walks UserCell rows on the current page. Open a /handle/followers view first.": "Durchl\xE4uft die UserCell-Zeilen der aktuellen Seite. \xD6ffne zuerst eine /name/followers-Ansicht.",
      "Capture following from this view": "Gefolgte aus dieser Ansicht erfassen",
      "Walks UserCell rows on the current page. Open a /handle/following view first.": "Durchl\xE4uft die UserCell-Zeilen der aktuellen Seite. \xD6ffne zuerst eine /name/following-Ansicht.",
      "Clear all snapshots": "Alle Momentaufnahmen l\xF6schen",
      "Drop every stored follower/following snapshot.": "Entfernt alle gespeicherten Follower- und Gefolgt-Momentaufnahmen.",
      "Download Markdown report": "Markdown-Bericht herunterladen",
      "Audit log + snapshot diff + cleanup preview.": "Pr\xFCfprotokoll, Momentaufnahmen-Vergleich und Bereinigungsvorschau.",
      "Cleanup review queue": "Pr\xFCfliste f\xFCr die Bereinigung",
      "Destructive actions": "Destruktive Aktionen",
      "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log.": "Aviary l\xF6scht niemals Beitr\xE4ge, Likes oder Follows. Die Liste dient nur der Pr\xFCfung; Zustimmen oder \xDCberspringen schreibt lediglich ins Pr\xFCfprotokoll.",
      "Enqueue cleanup preview for review": "Bereinigungsvorschau zur Pr\xFCfung einreihen",
      "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).": "F\xFCgt alle ungesch\xFCtzten Kandidaten der letzten Bereinigungsvorschau der Liste hinzu (keine destruktive Aktion).",
      "Clear cleanup queue": "Bereinigungsliste leeren",
      "Drop every queued item without touching account data.": "Entfernt alle Eintr\xE4ge der Liste, ohne Kontodaten anzur\xFChren.",
      "Aria2 handoff": "Aria2-\xDCbergabe",
      "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.": "Sendet gro\xDFe Mediendownloads an einen selbst gehosteten Aria2-JSON-RPC-Endpunkt.",
      "Aria2 endpoint": "Aria2-Endpunkt",
      "http://localhost:6800 (no trailing slash needed)": "http://localhost:6800 (kein abschlie\xDFender Schr\xE4gstrich n\xF6tig)",
      "Aria2 RPC secret": "Aria2-RPC-Secret",
      "Optional shared secret for token: auth.": "Optionales gemeinsames Secret f\xFCr die token:-Authentifizierung.",
      "Show": "Anzeigen",
      "Test Aria2 connection": "Aria2-Verbindung testen",
      "Sends a trivial JSON-RPC call.": "Sendet einen einfachen JSON-RPC-Aufruf.",
      "Refresh": "Aktualisieren",
      "Bluesky crosspost": "Bluesky-Crosspost",
      "Post composer text to your Bluesky account on demand.": "Ver\xF6ffentlicht den Verfassertext auf Wunsch in Ihrem Bluesky-Konto.",
      "Bluesky service URL": "Bluesky-Dienst-URL",
      "Default: https://bsky.social": "Standard: https://bsky.social",
      "Bluesky handle": "Bluesky-Konto",
      "Your handle (no @, e.g. you.bsky.social)": "Ihr Konto (ohne @, z. B. sie.bsky.social)",
      "Bluesky app password": "Bluesky-App-Passwort",
      "App password from your account settings \u2014 never your main password.": "App-Passwort aus Ihren Kontoeinstellungen \u2014 niemals Ihr Hauptpasswort.",
      "Mastodon crosspost": "Mastodon-Crosspost",
      "Post composer text to your Mastodon account on demand.": "Ver\xF6ffentlicht den Verfassertext auf Wunsch in Ihrem Mastodon-Konto.",
      "Mastodon instance": "Mastodon-Instanz",
      "https://mastodon.social": "https://mastodon.social",
      "Mastodon access token": "Mastodon-Zugriffstoken",
      "Bearer token with write:statuses scope.": "Bearer-Token mit dem Geltungsbereich write:statuses.",
      "Attach last download": "Letzten Download anh\xE4ngen",
      "Upload the last successful Aviary media download with the first post in an explicit crosspost.": "H\xE4ngt den letzten erfolgreichen Aviary-Mediendownload an den ersten Beitrag eines ausdr\xFCcklichen Crossposts an.",
      "Crosspost composer \u2192 Bluesky": "Entwurf auf Bluesky posten",
      "Uses the current composer text.": "Verwendet den aktuellen Text im Editor.",
      "Crosspost composer \u2192 Mastodon": "Entwurf auf Mastodon posten",
      "AI provider runs": "KI-Anbieter nutzen",
      "Let the AI command menu POST prompts to your configured provider.": "Erlaubt dem KI-Befehlsmen\xFC, Prompts an Ihren konfigurierten Anbieter zu senden.",
      "AI provider": "KI-Anbieter",
      "Anthropic Messages API": "Anthropic Messages API",
      "OpenAI Chat Completions": "OpenAI Chat Completions",
      "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)": "OpenAI-kompatibel (LocalAI, Ollama-Proxy, \u2026)",
      "AI endpoint (optional)": "KI-Endpunkt (optional)",
      "Override the default endpoint for the chosen provider.": "\xDCberschreibt den Standardendpunkt des gew\xE4hlten Anbieters.",
      "AI model": "KI-Modell",
      "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b": "z. B. claude-sonnet-4-6, gpt-4o, llama3.1:8b",
      "AI API key": "KI-API-Schl\xFCssel",
      "Stored locally only. Aviary never sends this except as the auth header to your provider.": "Wird nur lokal gespeichert. Aviary sendet ihn ausschlie\xDFlich als Auth-Header an Ihren Anbieter.",
      "Semantic search": "Semantische Suche",
      "Embed CheckpointStore records via your provider for similarity search.": "Bettet CheckpointStore-Datens\xE4tze \xFCber Ihren Anbieter f\xFCr die \xC4hnlichkeitssuche ein.",
      "Embedding endpoint": "Embedding-Endpunkt",
      "POST endpoint that returns {data: [{embedding: number[]}]}": "POST-Endpunkt, der {data: [{embedding: number[]}]} zur\xFCckgibt",
      "Embedding model": "Embedding-Modell",
      "e.g. text-embedding-3-small": "z. B. text-embedding-3-small",
      "Embedding API key": "Embedding-API-Schl\xFCssel",
      "Stored locally; used only as the Authorization header.": "Wird lokal gespeichert und nur als Authorization-Header verwendet.",
      "Auto-embed every export": "Jeden Export automatisch einbetten",
      "After each export run, kick the embedding job in the background. Off by default.": "St\xF6\xDFt nach jedem Exportlauf den Embedding-Job im Hintergrund an. Standardm\xE4\xDFig aus.",
      "Rebuild semantic index": "Semantischen Index neu aufbauen",
      "Embed every captured record. Re-running is cheap because cached entries are skipped.": "Erzeugt Embeddings f\xFCr jeden erfassten Datensatz. Ein erneuter Lauf ist g\xFCnstig, da zwischengespeicherte Eintr\xE4ge \xFCbersprungen werden.",
      "Clear semantic index": "Semantischen Index l\xF6schen",
      "Forget every embedded record.": "Vergisst alle eingebetteten Datens\xE4tze.",
      "Integration status": "Status der Integrationen",
      "Export settings": "Einstellungen exportieren",
      "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.": "L\xE4dt deine Einstellungen als JSON herunter. API-Schl\xFCssel und Passw\xF6rter werden durch einen Platzhalter ersetzt, die Datei l\xE4sst sich also gefahrlos weitergeben; beim Import hier bleiben die auf diesem Rechner gespeicherten Zugangsdaten erhalten.",
      "Import settings (JSON)": "Einstellungen importieren (JSON)",
      "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.": "F\xFCge eine aus Aviary exportierte Einstellungsdatei ein und w\xE4hle Importieren. Geschw\xE4rzte Zugangsdaten behalten die hier gespeicherten Werte.",
      "Import": "Importieren",
      "Keep a local action log": "Lokales Aktionsprotokoll f\xFChren",
      "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.": "Zeichnet Downloads, Exporte und Einstellungs\xE4nderungen auf diesem Ger\xE4t auf, damit du nachvollziehen kannst, was Aviary getan hat. Es wird nichts \xFCbertragen. Beim Ausschalten werden sofort keine neuen Eintr\xE4ge mehr angelegt; vorhandene bleiben, bis du sie l\xF6schst.",
      "Audit entries": "Pr\xFCfprotokoll-Eintr\xE4ge",
      "Clear audit log": "Pr\xFCfprotokoll l\xF6schen",
      "Drop the local action log.": "Entfernt das lokale Aktionsprotokoll.",
      "Storage": "Speicher",
      "Settings stay in this browser.": "Einstellungen bleiben in diesem Browser.",
      "Local-only mode": "Nur-lokal-Modus",
      "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.": "Blockiert jede ausgehende Anfrage, auch die von dir eingerichteten Integrationen. Standardm\xE4\xDFig an; das Einschalten einer Integration schaltet ihn aus.",
      "Some changes could not be saved \u2014 the browser store may be full.": "Einige \xC4nderungen konnten nicht gespeichert werden \u2013 der Browser-Speicher ist m\xF6glicherweise voll.",
      "Saving": "Speichern",
      "Telemetry": "Telemetrie",
      "Disabled": "Deaktiviert",
      "Panel language": "Sprache des Panels",
      "Selector health": "Selektor-Zustand",
      "Working \u2014 every change has been written.": "Alles in Ordnung \u2013 jede \xC4nderung wurde gespeichert.",
      "Monitoring active": "\xDCberwachung aktiv",
      "Preset packs unavailable in this build.": "Voreinstellungspakete stehen in diesem Build nicht zur Verf\xFCgung.",
      "Hidden post store unavailable in this build.": "Speicher f\xFCr ausgeblendete Beitr\xE4ge steht in diesem Build nicht zur Verf\xFCgung.",
      "Cancel": "Abbrechen"
    },
    ja: {
      "Aviary": "Aviary",
      "Local controls for a quieter X.": "\u9759\u304B\u306A X \u306E\u305F\u3081\u306E\u30ED\u30FC\u30AB\u30EB\u8A2D\u5B9A\u3002",
      "Close": "\u9589\u3058\u308B",
      "Search settings": "\u8A2D\u5B9A\u3092\u691C\u7D22",
      "Saved locally": "\u30ED\u30FC\u30AB\u30EB\u306B\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Settings sections": "\u8A2D\u5B9A\u306E\u30BB\u30AF\u30B7\u30E7\u30F3",
      "Start": "\u306F\u3058\u3081\u306B",
      "Presets": "\u30D7\u30EA\u30BB\u30C3\u30C8",
      "Reading": "\u8868\u793A",
      "Appearance": "\u5916\u89B3",
      "Layout": "\u30EC\u30A4\u30A2\u30A6\u30C8",
      "Filtering": "\u30D5\u30A3\u30EB\u30BF",
      "Hidden posts": "\u975E\u8868\u793A\u306E\u6295\u7A3F",
      "Data": "\u30C7\u30FC\u30BF",
      "Media": "\u30E1\u30C7\u30A3\u30A2",
      "Export": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8",
      "Library": "\u30E9\u30A4\u30D6\u30E9\u30EA",
      "Snapshots & Archive": "\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u3068\u30A2\u30FC\u30AB\u30A4\u30D6",
      "Advanced": "\u8A73\u7D30\u8A2D\u5B9A",
      "Integrations": "\u9023\u643A",
      "Backup & Audit": "\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3068\u76E3\u67FB",
      "Trust": "\u30D7\u30E9\u30A4\u30D0\u30B7\u30FC",
      "Apply": "\u9069\u7528",
      "Locale": "\u8A00\u8A9E",
      "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.": "\u30D1\u30CD\u30EB\u3092\u7FFB\u8A33\u3057\u3001\u8AAD\u3080\u65B9\u5411\u3092\u8A2D\u5B9A\u3057\u307E\u3059\uFF08\u30A2\u30E9\u30D3\u30A2\u8A9E\u3068\u30D8\u30D6\u30E9\u30A4\u8A9E\u306F\u53F3\u304B\u3089\u5DE6\uFF09\u3002\u300C\u30D7\u30E9\u30A4\u30D0\u30B7\u30FC\u300D\u306B\u9078\u629E\u3057\u305F\u8A00\u8A9E\u306E\u7FFB\u8A33\u7387\u304C\u8868\u793A\u3055\u308C\u3001\u672A\u7FFB\u8A33\u306E\u9805\u76EE\u306F\u82F1\u8A9E\u306E\u307E\u307E\u306B\u306A\u308A\u307E\u3059\u3002",
      "Theme value is not supported.": "\u305D\u306E\u30C6\u30FC\u30DE\u306B\u306F\u5BFE\u5FDC\u3057\u3066\u3044\u307E\u305B\u3093\u3002",
      "Theme updated": "\u30C6\u30FC\u30DE\u3092\u66F4\u65B0\u3057\u307E\u3057\u305F",
      "Density updated": "\u8868\u793A\u5BC6\u5EA6\u3092\u66F4\u65B0\u3057\u307E\u3057\u305F",
      "Contrast preference saved": "\u30B3\u30F3\u30C8\u30E9\u30B9\u30C8\u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Motion preference saved": "\u30E2\u30FC\u30B7\u30E7\u30F3\u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Sidebar preference saved": "\u30B5\u30A4\u30C9\u30D0\u30FC\u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Trend preference saved": "\u30C8\u30EC\u30F3\u30C9\u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Grok preference saved": "Grok \u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Could not apply preset.": "\u30D7\u30EA\u30BB\u30C3\u30C8\u3092\u9069\u7528\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Snapshot failed.": "\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002",
      "Snapshots cleared": "\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u3092\u6D88\u53BB\u3057\u307E\u3057\u305F",
      "Could not clear snapshots.": "\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u3092\u6D88\u53BB\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Reading archive \u2014 large files take a moment\u2026": "\u30A2\u30FC\u30AB\u30A4\u30D6\u3092\u8AAD\u307F\u8FBC\u307F\u4E2D \u2014 \u5927\u304D\u306A\u30D5\u30A1\u30A4\u30EB\u306F\u5C11\u3057\u6642\u9593\u304C\u304B\u304B\u308A\u307E\u3059\u2026",
      "Archive import failed.": "\u30A2\u30FC\u30AB\u30A4\u30D6\u306E\u8AAD\u307F\u8FBC\u307F\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002",
      "Building report\u2026": "\u30EC\u30DD\u30FC\u30C8\u3092\u4F5C\u6210\u4E2D\u2026",
      "Report downloaded.": "\u30EC\u30DD\u30FC\u30C8\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u307E\u3057\u305F\u3002",
      "Could not build report.": "\u30EC\u30DD\u30FC\u30C8\u3092\u4F5C\u6210\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Building cleanup preview\u2026": "\u6574\u7406\u306E\u30D7\u30EC\u30D3\u30E5\u30FC\u3092\u4F5C\u6210\u4E2D\u2026",
      "Could not enqueue cleanup.": "\u6574\u7406\u3092\u30AD\u30E5\u30FC\u306B\u8FFD\u52A0\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Cleanup queue cleared": "\u6574\u7406\u30AD\u30E5\u30FC\u3092\u7A7A\u306B\u3057\u307E\u3057\u305F",
      "Could not clear queue.": "\u30AD\u30E5\u30FC\u3092\u7A7A\u306B\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Aria2 endpoint saved": "Aria2 \u306E\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Aria2 secret saved": "Aria2 \u306E\u30B7\u30FC\u30AF\u30EC\u30C3\u30C8\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Aria2 sweep failed.": "Aria2 \u306E\u4E00\u89A7\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002",
      "Bluesky service saved": "Bluesky \u306E\u30B5\u30FC\u30D3\u30B9\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Bluesky handle saved": "Bluesky \u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u540D\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Bluesky app password saved": "Bluesky \u306E\u30A2\u30D7\u30EA\u30D1\u30B9\u30EF\u30FC\u30C9\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Mastodon instance saved": "Mastodon \u306E\u30A4\u30F3\u30B9\u30BF\u30F3\u30B9\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Mastodon token saved": "Mastodon \u306E\u30C8\u30FC\u30AF\u30F3\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "AI endpoint saved": "AI \u306E\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "AI model saved": "AI \u30E2\u30C7\u30EB\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "AI API key saved": "AI \u306E API \u30AD\u30FC\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Embedding endpoint saved": "\u57CB\u3081\u8FBC\u307F\u306E\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Embedding model saved": "\u57CB\u3081\u8FBC\u307F\u30E2\u30C7\u30EB\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Embedding API key saved": "\u57CB\u3081\u8FBC\u307F\u306E API \u30AD\u30FC\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Rebuilding semantic index\u2026": "\u30BB\u30DE\u30F3\u30C6\u30A3\u30C3\u30AF\u7D22\u5F15\u3092\u518D\u69CB\u7BC9\u4E2D\u2026",
      "Embedding failed.": "\u57CB\u3081\u8FBC\u307F\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002",
      "Semantic index cleared": "\u30BB\u30DE\u30F3\u30C6\u30A3\u30C3\u30AF\u7D22\u5F15\u3092\u6D88\u53BB\u3057\u307E\u3057\u305F",
      "Account notes cleared": "\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30E1\u30E2\u3092\u6D88\u53BB\u3057\u307E\u3057\u305F",
      "Could not clear notes.": "\u30E1\u30E2\u3092\u6D88\u53BB\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Settings exported.": "\u8A2D\u5B9A\u3092\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3057\u307E\u3057\u305F\u3002",
      "Could not export settings.": "\u8A2D\u5B9A\u3092\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Could not import settings.": "\u8A2D\u5B9A\u3092\u30A4\u30F3\u30DD\u30FC\u30C8\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Audit log cleared": "\u76E3\u67FB\u30ED\u30B0\u3092\u6D88\u53BB\u3057\u307E\u3057\u305F",
      "Could not clear audit log.": "\u76E3\u67FB\u30ED\u30B0\u3092\u6D88\u53BB\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Raw payload preference saved": "\u751F\u30EC\u30B9\u30DD\u30F3\u30B9\u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Query discovery preference saved": "\u30AF\u30A8\u30EA\u691C\u51FA\u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Save folder hint saved": "\u4FDD\u5B58\u5148\u30D5\u30A9\u30EB\u30C0\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Collecting visible posts\u2026": "\u8868\u793A\u4E2D\u306E\u6295\u7A3F\u3092\u53CE\u96C6\u4E2D\u2026",
      "Export failed. See diagnostics.": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002\u8A3A\u65AD\u60C5\u5831\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
      "Diagnostics copied to clipboard.": "\u8A3A\u65AD\u60C5\u5831\u3092\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u306B\u30B3\u30D4\u30FC\u3057\u307E\u3057\u305F\u3002",
      "Could not copy diagnostics.": "\u8A3A\u65AD\u60C5\u5831\u3092\u30B3\u30D4\u30FC\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Building WARC archive\u2026": "WARC \u30A2\u30FC\u30AB\u30A4\u30D6\u3092\u4F5C\u6210\u4E2D\u2026",
      "WARC export failed.": "WARC \u306E\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002",
      "External export failed.": "\u5916\u90E8\u3078\u306E\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002",
      "Records per ZIP saved": "ZIP \u3042\u305F\u308A\u306E\u4EF6\u6570\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Export job retention saved": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u30B8\u30E7\u30D6\u306E\u4FDD\u6301\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Record retention saved": "\u8A18\u9332\u306E\u4FDD\u6301\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Age-based retention saved": "\u65E5\u6570\u306B\u3088\u308B\u4FDD\u6301\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Original quality preference saved": "\u30AA\u30EA\u30B8\u30CA\u30EB\u753B\u8CEA\u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Filename template saved": "\u30D5\u30A1\u30A4\u30EB\u540D\u306E\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Sensitive content preference saved": "\u30BB\u30F3\u30B7\u30C6\u30A3\u30D6\u306A\u5185\u5BB9\u306E\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Media layout saved": "\u30E1\u30C7\u30A3\u30A2\u306E\u30EC\u30A4\u30A2\u30A6\u30C8\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "History cleared": "\u5C65\u6B74\u3092\u6D88\u53BB\u3057\u307E\u3057\u305F",
      "Could not clear history.": "\u5C65\u6B74\u3092\u6D88\u53BB\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Downloading media from this view\u2026": "\u3053\u306E\u753B\u9762\u306E\u30E1\u30C7\u30A3\u30A2\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u4E2D\u2026",
      "Batch download failed.": "\u4E00\u62EC\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002",
      "Premium filter saved": "\u30D7\u30EC\u30DF\u30A2\u30E0\u30D5\u30A3\u30EB\u30BF\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F",
      "Could not undo the last hide.": "\u76F4\u524D\u306E\u975E\u8868\u793A\u3092\u53D6\u308A\u6D88\u305B\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Could not restore the post.": "\u6295\u7A3F\u3092\u5143\u306B\u623B\u305B\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Could not clear hidden posts.": "\u975E\u8868\u793A\u306E\u6295\u7A3F\u3092\u6D88\u53BB\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
      "Saving...": "\u4FDD\u5B58\u4E2D...",
      "Could not save settings. Try again.": "\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u3082\u3046\u4E00\u5EA6\u304A\u8A66\u3057\u304F\u3060\u3055\u3044\u3002",
      "Theme": "\u30C6\u30FC\u30DE",
      "Dim": "\u30C7\u30A3\u30E0",
      "Lights out": "\u30E9\u30A4\u30C8\u30A2\u30A6\u30C8",
      "Graphite": "\u30B0\u30E9\u30D5\u30A1\u30A4\u30C8",
      "Plum": "\u30D7\u30E9\u30E0",
      "Midnight": "\u30DF\u30C3\u30C9\u30CA\u30A4\u30C8",
      "Dense mode": "\u9AD8\u5BC6\u5EA6\u30E2\u30FC\u30C9",
      "Tighten timeline spacing for scanning.": "\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306E\u4F59\u767D\u3092\u8A70\u3081\u3066\u4E00\u89A7\u3057\u3084\u3059\u304F\u3057\u307E\u3059\u3002",
      "Hide engagement counts": "\u30A8\u30F3\u30B2\u30FC\u30B8\u30E1\u30F3\u30C8\u6570\u3092\u975E\u8868\u793A",
      "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.": "\u8FD4\u4FE1\u30FB\u30EA\u30DD\u30B9\u30C8\u30FB\u3044\u3044\u306D\u306E\u6570\u3092\u96A0\u3057\u307E\u3059\u3002\u30DC\u30BF\u30F3\u306F\u5F15\u304D\u7D9A\u304D\u6A5F\u80FD\u3057\u3001\u30B9\u30AF\u30EA\u30FC\u30F3\u30EA\u30FC\u30C0\u30FC\u306F\u5408\u8A08\u3092\u8AAD\u307F\u4E0A\u3052\u307E\u3059\u3002",
      "Hide row borders": "\u884C\u306E\u5883\u754C\u7DDA\u3092\u975E\u8868\u793A",
      "Remove the 1px divider under each timeline post and the primary column's side rules.": "\u5404\u6295\u7A3F\u306E\u4E0B\u306B\u3042\u308B 1px \u306E\u533A\u5207\u308A\u7DDA\u3068\u3001\u30E1\u30A4\u30F3\u30AB\u30E9\u30E0\u306E\u5DE6\u53F3\u306E\u7F6B\u7DDA\u3092\u6D88\u3057\u307E\u3059\u3002",
      "High contrast": "\u30CF\u30A4\u30B3\u30F3\u30C8\u30E9\u30B9\u30C8",
      "Use stronger borders and text contrast.": "\u5883\u754C\u7DDA\u3068\u6587\u5B57\u306E\u30B3\u30F3\u30C8\u30E9\u30B9\u30C8\u3092\u5F37\u3081\u307E\u3059\u3002",
      "Reduced motion": "\u8996\u5DEE\u52B9\u679C\u3092\u6E1B\u3089\u3059",
      "Follow system setting": "\u30B7\u30B9\u30C6\u30E0\u8A2D\u5B9A\u306B\u5F93\u3046",
      "Always reduce": "\u5E38\u306B\u6E1B\u3089\u3059",
      "Never reduce": "\u6E1B\u3089\u3055\u306A\u3044",
      "Hide right sidebar": "\u53F3\u30B5\u30A4\u30C9\u30D0\u30FC\u3092\u975E\u8868\u793A",
      "Reduce trends, recommendations, and footer noise.": "\u30C8\u30EC\u30F3\u30C9\u30FB\u304A\u3059\u3059\u3081\u30FB\u30D5\u30C3\u30BF\u30FC\u306E\u30CE\u30A4\u30BA\u3092\u6E1B\u3089\u3057\u307E\u3059\u3002",
      "Hide trends": "\u30C8\u30EC\u30F3\u30C9\u3092\u975E\u8868\u793A",
      "Remove trending topics and news modules.": "\u30C8\u30EC\u30F3\u30C9\u3068\u30CB\u30E5\u30FC\u30B9\u306E\u30E2\u30B8\u30E5\u30FC\u30EB\u3092\u6D88\u3057\u307E\u3059\u3002",
      "Hide Grok surfaces": "Grok \u306E\u8981\u7D20\u3092\u975E\u8868\u793A",
      "Remove Grok drawer and composer buttons where detected.": "\u691C\u51FA\u3067\u304D\u305F Grok \u306E\u30C9\u30ED\u30EF\u30FC\u3068\u6295\u7A3F\u6B04\u306E\u30DC\u30BF\u30F3\u3092\u6D88\u3057\u307E\u3059\u3002",
      "Writer mode": "\u30E9\u30A4\u30BF\u30FC\u30E2\u30FC\u30C9",
      "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.": "\u6295\u7A3F\u6B04\u306B\u30D5\u30A9\u30FC\u30AB\u30B9\u304C\u3042\u308B\u9593\u3001\u30B5\u30A4\u30C9\u30D0\u30FC\u3068\u80CC\u5F8C\u306E\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u3092\u8584\u304F\u3057\u307E\u3059\u3002\u5225\u306E\u5834\u6240\u3092\u30AF\u30EA\u30C3\u30AF\u3059\u308C\u3070\u3059\u3050\u5143\u306B\u623B\u308A\u307E\u3059\u3002",
      "Enable filters": "\u30D5\u30A3\u30EB\u30BF\u3092\u6709\u52B9\u306B\u3059\u308B",
      "Master switch for keyword, regex, premium, and media filters.": "\u30AD\u30FC\u30EF\u30FC\u30C9\u30FB\u6B63\u898F\u8868\u73FE\u30FB\u30D7\u30EC\u30DF\u30A2\u30E0\u30FB\u30E1\u30C7\u30A3\u30A2\u306E\u5404\u30D5\u30A3\u30EB\u30BF\u3092\u307E\u3068\u3081\u3066\u5207\u308A\u66FF\u3048\u307E\u3059\u3002",
      "Keyword rules": "\u30AD\u30FC\u30EF\u30FC\u30C9\u306E\u30EB\u30FC\u30EB",
      "One keyword or phrase per line. Case-insensitive substring match.": "1 \u884C\u306B 1 \u3064\u306E\u30AD\u30FC\u30EF\u30FC\u30C9\u307E\u305F\u306F\u30D5\u30EC\u30FC\u30BA\u3002\u5927\u6587\u5B57\u5C0F\u6587\u5B57\u3092\u533A\u5225\u3057\u306A\u3044\u90E8\u5206\u4E00\u81F4\u3067\u3059\u3002",
      "Save list": "\u30EA\u30B9\u30C8\u3092\u4FDD\u5B58",
      "Regex rules": "\u6B63\u898F\u8868\u73FE\u306E\u30EB\u30FC\u30EB",
      "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).": "1 \u884C\u306B 1 \u3064\u306E\u30D1\u30BF\u30FC\u30F3\u3002/pattern/flags \u5F62\u5F0F\u304B\u3001\u305D\u306E\u307E\u307E\u306E\u30D1\u30BF\u30FC\u30F3\uFF08\u5927\u6587\u5B57\u5C0F\u6587\u5B57\u3092\u533A\u5225\u3057\u307E\u305B\u3093\uFF09\u3002",
      "Whitelist handles": "\u9664\u5916\u3059\u308B\u30A2\u30AB\u30A6\u30F3\u30C8",
      "Handles (one per line, no @) that are never filtered.": "\u30D5\u30A3\u30EB\u30BF\u3057\u306A\u3044\u30A2\u30AB\u30A6\u30F3\u30C8\u540D\uFF081 \u884C\u306B 1 \u3064\u3001@ \u306A\u3057\uFF09\u3002",
      "Premium / verified posts": "\u30D7\u30EC\u30DF\u30A2\u30E0\u30FB\u8A8D\u8A3C\u6E08\u307F\u306E\u6295\u7A3F",
      "Off": "\u30AA\u30D5",
      "Hide": "\u975E\u8868\u793A",
      "Hide posts with photos": "\u5199\u771F\u4ED8\u304D\u306E\u6295\u7A3F\u3092\u975E\u8868\u793A",
      "Filter posts containing photos.": "\u5199\u771F\u3092\u542B\u3080\u6295\u7A3F\u3092\u30D5\u30A3\u30EB\u30BF\u3057\u307E\u3059\u3002",
      "Hide posts with videos": "\u52D5\u753B\u4ED8\u304D\u306E\u6295\u7A3F\u3092\u975E\u8868\u793A",
      "Filter posts containing videos.": "\u52D5\u753B\u3092\u542B\u3080\u6295\u7A3F\u3092\u30D5\u30A3\u30EB\u30BF\u3057\u307E\u3059\u3002",
      "Hide posts with gifs": "GIF \u4ED8\u304D\u306E\u6295\u7A3F\u3092\u975E\u8868\u793A",
      "Filter posts containing gifs.": "GIF \u3092\u542B\u3080\u6295\u7A3F\u3092\u30D5\u30A3\u30EB\u30BF\u3057\u307E\u3059\u3002",
      "Active on": "\u9069\u7528\u3059\u308B\u30DA\u30FC\u30B8",
      "Routes where filters run.": "\u30D5\u30A3\u30EB\u30BF\u3092\u5B9F\u884C\u3059\u308B\u30DA\u30FC\u30B8\u3002",
      "Home": "\u30DB\u30FC\u30E0",
      "Status": "\u6295\u7A3F",
      "Profile": "\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB",
      "Search": "\u691C\u7D22",
      "Notifications": "\u901A\u77E5",
      "Messages": "\u30E1\u30C3\u30BB\u30FC\u30B8",
      "Blocked accounts / self-reposts": "\u30D6\u30ED\u30C3\u30AF\u6E08\u307F\u30A2\u30AB\u30A6\u30F3\u30C8\u30FB\u81EA\u5206\u306E\u30EA\u30DD\u30B9\u30C8",
      "Pending an authenticated fixture; controls stay disabled.": "\u8A8D\u8A3C\u6E08\u307F\u306E\u30D5\u30A3\u30AF\u30B9\u30C1\u30E3\u5F85\u3061\u306E\u305F\u3081\u3001\u3053\u306E\u8A2D\u5B9A\u306F\u7121\u52B9\u306E\u307E\u307E\u3067\u3059\u3002",
      "Hide dismissed posts": "\u9589\u3058\u305F\u6295\u7A3F\u3092\u975E\u8868\u793A",
      "Keep posts you hid collapsed so the next post rises to the top.": "\u975E\u8868\u793A\u306B\u3057\u305F\u6295\u7A3F\u3092\u6298\u308A\u305F\u305F\u3093\u3060\u307E\u307E\u306B\u3057\u3001\u6B21\u306E\u6295\u7A3F\u3092\u7E70\u308A\u4E0A\u3052\u307E\u3059\u3002",
      "Show hide buttons": "\u975E\u8868\u793A\u30DC\u30BF\u30F3\u3092\u8868\u793A",
      "Adds a Hide control to every post next to the More menu.": "\u5404\u6295\u7A3F\u306E\u300C\u3082\u3063\u3068\u898B\u308B\u300D\u30E1\u30CB\u30E5\u30FC\u306E\u6A2A\u306B\u975E\u8868\u793A\u30DC\u30BF\u30F3\u3092\u8FFD\u52A0\u3057\u307E\u3059\u3002",
      "Routes where hiding and the Hide button apply.": "\u975E\u8868\u793A\u6A5F\u80FD\u3068\u975E\u8868\u793A\u30DC\u30BF\u30F3\u3092\u9069\u7528\u3059\u308B\u30DA\u30FC\u30B8\u3002",
      "Maximum remembered posts": "\u8A18\u61B6\u3059\u308B\u6295\u7A3F\u306E\u4E0A\u9650",
      "Oldest entries are dropped once the store passes this size (100-50000).": "\u3053\u306E\u4EF6\u6570\uFF08100\u301C50000\uFF09\u3092\u8D85\u3048\u308B\u3068\u53E4\u3044\u3082\u306E\u304B\u3089\u524A\u9664\u3055\u308C\u307E\u3059\u3002",
      "Save": "\u4FDD\u5B58",
      "Hidden posts stored": "\u4FDD\u5B58\u3055\u308C\u305F\u975E\u8868\u793A\u306E\u6295\u7A3F",
      "Undo last hide": "\u76F4\u524D\u306E\u975E\u8868\u793A\u3092\u53D6\u308A\u6D88\u3059",
      "Restores the most recently hidden post.": "\u6700\u5F8C\u306B\u975E\u8868\u793A\u306B\u3057\u305F\u6295\u7A3F\u3092\u5143\u306B\u623B\u3057\u307E\u3059\u3002",
      "Restore": "\u5143\u306B\u623B\u3059",
      "Clear hidden posts": "\u975E\u8868\u793A\u306E\u6295\u7A3F\u3092\u6D88\u53BB",
      "Forgets every hidden post and brings them all back.": "\u975E\u8868\u793A\u306B\u3057\u305F\u6295\u7A3F\u3092\u3059\u3079\u3066\u5FD8\u308C\u3001\u5143\u306B\u623B\u3057\u307E\u3059\u3002",
      "Show download buttons": "\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u30DC\u30BF\u30F3\u3092\u8868\u793A",
      "Inject Save and Thumb buttons over tweet photos and video thumbnails.": "\u6295\u7A3F\u306E\u5199\u771F\u3068\u52D5\u753B\u30B5\u30E0\u30CD\u30A4\u30EB\u306E\u4E0A\u306B\u300C\u4FDD\u5B58\u300D\u300C\u30B5\u30E0\u30CD\u300D\u30DC\u30BF\u30F3\u3092\u8FFD\u52A0\u3057\u307E\u3059\u3002",
      "Prefer original quality": "\u30AA\u30EA\u30B8\u30CA\u30EB\u753B\u8CEA\u3092\u512A\u5148",
      "Rewrite image URLs to name=orig before downloading.": "\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u524D\u306B\u753B\u50CF URL \u3092 name=orig \u306B\u66F8\u304D\u63DB\u3048\u307E\u3059\u3002",
      "Filename template": "\u30D5\u30A1\u30A4\u30EB\u540D\u306E\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
      "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.": "\u4F7F\u7528\u3067\u304D\u308B\u9805\u76EE: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}\u3002",
      "Duplicate history": "\u91CD\u8907\u306E\u5C65\u6B74",
      "Skip downloads of media you have already saved from this browser.": "\u3053\u306E\u30D6\u30E9\u30A6\u30B6\u3067\u4FDD\u5B58\u6E08\u307F\u306E\u30E1\u30C7\u30A3\u30A2\u306F\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u307E\u305B\u3093\u3002",
      "Sensitive content": "\u30BB\u30F3\u30B7\u30C6\u30A3\u30D6\u306A\u5185\u5BB9",
      "Default (X choice)": "\u30C7\u30D5\u30A9\u30EB\u30C8\uFF08X \u306E\u8A2D\u5B9A\uFF09",
      "Always reveal": "\u5E38\u306B\u8868\u793A",
      "Blur until hovered": "\u30DB\u30D0\u30FC\u3059\u308B\u307E\u3067\u307C\u304B\u3059",
      "Always hide": "\u5E38\u306B\u975E\u8868\u793A",
      "Media layout": "\u30E1\u30C7\u30A3\u30A2\u306E\u30EC\u30A4\u30A2\u30A6\u30C8",
      "Default grid": "\u30C7\u30D5\u30A9\u30EB\u30C8\u306E\u30B0\u30EA\u30C3\u30C9",
      "Stacked": "\u7E26\u7A4D\u307F",
      "Strict grid": "\u5747\u7B49\u30B0\u30EA\u30C3\u30C9",
      "Download status": "\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u306E\u72B6\u614B",
      "History entries": "\u5C65\u6B74\u306E\u4EF6\u6570",
      "Clear download history": "\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u5C65\u6B74\u3092\u6D88\u53BB",
      "Reset the local dedup index.": "\u30ED\u30FC\u30AB\u30EB\u306E\u91CD\u8907\u5224\u5B9A\u30A4\u30F3\u30C7\u30C3\u30AF\u30B9\u3092\u521D\u671F\u5316\u3057\u307E\u3059\u3002",
      "Download all visible media": "\u8868\u793A\u4E2D\u306E\u30E1\u30C7\u30A3\u30A2\u3092\u3059\u3079\u3066\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9",
      "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.": "\u73FE\u5728\u306E\u30DA\u30FC\u30B8\u306B\u8868\u793A\u3055\u308C\u3066\u3044\u308B\u6295\u7A3F\u3092\u3059\u3079\u3066\u8D70\u67FB\u3057\u3001\u5199\u771F\u30FB\u52D5\u753B\u30FBGIF\u30FB\u30B5\u30E0\u30CD\u30A4\u30EB\u3092\u65E2\u5B58\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u30AD\u30E5\u30FC\u306B\u8FFD\u52A0\u3057\u307E\u3059\u3002",
      "Capture visible tweets": "\u8868\u793A\u4E2D\u306E\u6295\u7A3F\u3092\u53CE\u96C6",
      "Accumulate tweets visible on the active page for the next export run.": "\u6B21\u56DE\u306E\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306B\u5099\u3048\u3066\u3001\u8868\u793A\u4E2D\u306E\u6295\u7A3F\u3092\u84C4\u7A4D\u3057\u307E\u3059\u3002",
      "Export formats": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u5F62\u5F0F",
      "Comma-separated list. Supported: json, csv, html, markdown, xlsx.": "\u30AB\u30F3\u30DE\u533A\u5207\u308A\u3067\u6307\u5B9A\u3057\u307E\u3059\u3002\u5BFE\u5FDC\u5F62\u5F0F: json, csv, html, markdown, xlsx\u3002",
      "Preserve raw payloads": "\u751F\u306E\u30EC\u30B9\u30DD\u30F3\u30B9\u3092\u4FDD\u5B58",
      "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.": "X \u304C\u3053\u306E\u30BF\u30D6\u306B\u8FD4\u3059 GraphQL \u306E\u751F\u30EC\u30B9\u30DD\u30F3\u30B9\u3082\u4FDD\u5B58\u3057\u3001\u3042\u3068\u304B\u3089\u518D\u89E3\u6790\u3067\u304D\u308B\u3088\u3046\u306B\u3057\u307E\u3059\u3002\u66F8\u304D\u8FBC\u3080\u524D\u306B\u30BB\u30C3\u30B7\u30E7\u30F3\u30C8\u30FC\u30AF\u30F3\u306F\u53D6\u308A\u9664\u304B\u308C\u307E\u3059\u3002",
      "Auto-discover query IDs": "\u30AF\u30A8\u30EA ID \u3092\u81EA\u52D5\u691C\u51FA",
      "Scan loaded scripts for X GraphQL operation IDs and cache them locally.": "\u8AAD\u307F\u8FBC\u307E\u308C\u305F\u30B9\u30AF\u30EA\u30D7\u30C8\u304B\u3089 X \u306E GraphQL \u64CD\u4F5C ID \u3092\u63A2\u3057\u3001\u30ED\u30FC\u30AB\u30EB\u306B\u4FDD\u5B58\u3057\u307E\u3059\u3002",
      "Save folder hint": "\u4FDD\u5B58\u5148\u30D5\u30A9\u30EB\u30C0",
      "Folder name (or path) used as the export ZIP root and download prefix.": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8 ZIP \u306E\u30EB\u30FC\u30C8\u304A\u3088\u3073\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u540D\u306E\u63A5\u982D\u8F9E\u306B\u4F7F\u3046\u30D5\u30A9\u30EB\u30C0\u540D\uFF08\u307E\u305F\u306F\u30D1\u30B9\uFF09\u3002",
      "Export status": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306E\u72B6\u614B",
      "Export visible tweets": "\u8868\u793A\u4E2D\u306E\u6295\u7A3F\u3092\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8",
      "Collect the currently rendered tweets and download a ZIP.": "\u8868\u793A\u4E2D\u306E\u6295\u7A3F\u3092\u96C6\u3081\u3066 ZIP \u3067\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u307E\u3059\u3002",
      "Copy diagnostics": "\u8A3A\u65AD\u60C5\u5831\u3092\u30B3\u30D4\u30FC",
      "Copy support diagnostics (version, route, recent log).": "\u30B5\u30DD\u30FC\u30C8\u7528\u306E\u8A3A\u65AD\u60C5\u5831\uFF08\u30D0\u30FC\u30B8\u30E7\u30F3\u30FB\u30EB\u30FC\u30C8\u30FB\u76F4\u8FD1\u306E\u30ED\u30B0\uFF09\u3092\u30B3\u30D4\u30FC\u3057\u307E\u3059\u3002",
      "Download as WARC": "WARC \u3067\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9",
      "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.": "\u53CE\u96C6\u3057\u305F\u8A18\u9332\u3092 ISO-28500 \u306E WARC \u30D5\u30A1\u30A4\u30EB\u306B\u307E\u3068\u3081\u3001\u7814\u7A76\u30FB\u4FDD\u5B58\u30C4\u30FC\u30EB\u3067\u6271\u3048\u308B\u3088\u3046\u306B\u3057\u307E\u3059\u3002",
      "Copy as Markdown": "Markdown \u3068\u3057\u3066\u30B3\u30D4\u30FC",
      "Push a plain Markdown export onto the clipboard.": "\u30D7\u30EC\u30FC\u30F3\u306A Markdown \u3092\u30AF\u30EA\u30C3\u30D7\u30DC\u30FC\u30C9\u306B\u30B3\u30D4\u30FC\u3057\u307E\u3059\u3002",
      "Save Obsidian Markdown": "Obsidian \u7528 Markdown \u3092\u4FDD\u5B58",
      "Markdown with YAML frontmatter and Aviary tags.": "YAML \u30D5\u30ED\u30F3\u30C8\u30DE\u30BF\u30FC\u3068 Aviary \u306E\u30BF\u30B0\u3092\u542B\u3080 Markdown\u3002",
      "Save Notion Markdown": "Notion \u7528 Markdown \u3092\u4FDD\u5B58",
      "Heading-first Markdown that Notion imports cleanly.": "Notion \u304C\u304D\u308C\u3044\u306B\u53D6\u308A\u8FBC\u3081\u308B\u3001\u898B\u51FA\u3057\u4E2D\u5FC3\u306E Markdown\u3002",
      "Save records JSON": "\u8A18\u9332\u3092 JSON \u3067\u4FDD\u5B58",
      "Raw ExportRecord[] JSON without ZIP wrapping.": "ZIP \u306B\u307E\u3068\u3081\u306A\u3044\u3001\u751F\u306E ExportRecord[] JSON\u3002",
      "Records per ZIP": "ZIP \u3042\u305F\u308A\u306E\u4EF6\u6570",
      "Split a long export across several archives instead of one huge file (25-1000).": "\u5927\u91CF\u306E\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3092 1 \u3064\u306E\u5DE8\u5927\u306A\u30D5\u30A1\u30A4\u30EB\u306B\u305B\u305A\u3001\u8907\u6570\u306E\u66F8\u5EAB\u306B\u5206\u5272\u3057\u307E\u3059\uFF0825\u301C1000\uFF09\u3002",
      "Maximum export jobs": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u30B8\u30E7\u30D6\u306E\u4E0A\u9650",
      "Keep the newest jobs. Use 0 for unlimited.": "\u65B0\u3057\u3044\u30B8\u30E7\u30D6\u3092\u6B8B\u3057\u307E\u3059\u30020 \u3067\u7121\u5236\u9650\u3002",
      "Maximum records per job": "\u30B8\u30E7\u30D6\u3054\u3068\u306E\u8A18\u9332\u306E\u4E0A\u9650",
      "Keep the newest records in each job. Use 0 for unlimited.": "\u5404\u30B8\u30E7\u30D6\u306E\u65B0\u3057\u3044\u8A18\u9332\u3092\u6B8B\u3057\u307E\u3059\u30020 \u3067\u7121\u5236\u9650\u3002",
      "Maximum export age (days)": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306E\u4FDD\u6301\u65E5\u6570",
      "Remove older jobs at boot. Use 0 to disable age-based cleanup.": "\u8D77\u52D5\u6642\u306B\u53E4\u3044\u30B8\u30E7\u30D6\u3092\u524A\u9664\u3057\u307E\u3059\u30020 \u3067\u65E5\u6570\u306B\u3088\u308B\u524A\u9664\u3092\u7121\u52B9\u5316\u3002",
      "Unshorten t.co links": "t.co \u30EA\u30F3\u30AF\u3092\u5C55\u958B",
      "Replace short `t.co` redirects with the destination from aria-labels and titles.": "\u77ED\u7E2E\u3055\u308C\u305F `t.co` \u306E\u30EA\u30F3\u30AF\u3092\u3001aria-label \u3084 title \u306B\u3042\u308B\u5B9F\u969B\u306E URL \u306B\u7F6E\u304D\u63DB\u3048\u307E\u3059\u3002",
      "Clean tracking from links": "\u30EA\u30F3\u30AF\u304B\u3089\u30C8\u30E9\u30C3\u30AD\u30F3\u30B0\u3092\u9664\u53BB",
      "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.": "\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306E\u30EA\u30F3\u30AF\u304B\u3089\u5171\u6709\u30C8\u30FC\u30AF\u30F3\u3068\u30AD\u30E3\u30F3\u30DA\u30FC\u30F3\u7528\u30D1\u30E9\u30E1\u30FC\u30BF\uFF08utm_*\u3001fbclid\u3001X \u72EC\u81EA\u306E t/s\uFF09\u3092\u53D6\u308A\u9664\u304D\u3001\u30B3\u30D4\u30FC\u3057\u305F\u5185\u5BB9\u304C\u7D20\u306E\u30A2\u30C9\u30EC\u30B9\u306B\u306A\u308B\u3088\u3046\u306B\u3057\u307E\u3059\u3002",
      "Account notes": "\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30E1\u30E2",
      "Format: handle: note. One per line. Empty notes remove the entry.": "\u5F62\u5F0F: \u30A2\u30AB\u30A6\u30F3\u30C8\u540D: \u30E1\u30E2\u30021 \u884C\u306B 1 \u3064\u3002\u30E1\u30E2\u3092\u7A7A\u306B\u3059\u308B\u3068\u524A\u9664\u3055\u308C\u307E\u3059\u3002",
      "Clear all account notes": "\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30E1\u30E2\u3092\u3059\u3079\u3066\u6D88\u53BB",
      "Drop every persisted note.": "\u4FDD\u5B58\u3055\u308C\u3066\u3044\u308B\u30E1\u30E2\u3092\u3059\u3079\u3066\u524A\u9664\u3057\u307E\u3059\u3002",
      "Composer snippets": "\u5B9A\u578B\u6587",
      "One snippet per line. Reusable replies / templates (insertion landing in a later release).": "1 \u884C\u306B 1 \u3064\u3002\u4F7F\u3044\u56DE\u305B\u308B\u8FD4\u4FE1\u3084\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u3067\u3059\uFF08\u633F\u5165\u6A5F\u80FD\u306F\u4ECA\u5F8C\u306E\u30EA\u30EA\u30FC\u30B9\u3067\u5BFE\u5FDC\uFF09\u3002",
      "Snapshots stored": "\u4FDD\u5B58\u3055\u308C\u305F\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8",
      "Capture followers from this view": "\u3053\u306E\u753B\u9762\u304B\u3089\u30D5\u30A9\u30ED\u30EF\u30FC\u3092\u53D6\u5F97",
      "Walks UserCell rows on the current page. Open a /handle/followers view first.": "\u73FE\u5728\u306E\u30DA\u30FC\u30B8\u306E UserCell \u884C\u3092\u8D70\u67FB\u3057\u307E\u3059\u3002\u5148\u306B /\u30A2\u30AB\u30A6\u30F3\u30C8\u540D/followers \u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",
      "Capture following from this view": "\u3053\u306E\u753B\u9762\u304B\u3089\u30D5\u30A9\u30ED\u30FC\u4E2D\u3092\u53D6\u5F97",
      "Walks UserCell rows on the current page. Open a /handle/following view first.": "\u73FE\u5728\u306E\u30DA\u30FC\u30B8\u306E UserCell \u884C\u3092\u8D70\u67FB\u3057\u307E\u3059\u3002\u5148\u306B /\u30A2\u30AB\u30A6\u30F3\u30C8\u540D/following \u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",
      "Clear all snapshots": "\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u3092\u3059\u3079\u3066\u6D88\u53BB",
      "Drop every stored follower/following snapshot.": "\u4FDD\u5B58\u6E08\u307F\u306E\u30D5\u30A9\u30ED\u30EF\u30FC\u30FB\u30D5\u30A9\u30ED\u30FC\u4E2D\u306E\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u3092\u3059\u3079\u3066\u524A\u9664\u3057\u307E\u3059\u3002",
      "Download Markdown report": "Markdown \u30EC\u30DD\u30FC\u30C8\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9",
      "Audit log + snapshot diff + cleanup preview.": "\u76E3\u67FB\u30ED\u30B0\u30FB\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u306E\u5DEE\u5206\u30FB\u6574\u7406\u306E\u30D7\u30EC\u30D3\u30E5\u30FC\u3002",
      "Cleanup review queue": "\u6574\u7406\u306E\u78BA\u8A8D\u30AD\u30E5\u30FC",
      "Destructive actions": "\u7834\u58CA\u7684\u306A\u64CD\u4F5C",
      "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log.": "Aviary \u306F\u6295\u7A3F\u30FB\u3044\u3044\u306D\u30FB\u30D5\u30A9\u30ED\u30FC\u3092\u524A\u9664\u3057\u307E\u305B\u3093\u3002\u3053\u306E\u30AD\u30E5\u30FC\u306F\u78BA\u8A8D\u7528\u306E\u4E00\u89A7\u3067\u3001\u627F\u8A8D\u3084\u30B9\u30AD\u30C3\u30D7\u306F\u76E3\u67FB\u30ED\u30B0\u306B\u8A18\u9332\u3055\u308C\u308B\u3060\u3051\u3067\u3059\u3002",
      "Enqueue cleanup preview for review": "\u6574\u7406\u306E\u30D7\u30EC\u30D3\u30E5\u30FC\u3092\u30AD\u30E5\u30FC\u306B\u8FFD\u52A0",
      "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).": "\u76F4\u8FD1\u306E\u6574\u7406\u30D7\u30EC\u30D3\u30E5\u30FC\u304B\u3089\u3001\u4FDD\u8B77\u3055\u308C\u3066\u3044\u306A\u3044\u5019\u88DC\u3092\u3059\u3079\u3066\u30AD\u30E5\u30FC\u306B\u8FFD\u52A0\u3057\u307E\u3059\uFF08\u7834\u58CA\u7684\u306A\u64CD\u4F5C\u306F\u884C\u3044\u307E\u305B\u3093\uFF09\u3002",
      "Clear cleanup queue": "\u6574\u7406\u30AD\u30E5\u30FC\u3092\u7A7A\u306B\u3059\u308B",
      "Drop every queued item without touching account data.": "\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30C7\u30FC\u30BF\u306B\u89E6\u308C\u305A\u306B\u3001\u30AD\u30E5\u30FC\u306E\u9805\u76EE\u3092\u3059\u3079\u3066\u524A\u9664\u3057\u307E\u3059\u3002",
      "Aria2 handoff": "Aria2 \u3078\u306E\u53D7\u3051\u6E21\u3057",
      "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.": "\u5927\u304D\u306A\u30E1\u30C7\u30A3\u30A2\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3092\u3001\u81EA\u5206\u3067\u7528\u610F\u3057\u305F Aria2 \u306E JSON-RPC \u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u306B\u6E21\u3057\u307E\u3059\u3002",
      "Aria2 endpoint": "Aria2 \u306E\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8",
      "http://localhost:6800 (no trailing slash needed)": "http://localhost:6800\uFF08\u672B\u5C3E\u306E\u30B9\u30E9\u30C3\u30B7\u30E5\u306F\u4E0D\u8981\uFF09",
      "Aria2 RPC secret": "Aria2 \u306E RPC \u30B7\u30FC\u30AF\u30EC\u30C3\u30C8",
      "Optional shared secret for token: auth.": "token: \u8A8D\u8A3C\u306B\u4F7F\u3046\u5171\u6709\u30B7\u30FC\u30AF\u30EC\u30C3\u30C8\uFF08\u4EFB\u610F\uFF09\u3002",
      "Show": "\u8868\u793A",
      "Test Aria2 connection": "Aria2 \u306E\u63A5\u7D9A\u3092\u78BA\u8A8D",
      "Sends a trivial JSON-RPC call.": "\u7C21\u5358\u306A JSON-RPC \u547C\u3073\u51FA\u3057\u3092\u9001\u4FE1\u3057\u307E\u3059\u3002",
      "Refresh": "\u66F4\u65B0",
      "Bluesky crosspost": "Bluesky \u3078\u306E\u30AF\u30ED\u30B9\u30DD\u30B9\u30C8",
      "Post composer text to your Bluesky account on demand.": "\u6295\u7A3F\u6B04\u306E\u30C6\u30AD\u30B9\u30C8\u3092\u3001\u5FC5\u8981\u306A\u3068\u304D\u306B Bluesky \u3078\u6295\u7A3F\u3057\u307E\u3059\u3002",
      "Bluesky service URL": "Bluesky \u306E\u30B5\u30FC\u30D3\u30B9 URL",
      "Default: https://bsky.social": "\u65E2\u5B9A\u5024: https://bsky.social",
      "Bluesky handle": "Bluesky \u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u540D",
      "Your handle (no @, e.g. you.bsky.social)": "\u81EA\u5206\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u540D\uFF08@ \u306A\u3057\u3001\u4F8B: you.bsky.social\uFF09",
      "Bluesky app password": "Bluesky \u306E\u30A2\u30D7\u30EA\u30D1\u30B9\u30EF\u30FC\u30C9",
      "App password from your account settings \u2014 never your main password.": "\u30A2\u30AB\u30A6\u30F3\u30C8\u8A2D\u5B9A\u3067\u767A\u884C\u3057\u305F\u30A2\u30D7\u30EA\u30D1\u30B9\u30EF\u30FC\u30C9\u3002\u30E1\u30A4\u30F3\u306E\u30D1\u30B9\u30EF\u30FC\u30C9\u306F\u4F7F\u308F\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u3002",
      "Mastodon crosspost": "Mastodon \u3078\u306E\u30AF\u30ED\u30B9\u30DD\u30B9\u30C8",
      "Post composer text to your Mastodon account on demand.": "\u6295\u7A3F\u6B04\u306E\u30C6\u30AD\u30B9\u30C8\u3092\u3001\u5FC5\u8981\u306A\u3068\u304D\u306B Mastodon \u3078\u6295\u7A3F\u3057\u307E\u3059\u3002",
      "Mastodon instance": "Mastodon \u306E\u30A4\u30F3\u30B9\u30BF\u30F3\u30B9",
      "https://mastodon.social": "https://mastodon.social",
      "Mastodon access token": "Mastodon \u306E\u30A2\u30AF\u30BB\u30B9\u30C8\u30FC\u30AF\u30F3",
      "Bearer token with write:statuses scope.": "write:statuses \u30B9\u30B3\u30FC\u30D7\u3092\u6301\u3064\u30D9\u30A2\u30E9\u30FC\u30C8\u30FC\u30AF\u30F3\u3002",
      "Attach last download": "\u76F4\u8FD1\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3092\u6DFB\u4ED8",
      "Upload the last successful Aviary media download with the first post in an explicit crosspost.": "\u30AF\u30ED\u30B9\u30DD\u30B9\u30C8\u306E\u6700\u521D\u306E\u6295\u7A3F\u306B\u3001Aviary \u3067\u6700\u5F8C\u306B\u6210\u529F\u3057\u305F\u30E1\u30C7\u30A3\u30A2\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3092\u6DFB\u4ED8\u3057\u307E\u3059\u3002",
      "Crosspost composer \u2192 Bluesky": "\u6295\u7A3F\u6B04\u3092 Bluesky \u3078",
      "Uses the current composer text.": "\u73FE\u5728\u306E\u6295\u7A3F\u6B04\u306E\u30C6\u30AD\u30B9\u30C8\u3092\u4F7F\u3044\u307E\u3059\u3002",
      "Crosspost composer \u2192 Mastodon": "\u6295\u7A3F\u6B04\u3092 Mastodon \u3078",
      "AI provider runs": "AI \u30D7\u30ED\u30D0\u30A4\u30C0\u306E\u5B9F\u884C",
      "Let the AI command menu POST prompts to your configured provider.": "AI \u30B3\u30DE\u30F3\u30C9\u30E1\u30CB\u30E5\u30FC\u304B\u3089\u3001\u8A2D\u5B9A\u3057\u305F\u30D7\u30ED\u30D0\u30A4\u30C0\u306B\u30D7\u30ED\u30F3\u30D7\u30C8\u3092\u9001\u4FE1\u3067\u304D\u308B\u3088\u3046\u306B\u3057\u307E\u3059\u3002",
      "AI provider": "AI \u30D7\u30ED\u30D0\u30A4\u30C0",
      "Anthropic Messages API": "Anthropic Messages API",
      "OpenAI Chat Completions": "OpenAI Chat Completions",
      "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)": "OpenAI \u4E92\u63DB\uFF08LocalAI\u3001Ollama \u30D7\u30ED\u30AD\u30B7\u306A\u3069\uFF09",
      "AI endpoint (optional)": "AI \u306E\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\uFF08\u4EFB\u610F\uFF09",
      "Override the default endpoint for the chosen provider.": "\u9078\u629E\u3057\u305F\u30D7\u30ED\u30D0\u30A4\u30C0\u306E\u65E2\u5B9A\u306E\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u3092\u4E0A\u66F8\u304D\u3057\u307E\u3059\u3002",
      "AI model": "AI \u30E2\u30C7\u30EB",
      "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b": "\u4F8B: claude-sonnet-4-6, gpt-4o, llama3.1:8b",
      "AI API key": "AI \u306E API \u30AD\u30FC",
      "Stored locally only. Aviary never sends this except as the auth header to your provider.": "\u30ED\u30FC\u30AB\u30EB\u306B\u306E\u307F\u4FDD\u5B58\u3055\u308C\u307E\u3059\u3002Aviary \u306F\u3001\u8A2D\u5B9A\u3057\u305F\u30D7\u30ED\u30D0\u30A4\u30C0\u3078\u306E\u8A8D\u8A3C\u30D8\u30C3\u30C0\u30FC\u4EE5\u5916\u306B\u3053\u308C\u3092\u9001\u4FE1\u3057\u307E\u305B\u3093\u3002",
      "Semantic search": "\u30BB\u30DE\u30F3\u30C6\u30A3\u30C3\u30AF\u691C\u7D22",
      "Embed CheckpointStore records via your provider for similarity search.": "\u985E\u4F3C\u691C\u7D22\u306E\u305F\u3081\u306B\u3001CheckpointStore \u306E\u8A18\u9332\u3092\u30D7\u30ED\u30D0\u30A4\u30C0\u3067\u57CB\u3081\u8FBC\u307F\u30D9\u30AF\u30C8\u30EB\u5316\u3057\u307E\u3059\u3002",
      "Embedding endpoint": "\u57CB\u3081\u8FBC\u307F\u306E\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8",
      "POST endpoint that returns {data: [{embedding: number[]}]}": "{data: [{embedding: number[]}]} \u3092\u8FD4\u3059 POST \u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8",
      "Embedding model": "\u57CB\u3081\u8FBC\u307F\u30E2\u30C7\u30EB",
      "e.g. text-embedding-3-small": "\u4F8B: text-embedding-3-small",
      "Embedding API key": "\u57CB\u3081\u8FBC\u307F\u306E API \u30AD\u30FC",
      "Stored locally; used only as the Authorization header.": "\u30ED\u30FC\u30AB\u30EB\u306B\u4FDD\u5B58\u3055\u308C\u3001Authorization \u30D8\u30C3\u30C0\u30FC\u3068\u3057\u3066\u306E\u307F\u4F7F\u308F\u308C\u307E\u3059\u3002",
      "Auto-embed every export": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3054\u3068\u306B\u81EA\u52D5\u3067\u57CB\u3081\u8FBC\u307F",
      "After each export run, kick the embedding job in the background. Off by default.": "\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306E\u305F\u3073\u306B\u3001\u57CB\u3081\u8FBC\u307F\u51E6\u7406\u3092\u30D0\u30C3\u30AF\u30B0\u30E9\u30A6\u30F3\u30C9\u3067\u958B\u59CB\u3057\u307E\u3059\u3002\u65E2\u5B9A\u306F\u30AA\u30D5\u3067\u3059\u3002",
      "Rebuild semantic index": "\u30BB\u30DE\u30F3\u30C6\u30A3\u30C3\u30AF\u7D22\u5F15\u3092\u518D\u69CB\u7BC9",
      "Embed every captured record. Re-running is cheap because cached entries are skipped.": "\u53CE\u96C6\u3057\u305F\u3059\u3079\u3066\u306E\u8A18\u9332\u3092\u57CB\u3081\u8FBC\u307F\u307E\u3059\u3002\u30AD\u30E3\u30C3\u30B7\u30E5\u6E08\u307F\u306F\u98DB\u3070\u3059\u306E\u3067\u3001\u518D\u5B9F\u884C\u306E\u8CA0\u8377\u306F\u5C0F\u3055\u3044\u3067\u3059\u3002",
      "Clear semantic index": "\u30BB\u30DE\u30F3\u30C6\u30A3\u30C3\u30AF\u7D22\u5F15\u3092\u6D88\u53BB",
      "Forget every embedded record.": "\u57CB\u3081\u8FBC\u307F\u6E08\u307F\u306E\u8A18\u9332\u3092\u3059\u3079\u3066\u5FD8\u308C\u307E\u3059\u3002",
      "Integration status": "\u9023\u643A\u306E\u72B6\u614B",
      "Export settings": "\u8A2D\u5B9A\u3092\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8",
      "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.": "\u8A2D\u5B9A\u3092 JSON \u3067\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u307E\u3059\u3002API \u30AD\u30FC\u3068\u30D1\u30B9\u30EF\u30FC\u30C9\u306F\u30D7\u30EC\u30FC\u30B9\u30DB\u30EB\u30C0\u306B\u7F6E\u304D\u63DB\u308F\u308B\u305F\u3081\u5171\u6709\u3057\u3066\u3082\u5B89\u5168\u3067\u3059\u3002\u3053\u3053\u3067\u8AAD\u307F\u8FBC\u3080\u5834\u5408\u3001\u3053\u306E\u7AEF\u672B\u306B\u4FDD\u5B58\u6E08\u307F\u306E\u8A8D\u8A3C\u60C5\u5831\u306F\u305D\u306E\u307E\u307E\u7DAD\u6301\u3055\u308C\u307E\u3059\u3002",
      "Import settings (JSON)": "\u8A2D\u5B9A\u3092\u30A4\u30F3\u30DD\u30FC\u30C8\uFF08JSON\uFF09",
      "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.": "Aviary \u304B\u3089\u66F8\u304D\u51FA\u3057\u305F\u8A2D\u5B9A\u30D5\u30A1\u30A4\u30EB\u3092\u8CBC\u308A\u4ED8\u3051\u3066\u300C\u30A4\u30F3\u30DD\u30FC\u30C8\u300D\u3092\u9078\u3073\u307E\u3059\u3002\u4F0F\u305B\u5B57\u306E\u8A8D\u8A3C\u60C5\u5831\u306F\u3001\u3053\u3053\u306B\u4FDD\u5B58\u6E08\u307F\u306E\u5024\u304C\u4FDD\u305F\u308C\u307E\u3059\u3002",
      "Import": "\u30A4\u30F3\u30DD\u30FC\u30C8",
      "Keep a local action log": "\u30ED\u30FC\u30AB\u30EB\u306E\u64CD\u4F5C\u30ED\u30B0\u3092\u6B8B\u3059",
      "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.": "\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u30FB\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u30FB\u8A2D\u5B9A\u5909\u66F4\u3092\u3053\u306E\u7AEF\u672B\u306B\u8A18\u9332\u3057\u3001Aviary \u306E\u52D5\u4F5C\u3092\u3042\u3068\u304B\u3089\u78BA\u8A8D\u3067\u304D\u308B\u3088\u3046\u306B\u3057\u307E\u3059\u3002\u3069\u3053\u306B\u3082\u9001\u4FE1\u3055\u308C\u307E\u305B\u3093\u3002\u30AA\u30D5\u306B\u3059\u308B\u3068\u65B0\u3057\u3044\u8A18\u9332\u306F\u76F4\u3061\u306B\u505C\u6B62\u3057\u3001\u65E2\u5B58\u306E\u8A18\u9332\u306F\u6D88\u53BB\u3059\u308B\u307E\u3067\u6B8B\u308A\u307E\u3059\u3002",
      "Audit entries": "\u76E3\u67FB\u30ED\u30B0\u306E\u4EF6\u6570",
      "Clear audit log": "\u76E3\u67FB\u30ED\u30B0\u3092\u6D88\u53BB",
      "Drop the local action log.": "\u30ED\u30FC\u30AB\u30EB\u306E\u64CD\u4F5C\u30ED\u30B0\u3092\u524A\u9664\u3057\u307E\u3059\u3002",
      "Storage": "\u4FDD\u5B58\u5834\u6240",
      "Settings stay in this browser.": "\u8A2D\u5B9A\u306F\u3053\u306E\u30D6\u30E9\u30A6\u30B6\u5185\u306B\u7559\u307E\u308A\u307E\u3059\u3002",
      "Local-only mode": "\u30ED\u30FC\u30AB\u30EB\u9650\u5B9A\u30E2\u30FC\u30C9",
      "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.": "\u8A2D\u5B9A\u3057\u305F\u9023\u643A\u3092\u542B\u3081\u3001\u5916\u90E8\u3078\u306E\u3059\u3079\u3066\u306E\u901A\u4FE1\u3092\u30D6\u30ED\u30C3\u30AF\u3057\u307E\u3059\u3002\u65E2\u5B9A\u3067\u30AA\u30F3\u3067\u3001\u9023\u643A\u3092\u30AA\u30F3\u306B\u3059\u308B\u3068\u3053\u308C\u304C\u30AA\u30D5\u306B\u306A\u308A\u307E\u3059\u3002",
      "Some changes could not be saved \u2014 the browser store may be full.": "\u4E00\u90E8\u306E\u5909\u66F4\u3092\u4FDD\u5B58\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u30D6\u30E9\u30A6\u30B6\u306E\u4FDD\u5B58\u9818\u57DF\u304C\u3044\u3063\u3071\u3044\u306E\u53EF\u80FD\u6027\u304C\u3042\u308A\u307E\u3059\u3002",
      "Saving": "\u4FDD\u5B58",
      "Telemetry": "\u30C6\u30EC\u30E1\u30C8\u30EA",
      "Disabled": "\u7121\u52B9",
      "Panel language": "\u30D1\u30CD\u30EB\u306E\u8A00\u8A9E",
      "Selector health": "\u30BB\u30EC\u30AF\u30BF\u306E\u72B6\u614B",
      "Working \u2014 every change has been written.": "\u6B63\u5E38\u3067\u3059\u3002\u3059\u3079\u3066\u306E\u5909\u66F4\u304C\u4FDD\u5B58\u3055\u308C\u3066\u3044\u307E\u3059\u3002",
      "Monitoring active": "\u76E3\u8996\u4E2D",
      "Preset packs unavailable in this build.": "\u3053\u306E\u30D3\u30EB\u30C9\u3067\u306F\u30D7\u30EA\u30BB\u30C3\u30C8\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002",
      "Hidden post store unavailable in this build.": "\u3053\u306E\u30D3\u30EB\u30C9\u3067\u306F\u975E\u8868\u793A\u6295\u7A3F\u306E\u4FDD\u5B58\u6A5F\u80FD\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002",
      "Cancel": "\u30AD\u30E3\u30F3\u30BB\u30EB"
    },
    ko: {
      "Aviary": "Aviary",
      "Local controls for a quieter X.": "\uC870\uC6A9\uD55C X\uB97C \uC704\uD55C \uB85C\uCEEC \uC124\uC815.",
      "Close": "\uB2EB\uAE30",
      "Search settings": "\uC124\uC815 \uAC80\uC0C9",
      "Saved locally": "\uB85C\uCEEC\uC5D0 \uC800\uC7A5\uB428",
      "Settings sections": "\uC124\uC815 \uC139\uC158",
      "Start": "\uC2DC\uC791",
      "Presets": "\uD504\uB9AC\uC14B",
      "Reading": "\uC77D\uAE30",
      "Appearance": "\uBAA8\uC591",
      "Layout": "\uB808\uC774\uC544\uC6C3",
      "Filtering": "\uD544\uD130",
      "Hidden posts": "\uC228\uAE34 \uAC8C\uC2DC\uBB3C",
      "Data": "\uB370\uC774\uD130",
      "Media": "\uBBF8\uB514\uC5B4",
      "Export": "\uB0B4\uBCF4\uB0B4\uAE30",
      "Library": "\uB77C\uC774\uBE0C\uB7EC\uB9AC",
      "Snapshots & Archive": "\uC2A4\uB0C5\uC0F7 \uBC0F \uBCF4\uAD00",
      "Advanced": "\uACE0\uAE09",
      "Integrations": "\uC5F0\uB3D9",
      "Backup & Audit": "\uBC31\uC5C5 \uBC0F \uAC10\uC0AC",
      "Trust": "\uAC1C\uC778\uC815\uBCF4",
      "Apply": "\uC801\uC6A9",
      "Locale": "\uC5B8\uC5B4",
      "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.": "\uD328\uB110\uC744 \uBC88\uC5ED\uD558\uACE0 \uC77D\uB294 \uBC29\uD5A5\uC744 \uC124\uC815\uD569\uB2C8\uB2E4(\uC544\uB78D\uC5B4\uC640 \uD788\uBE0C\uB9AC\uC5B4\uB294 \uC624\uB978\uCABD\uC5D0\uC11C \uC67C\uCABD). '\uAC1C\uC778\uC815\uBCF4'\uC5D0 \uC120\uD0DD\uD55C \uC5B8\uC5B4\uC758 \uBC88\uC5ED \uC815\uB3C4\uAC00 \uD45C\uC2DC\uB418\uBA70, \uBE60\uC9C4 \uD56D\uBAA9\uC740 \uC601\uC5B4\uB85C \uB0A8\uC2B5\uB2C8\uB2E4.",
      "Theme value is not supported.": "\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uD14C\uB9C8\uC785\uB2C8\uB2E4.",
      "Theme updated": "\uD14C\uB9C8\uB97C \uBCC0\uACBD\uD588\uC2B5\uB2C8\uB2E4",
      "Density updated": "\uD45C\uC2DC \uBC00\uB3C4\uB97C \uBCC0\uACBD\uD588\uC2B5\uB2C8\uB2E4",
      "Contrast preference saved": "\uB300\uBE44 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Motion preference saved": "\uBAA8\uC158 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Sidebar preference saved": "\uC0AC\uC774\uB4DC\uBC14 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Trend preference saved": "\uD2B8\uB80C\uB4DC \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Grok preference saved": "Grok \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Could not apply preset.": "\uD504\uB9AC\uC14B\uC744 \uC801\uC6A9\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Snapshot failed.": "\uC2A4\uB0C5\uC0F7\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.",
      "Snapshots cleared": "\uC2A4\uB0C5\uC0F7\uC744 \uC9C0\uC6E0\uC2B5\uB2C8\uB2E4",
      "Could not clear snapshots.": "\uC2A4\uB0C5\uC0F7\uC744 \uC9C0\uC6B0\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Reading archive \u2014 large files take a moment\u2026": "\uBCF4\uAD00 \uD30C\uC77C\uC744 \uC77D\uB294 \uC911 \u2014 \uD070 \uD30C\uC77C\uC740 \uC2DC\uAC04\uC774 \uAC78\uB9BD\uB2C8\uB2E4\u2026",
      "Archive import failed.": "\uBCF4\uAD00 \uD30C\uC77C \uAC00\uC838\uC624\uAE30\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.",
      "Building report\u2026": "\uBCF4\uACE0\uC11C\uB97C \uB9CC\uB4DC\uB294 \uC911\u2026",
      "Report downloaded.": "\uBCF4\uACE0\uC11C\uB97C \uB0B4\uB824\uBC1B\uC558\uC2B5\uB2C8\uB2E4.",
      "Could not build report.": "\uBCF4\uACE0\uC11C\uB97C \uB9CC\uB4E4\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Building cleanup preview\u2026": "\uC815\uB9AC \uBBF8\uB9AC\uBCF4\uAE30\uB97C \uB9CC\uB4DC\uB294 \uC911\u2026",
      "Could not enqueue cleanup.": "\uC815\uB9AC\uB97C \uB300\uAE30\uC5F4\uC5D0 \uB123\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Cleanup queue cleared": "\uC815\uB9AC \uB300\uAE30\uC5F4\uC744 \uBE44\uC6E0\uC2B5\uB2C8\uB2E4",
      "Could not clear queue.": "\uB300\uAE30\uC5F4\uC744 \uBE44\uC6B0\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Aria2 endpoint saved": "Aria2 \uC5D4\uB4DC\uD3EC\uC778\uD2B8\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Aria2 secret saved": "Aria2 \uC2DC\uD06C\uB9BF\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Aria2 sweep failed.": "Aria2 \uBAA9\uB85D\uC744 \uAC00\uC838\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Bluesky service saved": "Bluesky \uC11C\uBE44\uC2A4\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Bluesky handle saved": "Bluesky \uACC4\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Bluesky app password saved": "Bluesky \uC571 \uBE44\uBC00\uBC88\uD638\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Mastodon instance saved": "Mastodon \uC778\uC2A4\uD134\uC2A4\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Mastodon token saved": "Mastodon \uD1A0\uD070\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "AI endpoint saved": "AI \uC5D4\uB4DC\uD3EC\uC778\uD2B8\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "AI model saved": "AI \uBAA8\uB378\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "AI API key saved": "AI API \uD0A4\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Embedding endpoint saved": "\uC784\uBCA0\uB529 \uC5D4\uB4DC\uD3EC\uC778\uD2B8\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Embedding model saved": "\uC784\uBCA0\uB529 \uBAA8\uB378\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Embedding API key saved": "\uC784\uBCA0\uB529 API \uD0A4\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Rebuilding semantic index\u2026": "\uC758\uBBF8 \uC0C9\uC778\uC744 \uB2E4\uC2DC \uB9CC\uB4DC\uB294 \uC911\u2026",
      "Embedding failed.": "\uC784\uBCA0\uB529\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.",
      "Semantic index cleared": "\uC758\uBBF8 \uC0C9\uC778\uC744 \uC9C0\uC6E0\uC2B5\uB2C8\uB2E4",
      "Account notes cleared": "\uACC4\uC815 \uBA54\uBAA8\uB97C \uC9C0\uC6E0\uC2B5\uB2C8\uB2E4",
      "Could not clear notes.": "\uBA54\uBAA8\uB97C \uC9C0\uC6B0\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Settings exported.": "\uC124\uC815\uC744 \uB0B4\uBCF4\uB0C8\uC2B5\uB2C8\uB2E4.",
      "Could not export settings.": "\uC124\uC815\uC744 \uB0B4\uBCF4\uB0B4\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Could not import settings.": "\uC124\uC815\uC744 \uAC00\uC838\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Audit log cleared": "\uAC10\uC0AC \uB85C\uADF8\uB97C \uC9C0\uC6E0\uC2B5\uB2C8\uB2E4",
      "Could not clear audit log.": "\uAC10\uC0AC \uB85C\uADF8\uB97C \uC9C0\uC6B0\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Raw payload preference saved": "\uC6D0\uBCF8 \uC751\uB2F5 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Query discovery preference saved": "\uCFFC\uB9AC \uAC80\uC0C9 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Save folder hint saved": "\uC800\uC7A5 \uD3F4\uB354\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Collecting visible posts\u2026": "\uD45C\uC2DC\uB41C \uAC8C\uC2DC\uBB3C\uC744 \uBAA8\uC73C\uB294 \uC911\u2026",
      "Export failed. See diagnostics.": "\uB0B4\uBCF4\uB0B4\uAE30\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4. \uC9C4\uB2E8 \uC815\uBCF4\uB97C \uD655\uC778\uD558\uC138\uC694.",
      "Diagnostics copied to clipboard.": "\uC9C4\uB2E8 \uC815\uBCF4\uB97C \uD074\uB9BD\uBCF4\uB4DC\uC5D0 \uBCF5\uC0AC\uD588\uC2B5\uB2C8\uB2E4.",
      "Could not copy diagnostics.": "\uC9C4\uB2E8 \uC815\uBCF4\uB97C \uBCF5\uC0AC\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Building WARC archive\u2026": "WARC \uBCF4\uAD00 \uD30C\uC77C\uC744 \uB9CC\uB4DC\uB294 \uC911\u2026",
      "WARC export failed.": "WARC \uB0B4\uBCF4\uB0B4\uAE30\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.",
      "External export failed.": "\uC678\uBD80 \uB0B4\uBCF4\uB0B4\uAE30\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.",
      "Records per ZIP saved": "ZIP\uB2F9 \uAE30\uB85D \uC218\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Export job retention saved": "\uB0B4\uBCF4\uB0B4\uAE30 \uC791\uC5C5 \uBCF4\uAD00 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Record retention saved": "\uAE30\uB85D \uBCF4\uAD00 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Age-based retention saved": "\uAE30\uAC04 \uAE30\uC900 \uBCF4\uAD00 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Original quality preference saved": "\uC6D0\uBCF8 \uD654\uC9C8 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Filename template saved": "\uD30C\uC77C \uC774\uB984 \uD15C\uD50C\uB9BF\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Sensitive content preference saved": "\uBBFC\uAC10\uD55C \uCF58\uD150\uCE20 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Media layout saved": "\uBBF8\uB514\uC5B4 \uBC30\uCE58\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "History cleared": "\uAE30\uB85D\uC744 \uC9C0\uC6E0\uC2B5\uB2C8\uB2E4",
      "Could not clear history.": "\uAE30\uB85D\uC744 \uC9C0\uC6B0\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Downloading media from this view\u2026": "\uC774 \uD654\uBA74\uC758 \uBBF8\uB514\uC5B4\uB97C \uB0B4\uB824\uBC1B\uB294 \uC911\u2026",
      "Batch download failed.": "\uC77C\uAD04 \uB2E4\uC6B4\uB85C\uB4DC\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.",
      "Premium filter saved": "\uD504\uB9AC\uBBF8\uC5C4 \uD544\uD130\uB97C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4",
      "Could not undo the last hide.": "\uB9C8\uC9C0\uB9C9 \uC228\uAE30\uAE30\uB97C \uCDE8\uC18C\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Could not restore the post.": "\uAC8C\uC2DC\uBB3C\uC744 \uBCF5\uC6D0\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Could not clear hidden posts.": "\uC228\uAE34 \uAC8C\uC2DC\uBB3C\uC744 \uC9C0\uC6B0\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.",
      "Saving...": "\uC800\uC7A5 \uC911...",
      "Could not save settings. Try again.": "\uC124\uC815\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uC2DC\uB3C4\uD558\uC138\uC694.",
      "Theme": "\uD14C\uB9C8",
      "Dim": "\uB524",
      "Lights out": "\uB77C\uC774\uD2B8 \uC544\uC6C3",
      "Graphite": "\uADF8\uB798\uD30C\uC774\uD2B8",
      "Plum": "\uD50C\uB7FC",
      "Midnight": "\uBBF8\uB4DC\uB098\uC774\uD2B8",
      "Dense mode": "\uACE0\uBC00\uB3C4 \uBAA8\uB4DC",
      "Tighten timeline spacing for scanning.": "\uD0C0\uC784\uB77C\uC778 \uAC04\uACA9\uC744 \uC881\uD600 \uD6D1\uC5B4\uBCF4\uAE30 \uC27D\uAC8C \uD569\uB2C8\uB2E4.",
      "Hide engagement counts": "\uBC18\uC751 \uC218 \uC228\uAE30\uAE30",
      "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.": "\uB2F5\uAE00\xB7\uC7AC\uAC8C\uC2DC\xB7\uB9C8\uC74C\uC5D0 \uB4E4\uC5B4\uC694 \uC218\uB97C \uC228\uAE41\uB2C8\uB2E4. \uBC84\uD2BC\uC740 \uADF8\uB300\uB85C \uC791\uB3D9\uD558\uACE0 \uC2A4\uD06C\uB9B0 \uB9AC\uB354\uB294 \uD569\uACC4\uB97C \uACC4\uC18D \uC77D\uC5B4 \uC90D\uB2C8\uB2E4.",
      "Hide row borders": "\uD589 \uACBD\uACC4\uC120 \uC228\uAE30\uAE30",
      "Remove the 1px divider under each timeline post and the primary column's side rules.": "\uAC01 \uAC8C\uC2DC\uBB3C \uC544\uB798\uC758 1px \uAD6C\uBD84\uC120\uACFC \uAE30\uBCF8 \uCE7C\uB7FC\uC758 \uC88C\uC6B0 \uC120\uC744 \uC5C6\uC571\uB2C8\uB2E4.",
      "High contrast": "\uACE0\uB300\uBE44",
      "Use stronger borders and text contrast.": "\uACBD\uACC4\uC120\uACFC \uAE00\uC790 \uB300\uBE44\uB97C \uAC15\uD558\uAC8C \uD569\uB2C8\uB2E4.",
      "Reduced motion": "\uBAA8\uC158 \uC904\uC774\uAE30",
      "Follow system setting": "\uC2DC\uC2A4\uD15C \uC124\uC815 \uB530\uB974\uAE30",
      "Always reduce": "\uD56D\uC0C1 \uC904\uC774\uAE30",
      "Never reduce": "\uC904\uC774\uC9C0 \uC54A\uAE30",
      "Hide right sidebar": "\uC624\uB978\uCABD \uC0AC\uC774\uB4DC\uBC14 \uC228\uAE30\uAE30",
      "Reduce trends, recommendations, and footer noise.": "\uD2B8\uB80C\uB4DC, \uCD94\uCC9C, \uD558\uB2E8 \uC601\uC5ED\uC758 \uC7A1\uC74C\uC744 \uC904\uC785\uB2C8\uB2E4.",
      "Hide trends": "\uD2B8\uB80C\uB4DC \uC228\uAE30\uAE30",
      "Remove trending topics and news modules.": "\uD2B8\uB80C\uB4DC\uC640 \uB274\uC2A4 \uBAA8\uB4C8\uC744 \uC5C6\uC571\uB2C8\uB2E4.",
      "Hide Grok surfaces": "Grok \uC694\uC18C \uC228\uAE30\uAE30",
      "Remove Grok drawer and composer buttons where detected.": "\uAC10\uC9C0\uB41C Grok \uC11C\uB78D\uACFC \uC791\uC131\uCC3D \uBC84\uD2BC\uC744 \uC5C6\uC571\uB2C8\uB2E4.",
      "Writer mode": "\uC9D1\uD544 \uBAA8\uB4DC",
      "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.": "\uC791\uC131\uCC3D\uC5D0 \uD3EC\uCEE4\uC2A4\uAC00 \uC788\uB294 \uB3D9\uC548 \uC0AC\uC774\uB4DC\uBC14\uC640 \uB4A4\uCABD \uD0C0\uC784\uB77C\uC778\uC744 \uD750\uB9AC\uAC8C \uD569\uB2C8\uB2E4. \uB2E4\uB978 \uACF3\uC744 \uD074\uB9AD\uD558\uBA74 \uC989\uC2DC \uB3CC\uC544\uC635\uB2C8\uB2E4.",
      "Enable filters": "\uD544\uD130 \uC0AC\uC6A9",
      "Master switch for keyword, regex, premium, and media filters.": "\uD0A4\uC6CC\uB4DC\xB7\uC815\uADDC\uC2DD\xB7\uD504\uB9AC\uBBF8\uC5C4\xB7\uBBF8\uB514\uC5B4 \uD544\uD130\uB97C \uD55C\uAEBC\uBC88\uC5D0 \uCF1C\uACE0 \uB055\uB2C8\uB2E4.",
      "Keyword rules": "\uD0A4\uC6CC\uB4DC \uADDC\uCE59",
      "One keyword or phrase per line. Case-insensitive substring match.": "\uD55C \uC904\uC5D0 \uD0A4\uC6CC\uB4DC\uB098 \uBB38\uAD6C \uD558\uB098\uC529. \uB300\uC18C\uBB38\uC790\uB97C \uAD6C\uBD84\uD558\uC9C0 \uC54A\uB294 \uBD80\uBD84 \uC77C\uCE58\uC785\uB2C8\uB2E4.",
      "Save list": "\uBAA9\uB85D \uC800\uC7A5",
      "Regex rules": "\uC815\uADDC\uC2DD \uADDC\uCE59",
      "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).": "\uD55C \uC904\uC5D0 \uD328\uD134 \uD558\uB098\uC529. /pattern/flags \uD615\uC2DD\uC774\uB098 \uD328\uD134\uB9CC \uC785\uB825\uD558\uC138\uC694(\uB300\uC18C\uBB38\uC790 \uAD6C\uBD84 \uC548 \uD568).",
      "Whitelist handles": "\uC81C\uC678\uD560 \uACC4\uC815",
      "Handles (one per line, no @) that are never filtered.": "\uD544\uD130\uC5D0\uC11C \uD56D\uC0C1 \uC81C\uC678\uD560 \uACC4\uC815(\uD55C \uC904\uC5D0 \uD558\uB098, @ \uC5C6\uC774).",
      "Premium / verified posts": "\uD504\uB9AC\uBBF8\uC5C4\xB7\uC778\uC99D \uAC8C\uC2DC\uBB3C",
      "Off": "\uB044\uAE30",
      "Hide": "\uC228\uAE30\uAE30",
      "Hide posts with photos": "\uC0AC\uC9C4\uC774 \uC788\uB294 \uAC8C\uC2DC\uBB3C \uC228\uAE30\uAE30",
      "Filter posts containing photos.": "\uC0AC\uC9C4\uC774 \uD3EC\uD568\uB41C \uAC8C\uC2DC\uBB3C\uC744 \uAC78\uB7EC\uB0C5\uB2C8\uB2E4.",
      "Hide posts with videos": "\uB3D9\uC601\uC0C1\uC774 \uC788\uB294 \uAC8C\uC2DC\uBB3C \uC228\uAE30\uAE30",
      "Filter posts containing videos.": "\uB3D9\uC601\uC0C1\uC774 \uD3EC\uD568\uB41C \uAC8C\uC2DC\uBB3C\uC744 \uAC78\uB7EC\uB0C5\uB2C8\uB2E4.",
      "Hide posts with gifs": "GIF\uAC00 \uC788\uB294 \uAC8C\uC2DC\uBB3C \uC228\uAE30\uAE30",
      "Filter posts containing gifs.": "GIF\uAC00 \uD3EC\uD568\uB41C \uAC8C\uC2DC\uBB3C\uC744 \uAC78\uB7EC\uB0C5\uB2C8\uB2E4.",
      "Active on": "\uC801\uC6A9 \uD398\uC774\uC9C0",
      "Routes where filters run.": "\uD544\uD130\uAC00 \uB3D9\uC791\uD560 \uD398\uC774\uC9C0.",
      "Home": "\uD648",
      "Status": "\uAC8C\uC2DC\uBB3C",
      "Profile": "\uD504\uB85C\uD544",
      "Search": "\uAC80\uC0C9",
      "Notifications": "\uC54C\uB9BC",
      "Messages": "\uBA54\uC2DC\uC9C0",
      "Blocked accounts / self-reposts": "\uCC28\uB2E8 \uACC4\uC815 \xB7 \uB0B4 \uC7AC\uAC8C\uC2DC",
      "Pending an authenticated fixture; controls stay disabled.": "\uC778\uC99D\uB41C \uD53D\uC2A4\uCC98\uAC00 \uC5C6\uC5B4 \uC774 \uC124\uC815\uC740 \uBE44\uD65C\uC131 \uC0C1\uD0DC\uC785\uB2C8\uB2E4.",
      "Hide dismissed posts": "\uB2EB\uC740 \uAC8C\uC2DC\uBB3C \uC228\uAE30\uAE30",
      "Keep posts you hid collapsed so the next post rises to the top.": "\uC228\uAE34 \uAC8C\uC2DC\uBB3C\uC744 \uC811\uC5B4 \uB450\uC5B4 \uB2E4\uC74C \uAC8C\uC2DC\uBB3C\uC774 \uC704\uB85C \uC62C\uB77C\uC624\uAC8C \uD569\uB2C8\uB2E4.",
      "Show hide buttons": "\uC228\uAE30\uAE30 \uBC84\uD2BC \uD45C\uC2DC",
      "Adds a Hide control to every post next to the More menu.": "\uAC01 \uAC8C\uC2DC\uBB3C\uC758 \uB354\uBCF4\uAE30 \uBA54\uB274 \uC606\uC5D0 \uC228\uAE30\uAE30 \uBC84\uD2BC\uC744 \uCD94\uAC00\uD569\uB2C8\uB2E4.",
      "Routes where hiding and the Hide button apply.": "\uC228\uAE30\uAE30 \uAE30\uB2A5\uACFC \uBC84\uD2BC\uC744 \uC801\uC6A9\uD560 \uD398\uC774\uC9C0.",
      "Maximum remembered posts": "\uAE30\uC5B5\uD560 \uAC8C\uC2DC\uBB3C \uCD5C\uB300 \uC218",
      "Oldest entries are dropped once the store passes this size (100-50000).": "\uC774 \uAC1C\uC218(100~50000)\uB97C \uB118\uC73C\uBA74 \uC624\uB798\uB41C \uD56D\uBAA9\uBD80\uD130 \uC0AD\uC81C\uB429\uB2C8\uB2E4.",
      "Save": "\uC800\uC7A5",
      "Hidden posts stored": "\uC800\uC7A5\uB41C \uC228\uAE34 \uAC8C\uC2DC\uBB3C",
      "Undo last hide": "\uB9C8\uC9C0\uB9C9 \uC228\uAE30\uAE30 \uCDE8\uC18C",
      "Restores the most recently hidden post.": "\uAC00\uC7A5 \uCD5C\uADFC\uC5D0 \uC228\uAE34 \uAC8C\uC2DC\uBB3C\uC744 \uB418\uB3CC\uB9BD\uB2C8\uB2E4.",
      "Restore": "\uBCF5\uC6D0",
      "Clear hidden posts": "\uC228\uAE34 \uAC8C\uC2DC\uBB3C \uC9C0\uC6B0\uAE30",
      "Forgets every hidden post and brings them all back.": "\uC228\uAE34 \uAC8C\uC2DC\uBB3C\uC744 \uBAA8\uB450 \uC78A\uACE0 \uB418\uB3CC\uB9BD\uB2C8\uB2E4.",
      "Show download buttons": "\uB2E4\uC6B4\uB85C\uB4DC \uBC84\uD2BC \uD45C\uC2DC",
      "Inject Save and Thumb buttons over tweet photos and video thumbnails.": "\uAC8C\uC2DC\uBB3C\uC758 \uC0AC\uC9C4\uACFC \uB3D9\uC601\uC0C1 \uC378\uB124\uC77C \uC704\uC5D0 \uC800\uC7A5\xB7\uC378\uB124\uC77C \uBC84\uD2BC\uC744 \uCD94\uAC00\uD569\uB2C8\uB2E4.",
      "Prefer original quality": "\uC6D0\uBCF8 \uD654\uC9C8 \uC6B0\uC120",
      "Rewrite image URLs to name=orig before downloading.": "\uB0B4\uB824\uBC1B\uAE30 \uC804\uC5D0 \uC774\uBBF8\uC9C0 URL\uC744 name=orig\uB85C \uBC14\uAFC9\uB2C8\uB2E4.",
      "Filename template": "\uD30C\uC77C \uC774\uB984 \uD15C\uD50C\uB9BF",
      "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.": "\uC0AC\uC6A9 \uAC00\uB2A5\uD55C \uD56D\uBAA9: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.",
      "Duplicate history": "\uC911\uBCF5 \uAE30\uB85D",
      "Skip downloads of media you have already saved from this browser.": "\uC774 \uBE0C\uB77C\uC6B0\uC800\uC5D0\uC11C \uC774\uBBF8 \uC800\uC7A5\uD55C \uBBF8\uB514\uC5B4\uB294 \uB0B4\uB824\uBC1B\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
      "Sensitive content": "\uBBFC\uAC10\uD55C \uCF58\uD150\uCE20",
      "Default (X choice)": "\uAE30\uBCF8\uAC12(X \uC124\uC815)",
      "Always reveal": "\uD56D\uC0C1 \uD45C\uC2DC",
      "Blur until hovered": "\uAC00\uB9AC\uD0A4\uAE30 \uC804\uAE4C\uC9C0 \uD750\uB9AC\uAC8C",
      "Always hide": "\uD56D\uC0C1 \uC228\uAE30\uAE30",
      "Media layout": "\uBBF8\uB514\uC5B4 \uBC30\uCE58",
      "Default grid": "\uAE30\uBCF8 \uADF8\uB9AC\uB4DC",
      "Stacked": "\uC138\uB85C \uC313\uAE30",
      "Strict grid": "\uADE0\uC77C \uADF8\uB9AC\uB4DC",
      "Download status": "\uB2E4\uC6B4\uB85C\uB4DC \uC0C1\uD0DC",
      "History entries": "\uAE30\uB85D \uAC1C\uC218",
      "Clear download history": "\uB2E4\uC6B4\uB85C\uB4DC \uAE30\uB85D \uC9C0\uC6B0\uAE30",
      "Reset the local dedup index.": "\uB85C\uCEEC \uC911\uBCF5 \uD310\uBCC4 \uC0C9\uC778\uC744 \uCD08\uAE30\uD654\uD569\uB2C8\uB2E4.",
      "Download all visible media": "\uD45C\uC2DC\uB41C \uBBF8\uB514\uC5B4 \uBAA8\uB450 \uB0B4\uB824\uBC1B\uAE30",
      "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.": "\uD604\uC7AC \uD398\uC774\uC9C0\uC5D0 \uD45C\uC2DC\uB41C \uAC8C\uC2DC\uBB3C\uC744 \uBAA8\uB450 \uD6D1\uC5B4 \uC0AC\uC9C4\xB7\uB3D9\uC601\uC0C1\xB7GIF\xB7\uC378\uB124\uC77C\uC744 \uAE30\uC874 \uB2E4\uC6B4\uB85C\uB4DC \uB300\uAE30\uC5F4\uC5D0 \uB123\uC2B5\uB2C8\uB2E4.",
      "Capture visible tweets": "\uD45C\uC2DC\uB41C \uAC8C\uC2DC\uBB3C \uC218\uC9D1",
      "Accumulate tweets visible on the active page for the next export run.": "\uB2E4\uC74C \uB0B4\uBCF4\uB0B4\uAE30\uB97C \uC704\uD574 \uD604\uC7AC \uD398\uC774\uC9C0\uC5D0 \uBCF4\uC774\uB294 \uAC8C\uC2DC\uBB3C\uC744 \uBAA8\uC544 \uB461\uB2C8\uB2E4.",
      "Export formats": "\uB0B4\uBCF4\uB0B4\uAE30 \uD615\uC2DD",
      "Comma-separated list. Supported: json, csv, html, markdown, xlsx.": "\uC27C\uD45C\uB85C \uAD6C\uBD84\uD574 \uC785\uB825\uD569\uB2C8\uB2E4. \uC9C0\uC6D0 \uD615\uC2DD: json, csv, html, markdown, xlsx.",
      "Preserve raw payloads": "\uC6D0\uBCF8 \uC751\uB2F5 \uBCF4\uAD00",
      "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.": "X\uAC00 \uC774 \uD0ED\uC5D0 \uBCF4\uB0B4\uB294 GraphQL \uC6D0\uBCF8 \uC751\uB2F5\uB3C4 \uC800\uC7A5\uD574 \uB098\uC911\uC5D0 \uB2E4\uC2DC \uD574\uC11D\uD560 \uC218 \uC788\uAC8C \uD569\uB2C8\uB2E4. \uC800\uC7A5 \uC804\uC5D0 \uC138\uC158 \uD1A0\uD070\uC740 \uC81C\uAC70\uB429\uB2C8\uB2E4.",
      "Auto-discover query IDs": "\uCFFC\uB9AC ID \uC790\uB3D9 \uAC80\uC0C9",
      "Scan loaded scripts for X GraphQL operation IDs and cache them locally.": "\uBD88\uB7EC\uC628 \uC2A4\uD06C\uB9BD\uD2B8\uC5D0\uC11C X\uC758 GraphQL \uC791\uC5C5 ID\uB97C \uCC3E\uC544 \uB85C\uCEEC\uC5D0 \uC800\uC7A5\uD569\uB2C8\uB2E4.",
      "Save folder hint": "\uC800\uC7A5 \uD3F4\uB354",
      "Folder name (or path) used as the export ZIP root and download prefix.": "\uB0B4\uBCF4\uB0B4\uAE30 ZIP\uC758 \uCD5C\uC0C1\uC704 \uD3F4\uB354\uC774\uC790 \uB2E4\uC6B4\uB85C\uB4DC \uC774\uB984 \uC55E\uC5D0 \uBD99\uC77C \uD3F4\uB354 \uC774\uB984(\uB610\uB294 \uACBD\uB85C).",
      "Export status": "\uB0B4\uBCF4\uB0B4\uAE30 \uC0C1\uD0DC",
      "Export visible tweets": "\uD45C\uC2DC\uB41C \uAC8C\uC2DC\uBB3C \uB0B4\uBCF4\uB0B4\uAE30",
      "Collect the currently rendered tweets and download a ZIP.": "\uD604\uC7AC \uD45C\uC2DC\uB41C \uAC8C\uC2DC\uBB3C\uC744 \uBAA8\uC544 ZIP\uC73C\uB85C \uB0B4\uB824\uBC1B\uC2B5\uB2C8\uB2E4.",
      "Copy diagnostics": "\uC9C4\uB2E8 \uC815\uBCF4 \uBCF5\uC0AC",
      "Copy support diagnostics (version, route, recent log).": "\uC9C0\uC6D0\uC6A9 \uC9C4\uB2E8 \uC815\uBCF4(\uBC84\uC804, \uACBD\uB85C, \uCD5C\uADFC \uB85C\uADF8)\uB97C \uBCF5\uC0AC\uD569\uB2C8\uB2E4.",
      "Download as WARC": "WARC\uB85C \uB0B4\uB824\uBC1B\uAE30",
      "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.": "\uC218\uC9D1\uD55C \uAE30\uB85D\uC744 ISO-28500 WARC \uD30C\uC77C\uB85C \uBB36\uC5B4 \uC5F0\uAD6C\xB7\uBCF4\uC874 \uB3C4\uAD6C\uC5D0\uC11C \uC4F8 \uC218 \uC788\uAC8C \uD569\uB2C8\uB2E4.",
      "Copy as Markdown": "Markdown\uC73C\uB85C \uBCF5\uC0AC",
      "Push a plain Markdown export onto the clipboard.": "\uC77C\uBC18 Markdown \uACB0\uACFC\uB97C \uD074\uB9BD\uBCF4\uB4DC\uC5D0 \uBCF5\uC0AC\uD569\uB2C8\uB2E4.",
      "Save Obsidian Markdown": "Obsidian\uC6A9 Markdown \uC800\uC7A5",
      "Markdown with YAML frontmatter and Aviary tags.": "YAML \uBA38\uB9AC\uB9D0\uACFC Aviary \uD0DC\uADF8\uAC00 \uD3EC\uD568\uB41C Markdown.",
      "Save Notion Markdown": "Notion\uC6A9 Markdown \uC800\uC7A5",
      "Heading-first Markdown that Notion imports cleanly.": "Notion\uC774 \uAE54\uB054\uD558\uAC8C \uAC00\uC838\uC624\uB294 \uC81C\uBAA9 \uC911\uC2EC Markdown.",
      "Save records JSON": "\uAE30\uB85D\uC744 JSON\uC73C\uB85C \uC800\uC7A5",
      "Raw ExportRecord[] JSON without ZIP wrapping.": "ZIP\uC73C\uB85C \uBB36\uC9C0 \uC54A\uC740 \uC6D0\uBCF8 ExportRecord[] JSON.",
      "Records per ZIP": "ZIP\uB2F9 \uAE30\uB85D \uC218",
      "Split a long export across several archives instead of one huge file (25-1000).": "\uAE34 \uB0B4\uBCF4\uB0B4\uAE30\uB97C \uD558\uB098\uC758 \uAC70\uB300\uD55C \uD30C\uC77C \uB300\uC2E0 \uC5EC\uB7EC \uC544\uCE74\uC774\uBE0C\uB85C \uB098\uB215\uB2C8\uB2E4(25~1000).",
      "Maximum export jobs": "\uB0B4\uBCF4\uB0B4\uAE30 \uC791\uC5C5 \uCD5C\uB300 \uC218",
      "Keep the newest jobs. Use 0 for unlimited.": "\uCD5C\uC2E0 \uC791\uC5C5\uC744 \uC720\uC9C0\uD569\uB2C8\uB2E4. 0\uC740 \uBB34\uC81C\uD55C\uC785\uB2C8\uB2E4.",
      "Maximum records per job": "\uC791\uC5C5\uB2F9 \uAE30\uB85D \uCD5C\uB300 \uC218",
      "Keep the newest records in each job. Use 0 for unlimited.": "\uAC01 \uC791\uC5C5\uC758 \uCD5C\uC2E0 \uAE30\uB85D\uC744 \uC720\uC9C0\uD569\uB2C8\uB2E4. 0\uC740 \uBB34\uC81C\uD55C\uC785\uB2C8\uB2E4.",
      "Maximum export age (days)": "\uB0B4\uBCF4\uB0B4\uAE30 \uBCF4\uAD00 \uAE30\uAC04(\uC77C)",
      "Remove older jobs at boot. Use 0 to disable age-based cleanup.": "\uC2DC\uC791\uD560 \uB54C \uC624\uB798\uB41C \uC791\uC5C5\uC744 \uC9C0\uC6C1\uB2C8\uB2E4. 0\uC774\uBA74 \uAE30\uAC04 \uAE30\uC900 \uC815\uB9AC\uB97C \uB055\uB2C8\uB2E4.",
      "Unshorten t.co links": "t.co \uB9C1\uD06C \uD3BC\uCE58\uAE30",
      "Replace short `t.co` redirects with the destination from aria-labels and titles.": "\uC9E7\uC740 `t.co` \uB9C1\uD06C\uB97C aria-label\uACFC title\uC5D0 \uC788\uB294 \uC2E4\uC81C \uC8FC\uC18C\uB85C \uBC14\uAFC9\uB2C8\uB2E4.",
      "Clean tracking from links": "\uB9C1\uD06C\uC5D0\uC11C \uCD94\uC801 \uC815\uBCF4 \uC81C\uAC70",
      "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.": "\uD0C0\uC784\uB77C\uC778 \uB9C1\uD06C\uC5D0\uC11C \uACF5\uC720 \uD1A0\uD070\uACFC \uCEA0\uD398\uC778 \uB9E4\uAC1C\uBCC0\uC218(utm_*, fbclid, X \uC790\uCCB4\uC758 t/s)\uB97C \uC81C\uAC70\uD574 \uBCF5\uC0AC\uD55C \uB0B4\uC6A9\uC774 \uC21C\uC218\uD55C \uC8FC\uC18C\uAC00 \uB418\uB3C4\uB85D \uD569\uB2C8\uB2E4.",
      "Account notes": "\uACC4\uC815 \uBA54\uBAA8",
      "Format: handle: note. One per line. Empty notes remove the entry.": "\uD615\uC2DD: \uACC4\uC815: \uBA54\uBAA8. \uD55C \uC904\uC5D0 \uD558\uB098\uC529. \uBA54\uBAA8\uB97C \uBE44\uC6B0\uBA74 \uC0AD\uC81C\uB429\uB2C8\uB2E4.",
      "Clear all account notes": "\uACC4\uC815 \uBA54\uBAA8 \uBAA8\uB450 \uC9C0\uC6B0\uAE30",
      "Drop every persisted note.": "\uC800\uC7A5\uB41C \uBA54\uBAA8\uB97C \uBAA8\uB450 \uC0AD\uC81C\uD569\uB2C8\uB2E4.",
      "Composer snippets": "\uC0C1\uC6A9\uAD6C",
      "One snippet per line. Reusable replies / templates (insertion landing in a later release).": "\uD55C \uC904\uC5D0 \uD558\uB098\uC529. \uB2E4\uC2DC \uC4F8 \uC218 \uC788\uB294 \uB2F5\uAE00\uC774\uB098 \uD15C\uD50C\uB9BF\uC785\uB2C8\uB2E4(\uC0BD\uC785 \uAE30\uB2A5\uC740 \uC774\uD6C4 \uB9B4\uB9AC\uC2A4\uC5D0\uC11C \uC9C0\uC6D0).",
      "Snapshots stored": "\uC800\uC7A5\uB41C \uC2A4\uB0C5\uC0F7",
      "Capture followers from this view": "\uC774 \uD654\uBA74\uC5D0\uC11C \uD314\uB85C\uC6CC \uC218\uC9D1",
      "Walks UserCell rows on the current page. Open a /handle/followers view first.": "\uD604\uC7AC \uD398\uC774\uC9C0\uC758 UserCell \uD589\uC744 \uD6D1\uC2B5\uB2C8\uB2E4. \uBA3C\uC800 /\uACC4\uC815/followers \uD654\uBA74\uC744 \uC5EC\uC138\uC694.",
      "Capture following from this view": "\uC774 \uD654\uBA74\uC5D0\uC11C \uD314\uB85C\uC789 \uC218\uC9D1",
      "Walks UserCell rows on the current page. Open a /handle/following view first.": "\uD604\uC7AC \uD398\uC774\uC9C0\uC758 UserCell \uD589\uC744 \uD6D1\uC2B5\uB2C8\uB2E4. \uBA3C\uC800 /\uACC4\uC815/following \uD654\uBA74\uC744 \uC5EC\uC138\uC694.",
      "Clear all snapshots": "\uC2A4\uB0C5\uC0F7 \uBAA8\uB450 \uC9C0\uC6B0\uAE30",
      "Drop every stored follower/following snapshot.": "\uC800\uC7A5\uB41C \uD314\uB85C\uC6CC\xB7\uD314\uB85C\uC789 \uC2A4\uB0C5\uC0F7\uC744 \uBAA8\uB450 \uC0AD\uC81C\uD569\uB2C8\uB2E4.",
      "Download Markdown report": "Markdown \uBCF4\uACE0\uC11C \uB0B4\uB824\uBC1B\uAE30",
      "Audit log + snapshot diff + cleanup preview.": "\uAC10\uC0AC \uB85C\uADF8, \uC2A4\uB0C5\uC0F7 \uBE44\uAD50, \uC815\uB9AC \uBBF8\uB9AC\uBCF4\uAE30.",
      "Cleanup review queue": "\uC815\uB9AC \uAC80\uD1A0 \uB300\uAE30\uC5F4",
      "Destructive actions": "\uD30C\uAD34\uC801\uC778 \uC791\uC5C5",
      "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log.": "Aviary\uB294 \uAC8C\uC2DC\uBB3C\xB7\uB9C8\uC74C\uC5D0 \uB4E4\uC5B4\uC694\xB7\uD314\uB85C\uC6B0\uB97C \uC0AD\uC81C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4. \uC774 \uB300\uAE30\uC5F4\uC740 \uAC80\uD1A0\uC6A9 \uBAA9\uB85D\uC774\uBA70, \uC2B9\uC778\uD558\uAC70\uB098 \uAC74\uB108\uB6F0\uC5B4\uB3C4 \uAC10\uC0AC \uB85C\uADF8\uC5D0\uB9CC \uAE30\uB85D\uB429\uB2C8\uB2E4.",
      "Enqueue cleanup preview for review": "\uC815\uB9AC \uBBF8\uB9AC\uBCF4\uAE30\uB97C \uB300\uAE30\uC5F4\uC5D0 \uCD94\uAC00",
      "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).": "\uCD5C\uADFC \uC815\uB9AC \uBBF8\uB9AC\uBCF4\uAE30\uC5D0\uC11C \uBCF4\uD638\uB418\uC9C0 \uC54A\uC740 \uD6C4\uBCF4\uB97C \uBAA8\uB450 \uB300\uAE30\uC5F4\uC5D0 \uCD94\uAC00\uD569\uB2C8\uB2E4(\uD30C\uAD34\uC801\uC778 \uC791\uC5C5 \uC5C6\uC74C).",
      "Clear cleanup queue": "\uC815\uB9AC \uB300\uAE30\uC5F4 \uBE44\uC6B0\uAE30",
      "Drop every queued item without touching account data.": "\uACC4\uC815 \uB370\uC774\uD130\uB97C \uAC74\uB4DC\uB9AC\uC9C0 \uC54A\uACE0 \uB300\uAE30\uC5F4 \uD56D\uBAA9\uC744 \uBAA8\uB450 \uC0AD\uC81C\uD569\uB2C8\uB2E4.",
      "Aria2 handoff": "Aria2\uB85C \uB118\uAE30\uAE30",
      "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.": "\uD070 \uBBF8\uB514\uC5B4 \uB2E4\uC6B4\uB85C\uB4DC\uB97C \uC9C1\uC811 \uC6B4\uC601\uD558\uB294 Aria2 JSON-RPC \uC5D4\uB4DC\uD3EC\uC778\uD2B8\uB85C \uBCF4\uB0C5\uB2C8\uB2E4.",
      "Aria2 endpoint": "Aria2 \uC5D4\uB4DC\uD3EC\uC778\uD2B8",
      "http://localhost:6800 (no trailing slash needed)": "http://localhost:6800 (\uB05D\uC5D0 \uC2AC\uB798\uC2DC \uBD88\uD544\uC694)",
      "Aria2 RPC secret": "Aria2 RPC \uC2DC\uD06C\uB9BF",
      "Optional shared secret for token: auth.": "token: \uC778\uC99D\uC5D0 \uC4F0\uB294 \uACF5\uC720 \uC2DC\uD06C\uB9BF(\uC120\uD0DD).",
      "Show": "\uD45C\uC2DC",
      "Test Aria2 connection": "Aria2 \uC5F0\uACB0 \uD14C\uC2A4\uD2B8",
      "Sends a trivial JSON-RPC call.": "\uAC04\uB2E8\uD55C JSON-RPC \uD638\uCD9C\uC744 \uBCF4\uB0C5\uB2C8\uB2E4.",
      "Refresh": "\uC0C8\uB85C \uACE0\uCE68",
      "Bluesky crosspost": "Bluesky \uAD50\uCC28 \uAC8C\uC2DC",
      "Post composer text to your Bluesky account on demand.": "\uC791\uC131\uCC3D\uC758 \uAE00\uC744 \uD544\uC694\uD560 \uB54C Bluesky \uACC4\uC815\uC5D0 \uC62C\uB9BD\uB2C8\uB2E4.",
      "Bluesky service URL": "Bluesky \uC11C\uBE44\uC2A4 URL",
      "Default: https://bsky.social": "\uAE30\uBCF8\uAC12: https://bsky.social",
      "Bluesky handle": "Bluesky \uACC4\uC815",
      "Your handle (no @, e.g. you.bsky.social)": "\uB0B4 \uACC4\uC815(@ \uC5C6\uC774, \uC608: you.bsky.social)",
      "Bluesky app password": "Bluesky \uC571 \uBE44\uBC00\uBC88\uD638",
      "App password from your account settings \u2014 never your main password.": "\uACC4\uC815 \uC124\uC815\uC5D0\uC11C \uBC1C\uAE09\uD55C \uC571 \uBE44\uBC00\uBC88\uD638. \uAE30\uBCF8 \uBE44\uBC00\uBC88\uD638\uB294 \uC4F0\uC9C0 \uB9C8\uC138\uC694.",
      "Mastodon crosspost": "Mastodon \uAD50\uCC28 \uAC8C\uC2DC",
      "Post composer text to your Mastodon account on demand.": "\uC791\uC131\uCC3D\uC758 \uAE00\uC744 \uD544\uC694\uD560 \uB54C Mastodon \uACC4\uC815\uC5D0 \uC62C\uB9BD\uB2C8\uB2E4.",
      "Mastodon instance": "Mastodon \uC778\uC2A4\uD134\uC2A4",
      "https://mastodon.social": "https://mastodon.social",
      "Mastodon access token": "Mastodon \uC561\uC138\uC2A4 \uD1A0\uD070",
      "Bearer token with write:statuses scope.": "write:statuses \uBC94\uC704\uB97C \uAC00\uC9C4 \uBCA0\uC5B4\uB7EC \uD1A0\uD070.",
      "Attach last download": "\uCD5C\uADFC \uB2E4\uC6B4\uB85C\uB4DC \uCCA8\uBD80",
      "Upload the last successful Aviary media download with the first post in an explicit crosspost.": "\uAD50\uCC28 \uAC8C\uC2DC\uC758 \uCCAB \uAE00\uC5D0 Aviary\uC5D0\uC11C \uB9C8\uC9C0\uB9C9\uC73C\uB85C \uC131\uACF5\uD55C \uBBF8\uB514\uC5B4 \uB2E4\uC6B4\uB85C\uB4DC\uB97C \uCCA8\uBD80\uD569\uB2C8\uB2E4.",
      "Crosspost composer \u2192 Bluesky": "\uC791\uC131\uCC3D\uC744 Bluesky\uB85C",
      "Uses the current composer text.": "\uD604\uC7AC \uC791\uC131\uCC3D\uC758 \uAE00\uC744 \uC0AC\uC6A9\uD569\uB2C8\uB2E4.",
      "Crosspost composer \u2192 Mastodon": "\uC791\uC131\uCC3D\uC744 Mastodon\uC73C\uB85C",
      "AI provider runs": "AI \uC81C\uACF5\uC790 \uC2E4\uD589",
      "Let the AI command menu POST prompts to your configured provider.": "AI \uBA85\uB839 \uBA54\uB274\uAC00 \uC124\uC815\uD55C \uC81C\uACF5\uC790\uC5D0\uAC8C \uD504\uB86C\uD504\uD2B8\uB97C \uBCF4\uB0BC \uC218 \uC788\uAC8C \uD569\uB2C8\uB2E4.",
      "AI provider": "AI \uC81C\uACF5\uC790",
      "Anthropic Messages API": "Anthropic Messages API",
      "OpenAI Chat Completions": "OpenAI Chat Completions",
      "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)": "OpenAI \uD638\uD658(LocalAI, Ollama \uD504\uB85D\uC2DC \uB4F1)",
      "AI endpoint (optional)": "AI \uC5D4\uB4DC\uD3EC\uC778\uD2B8(\uC120\uD0DD)",
      "Override the default endpoint for the chosen provider.": "\uC120\uD0DD\uD55C \uC81C\uACF5\uC790\uC758 \uAE30\uBCF8 \uC5D4\uB4DC\uD3EC\uC778\uD2B8\uB97C \uB300\uCCB4\uD569\uB2C8\uB2E4.",
      "AI model": "AI \uBAA8\uB378",
      "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b": "\uC608: claude-sonnet-4-6, gpt-4o, llama3.1:8b",
      "AI API key": "AI API \uD0A4",
      "Stored locally only. Aviary never sends this except as the auth header to your provider.": "\uB85C\uCEEC\uC5D0\uB9CC \uC800\uC7A5\uB429\uB2C8\uB2E4. Aviary\uB294 \uC124\uC815\uD55C \uC81C\uACF5\uC790\uC758 \uC778\uC99D \uD5E4\uB354 \uC678\uC5D0\uB294 \uC774 \uAC12\uC744 \uBCF4\uB0B4\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
      "Semantic search": "\uC758\uBBF8 \uAE30\uBC18 \uAC80\uC0C9",
      "Embed CheckpointStore records via your provider for similarity search.": "\uC720\uC0AC\uB3C4 \uAC80\uC0C9\uC744 \uC704\uD574 CheckpointStore \uAE30\uB85D\uC744 \uC81C\uACF5\uC790\uB85C \uC784\uBCA0\uB529\uD569\uB2C8\uB2E4.",
      "Embedding endpoint": "\uC784\uBCA0\uB529 \uC5D4\uB4DC\uD3EC\uC778\uD2B8",
      "POST endpoint that returns {data: [{embedding: number[]}]}": "{data: [{embedding: number[]}]}\uB97C \uBC18\uD658\uD558\uB294 POST \uC5D4\uB4DC\uD3EC\uC778\uD2B8",
      "Embedding model": "\uC784\uBCA0\uB529 \uBAA8\uB378",
      "e.g. text-embedding-3-small": "\uC608: text-embedding-3-small",
      "Embedding API key": "\uC784\uBCA0\uB529 API \uD0A4",
      "Stored locally; used only as the Authorization header.": "\uB85C\uCEEC\uC5D0 \uC800\uC7A5\uB418\uBA70 Authorization \uD5E4\uB354\uB85C\uB9CC \uC0AC\uC6A9\uB429\uB2C8\uB2E4.",
      "Auto-embed every export": "\uB0B4\uBCF4\uB0BC \uB54C\uB9C8\uB2E4 \uC790\uB3D9 \uC784\uBCA0\uB529",
      "After each export run, kick the embedding job in the background. Off by default.": "\uB0B4\uBCF4\uB0B4\uAE30\uB97C \uB9C8\uCE60 \uB54C\uB9C8\uB2E4 \uC784\uBCA0\uB529 \uC791\uC5C5\uC744 \uBC31\uADF8\uB77C\uC6B4\uB4DC\uC5D0\uC11C \uC2DC\uC791\uD569\uB2C8\uB2E4. \uAE30\uBCF8\uC740 \uAEBC\uC9D0\uC785\uB2C8\uB2E4.",
      "Rebuild semantic index": "\uC758\uBBF8 \uC0C9\uC778 \uB2E4\uC2DC \uB9CC\uB4E4\uAE30",
      "Embed every captured record. Re-running is cheap because cached entries are skipped.": "\uC218\uC9D1\uD55C \uBAA8\uB4E0 \uAE30\uB85D\uC744 \uC784\uBCA0\uB529\uD569\uB2C8\uB2E4. \uCE90\uC2DC\uB41C \uD56D\uBAA9\uC740 \uAC74\uB108\uB6F0\uBBC0\uB85C \uB2E4\uC2DC \uC2E4\uD589\uD574\uB3C4 \uBD80\uB2F4\uC774 \uC801\uC2B5\uB2C8\uB2E4.",
      "Clear semantic index": "\uC758\uBBF8 \uC0C9\uC778 \uC9C0\uC6B0\uAE30",
      "Forget every embedded record.": "\uC784\uBCA0\uB529\uB41C \uAE30\uB85D\uC744 \uBAA8\uB450 \uC78A\uC2B5\uB2C8\uB2E4.",
      "Integration status": "\uC5F0\uB3D9 \uC0C1\uD0DC",
      "Export settings": "\uC124\uC815 \uB0B4\uBCF4\uB0B4\uAE30",
      "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.": "\uC124\uC815\uC744 JSON\uC73C\uB85C \uB0B4\uB824\uBC1B\uC2B5\uB2C8\uB2E4. API \uD0A4\uC640 \uBE44\uBC00\uBC88\uD638\uB294 \uC790\uB9AC\uD45C\uC2DC\uC790\uB85C \uBC14\uB00C\uBBC0\uB85C \uACF5\uC720\uD574\uB3C4 \uC548\uC804\uD569\uB2C8\uB2E4. \uC5EC\uAE30\uC11C \uAC00\uC838\uC624\uBA74 \uC774 \uCEF4\uD4E8\uD130\uC5D0 \uC800\uC7A5\uB41C \uC778\uC99D \uC815\uBCF4\uB294 \uADF8\uB300\uB85C \uC720\uC9C0\uB429\uB2C8\uB2E4.",
      "Import settings (JSON)": "\uC124\uC815 \uAC00\uC838\uC624\uAE30(JSON)",
      "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.": "Aviary\uC5D0\uC11C \uB0B4\uBCF4\uB0B8 \uC124\uC815 \uD30C\uC77C\uC744 \uBD99\uC5EC \uB123\uACE0 \uAC00\uC838\uC624\uAE30\uB97C \uB204\uB974\uC138\uC694. \uAC00\uB824\uC9C4 \uC778\uC99D \uC815\uBCF4\uB294 \uC5EC\uAE30\uC5D0 \uC800\uC7A5\uB41C \uAC12\uC774 \uC720\uC9C0\uB429\uB2C8\uB2E4.",
      "Import": "\uAC00\uC838\uC624\uAE30",
      "Keep a local action log": "\uB85C\uCEEC \uC791\uC5C5 \uB85C\uADF8 \uC720\uC9C0",
      "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.": "\uB2E4\uC6B4\uB85C\uB4DC, \uB0B4\uBCF4\uB0B4\uAE30, \uC124\uC815 \uBCC0\uACBD\uC744 \uC774 \uAE30\uAE30\uC5D0 \uAE30\uB85D\uD574 Aviary\uAC00 \uBB34\uC5C7\uC744 \uD588\uB294\uC9C0 \uD655\uC778\uD560 \uC218 \uC788\uAC8C \uD569\uB2C8\uB2E4. \uC678\uBD80\uB85C \uC804\uC1A1\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4. \uB044\uBA74 \uC0C8 \uAE30\uB85D\uC774 \uC989\uC2DC \uC911\uB2E8\uB418\uBA70, \uAE30\uC874 \uAE30\uB85D\uC740 \uC9C0\uC6B8 \uB54C\uAE4C\uC9C0 \uB0A8\uC2B5\uB2C8\uB2E4.",
      "Audit entries": "\uAC10\uC0AC \uAE30\uB85D \uC218",
      "Clear audit log": "\uAC10\uC0AC \uB85C\uADF8 \uC9C0\uC6B0\uAE30",
      "Drop the local action log.": "\uB85C\uCEEC \uC791\uC5C5 \uB85C\uADF8\uB97C \uC0AD\uC81C\uD569\uB2C8\uB2E4.",
      "Storage": "\uC800\uC7A5 \uC704\uCE58",
      "Settings stay in this browser.": "\uC124\uC815\uC740 \uC774 \uBE0C\uB77C\uC6B0\uC800\uC5D0\uB9CC \uB0A8\uC2B5\uB2C8\uB2E4.",
      "Local-only mode": "\uB85C\uCEEC \uC804\uC6A9 \uBAA8\uB4DC",
      "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.": "\uC124\uC815\uD55C \uC5F0\uB3D9\uC744 \uD3EC\uD568\uD574 \uBAA8\uB4E0 \uC678\uBD80 \uC694\uCCAD\uC744 \uCC28\uB2E8\uD569\uB2C8\uB2E4. \uAE30\uBCF8\uC73C\uB85C \uCF1C\uC838 \uC788\uC73C\uBA70, \uC5F0\uB3D9\uC744 \uCF1C\uBA74 \uC774 \uBAA8\uB4DC\uAC00 \uAEBC\uC9D1\uB2C8\uB2E4.",
      "Some changes could not be saved \u2014 the browser store may be full.": "\uC77C\uBD80 \uBCC0\uACBD \uC0AC\uD56D\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uBE0C\uB77C\uC6B0\uC800 \uC800\uC7A5 \uACF5\uAC04\uC774 \uAC00\uB4DD \uCC3C\uC744 \uC218 \uC788\uC2B5\uB2C8\uB2E4.",
      "Saving": "\uC800\uC7A5",
      "Telemetry": "\uD154\uB808\uBA54\uD2B8\uB9AC",
      "Disabled": "\uC0AC\uC6A9 \uC548 \uD568",
      "Panel language": "\uD328\uB110 \uC5B8\uC5B4",
      "Selector health": "\uC120\uD0DD\uC790 \uC0C1\uD0DC",
      "Working \u2014 every change has been written.": "\uC815\uC0C1\uC785\uB2C8\uB2E4. \uBAA8\uB4E0 \uBCC0\uACBD \uC0AC\uD56D\uC774 \uC800\uC7A5\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
      "Monitoring active": "\uBAA8\uB2C8\uD130\uB9C1 \uC911",
      "Preset packs unavailable in this build.": "\uC774 \uBE4C\uB4DC\uC5D0\uC11C\uB294 \uD504\uB9AC\uC14B\uC744 \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.",
      "Hidden post store unavailable in this build.": "\uC774 \uBE4C\uB4DC\uC5D0\uC11C\uB294 \uC228\uAE34 \uAC8C\uC2DC\uBB3C \uC800\uC7A5\uC18C\uB97C \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.",
      "Cancel": "\uCDE8\uC18C"
    },
    ar: {
      "Aviary": "Aviary",
      "Local controls for a quieter X.": "\u0623\u062F\u0648\u0627\u062A \u0645\u062D\u0644\u064A\u0629 \u0644\u062A\u062C\u0631\u0628\u0629 \u0623\u0647\u062F\u0623 \u0639\u0644\u0649 X.",
      "Close": "\u0625\u063A\u0644\u0627\u0642",
      "Search settings": "\u0627\u0644\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A",
      "Saved locally": "\u062A\u0645 \u0627\u0644\u062D\u0641\u0638 \u0645\u062D\u0644\u064A\u064B\u0627",
      "Settings sections": "\u0623\u0642\u0633\u0627\u0645 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A",
      "Start": "\u0627\u0644\u0628\u062F\u0627\u064A\u0629",
      "Presets": "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062C\u0627\u0647\u0632\u0629",
      "Reading": "\u0627\u0644\u0642\u0631\u0627\u0621\u0629",
      "Appearance": "\u0627\u0644\u0645\u0638\u0647\u0631",
      "Layout": "\u0627\u0644\u062A\u062E\u0637\u064A\u0637",
      "Filtering": "\u0627\u0644\u062A\u0635\u0641\u064A\u0629",
      "Hidden posts": "\u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u062E\u0641\u064A\u0629",
      "Data": "\u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A",
      "Media": "\u0627\u0644\u0648\u0633\u0627\u0626\u0637",
      "Export": "\u0627\u0644\u062A\u0635\u062F\u064A\u0631",
      "Library": "\u0627\u0644\u0645\u0643\u062A\u0628\u0629",
      "Snapshots & Archive": "\u0627\u0644\u0644\u0642\u0637\u0627\u062A \u0648\u0627\u0644\u0623\u0631\u0634\u064A\u0641",
      "Advanced": "\u0645\u062A\u0642\u062F\u0645",
      "Integrations": "\u0627\u0644\u062A\u0643\u0627\u0645\u0644\u0627\u062A",
      "Backup & Audit": "\u0627\u0644\u0646\u0633\u062E \u0627\u0644\u0627\u062D\u062A\u064A\u0627\u0637\u064A \u0648\u0627\u0644\u062A\u062F\u0642\u064A\u0642",
      "Trust": "\u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629",
      "Apply": "\u062A\u0637\u0628\u064A\u0642",
      "Locale": "\u0627\u0644\u0644\u063A\u0629",
      "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.": "\u064A\u062A\u0631\u062C\u0645 \u0627\u0644\u0644\u0648\u062D\u0629 \u0648\u064A\u0636\u0628\u0637 \u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u2014 \u0645\u0646 \u0627\u0644\u064A\u0645\u064A\u0646 \u0625\u0644\u0649 \u0627\u0644\u064A\u0633\u0627\u0631 \u0644\u0644\u0639\u0631\u0628\u064A\u0629 \u0648\u0627\u0644\u0639\u0628\u0631\u064A\u0629. \u064A\u0639\u0631\u0636 \u0642\u0633\u0645 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 \u0646\u0633\u0628\u0629 \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u0644\u063A\u0629 \u0627\u0644\u0645\u062E\u062A\u0627\u0631\u0629\u060C \u0648\u0645\u0627 \u064A\u0646\u0642\u0635 \u064A\u0628\u0642\u0649 \u0628\u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629.",
      "Theme value is not supported.": "\u0647\u0630\u0627 \u0627\u0644\u0645\u0638\u0647\u0631 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645.",
      "Theme updated": "\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u0638\u0647\u0631",
      "Density updated": "\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0643\u062B\u0627\u0641\u0629",
      "Contrast preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 \u0627\u0644\u062A\u0628\u0627\u064A\u0646",
      "Motion preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 \u0627\u0644\u062D\u0631\u0643\u0629",
      "Sidebar preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 \u0627\u0644\u0634\u0631\u064A\u0637 \u0627\u0644\u062C\u0627\u0646\u0628\u064A",
      "Trend preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 \u0627\u0644\u062A\u0631\u0646\u062F\u0627\u062A",
      "Grok preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 Grok",
      "Could not apply preset.": "\u062A\u0639\u0630\u0651\u0631 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0625\u0639\u062F\u0627\u062F \u0627\u0644\u062C\u0627\u0647\u0632.",
      "Snapshot failed.": "\u0641\u0634\u0644\u062A \u0627\u0644\u0644\u0642\u0637\u0629.",
      "Snapshots cleared": "\u062A\u0645 \u0645\u0633\u062D \u0627\u0644\u0644\u0642\u0637\u0627\u062A",
      "Could not clear snapshots.": "\u062A\u0639\u0630\u0651\u0631 \u0645\u0633\u062D \u0627\u0644\u0644\u0642\u0637\u0627\u062A.",
      "Reading archive \u2014 large files take a moment\u2026": "\u062C\u0627\u0631\u064D \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0623\u0631\u0634\u064A\u0641 \u2014 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0643\u0628\u064A\u0631\u0629 \u062A\u0633\u062A\u063A\u0631\u0642 \u0644\u062D\u0638\u0629\u2026",
      "Archive import failed.": "\u0641\u0634\u0644 \u0627\u0633\u062A\u064A\u0631\u0627\u062F \u0627\u0644\u0623\u0631\u0634\u064A\u0641.",
      "Building report\u2026": "\u062C\u0627\u0631\u064D \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u062A\u0642\u0631\u064A\u0631\u2026",
      "Report downloaded.": "\u062A\u0645 \u062A\u0646\u0632\u064A\u0644 \u0627\u0644\u062A\u0642\u0631\u064A\u0631.",
      "Could not build report.": "\u062A\u0639\u0630\u0651\u0631 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u062A\u0642\u0631\u064A\u0631.",
      "Building cleanup preview\u2026": "\u062C\u0627\u0631\u064D \u0625\u0646\u0634\u0627\u0621 \u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u062A\u0646\u0638\u064A\u0641\u2026",
      "Could not enqueue cleanup.": "\u062A\u0639\u0630\u0651\u0631 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u062A\u0646\u0638\u064A\u0641 \u0625\u0644\u0649 \u0627\u0644\u0642\u0627\u0626\u0645\u0629.",
      "Cleanup queue cleared": "\u062A\u0645 \u0625\u0641\u0631\u0627\u063A \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062A\u0646\u0638\u064A\u0641",
      "Could not clear queue.": "\u062A\u0639\u0630\u0651\u0631 \u0625\u0641\u0631\u0627\u063A \u0627\u0644\u0642\u0627\u0626\u0645\u0629.",
      "Aria2 endpoint saved": "\u062A\u0645 \u062D\u0641\u0638 \u0646\u0642\u0637\u0629 Aria2",
      "Aria2 secret saved": "\u062A\u0645 \u062D\u0641\u0638 \u0633\u0631 Aria2",
      "Aria2 sweep failed.": "\u062A\u0639\u0630\u0651\u0631 \u062C\u0644\u0628 \u0642\u0627\u0626\u0645\u0629 Aria2.",
      "Bluesky service saved": "\u062A\u0645 \u062D\u0641\u0638 \u062E\u062F\u0645\u0629 Bluesky",
      "Bluesky handle saved": "\u062A\u0645 \u062D\u0641\u0638 \u062D\u0633\u0627\u0628 Bluesky",
      "Bluesky app password saved": "\u062A\u0645 \u062D\u0641\u0638 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062A\u0637\u0628\u064A\u0642 Bluesky",
      "Mastodon instance saved": "\u062A\u0645 \u062D\u0641\u0638 \u062E\u0627\u062F\u0645 Mastodon",
      "Mastodon token saved": "\u062A\u0645 \u062D\u0641\u0638 \u0631\u0645\u0632 Mastodon",
      "AI endpoint saved": "\u062A\u0645 \u062D\u0641\u0638 \u0646\u0642\u0637\u0629 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A",
      "AI model saved": "\u062A\u0645 \u062D\u0641\u0638 \u0646\u0645\u0648\u0630\u062C \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A",
      "AI API key saved": "\u062A\u0645 \u062D\u0641\u0638 \u0645\u0641\u062A\u0627\u062D API \u0644\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A",
      "Embedding endpoint saved": "\u062A\u0645 \u062D\u0641\u0638 \u0646\u0642\u0637\u0629 \u0627\u0644\u062A\u0636\u0645\u064A\u0646",
      "Embedding model saved": "\u062A\u0645 \u062D\u0641\u0638 \u0646\u0645\u0648\u0630\u062C \u0627\u0644\u062A\u0636\u0645\u064A\u0646",
      "Embedding API key saved": "\u062A\u0645 \u062D\u0641\u0638 \u0645\u0641\u062A\u0627\u062D API \u0644\u0644\u062A\u0636\u0645\u064A\u0646",
      "Rebuilding semantic index\u2026": "\u062C\u0627\u0631\u064D \u0625\u0639\u0627\u062F\u0629 \u0628\u0646\u0627\u0621 \u0627\u0644\u0641\u0647\u0631\u0633 \u0627\u0644\u062F\u0644\u0627\u0644\u064A\u2026",
      "Embedding failed.": "\u0641\u0634\u0644 \u0627\u0644\u062A\u0636\u0645\u064A\u0646.",
      "Semantic index cleared": "\u062A\u0645 \u0645\u0633\u062D \u0627\u0644\u0641\u0647\u0631\u0633 \u0627\u0644\u062F\u0644\u0627\u0644\u064A",
      "Account notes cleared": "\u062A\u0645 \u0645\u0633\u062D \u0645\u0644\u0627\u062D\u0638\u0627\u062A \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A",
      "Could not clear notes.": "\u062A\u0639\u0630\u0651\u0631 \u0645\u0633\u062D \u0627\u0644\u0645\u0644\u0627\u062D\u0638\u0627\u062A.",
      "Settings exported.": "\u062A\u0645 \u062A\u0635\u062F\u064A\u0631 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A.",
      "Could not export settings.": "\u062A\u0639\u0630\u0651\u0631 \u062A\u0635\u062F\u064A\u0631 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A.",
      "Could not import settings.": "\u062A\u0639\u0630\u0651\u0631 \u0627\u0633\u062A\u064A\u0631\u0627\u062F \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A.",
      "Audit log cleared": "\u062A\u0645 \u0645\u0633\u062D \u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642",
      "Could not clear audit log.": "\u062A\u0639\u0630\u0651\u0631 \u0645\u0633\u062D \u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642.",
      "Raw payload preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 \u0627\u0644\u0627\u0633\u062A\u062C\u0627\u0628\u0627\u062A \u0627\u0644\u062E\u0627\u0645",
      "Query discovery preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 \u0627\u0643\u062A\u0634\u0627\u0641 \u0627\u0644\u0627\u0633\u062A\u0639\u0644\u0627\u0645\u0627\u062A",
      "Save folder hint saved": "\u062A\u0645 \u062D\u0641\u0638 \u0645\u062C\u0644\u062F \u0627\u0644\u062D\u0641\u0638",
      "Collecting visible posts\u2026": "\u062C\u0627\u0631\u064D \u062C\u0645\u0639 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0638\u0627\u0647\u0631\u0629\u2026",
      "Export failed. See diagnostics.": "\u0641\u0634\u0644 \u0627\u0644\u062A\u0635\u062F\u064A\u0631. \u0631\u0627\u062C\u0639 \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062A\u0634\u062E\u064A\u0635.",
      "Diagnostics copied to clipboard.": "\u062A\u0645 \u0646\u0633\u062E \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062A\u0634\u062E\u064A\u0635 \u0625\u0644\u0649 \u0627\u0644\u062D\u0627\u0641\u0638\u0629.",
      "Could not copy diagnostics.": "\u062A\u0639\u0630\u0651\u0631 \u0646\u0633\u062E \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062A\u0634\u062E\u064A\u0635.",
      "Building WARC archive\u2026": "\u062C\u0627\u0631\u064D \u0625\u0646\u0634\u0627\u0621 \u0623\u0631\u0634\u064A\u0641 WARC\u2026",
      "WARC export failed.": "\u0641\u0634\u0644 \u062A\u0635\u062F\u064A\u0631 WARC.",
      "External export failed.": "\u0641\u0634\u0644 \u0627\u0644\u062A\u0635\u062F\u064A\u0631 \u0627\u0644\u062E\u0627\u0631\u062C\u064A.",
      "Records per ZIP saved": "\u062A\u0645 \u062D\u0641\u0638 \u0639\u062F\u062F \u0627\u0644\u0633\u062C\u0644\u0627\u062A \u0644\u0643\u0644 ZIP",
      "Export job retention saved": "\u062A\u0645 \u062D\u0641\u0638 \u0645\u062F\u0629 \u0627\u0644\u0627\u062D\u062A\u0641\u0627\u0638 \u0628\u0645\u0647\u0627\u0645 \u0627\u0644\u062A\u0635\u062F\u064A\u0631",
      "Record retention saved": "\u062A\u0645 \u062D\u0641\u0638 \u0645\u062F\u0629 \u0627\u0644\u0627\u062D\u062A\u0641\u0627\u0638 \u0628\u0627\u0644\u0633\u062C\u0644\u0627\u062A",
      "Age-based retention saved": "\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u0627\u062D\u062A\u0641\u0627\u0638 \u062D\u0633\u0628 \u0627\u0644\u0639\u0645\u0631",
      "Original quality preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 \u0627\u0644\u062C\u0648\u062F\u0629 \u0627\u0644\u0623\u0635\u0644\u064A\u0629",
      "Filename template saved": "\u062A\u0645 \u062D\u0641\u0638 \u0642\u0627\u0644\u0628 \u0627\u0633\u0645 \u0627\u0644\u0645\u0644\u0641",
      "Sensitive content preference saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0641\u0636\u064A\u0644 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u062D\u0633\u0627\u0633",
      "Media layout saved": "\u062A\u0645 \u062D\u0641\u0638 \u062A\u062E\u0637\u064A\u0637 \u0627\u0644\u0648\u0633\u0627\u0626\u0637",
      "History cleared": "\u062A\u0645 \u0645\u0633\u062D \u0627\u0644\u0633\u062C\u0644",
      "Could not clear history.": "\u062A\u0639\u0630\u0651\u0631 \u0645\u0633\u062D \u0627\u0644\u0633\u062C\u0644.",
      "Downloading media from this view\u2026": "\u062C\u0627\u0631\u064D \u062A\u0646\u0632\u064A\u0644 \u0648\u0633\u0627\u0626\u0637 \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629\u2026",
      "Batch download failed.": "\u0641\u0634\u0644 \u0627\u0644\u062A\u0646\u0632\u064A\u0644 \u0627\u0644\u062C\u0645\u0627\u0639\u064A.",
      "Premium filter saved": "\u062A\u0645 \u062D\u0641\u0638 \u0641\u0644\u062A\u0631 Premium",
      "Could not undo the last hide.": "\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u062A\u0631\u0627\u062C\u0639 \u0639\u0646 \u0622\u062E\u0631 \u0625\u062E\u0641\u0627\u0621.",
      "Could not restore the post.": "\u062A\u0639\u0630\u0651\u0631\u062A \u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u0646\u0634\u0648\u0631.",
      "Could not clear hidden posts.": "\u062A\u0639\u0630\u0651\u0631 \u0645\u0633\u062D \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u062E\u0641\u064A\u0629.",
      "Saving...": "\u062C\u0627\u0631\u064D \u0627\u0644\u062D\u0641\u0638...",
      "Could not save settings. Try again.": "\u062A\u0639\u0630\u0651\u0631 \u062D\u0641\u0638 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A. \u062D\u0627\u0648\u0644 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649.",
      "Theme": "\u0627\u0644\u0645\u0638\u0647\u0631",
      "Dim": "\u062E\u0627\u0641\u062A",
      "Lights out": "\u0625\u0637\u0641\u0627\u0621 \u0627\u0644\u0623\u0636\u0648\u0627\u0621",
      "Graphite": "\u062C\u0631\u0627\u0641\u064A\u062A",
      "Plum": "\u0628\u0631\u0642\u0648\u0642\u064A",
      "Midnight": "\u0645\u0646\u062A\u0635\u0641 \u0627\u0644\u0644\u064A\u0644",
      "Dense mode": "\u0627\u0644\u0648\u0636\u0639 \u0627\u0644\u0645\u0643\u062B\u0641",
      "Tighten timeline spacing for scanning.": "\u064A\u0642\u0644\u0651\u0635 \u0627\u0644\u0645\u0633\u0627\u0641\u0627\u062A \u0641\u064A \u0627\u0644\u062E\u0637 \u0627\u0644\u0632\u0645\u0646\u064A \u0644\u062A\u0635\u0641\u0651\u062D \u0623\u0633\u0631\u0639.",
      "Hide engagement counts": "\u0625\u062E\u0641\u0627\u0621 \u0623\u0639\u062F\u0627\u062F \u0627\u0644\u062A\u0641\u0627\u0639\u0644",
      "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.": "\u064A\u062E\u0641\u064A \u0623\u0639\u062F\u0627\u062F \u0627\u0644\u0631\u062F\u0648\u062F \u0648\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0646\u0634\u0631 \u0648\u0627\u0644\u0625\u0639\u062C\u0627\u0628\u0627\u062A. \u062A\u0638\u0644 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u062A\u0639\u0645\u0644 \u0648\u062A\u0638\u0644 \u0642\u0627\u0631\u0626\u0627\u062A \u0627\u0644\u0634\u0627\u0634\u0629 \u062A\u0639\u0644\u0646 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A\u0627\u062A.",
      "Hide row borders": "\u0625\u062E\u0641\u0627\u0621 \u062D\u062F\u0648\u062F \u0627\u0644\u0635\u0641\u0648\u0641",
      "Remove the 1px divider under each timeline post and the primary column's side rules.": "\u064A\u0632\u064A\u0644 \u0627\u0644\u0641\u0627\u0635\u0644 \u0628\u0633\u0645\u0643 \u0628\u0643\u0633\u0644 \u0648\u0627\u062D\u062F \u0623\u0633\u0641\u0644 \u0643\u0644 \u0645\u0646\u0634\u0648\u0631\u060C \u0648\u0627\u0644\u062E\u0637\u0648\u0637 \u0627\u0644\u062C\u0627\u0646\u0628\u064A\u0629 \u0644\u0644\u0639\u0645\u0648\u062F \u0627\u0644\u0631\u0626\u064A\u0633\u064A.",
      "High contrast": "\u062A\u0628\u0627\u064A\u0646 \u0639\u0627\u0644\u064D",
      "Use stronger borders and text contrast.": "\u064A\u0633\u062A\u062E\u062F\u0645 \u062D\u062F\u0648\u062F\u064B\u0627 \u0648\u062A\u0628\u0627\u064A\u0646\u064B\u0627 \u0646\u0635\u064A\u064B\u0627 \u0623\u0642\u0648\u0649.",
      "Reduced motion": "\u062A\u0642\u0644\u064A\u0644 \u0627\u0644\u062D\u0631\u0643\u0629",
      "Follow system setting": "\u0627\u062A\u0651\u0628\u0627\u0639 \u0625\u0639\u062F\u0627\u062F \u0627\u0644\u0646\u0638\u0627\u0645",
      "Always reduce": "\u0627\u0644\u062A\u0642\u0644\u064A\u0644 \u062F\u0627\u0626\u0645\u064B\u0627",
      "Never reduce": "\u0639\u062F\u0645 \u0627\u0644\u062A\u0642\u0644\u064A\u0644",
      "Hide right sidebar": "\u0625\u062E\u0641\u0627\u0621 \u0627\u0644\u0634\u0631\u064A\u0637 \u0627\u0644\u062C\u0627\u0646\u0628\u064A",
      "Reduce trends, recommendations, and footer noise.": "\u064A\u0642\u0644\u0651\u0644 \u0636\u062C\u064A\u062C \u0627\u0644\u062A\u0631\u0646\u062F\u0627\u062A \u0648\u0627\u0644\u062A\u0648\u0635\u064A\u0627\u062A \u0648\u0627\u0644\u062A\u0630\u064A\u064A\u0644.",
      "Hide trends": "\u0625\u062E\u0641\u0627\u0621 \u0627\u0644\u062A\u0631\u0646\u062F\u0627\u062A",
      "Remove trending topics and news modules.": "\u064A\u0632\u064A\u0644 \u0627\u0644\u0645\u0648\u0627\u0636\u064A\u0639 \u0627\u0644\u0631\u0627\u0626\u062C\u0629 \u0648\u0648\u062D\u062F\u0627\u062A \u0627\u0644\u0623\u062E\u0628\u0627\u0631.",
      "Hide Grok surfaces": "\u0625\u062E\u0641\u0627\u0621 \u0648\u0627\u062C\u0647\u0627\u062A Grok",
      "Remove Grok drawer and composer buttons where detected.": "\u064A\u0632\u064A\u0644 \u0644\u0648\u062D\u0629 Grok \u0648\u0623\u0632\u0631\u0627\u0631\u0647 \u0641\u064A \u0645\u062D\u0631\u0631 \u0627\u0644\u0645\u0646\u0634\u0648\u0631 \u0639\u0646\u062F \u0627\u0643\u062A\u0634\u0627\u0641\u0647\u0627.",
      "Writer mode": "\u0648\u0636\u0639 \u0627\u0644\u0643\u062A\u0627\u0628\u0629",
      "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.": "\u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u062A\u0631\u0643\u064A\u0632 \u0639\u0644\u0649 \u0645\u062D\u0631\u0631 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u060C \u064A\u062E\u0641\u062A \u0627\u0644\u0634\u0631\u064A\u0637 \u0627\u0644\u062C\u0627\u0646\u0628\u064A \u0648\u0627\u0644\u062E\u0637 \u0627\u0644\u0632\u0645\u0646\u064A \u062E\u0644\u0641\u0647. \u064A\u0639\u0648\u062F \u0643\u0644 \u0634\u064A\u0621 \u0628\u0645\u062C\u0631\u062F \u0627\u0644\u0646\u0642\u0631 \u062E\u0627\u0631\u062C\u0647.",
      "Enable filters": "\u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u0641\u0644\u0627\u062A\u0631",
      "Master switch for keyword, regex, premium, and media filters.": "\u0645\u0641\u062A\u0627\u062D \u0631\u0626\u064A\u0633\u064A \u0644\u0641\u0644\u0627\u062A\u0631 \u0627\u0644\u0643\u0644\u0645\u0627\u062A \u0627\u0644\u0645\u0641\u062A\u0627\u062D\u064A\u0629 \u0648\u0627\u0644\u062A\u0639\u0628\u064A\u0631\u0627\u062A \u0627\u0644\u0646\u0645\u0637\u064A\u0629 \u0648\u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A \u0627\u0644\u0645\u0645\u064A\u0632\u0629 \u0648\u0627\u0644\u0648\u0633\u0627\u0626\u0637.",
      "Keyword rules": "\u0642\u0648\u0627\u0639\u062F \u0627\u0644\u0643\u0644\u0645\u0627\u062A \u0627\u0644\u0645\u0641\u062A\u0627\u062D\u064A\u0629",
      "One keyword or phrase per line. Case-insensitive substring match.": "\u0643\u0644\u0645\u0629 \u0623\u0648 \u0639\u0628\u0627\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u064A \u0643\u0644 \u0633\u0637\u0631. \u0627\u0644\u0645\u0637\u0627\u0628\u0642\u0629 \u062C\u0632\u0626\u064A\u0629 \u0648\u0644\u0627 \u062A\u0645\u064A\u0651\u0632 \u0628\u064A\u0646 \u0627\u0644\u0623\u062D\u0631\u0641 \u0627\u0644\u0643\u0628\u064A\u0631\u0629 \u0648\u0627\u0644\u0635\u063A\u064A\u0631\u0629.",
      "Save list": "\u062D\u0641\u0638 \u0627\u0644\u0642\u0627\u0626\u0645\u0629",
      "Regex rules": "\u0642\u0648\u0627\u0639\u062F \u0627\u0644\u062A\u0639\u0628\u064A\u0631\u0627\u062A \u0627\u0644\u0646\u0645\u0637\u064A\u0629",
      "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).": "\u0646\u0645\u0637 \u0648\u0627\u062D\u062F \u0641\u064A \u0643\u0644 \u0633\u0637\u0631. \u0627\u0633\u062A\u062E\u062F\u0645 \u200E/pattern/flags\u200E \u0623\u0648 \u0627\u0644\u0646\u0645\u0637 \u0645\u062C\u0631\u062F\u064B\u0627 (\u062F\u0648\u0646 \u062A\u0645\u064A\u064A\u0632 \u062D\u0627\u0644\u0629 \u0627\u0644\u0623\u062D\u0631\u0641).",
      "Whitelist handles": "\u062D\u0633\u0627\u0628\u0627\u062A \u0645\u0633\u062A\u062B\u0646\u0627\u0629",
      "Handles (one per line, no @) that are never filtered.": "\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A (\u0648\u0627\u062D\u062F \u0641\u064A \u0643\u0644 \u0633\u0637\u0631\u060C \u062F\u0648\u0646 @) \u0627\u0644\u062A\u064A \u0644\u0627 \u062A\u064F\u0641\u0644\u062A\u0631 \u0623\u0628\u062F\u064B\u0627.",
      "Premium / verified posts": "\u0645\u0646\u0634\u0648\u0631\u0627\u062A Premium \u0648\u0627\u0644\u0645\u0648\u062B\u0651\u0642\u0629",
      "Off": "\u0625\u064A\u0642\u0627\u0641",
      "Hide": "\u0625\u062E\u0641\u0627\u0621",
      "Hide posts with photos": "\u0625\u062E\u0641\u0627\u0621 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0630\u0627\u062A \u0627\u0644\u0635\u0648\u0631",
      "Filter posts containing photos.": "\u064A\u0641\u0644\u062A\u0631 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 \u0635\u0648\u0631.",
      "Hide posts with videos": "\u0625\u062E\u0641\u0627\u0621 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0630\u0627\u062A \u0627\u0644\u0641\u064A\u062F\u064A\u0648",
      "Filter posts containing videos.": "\u064A\u0641\u0644\u062A\u0631 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 \u0645\u0642\u0627\u0637\u0639 \u0641\u064A\u062F\u064A\u0648.",
      "Hide posts with gifs": "\u0625\u062E\u0641\u0627\u0621 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0630\u0627\u062A \u0635\u0648\u0631 GIF",
      "Filter posts containing gifs.": "\u064A\u0641\u0644\u062A\u0631 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 \u0635\u0648\u0631 GIF.",
      "Active on": "\u0645\u0641\u0639\u0651\u0644 \u0641\u064A",
      "Routes where filters run.": "\u0627\u0644\u0635\u0641\u062D\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0639\u0645\u0644 \u0641\u064A\u0647\u0627 \u0627\u0644\u0641\u0644\u0627\u062A\u0631.",
      "Home": "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
      "Status": "\u0645\u0646\u0634\u0648\u0631",
      "Profile": "\u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A",
      "Search": "\u0627\u0644\u0628\u062D\u062B",
      "Notifications": "\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A",
      "Messages": "\u0627\u0644\u0631\u0633\u0627\u0626\u0644",
      "Blocked accounts / self-reposts": "\u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A \u0627\u0644\u0645\u062D\u0638\u0648\u0631\u0629 \u0648\u0625\u0639\u0627\u062F\u0629 \u0646\u0634\u0631 \u0627\u0644\u0630\u0627\u062A",
      "Pending an authenticated fixture; controls stay disabled.": "\u0641\u064A \u0627\u0646\u062A\u0638\u0627\u0631 \u0639\u064A\u0651\u0646\u0629 \u0645\u0648\u062B\u0651\u0642\u0629\u061B \u062A\u0628\u0642\u0649 \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A \u0645\u0639\u0637\u0651\u0644\u0629.",
      "Hide dismissed posts": "\u0625\u062E\u0641\u0627\u0621 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u0628\u0639\u062F\u0629",
      "Keep posts you hid collapsed so the next post rises to the top.": "\u064A\u0628\u0642\u064A \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u062A\u064A \u0623\u062E\u0641\u064A\u062A\u0647\u0627 \u0645\u0637\u0648\u064A\u0629 \u0644\u064A\u0635\u0639\u062F \u0627\u0644\u0645\u0646\u0634\u0648\u0631 \u0627\u0644\u062A\u0627\u0644\u064A \u0625\u0644\u0649 \u0627\u0644\u0623\u0639\u0644\u0649.",
      "Show hide buttons": "\u0625\u0638\u0647\u0627\u0631 \u0623\u0632\u0631\u0627\u0631 \u0627\u0644\u0625\u062E\u0641\u0627\u0621",
      "Adds a Hide control to every post next to the More menu.": "\u064A\u0636\u064A\u0641 \u0632\u0631 \u0625\u062E\u0641\u0627\u0621 \u0644\u0643\u0644 \u0645\u0646\u0634\u0648\u0631 \u0628\u062C\u0627\u0646\u0628 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0632\u064A\u062F.",
      "Routes where hiding and the Hide button apply.": "\u0627\u0644\u0635\u0641\u062D\u0627\u062A \u0627\u0644\u062A\u064A \u064A\u0646\u0637\u0628\u0642 \u0641\u064A\u0647\u0627 \u0627\u0644\u0625\u062E\u0641\u0627\u0621 \u0648\u0632\u0631\u0647.",
      "Maximum remembered posts": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629",
      "Oldest entries are dropped once the store passes this size (100-50000).": "\u062A\u064F\u062D\u0630\u0641 \u0623\u0642\u062F\u0645 \u0627\u0644\u0639\u0646\u0627\u0635\u0631 \u0639\u0646\u062F \u062A\u062C\u0627\u0648\u0632 \u0647\u0630\u0627 \u0627\u0644\u0639\u062F\u062F (100-50000).",
      "Save": "\u062D\u0641\u0638",
      "Hidden posts stored": "\u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u062E\u0641\u064A\u0629 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629",
      "Undo last hide": "\u0627\u0644\u062A\u0631\u0627\u062C\u0639 \u0639\u0646 \u0622\u062E\u0631 \u0625\u062E\u0641\u0627\u0621",
      "Restores the most recently hidden post.": "\u064A\u0633\u062A\u0639\u064A\u062F \u0622\u062E\u0631 \u0645\u0646\u0634\u0648\u0631 \u062A\u0645 \u0625\u062E\u0641\u0627\u0624\u0647.",
      "Restore": "\u0627\u0633\u062A\u0639\u0627\u062F\u0629",
      "Clear hidden posts": "\u0645\u0633\u062D \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u062E\u0641\u064A\u0629",
      "Forgets every hidden post and brings them all back.": "\u064A\u0646\u0633\u0649 \u0643\u0644 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u062E\u0641\u064A\u0629 \u0648\u064A\u0639\u064A\u062F\u0647\u0627 \u062C\u0645\u064A\u0639\u064B\u0627.",
      "Show download buttons": "\u0625\u0638\u0647\u0627\u0631 \u0623\u0632\u0631\u0627\u0631 \u0627\u0644\u062A\u0646\u0632\u064A\u0644",
      "Inject Save and Thumb buttons over tweet photos and video thumbnails.": "\u064A\u0636\u064A\u0641 \u0632\u0631\u064E\u0651\u064A \u0627\u0644\u062D\u0641\u0638 \u0648\u0627\u0644\u0645\u0635\u063A\u0651\u0631\u0629 \u0641\u0648\u0642 \u0635\u0648\u0631 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0648\u0645\u0635\u063A\u0651\u0631\u0627\u062A \u0627\u0644\u0641\u064A\u062F\u064A\u0648.",
      "Prefer original quality": "\u062A\u0641\u0636\u064A\u0644 \u0627\u0644\u062C\u0648\u062F\u0629 \u0627\u0644\u0623\u0635\u0644\u064A\u0629",
      "Rewrite image URLs to name=orig before downloading.": "\u064A\u0639\u064A\u062F \u0643\u062A\u0627\u0628\u0629 \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u0635\u0648\u0631 \u0625\u0644\u0649 name=orig \u0642\u0628\u0644 \u0627\u0644\u062A\u0646\u0632\u064A\u0644.",
      "Filename template": "\u0642\u0627\u0644\u0628 \u0627\u0633\u0645 \u0627\u0644\u0645\u0644\u0641",
      "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.": "\u0627\u0644\u062D\u0642\u0648\u0644: {handle}\u060C {tweetId}\u060C {mediaId}\u060C {index}\u060C {total}\u060C {date}\u060C {text}\u060C {ext}.",
      "Duplicate history": "\u0633\u062C\u0644 \u0627\u0644\u062A\u0643\u0631\u0627\u0631\u0627\u062A",
      "Skip downloads of media you have already saved from this browser.": "\u064A\u062A\u062E\u0637\u0649 \u062A\u0646\u0632\u064A\u0644 \u0627\u0644\u0648\u0633\u0627\u0626\u0637 \u0627\u0644\u062A\u064A \u0633\u0628\u0642 \u062D\u0641\u0638\u0647\u0627 \u0645\u0646 \u0647\u0630\u0627 \u0627\u0644\u0645\u062A\u0635\u0641\u062D.",
      "Sensitive content": "\u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u062D\u0633\u0627\u0633",
      "Default (X choice)": "\u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A (\u0625\u0639\u062F\u0627\u062F X)",
      "Always reveal": "\u0627\u0644\u0625\u0638\u0647\u0627\u0631 \u062F\u0627\u0626\u0645\u064B\u0627",
      "Blur until hovered": "\u0627\u0644\u062A\u0645\u0648\u064A\u0647 \u062D\u062A\u0649 \u0627\u0644\u0645\u0631\u0648\u0631 \u0628\u0627\u0644\u0645\u0624\u0634\u0631",
      "Always hide": "\u0627\u0644\u0625\u062E\u0641\u0627\u0621 \u062F\u0627\u0626\u0645\u064B\u0627",
      "Media layout": "\u062A\u062E\u0637\u064A\u0637 \u0627\u0644\u0648\u0633\u0627\u0626\u0637",
      "Default grid": "\u0627\u0644\u0634\u0628\u0643\u0629 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629",
      "Stacked": "\u0645\u062A\u0631\u0627\u0635",
      "Strict grid": "\u0634\u0628\u0643\u0629 \u0645\u0646\u062A\u0638\u0645\u0629",
      "Download status": "\u062D\u0627\u0644\u0629 \u0627\u0644\u062A\u0646\u0632\u064A\u0644",
      "History entries": "\u0639\u062F\u062F \u0639\u0646\u0627\u0635\u0631 \u0627\u0644\u0633\u062C\u0644",
      "Clear download history": "\u0645\u0633\u062D \u0633\u062C\u0644 \u0627\u0644\u062A\u0646\u0632\u064A\u0644\u0627\u062A",
      "Reset the local dedup index.": "\u064A\u0639\u064A\u062F \u0636\u0628\u0637 \u0641\u0647\u0631\u0633 \u0627\u0644\u062A\u0643\u0631\u0627\u0631\u0627\u062A \u0627\u0644\u0645\u062D\u0644\u064A.",
      "Download all visible media": "\u062A\u0646\u0632\u064A\u0644 \u0643\u0644 \u0627\u0644\u0648\u0633\u0627\u0626\u0637 \u0627\u0644\u0638\u0627\u0647\u0631\u0629",
      "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.": "\u064A\u0645\u0631\u0651 \u0639\u0644\u0649 \u0643\u0644 \u0645\u0646\u0634\u0648\u0631 \u0645\u0639\u0631\u0648\u0636 \u0641\u064A \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629 \u0648\u064A\u0636\u064A\u0641 \u0643\u0644 \u0635\u0648\u0631\u0629 \u0648\u0641\u064A\u062F\u064A\u0648 \u0648GIF \u0648\u0645\u0635\u063A\u0651\u0631\u0629 \u0625\u0644\u0649 \u0637\u0627\u0628\u0648\u0631 \u0627\u0644\u062A\u0646\u0632\u064A\u0644 \u0627\u0644\u062D\u0627\u0644\u064A.",
      "Capture visible tweets": "\u062C\u0645\u0639 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0638\u0627\u0647\u0631\u0629",
      "Accumulate tweets visible on the active page for the next export run.": "\u064A\u062C\u0645\u0639 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0638\u0627\u0647\u0631\u0629 \u0641\u064A \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629 \u0627\u0633\u062A\u0639\u062F\u0627\u062F\u064B\u0627 \u0644\u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u062A\u0635\u062F\u064A\u0631 \u0627\u0644\u062A\u0627\u0644\u064A\u0629.",
      "Export formats": "\u0635\u064A\u063A \u0627\u0644\u062A\u0635\u062F\u064A\u0631",
      "Comma-separated list. Supported: json, csv, html, markdown, xlsx.": "\u0642\u0627\u0626\u0645\u0629 \u0645\u0641\u0635\u0648\u0644\u0629 \u0628\u0641\u0648\u0627\u0635\u0644. \u0627\u0644\u0645\u062F\u0639\u0648\u0645: json\u060C csv\u060C html\u060C markdown\u060C xlsx.",
      "Preserve raw payloads": "\u062D\u0641\u0638 \u0627\u0644\u0627\u0633\u062A\u062C\u0627\u0628\u0627\u062A \u0627\u0644\u062E\u0627\u0645",
      "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.": "\u064A\u062D\u0641\u0638 \u0623\u064A\u0636\u064B\u0627 \u0627\u0633\u062A\u062C\u0627\u0628\u0627\u062A GraphQL \u0627\u0644\u062E\u0627\u0645 \u0627\u0644\u062A\u064A \u064A\u0631\u0633\u0644\u0647\u0627 X \u0625\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u062A\u0628\u0648\u064A\u0628\u0629\u060C \u0644\u064A\u0645\u0643\u0646 \u062A\u062D\u0644\u064A\u0644\u0647\u0627 \u0644\u0627\u062D\u0642\u064B\u0627. \u062A\u064F\u0632\u0627\u0644 \u0631\u0645\u0648\u0632 \u0627\u0644\u062C\u0644\u0633\u0629 \u0642\u0628\u0644 \u0627\u0644\u0643\u062A\u0627\u0628\u0629.",
      "Auto-discover query IDs": "\u0627\u0643\u062A\u0634\u0627\u0641 \u0645\u0639\u0631\u0651\u0641\u0627\u062A \u0627\u0644\u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627",
      "Scan loaded scripts for X GraphQL operation IDs and cache them locally.": "\u064A\u0641\u062D\u0635 \u0627\u0644\u0633\u0643\u0631\u0628\u062A\u0627\u062A \u0627\u0644\u0645\u062D\u0645\u0651\u0644\u0629 \u0628\u062D\u062B\u064B\u0627 \u0639\u0646 \u0645\u0639\u0631\u0651\u0641\u0627\u062A \u0639\u0645\u0644\u064A\u0627\u062A GraphQL \u0641\u064A X \u0648\u064A\u062E\u0632\u0651\u0646\u0647\u0627 \u0645\u062D\u0644\u064A\u064B\u0627.",
      "Save folder hint": "\u0645\u062C\u0644\u062F \u0627\u0644\u062D\u0641\u0638",
      "Folder name (or path) used as the export ZIP root and download prefix.": "\u0627\u0633\u0645 \u0627\u0644\u0645\u062C\u0644\u062F (\u0623\u0648 \u0627\u0644\u0645\u0633\u0627\u0631) \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0643\u062C\u0630\u0631 \u0644\u0645\u0644\u0641 ZIP \u0648\u0643\u0628\u0627\u062F\u0626\u0629 \u0644\u0644\u062A\u0646\u0632\u064A\u0644.",
      "Export status": "\u062D\u0627\u0644\u0629 \u0627\u0644\u062A\u0635\u062F\u064A\u0631",
      "Export visible tweets": "\u062A\u0635\u062F\u064A\u0631 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0638\u0627\u0647\u0631\u0629",
      "Collect the currently rendered tweets and download a ZIP.": "\u064A\u062C\u0645\u0639 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u062D\u0627\u0644\u064A\u064B\u0627 \u0648\u064A\u0646\u0632\u0651\u0644\u0647\u0627 \u0643\u0645\u0644\u0641 ZIP.",
      "Copy diagnostics": "\u0646\u0633\u062E \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062A\u0634\u062E\u064A\u0635",
      "Copy support diagnostics (version, route, recent log).": "\u064A\u0646\u0633\u062E \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062F\u0639\u0645 (\u0627\u0644\u0625\u0635\u062F\u0627\u0631\u060C \u0627\u0644\u0635\u0641\u062D\u0629\u060C \u0622\u062E\u0631 \u0627\u0644\u0633\u062C\u0644).",
      "Download as WARC": "\u0627\u0644\u062A\u0646\u0632\u064A\u0644 \u0628\u0635\u064A\u063A\u0629 WARC",
      "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.": "\u064A\u063A\u0644\u0651\u0641 \u0627\u0644\u0633\u062C\u0644\u0627\u062A \u0627\u0644\u0645\u062C\u0645\u0651\u0639\u0629 \u0641\u064A \u0645\u0644\u0641 WARC \u0648\u0641\u0642 ISO-28500 \u0644\u0623\u062F\u0648\u0627\u062A \u0627\u0644\u0628\u062D\u062B \u0648\u0627\u0644\u062D\u0641\u0638.",
      "Copy as Markdown": "\u0646\u0633\u062E \u0628\u0635\u064A\u063A\u0629 Markdown",
      "Push a plain Markdown export onto the clipboard.": "\u064A\u0646\u0633\u062E \u062A\u0635\u062F\u064A\u0631\u064B\u0627 \u0628\u0635\u064A\u063A\u0629 Markdown \u0628\u0633\u064A\u0637\u0629 \u0625\u0644\u0649 \u0627\u0644\u062D\u0627\u0641\u0638\u0629.",
      "Save Obsidian Markdown": "\u062D\u0641\u0638 Markdown \u0644\u0640 Obsidian",
      "Markdown with YAML frontmatter and Aviary tags.": "Markdown \u0645\u0639 \u062A\u0631\u0648\u064A\u0633\u0629 YAML \u0648\u0648\u0633\u0648\u0645 Aviary.",
      "Save Notion Markdown": "\u062D\u0641\u0638 Markdown \u0644\u0640 Notion",
      "Heading-first Markdown that Notion imports cleanly.": "Markdown \u064A\u0639\u062A\u0645\u062F \u0639\u0644\u0649 \u0627\u0644\u0639\u0646\u0627\u0648\u064A\u0646 \u0648\u064A\u0633\u062A\u0648\u0631\u062F\u0647 Notion \u0628\u0633\u0644\u0627\u0633\u0629.",
      "Save records JSON": "\u062D\u0641\u0638 \u0627\u0644\u0633\u062C\u0644\u0627\u062A \u0628\u0635\u064A\u063A\u0629 JSON",
      "Raw ExportRecord[] JSON without ZIP wrapping.": "\u200FJSON \u062E\u0627\u0645 \u0645\u0646 \u0646\u0648\u0639 ExportRecord[] \u062F\u0648\u0646 \u062A\u063A\u0644\u064A\u0641 ZIP.",
      "Records per ZIP": "\u0639\u062F\u062F \u0627\u0644\u0633\u062C\u0644\u0627\u062A \u0644\u0643\u0644 ZIP",
      "Split a long export across several archives instead of one huge file (25-1000).": "\u064A\u0642\u0633\u0651\u0645 \u0639\u0645\u0644\u064A\u0627\u062A \u0627\u0644\u062A\u0635\u062F\u064A\u0631 \u0627\u0644\u0637\u0648\u064A\u0644\u0629 \u0639\u0644\u0649 \u0639\u062F\u0629 \u0645\u0644\u0641\u0627\u062A \u0628\u062F\u0644 \u0645\u0644\u0641 \u0648\u0627\u062D\u062F \u0636\u062E\u0645 (25-1000).",
      "Maximum export jobs": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0645\u0647\u0627\u0645 \u0627\u0644\u062A\u0635\u062F\u064A\u0631",
      "Keep the newest jobs. Use 0 for unlimited.": "\u064A\u062D\u062A\u0641\u0638 \u0628\u0623\u062D\u062F\u062B \u0627\u0644\u0645\u0647\u0627\u0645. \u0627\u0633\u062A\u062E\u062F\u0645 0 \u0644\u0639\u062F\u062F \u063A\u064A\u0631 \u0645\u062D\u062F\u0648\u062F.",
      "Maximum records per job": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0644\u0633\u062C\u0644\u0627\u062A \u0644\u0643\u0644 \u0645\u0647\u0645\u0629",
      "Keep the newest records in each job. Use 0 for unlimited.": "\u064A\u062D\u062A\u0641\u0638 \u0628\u0623\u062D\u062F\u062B \u0627\u0644\u0633\u062C\u0644\u0627\u062A \u0641\u064A \u0643\u0644 \u0645\u0647\u0645\u0629. \u0627\u0633\u062A\u062E\u062F\u0645 0 \u0644\u0639\u062F\u062F \u063A\u064A\u0631 \u0645\u062D\u062F\u0648\u062F.",
      "Maximum export age (days)": "\u0623\u0642\u0635\u0649 \u0639\u0645\u0631 \u0644\u0644\u062A\u0635\u062F\u064A\u0631 (\u0628\u0627\u0644\u0623\u064A\u0627\u0645)",
      "Remove older jobs at boot. Use 0 to disable age-based cleanup.": "\u064A\u062D\u0630\u0641 \u0627\u0644\u0645\u0647\u0627\u0645 \u0627\u0644\u0623\u0642\u062F\u0645 \u0639\u0646\u062F \u0627\u0644\u0628\u062F\u0621. \u0627\u0633\u062A\u062E\u062F\u0645 0 \u0644\u062A\u0639\u0637\u064A\u0644 \u0627\u0644\u062A\u0646\u0638\u064A\u0641 \u062D\u0633\u0628 \u0627\u0644\u0639\u0645\u0631.",
      "Unshorten t.co links": "\u062A\u0648\u0633\u064A\u0639 \u0631\u0648\u0627\u0628\u0637 t.co",
      "Replace short `t.co` redirects with the destination from aria-labels and titles.": "\u064A\u0633\u062A\u0628\u062F\u0644 \u0631\u0648\u0627\u0628\u0637 `t.co` \u0627\u0644\u0645\u062E\u062A\u0635\u0631\u0629 \u0628\u0627\u0644\u0648\u062C\u0647\u0629 \u0627\u0644\u0645\u0623\u062E\u0648\u0630\u0629 \u0645\u0646 aria-label \u0648\u0627\u0644\u0639\u0646\u0627\u0648\u064A\u0646.",
      "Clean tracking from links": "\u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u062A\u062A\u0628\u0651\u0639 \u0645\u0646 \u0627\u0644\u0631\u0648\u0627\u0628\u0637",
      "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.": "\u064A\u0632\u064A\u0644 \u0631\u0645\u0648\u0632 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0648\u0645\u0639\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u062D\u0645\u0644\u0627\u062A (utm_* \u0648fbclid \u0648\u0645\u0639\u0627\u0645\u0644\u0627\u062A t/s \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0640 X) \u0645\u0646 \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u062E\u0637 \u0627\u0644\u0632\u0645\u0646\u064A\u060C \u0641\u064A\u0635\u0628\u062D \u0645\u0627 \u062A\u0646\u0633\u062E\u0647 \u0647\u0648 \u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u062C\u0631\u0651\u062F.",
      "Account notes": "\u0645\u0644\u0627\u062D\u0638\u0627\u062A \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A",
      "Format: handle: note. One per line. Empty notes remove the entry.": "\u0627\u0644\u0635\u064A\u063A\u0629: \u0627\u0644\u062D\u0633\u0627\u0628: \u0627\u0644\u0645\u0644\u0627\u062D\u0638\u0629. \u0648\u0627\u062D\u062F\u0629 \u0641\u064A \u0643\u0644 \u0633\u0637\u0631. \u0627\u0644\u0645\u0644\u0627\u062D\u0638\u0629 \u0627\u0644\u0641\u0627\u0631\u063A\u0629 \u062A\u062D\u0630\u0641 \u0627\u0644\u0639\u0646\u0635\u0631.",
      "Clear all account notes": "\u0645\u0633\u062D \u0643\u0644 \u0645\u0644\u0627\u062D\u0638\u0627\u062A \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A",
      "Drop every persisted note.": "\u064A\u062D\u0630\u0641 \u0643\u0644 \u0627\u0644\u0645\u0644\u0627\u062D\u0638\u0627\u062A \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629.",
      "Composer snippets": "\u0627\u0644\u0646\u0635\u0648\u0635 \u0627\u0644\u062C\u0627\u0647\u0632\u0629",
      "One snippet per line. Reusable replies / templates (insertion landing in a later release).": "\u0646\u0635 \u0648\u0627\u062D\u062F \u0641\u064A \u0643\u0644 \u0633\u0637\u0631. \u0631\u062F\u0648\u062F \u0648\u0642\u0648\u0627\u0644\u0628 \u0642\u0627\u0628\u0644\u0629 \u0644\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 (\u0627\u0644\u0625\u062F\u0631\u0627\u062C \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A \u0641\u064A \u0625\u0635\u062F\u0627\u0631 \u0644\u0627\u062D\u0642).",
      "Snapshots stored": "\u0627\u0644\u0644\u0642\u0637\u0627\u062A \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629",
      "Capture followers from this view": "\u062C\u0645\u0639 \u0627\u0644\u0645\u062A\u0627\u0628\u0650\u0639\u064A\u0646 \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629",
      "Walks UserCell rows on the current page. Open a /handle/followers view first.": "\u064A\u0645\u0631\u0651 \u0639\u0644\u0649 \u0635\u0641\u0648\u0641 UserCell \u0641\u064A \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629. \u0627\u0641\u062A\u062D \u0623\u0648\u0644\u064B\u0627 \u0635\u0641\u062D\u0629 \u200E/\u0627\u0644\u062D\u0633\u0627\u0628/followers\u200E.",
      "Capture following from this view": "\u062C\u0645\u0639 \u0627\u0644\u0645\u062A\u0627\u0628\u064E\u0639\u064A\u0646 \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629",
      "Walks UserCell rows on the current page. Open a /handle/following view first.": "\u064A\u0645\u0631\u0651 \u0639\u0644\u0649 \u0635\u0641\u0648\u0641 UserCell \u0641\u064A \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629. \u0627\u0641\u062A\u062D \u0623\u0648\u0644\u064B\u0627 \u0635\u0641\u062D\u0629 \u200E/\u0627\u0644\u062D\u0633\u0627\u0628/following\u200E.",
      "Clear all snapshots": "\u0645\u0633\u062D \u0643\u0644 \u0627\u0644\u0644\u0642\u0637\u0627\u062A",
      "Drop every stored follower/following snapshot.": "\u064A\u062D\u0630\u0641 \u0643\u0644 \u0644\u0642\u0637\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u0628\u0650\u0639\u064A\u0646 \u0648\u0627\u0644\u0645\u062A\u0627\u0628\u064E\u0639\u064A\u0646 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629.",
      "Download Markdown report": "\u062A\u0646\u0632\u064A\u0644 \u062A\u0642\u0631\u064A\u0631 Markdown",
      "Audit log + snapshot diff + cleanup preview.": "\u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642 \u0648\u0645\u0642\u0627\u0631\u0646\u0629 \u0627\u0644\u0644\u0642\u0637\u0627\u062A \u0648\u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u062A\u0646\u0638\u064A\u0641.",
      "Cleanup review queue": "\u0642\u0627\u0626\u0645\u0629 \u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u062A\u0646\u0638\u064A\u0641",
      "Destructive actions": "\u0627\u0644\u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0627\u0644\u0645\u062F\u0645\u0651\u0631\u0629",
      "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log.": "\u0644\u0627 \u064A\u062D\u0630\u0641 Aviary \u0623\u064A \u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0623\u0648 \u0625\u0639\u062C\u0627\u0628\u0627\u062A \u0623\u0648 \u0645\u062A\u0627\u0628\u0639\u0627\u062A. \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629 \u0641\u0642\u0637\u061B \u0648\u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0623\u0648 \u0627\u0644\u062A\u062E\u0637\u064A \u064A\u064F\u0633\u062C\u064E\u0651\u0644\u0627\u0646 \u0641\u064A \u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642 \u0644\u0627 \u0623\u0643\u062B\u0631.",
      "Enqueue cleanup preview for review": "\u0625\u0636\u0627\u0641\u0629 \u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u062A\u0646\u0638\u064A\u0641 \u0625\u0644\u0649 \u0627\u0644\u0642\u0627\u0626\u0645\u0629",
      "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).": "\u064A\u0636\u064A\u0641 \u0625\u0644\u0649 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0643\u0644 \u0627\u0644\u0645\u0631\u0634\u062D\u064A\u0646 \u063A\u064A\u0631 \u0627\u0644\u0645\u062D\u0645\u064A\u064A\u0646 \u0645\u0646 \u0622\u062E\u0631 \u0645\u0639\u0627\u064A\u0646\u0629 \u062A\u0646\u0638\u064A\u0641 (\u062F\u0648\u0646 \u0623\u064A \u0625\u062C\u0631\u0627\u0621 \u0645\u062F\u0645\u0651\u0631).",
      "Clear cleanup queue": "\u0625\u0641\u0631\u0627\u063A \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062A\u0646\u0638\u064A\u0641",
      "Drop every queued item without touching account data.": "\u064A\u062D\u0630\u0641 \u0643\u0644 \u0639\u0646\u0627\u0635\u0631 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u062F\u0648\u0646 \u0627\u0644\u0645\u0633\u0627\u0633 \u0628\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062D\u0633\u0627\u0628.",
      "Aria2 handoff": "\u0627\u0644\u062A\u0633\u0644\u064A\u0645 \u0625\u0644\u0649 Aria2",
      "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.": "\u064A\u0631\u0633\u0644 \u062A\u0646\u0632\u064A\u0644\u0627\u062A \u0627\u0644\u0648\u0633\u0627\u0626\u0637 \u0627\u0644\u0643\u0628\u064A\u0631\u0629 \u0625\u0644\u0649 \u0646\u0642\u0637\u0629 Aria2 JSON-RPC \u0645\u0633\u062A\u0636\u0627\u0641\u0629 \u0630\u0627\u062A\u064A\u064B\u0627.",
      "Aria2 endpoint": "\u0646\u0642\u0637\u0629 Aria2",
      "http://localhost:6800 (no trailing slash needed)": "\u200Fhttp://localhost:6800 (\u062F\u0648\u0646 \u0634\u0631\u0637\u0629 \u0645\u0627\u0626\u0644\u0629 \u0641\u064A \u0627\u0644\u0646\u0647\u0627\u064A\u0629)",
      "Aria2 RPC secret": "\u0633\u0631 RPC \u0627\u0644\u062E\u0627\u0635 \u0628\u0640 Aria2",
      "Optional shared secret for token: auth.": "\u0633\u0631 \u0645\u0634\u062A\u0631\u0643 \u0627\u062E\u062A\u064A\u0627\u0631\u064A \u0644\u0645\u0635\u0627\u062F\u0642\u0629 token:.",
      "Show": "\u0625\u0638\u0647\u0627\u0631",
      "Test Aria2 connection": "\u0627\u062E\u062A\u0628\u0627\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0640 Aria2",
      "Sends a trivial JSON-RPC call.": "\u064A\u0631\u0633\u0644 \u0637\u0644\u0628 JSON-RPC \u0628\u0633\u064A\u0637\u064B\u0627.",
      "Refresh": "\u062A\u062D\u062F\u064A\u062B",
      "Bluesky crosspost": "\u0627\u0644\u0646\u0634\u0631 \u0627\u0644\u0645\u062A\u0642\u0627\u0637\u0639 \u0639\u0644\u0649 Bluesky",
      "Post composer text to your Bluesky account on demand.": "\u064A\u0646\u0634\u0631 \u0646\u0635 \u0627\u0644\u0645\u062D\u0631\u0631 \u0639\u0644\u0649 \u062D\u0633\u0627\u0628\u0643 \u0641\u064A Bluesky \u0639\u0646\u062F \u0627\u0644\u0637\u0644\u0628.",
      "Bluesky service URL": "\u0631\u0627\u0628\u0637 \u062E\u062F\u0645\u0629 Bluesky",
      "Default: https://bsky.social": "\u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A: https://bsky.social",
      "Bluesky handle": "\u062D\u0633\u0627\u0628 Bluesky",
      "Your handle (no @, e.g. you.bsky.social)": "\u0627\u0633\u0645 \u062D\u0633\u0627\u0628\u0643 (\u062F\u0648\u0646 @\u060C \u0645\u062B\u0644 you.bsky.social)",
      "Bluesky app password": "\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062A\u0637\u0628\u064A\u0642 Bluesky",
      "App password from your account settings \u2014 never your main password.": "\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0645\u0646 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u062D\u0633\u0627\u0628\u0643 \u2014 \u0644\u0627 \u062A\u0633\u062A\u062E\u062F\u0645 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631\u0643 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629 \u0623\u0628\u062F\u064B\u0627.",
      "Mastodon crosspost": "\u0627\u0644\u0646\u0634\u0631 \u0627\u0644\u0645\u062A\u0642\u0627\u0637\u0639 \u0639\u0644\u0649 Mastodon",
      "Post composer text to your Mastodon account on demand.": "\u064A\u0646\u0634\u0631 \u0646\u0635 \u0627\u0644\u0645\u062D\u0631\u0631 \u0639\u0644\u0649 \u062D\u0633\u0627\u0628\u0643 \u0641\u064A Mastodon \u0639\u0646\u062F \u0627\u0644\u0637\u0644\u0628.",
      "Mastodon instance": "\u062E\u0627\u062F\u0645 Mastodon",
      "https://mastodon.social": "https://mastodon.social",
      "Mastodon access token": "\u0631\u0645\u0632 \u0648\u0635\u0648\u0644 Mastodon",
      "Bearer token with write:statuses scope.": "\u0631\u0645\u0632 Bearer \u0628\u0646\u0637\u0627\u0642 write:statuses.",
      "Attach last download": "\u0625\u0631\u0641\u0627\u0642 \u0622\u062E\u0631 \u062A\u0646\u0632\u064A\u0644",
      "Upload the last successful Aviary media download with the first post in an explicit crosspost.": "\u064A\u0631\u0641\u0639 \u0622\u062E\u0631 \u0648\u0633\u0627\u0626\u0637 \u0646\u0632\u0651\u0644\u0647\u0627 Aviary \u0628\u0646\u062C\u0627\u062D \u0645\u0639 \u0623\u0648\u0644 \u0645\u0646\u0634\u0648\u0631 \u0641\u064A \u0627\u0644\u0646\u0634\u0631 \u0627\u0644\u0645\u062A\u0642\u0627\u0637\u0639.",
      "Crosspost composer \u2192 Bluesky": "\u0646\u0634\u0631 \u0627\u0644\u0645\u062D\u0631\u0631 \u0639\u0644\u0649 Bluesky",
      "Uses the current composer text.": "\u064A\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0646\u0635 \u0627\u0644\u062D\u0627\u0644\u064A \u0641\u064A \u0627\u0644\u0645\u062D\u0631\u0631.",
      "Crosspost composer \u2192 Mastodon": "\u0646\u0634\u0631 \u0627\u0644\u0645\u062D\u0631\u0631 \u0639\u0644\u0649 Mastodon",
      "AI provider runs": "\u062A\u0634\u063A\u064A\u0644 \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A",
      "Let the AI command menu POST prompts to your configured provider.": "\u064A\u0633\u0645\u062D \u0644\u0642\u0627\u0626\u0645\u0629 \u0623\u0648\u0627\u0645\u0631 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A \u0628\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0625\u0644\u0649 \u0627\u0644\u0645\u0632\u0648\u0651\u062F \u0627\u0644\u0630\u064A \u0623\u0639\u062F\u062F\u062A\u0647.",
      "AI provider": "\u0645\u0632\u0648\u0651\u062F \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A",
      "Anthropic Messages API": "Anthropic Messages API",
      "OpenAI Chat Completions": "OpenAI Chat Completions",
      "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)": "\u0645\u062A\u0648\u0627\u0641\u0642 \u0645\u0639 OpenAI (LocalAI\u060C \u0648\u0633\u064A\u0637 Ollama\u060C \u2026)",
      "AI endpoint (optional)": "\u0646\u0642\u0637\u0629 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
      "Override the default endpoint for the chosen provider.": "\u064A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u0646\u0642\u0637\u0629 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629 \u0644\u0644\u0645\u0632\u0648\u0651\u062F \u0627\u0644\u0645\u062E\u062A\u0627\u0631.",
      "AI model": "\u0646\u0645\u0648\u0630\u062C \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A",
      "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b": "\u0645\u062B\u0627\u0644: claude-sonnet-4-6\u060C gpt-4o\u060C llama3.1:8b",
      "AI API key": "\u0645\u0641\u062A\u0627\u062D API \u0644\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A",
      "Stored locally only. Aviary never sends this except as the auth header to your provider.": "\u064A\u064F\u062D\u0641\u0638 \u0645\u062D\u0644\u064A\u064B\u0627 \u0641\u0642\u0637. \u0644\u0627 \u064A\u0631\u0633\u0644\u0647 Aviary \u0625\u0644\u0627 \u0643\u062A\u0631\u0648\u064A\u0633\u0629 \u0645\u0635\u0627\u062F\u0642\u0629 \u0625\u0644\u0649 \u0645\u0632\u0648\u0651\u062F\u0643.",
      "Semantic search": "\u0627\u0644\u0628\u062D\u062B \u0627\u0644\u062F\u0644\u0627\u0644\u064A",
      "Embed CheckpointStore records via your provider for similarity search.": "\u064A\u062D\u0648\u0651\u0644 \u0633\u062C\u0644\u0627\u062A CheckpointStore \u0625\u0644\u0649 \u0645\u062A\u062C\u0647\u0627\u062A \u0639\u0628\u0631 \u0645\u0632\u0648\u0651\u062F\u0643 \u0644\u0644\u0628\u062D\u062B \u0628\u0627\u0644\u062A\u0634\u0627\u0628\u0647.",
      "Embedding endpoint": "\u0646\u0642\u0637\u0629 \u0627\u0644\u062A\u0636\u0645\u064A\u0646",
      "POST endpoint that returns {data: [{embedding: number[]}]}": "\u0646\u0642\u0637\u0629 POST \u062A\u064F\u0639\u064A\u062F {data: [{embedding: number[]}]}",
      "Embedding model": "\u0646\u0645\u0648\u0630\u062C \u0627\u0644\u062A\u0636\u0645\u064A\u0646",
      "e.g. text-embedding-3-small": "\u0645\u062B\u0627\u0644: text-embedding-3-small",
      "Embedding API key": "\u0645\u0641\u062A\u0627\u062D API \u0644\u0644\u062A\u0636\u0645\u064A\u0646",
      "Stored locally; used only as the Authorization header.": "\u064A\u064F\u062D\u0641\u0638 \u0645\u062D\u0644\u064A\u064B\u0627\u060C \u0648\u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0641\u0642\u0637 \u0643\u062A\u0631\u0648\u064A\u0633\u0629 Authorization.",
      "Auto-embed every export": "\u0627\u0644\u062A\u0636\u0645\u064A\u0646 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A \u0628\u0639\u062F \u0643\u0644 \u062A\u0635\u062F\u064A\u0631",
      "After each export run, kick the embedding job in the background. Off by default.": "\u0628\u0639\u062F \u0643\u0644 \u0639\u0645\u0644\u064A\u0629 \u062A\u0635\u062F\u064A\u0631\u060C \u064A\u0628\u062F\u0623 \u0627\u0644\u062A\u0636\u0645\u064A\u0646 \u0641\u064A \u0627\u0644\u062E\u0644\u0641\u064A\u0629. \u0645\u0639\u0637\u0651\u0644 \u0627\u0641\u062A\u0631\u0627\u0636\u064A\u064B\u0627.",
      "Rebuild semantic index": "\u0625\u0639\u0627\u062F\u0629 \u0628\u0646\u0627\u0621 \u0627\u0644\u0641\u0647\u0631\u0633 \u0627\u0644\u062F\u0644\u0627\u0644\u064A",
      "Embed every captured record. Re-running is cheap because cached entries are skipped.": "\u064A\u0636\u0645\u0651\u0646 \u0643\u0644 \u0633\u062C\u0644 \u0645\u062C\u0645\u0651\u0639. \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0634\u063A\u064A\u0644 \u063A\u064A\u0631 \u0645\u0643\u0644\u0641\u0629 \u0644\u0623\u0646 \u0627\u0644\u0639\u0646\u0627\u0635\u0631 \u0627\u0644\u0645\u062E\u0632\u0651\u0646\u0629 \u062A\u064F\u062A\u062E\u0637\u0651\u0649.",
      "Clear semantic index": "\u0645\u0633\u062D \u0627\u0644\u0641\u0647\u0631\u0633 \u0627\u0644\u062F\u0644\u0627\u0644\u064A",
      "Forget every embedded record.": "\u064A\u0646\u0633\u0649 \u0643\u0644 \u0627\u0644\u0633\u062C\u0644\u0627\u062A \u0627\u0644\u0645\u0636\u0645\u0651\u0646\u0629.",
      "Integration status": "\u062D\u0627\u0644\u0629 \u0627\u0644\u062A\u0643\u0627\u0645\u0644\u0627\u062A",
      "Export settings": "\u062A\u0635\u062F\u064A\u0631 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A",
      "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.": "\u064A\u0646\u0632\u0651\u0644 \u062A\u0641\u0636\u064A\u0644\u0627\u062A\u0643 \u0628\u0635\u064A\u063A\u0629 JSON. \u062A\u064F\u0633\u062A\u0628\u062F\u0644 \u0645\u0641\u0627\u062A\u064A\u062D API \u0648\u0643\u0644\u0645\u0627\u062A \u0627\u0644\u0645\u0631\u0648\u0631 \u0628\u0639\u0646\u0635\u0631 \u0646\u0627\u0626\u0628\u060C \u0641\u064A\u0635\u0628\u062D \u0627\u0644\u0645\u0644\u0641 \u0622\u0645\u0646\u064B\u0627 \u0644\u0644\u0645\u0634\u0627\u0631\u0643\u0629\u061B \u0648\u0627\u0633\u062A\u064A\u0631\u0627\u062F\u0647 \u0647\u0646\u0627 \u064A\u0628\u0642\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632.",
      "Import settings (JSON)": "\u0627\u0633\u062A\u064A\u0631\u0627\u062F \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A (JSON)",
      "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.": "\u0627\u0644\u0635\u0642 \u0645\u0644\u0641 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0645\u064F\u0635\u062F\u064E\u0651\u0631\u064B\u0627 \u0645\u0646 Aviary \u062B\u0645 \u0627\u062E\u062A\u0631 \u0627\u0633\u062A\u064A\u0631\u0627\u062F. \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u0645\u062D\u062C\u0648\u0628\u0629 \u062A\u062D\u062A\u0641\u0638 \u0628\u0627\u0644\u0642\u064A\u0645 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629 \u0647\u0646\u0627.",
      "Import": "\u0627\u0633\u062A\u064A\u0631\u0627\u062F",
      "Keep a local action log": "\u0627\u0644\u0627\u062D\u062A\u0641\u0627\u0638 \u0628\u0633\u062C\u0644 \u0645\u062D\u0644\u064A \u0644\u0644\u0625\u062C\u0631\u0627\u0621\u0627\u062A",
      "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.": "\u064A\u0633\u062C\u0651\u0644 \u0627\u0644\u062A\u0646\u0632\u064A\u0644\u0627\u062A \u0648\u0639\u0645\u0644\u064A\u0627\u062A \u0627\u0644\u062A\u0635\u062F\u064A\u0631 \u0648\u062A\u063A\u064A\u064A\u0631\u0627\u062A \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632 \u0644\u062A\u062A\u0645\u0643\u0646 \u0645\u0646 \u0645\u0631\u0627\u062C\u0639\u0629 \u0645\u0627 \u0641\u0639\u0644\u0647 Aviary. \u0644\u0627 \u064A\u064F\u0631\u0633\u0644 \u0623\u064A \u0634\u064A\u0621 \u0625\u0644\u0649 \u0623\u064A \u062C\u0647\u0629. \u0625\u064A\u0642\u0627\u0641\u0647 \u064A\u0645\u0646\u0639 \u0625\u0636\u0627\u0641\u0629 \u0623\u064A \u0639\u0646\u0627\u0635\u0631 \u062C\u062F\u064A\u062F\u0629 \u0641\u0648\u0631\u064B\u0627\u060C \u0648\u062A\u0628\u0642\u0649 \u0627\u0644\u0639\u0646\u0627\u0635\u0631 \u0627\u0644\u062D\u0627\u0644\u064A\u0629 \u062D\u062A\u0649 \u062A\u0645\u0633\u062D\u0647\u0627.",
      "Audit entries": "\u0639\u0646\u0627\u0635\u0631 \u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642",
      "Clear audit log": "\u0645\u0633\u062D \u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642",
      "Drop the local action log.": "\u064A\u062D\u0630\u0641 \u0633\u062C\u0644 \u0627\u0644\u0625\u062C\u0631\u0627\u0621\u0627\u062A \u0627\u0644\u0645\u062D\u0644\u064A.",
      "Storage": "\u0627\u0644\u062A\u062E\u0632\u064A\u0646",
      "Settings stay in this browser.": "\u062A\u0628\u0642\u0649 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u062F\u0627\u062E\u0644 \u0647\u0630\u0627 \u0627\u0644\u0645\u062A\u0635\u0641\u062D.",
      "Local-only mode": "\u0627\u0644\u0648\u0636\u0639 \u0627\u0644\u0645\u062D\u0644\u064A \u0641\u0642\u0637",
      "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.": "\u064A\u0645\u0646\u0639 \u0643\u0644 \u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0635\u0627\u062F\u0631\u0629\u060C \u0628\u0645\u0627 \u0641\u064A\u0647\u0627 \u0627\u0644\u062A\u0643\u0627\u0645\u0644\u0627\u062A \u0627\u0644\u062A\u064A \u0623\u0639\u062F\u062F\u062A\u0647\u0627. \u0645\u064F\u0641\u0639\u0651\u0644 \u0627\u0641\u062A\u0631\u0627\u0636\u064A\u064B\u0627\u060C \u0648\u062A\u0641\u0639\u064A\u0644 \u0623\u064A \u062A\u0643\u0627\u0645\u0644 \u0647\u0648 \u0645\u0627 \u064A\u0648\u0642\u0641\u0647.",
      "Some changes could not be saved \u2014 the browser store may be full.": "\u062A\u0639\u0630\u0651\u0631 \u062D\u0641\u0638 \u0628\u0639\u0636 \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A \u2014 \u0642\u062F \u062A\u0643\u0648\u0646 \u0645\u0633\u0627\u062D\u0629 \u062A\u062E\u0632\u064A\u0646 \u0627\u0644\u0645\u062A\u0635\u0641\u062D \u0645\u0645\u062A\u0644\u0626\u0629.",
      "Saving": "\u0627\u0644\u062D\u0641\u0638",
      "Telemetry": "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645",
      "Disabled": "\u0645\u0639\u0637\u0651\u0644",
      "Panel language": "\u0644\u063A\u0629 \u0627\u0644\u0644\u0648\u062D\u0629",
      "Selector health": "\u062D\u0627\u0644\u0629 \u0627\u0644\u0645\u062D\u062F\u0650\u0651\u062F\u0627\u062A",
      "Working \u2014 every change has been written.": "\u064A\u0639\u0645\u0644 \u0628\u0634\u0643\u0644 \u0633\u0644\u064A\u0645 \u2014 \u062A\u0645 \u062D\u0641\u0638 \u0643\u0644 \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A.",
      "Monitoring active": "\u0627\u0644\u0645\u0631\u0627\u0642\u0628\u0629 \u0646\u0634\u0637\u0629",
      "Preset packs unavailable in this build.": "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062C\u0627\u0647\u0632\u0629 \u063A\u064A\u0631 \u0645\u062A\u0648\u0641\u0631\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0646\u0633\u062E\u0629.",
      "Hidden post store unavailable in this build.": "\u0645\u062E\u0632\u0646 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0627\u062A \u0627\u0644\u0645\u062E\u0641\u064A\u0629 \u063A\u064A\u0631 \u0645\u062A\u0648\u0641\u0631 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0646\u0633\u062E\u0629.",
      "Cancel": "\u0625\u0644\u063A\u0627\u0621"
    },
    he: {
      "Aviary": "Aviary",
      "Local controls for a quieter X.": "\u05DB\u05DC\u05D9\u05DD \u05DE\u05E7\u05D5\u05DE\u05D9\u05D9\u05DD \u05DC\u2011X \u05E9\u05E7\u05D8 \u05D9\u05D5\u05EA\u05E8.",
      "Close": "\u05E1\u05D2\u05D9\u05E8\u05D4",
      "Search settings": "\u05D7\u05D9\u05E4\u05D5\u05E9 \u05D1\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA",
      "Saved locally": "\u05E0\u05E9\u05DE\u05E8 \u05DE\u05E7\u05D5\u05DE\u05D9\u05EA",
      "Settings sections": "\u05DE\u05E7\u05D8\u05E2\u05D9 \u05D4\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA",
      "Start": "\u05D4\u05EA\u05D7\u05DC\u05D4",
      "Presets": "\u05E2\u05E8\u05DB\u05D5\u05EA \u05DE\u05D5\u05DB\u05E0\u05D5\u05EA",
      "Reading": "\u05E7\u05E8\u05D9\u05D0\u05D4",
      "Appearance": "\u05DE\u05E8\u05D0\u05D4",
      "Layout": "\u05E4\u05E8\u05D9\u05E1\u05D4",
      "Filtering": "\u05E1\u05D9\u05E0\u05D5\u05DF",
      "Hidden posts": "\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05DE\u05D5\u05E1\u05EA\u05E8\u05D9\u05DD",
      "Data": "\u05E0\u05EA\u05D5\u05E0\u05D9\u05DD",
      "Media": "\u05DE\u05D3\u05D9\u05D4",
      "Export": "\u05D9\u05D9\u05E6\u05D5\u05D0",
      "Library": "\u05E1\u05E4\u05E8\u05D9\u05D9\u05D4",
      "Snapshots & Archive": "\u05EA\u05E6\u05DC\u05D5\u05DE\u05D9 \u05DE\u05E6\u05D1 \u05D5\u05D0\u05E8\u05DB\u05D9\u05D5\u05DF",
      "Advanced": "\u05DE\u05EA\u05E7\u05D3\u05DD",
      "Integrations": "\u05D0\u05D9\u05E0\u05D8\u05D2\u05E8\u05E6\u05D9\u05D5\u05EA",
      "Backup & Audit": "\u05D2\u05D9\u05D1\u05D5\u05D9 \u05D5\u05D1\u05D9\u05E7\u05D5\u05E8\u05EA",
      "Trust": "\u05E4\u05E8\u05D8\u05D9\u05D5\u05EA",
      "Apply": "\u05D4\u05D7\u05DC\u05D4",
      "Locale": "\u05E9\u05E4\u05D4",
      "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.": "\u05DE\u05EA\u05E8\u05D2\u05DD \u05D0\u05EA \u05D4\u05E4\u05D0\u05E0\u05DC \u05D5\u05E7\u05D5\u05D1\u05E2 \u05D0\u05EA \u05DB\u05D9\u05D5\u05D5\u05DF \u05D4\u05E7\u05E8\u05D9\u05D0\u05D4 \u2014 \u05DE\u05D9\u05DE\u05D9\u05DF \u05DC\u05E9\u05DE\u05D0\u05DC \u05D1\u05E2\u05E8\u05D1\u05D9\u05EA \u05D5\u05D1\u05E2\u05D1\u05E8\u05D9\u05EA. \u05D1\u05DE\u05E7\u05D8\u05E2 \u05D4\u05E4\u05E8\u05D8\u05D9\u05D5\u05EA \u05DE\u05D5\u05E6\u05D2 \u05DB\u05DE\u05D4 \u05DE\u05D4\u05E9\u05E4\u05D4 \u05D4\u05E0\u05D1\u05D7\u05E8\u05EA \u05DE\u05EA\u05D5\u05E8\u05D2\u05DD; \u05DE\u05D4 \u05E9\u05D7\u05E1\u05E8 \u05E0\u05E9\u05D0\u05E8 \u05D1\u05D0\u05E0\u05D2\u05DC\u05D9\u05EA.",
      "Theme value is not supported.": "\u05E2\u05E8\u05DB\u05EA \u05D4\u05E0\u05D5\u05E9\u05D0 \u05D4\u05D6\u05D5 \u05D0\u05D9\u05E0\u05D4 \u05E0\u05EA\u05DE\u05DB\u05EA.",
      "Theme updated": "\u05E2\u05E8\u05DB\u05EA \u05D4\u05E0\u05D5\u05E9\u05D0 \u05E2\u05D5\u05D3\u05DB\u05E0\u05D4",
      "Density updated": "\u05D4\u05E6\u05E4\u05D9\u05E4\u05D5\u05EA \u05E2\u05D5\u05D3\u05DB\u05E0\u05D4",
      "Contrast preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05D4\u05E0\u05D9\u05D2\u05D5\u05D3\u05D9\u05D5\u05EA \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Motion preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05D4\u05EA\u05E0\u05D5\u05E2\u05D4 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Sidebar preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05E1\u05E8\u05D2\u05DC \u05D4\u05E6\u05D3 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Trend preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05D4\u05DE\u05D2\u05DE\u05D5\u05EA \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Grok preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA Grok \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Could not apply preset.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D4\u05D7\u05D9\u05DC \u05D0\u05EA \u05D4\u05E2\u05E8\u05DB\u05D4.",
      "Snapshot failed.": "\u05EA\u05E6\u05DC\u05D5\u05DD \u05D4\u05DE\u05E6\u05D1 \u05E0\u05DB\u05E9\u05DC.",
      "Snapshots cleared": "\u05EA\u05E6\u05DC\u05D5\u05DE\u05D9 \u05D4\u05DE\u05E6\u05D1 \u05E0\u05D5\u05E7\u05D5",
      "Could not clear snapshots.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E0\u05E7\u05D5\u05EA \u05D0\u05EA \u05EA\u05E6\u05DC\u05D5\u05DE\u05D9 \u05D4\u05DE\u05E6\u05D1.",
      "Reading archive \u2014 large files take a moment\u2026": "\u05E7\u05D5\u05E8\u05D0 \u05D0\u05EA \u05D4\u05D0\u05E8\u05DB\u05D9\u05D5\u05DF \u2014 \u05E7\u05D1\u05E6\u05D9\u05DD \u05D2\u05D3\u05D5\u05DC\u05D9\u05DD \u05DC\u05D5\u05E7\u05D7\u05D9\u05DD \u05E8\u05D2\u05E2\u2026",
      "Archive import failed.": "\u05D9\u05D9\u05D1\u05D5\u05D0 \u05D4\u05D0\u05E8\u05DB\u05D9\u05D5\u05DF \u05E0\u05DB\u05E9\u05DC.",
      "Building report\u2026": "\u05D1\u05D5\u05E0\u05D4 \u05D0\u05EA \u05D4\u05D3\u05D5\u05D7\u2026",
      "Report downloaded.": "\u05D4\u05D3\u05D5\u05D7 \u05D4\u05D5\u05E8\u05D3.",
      "Could not build report.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D1\u05E0\u05D5\u05EA \u05D0\u05EA \u05D4\u05D3\u05D5\u05D7.",
      "Building cleanup preview\u2026": "\u05D1\u05D5\u05E0\u05D4 \u05EA\u05E6\u05D5\u05D2\u05D4 \u05DE\u05E7\u05D3\u05D9\u05DE\u05D4 \u05E9\u05DC \u05D4\u05E0\u05D9\u05E7\u05D5\u05D9\u2026",
      "Could not enqueue cleanup.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D4\u05D5\u05E1\u05D9\u05E3 \u05D0\u05EA \u05D4\u05E0\u05D9\u05E7\u05D5\u05D9 \u05DC\u05EA\u05D5\u05E8.",
      "Cleanup queue cleared": "\u05EA\u05D5\u05E8 \u05D4\u05E0\u05D9\u05E7\u05D5\u05D9 \u05E8\u05D5\u05E7\u05DF",
      "Could not clear queue.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E8\u05D5\u05E7\u05DF \u05D0\u05EA \u05D4\u05EA\u05D5\u05E8.",
      "Aria2 endpoint saved": "\u05E0\u05E7\u05D5\u05D3\u05EA \u05D4\u05E7\u05E6\u05D4 \u05E9\u05DC Aria2 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Aria2 secret saved": "\u05D4\u05E1\u05D5\u05D3 \u05E9\u05DC Aria2 \u05E0\u05E9\u05DE\u05E8",
      "Aria2 sweep failed.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E7\u05D1\u05DC \u05D0\u05EA \u05E8\u05E9\u05D9\u05DE\u05EA Aria2.",
      "Bluesky service saved": "\u05E9\u05D9\u05E8\u05D5\u05EA Bluesky \u05E0\u05E9\u05DE\u05E8",
      "Bluesky handle saved": "\u05D7\u05E9\u05D1\u05D5\u05DF Bluesky \u05E0\u05E9\u05DE\u05E8",
      "Bluesky app password saved": "\u05E1\u05D9\u05E1\u05DE\u05EA \u05D4\u05D0\u05E4\u05DC\u05D9\u05E7\u05E6\u05D9\u05D4 \u05E9\u05DC Bluesky \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Mastodon instance saved": "\u05E9\u05E8\u05EA Mastodon \u05E0\u05E9\u05DE\u05E8",
      "Mastodon token saved": "\u05D0\u05E1\u05D9\u05DE\u05D5\u05DF Mastodon \u05E0\u05E9\u05DE\u05E8",
      "AI endpoint saved": "\u05E0\u05E7\u05D5\u05D3\u05EA \u05D4\u05E7\u05E6\u05D4 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "AI model saved": "\u05D4\u05DE\u05D5\u05D3\u05DC \u05E0\u05E9\u05DE\u05E8",
      "AI API key saved": "\u05DE\u05E4\u05EA\u05D7 \u05D4\u2011API \u05E0\u05E9\u05DE\u05E8",
      "Embedding endpoint saved": "\u05E0\u05E7\u05D5\u05D3\u05EA \u05D4\u05E7\u05E6\u05D4 \u05DC\u05D4\u05D8\u05DE\u05E2\u05D4 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Embedding model saved": "\u05DE\u05D5\u05D3\u05DC \u05D4\u05D4\u05D8\u05DE\u05E2\u05D4 \u05E0\u05E9\u05DE\u05E8",
      "Embedding API key saved": "\u05DE\u05E4\u05EA\u05D7 \u05D4\u2011API \u05DC\u05D4\u05D8\u05DE\u05E2\u05D4 \u05E0\u05E9\u05DE\u05E8",
      "Rebuilding semantic index\u2026": "\u05D1\u05D5\u05E0\u05D4 \u05DE\u05D7\u05D3\u05E9 \u05D0\u05EA \u05D4\u05D0\u05D9\u05E0\u05D3\u05E7\u05E1 \u05D4\u05E1\u05DE\u05E0\u05D8\u05D9\u2026",
      "Embedding failed.": "\u05D4\u05D4\u05D8\u05DE\u05E2\u05D4 \u05E0\u05DB\u05E9\u05DC\u05D4.",
      "Semantic index cleared": "\u05D4\u05D0\u05D9\u05E0\u05D3\u05E7\u05E1 \u05D4\u05E1\u05DE\u05E0\u05D8\u05D9 \u05E0\u05D5\u05E7\u05D4",
      "Account notes cleared": "\u05D4\u05D4\u05E2\u05E8\u05D5\u05EA \u05E2\u05DC \u05D4\u05D7\u05E9\u05D1\u05D5\u05E0\u05D5\u05EA \u05E0\u05D5\u05E7\u05D5",
      "Could not clear notes.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E0\u05E7\u05D5\u05EA \u05D0\u05EA \u05D4\u05D4\u05E2\u05E8\u05D5\u05EA.",
      "Settings exported.": "\u05D4\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05D9\u05D5\u05E6\u05D0\u05D5.",
      "Could not export settings.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D9\u05D9\u05E6\u05D0 \u05D0\u05EA \u05D4\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA.",
      "Could not import settings.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D9\u05D9\u05D1\u05D0 \u05D0\u05EA \u05D4\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA.",
      "Audit log cleared": "\u05D9\u05D5\u05DE\u05DF \u05D4\u05D1\u05D9\u05E7\u05D5\u05E8\u05EA \u05E0\u05D5\u05E7\u05D4",
      "Could not clear audit log.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E0\u05E7\u05D5\u05EA \u05D0\u05EA \u05D9\u05D5\u05DE\u05DF \u05D4\u05D1\u05D9\u05E7\u05D5\u05E8\u05EA.",
      "Raw payload preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05D4\u05EA\u05E9\u05D5\u05D1\u05D5\u05EA \u05D4\u05D2\u05D5\u05DC\u05DE\u05D9\u05D5\u05EA \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Query discovery preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05D6\u05D9\u05D4\u05D5\u05D9 \u05D4\u05E9\u05D0\u05D9\u05DC\u05EA\u05D5\u05EA \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Save folder hint saved": "\u05EA\u05D9\u05E7\u05D9\u05D9\u05EA \u05D4\u05E9\u05DE\u05D9\u05E8\u05D4 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Collecting visible posts\u2026": "\u05D0\u05D5\u05E1\u05E3 \u05D0\u05EA \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E6\u05D2\u05D9\u05DD\u2026",
      "Export failed. See diagnostics.": "\u05D4\u05D9\u05D9\u05E6\u05D5\u05D0 \u05E0\u05DB\u05E9\u05DC. \u05E2\u05D9\u05D9\u05DF \u05D1\u05E0\u05EA\u05D5\u05E0\u05D9 \u05D4\u05D0\u05D1\u05D7\u05D5\u05DF.",
      "Diagnostics copied to clipboard.": "\u05E0\u05EA\u05D5\u05E0\u05D9 \u05D4\u05D0\u05D1\u05D7\u05D5\u05DF \u05D4\u05D5\u05E2\u05EA\u05E7\u05D5 \u05DC\u05DC\u05D5\u05D7.",
      "Could not copy diagnostics.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D4\u05E2\u05EA\u05D9\u05E7 \u05D0\u05EA \u05E0\u05EA\u05D5\u05E0\u05D9 \u05D4\u05D0\u05D1\u05D7\u05D5\u05DF.",
      "Building WARC archive\u2026": "\u05D1\u05D5\u05E0\u05D4 \u05D0\u05E8\u05DB\u05D9\u05D5\u05DF WARC\u2026",
      "WARC export failed.": "\u05D9\u05D9\u05E6\u05D5\u05D0 \u05D4\u2011WARC \u05E0\u05DB\u05E9\u05DC.",
      "External export failed.": "\u05D4\u05D9\u05D9\u05E6\u05D5\u05D0 \u05D4\u05D7\u05D9\u05E6\u05D5\u05E0\u05D9 \u05E0\u05DB\u05E9\u05DC.",
      "Records per ZIP saved": "\u05DE\u05E1\u05E4\u05E8 \u05D4\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05DC\u05DB\u05DC ZIP \u05E0\u05E9\u05DE\u05E8",
      "Export job retention saved": "\u05E9\u05DE\u05D9\u05E8\u05EA \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05D4\u05D9\u05D9\u05E6\u05D5\u05D0 \u05D4\u05D5\u05D2\u05D3\u05E8\u05D4",
      "Record retention saved": "\u05E9\u05DE\u05D9\u05E8\u05EA \u05D4\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05D4\u05D5\u05D2\u05D3\u05E8\u05D4",
      "Age-based retention saved": "\u05D4\u05E9\u05DE\u05D9\u05E8\u05D4 \u05DC\u05E4\u05D9 \u05D2\u05D9\u05DC \u05D4\u05D5\u05D2\u05D3\u05E8\u05D4",
      "Original quality preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05D4\u05D0\u05D9\u05DB\u05D5\u05EA \u05D4\u05DE\u05E7\u05D5\u05E8\u05D9\u05EA \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Filename template saved": "\u05EA\u05D1\u05E0\u05D9\u05EA \u05E9\u05DD \u05D4\u05E7\u05D5\u05D1\u05E5 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Sensitive content preference saved": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05D4\u05EA\u05D5\u05DB\u05DF \u05D4\u05E8\u05D2\u05D9\u05E9 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "Media layout saved": "\u05E4\u05E8\u05D9\u05E1\u05EA \u05D4\u05DE\u05D3\u05D9\u05D4 \u05E0\u05E9\u05DE\u05E8\u05D4",
      "History cleared": "\u05D4\u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D4 \u05E0\u05D5\u05E7\u05EA\u05D4",
      "Could not clear history.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E0\u05E7\u05D5\u05EA \u05D0\u05EA \u05D4\u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D4.",
      "Downloading media from this view\u2026": "\u05DE\u05D5\u05E8\u05D9\u05D3 \u05D0\u05EA \u05D4\u05DE\u05D3\u05D9\u05D4 \u05DE\u05D4\u05E2\u05DE\u05D5\u05D3 \u05D4\u05D6\u05D4\u2026",
      "Batch download failed.": "\u05D4\u05D4\u05D5\u05E8\u05D3\u05D4 \u05D4\u05DE\u05E8\u05D5\u05DB\u05D6\u05EA \u05E0\u05DB\u05E9\u05DC\u05D4.",
      "Premium filter saved": "\u05DE\u05E1\u05E0\u05DF \u05D4\u05E4\u05E8\u05D9\u05DE\u05D9\u05D5\u05DD \u05E0\u05E9\u05DE\u05E8",
      "Could not undo the last hide.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D1\u05D8\u05DC \u05D0\u05EA \u05D4\u05D4\u05E1\u05EA\u05E8\u05D4 \u05D4\u05D0\u05D7\u05E8\u05D5\u05E0\u05D4.",
      "Could not restore the post.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E9\u05D7\u05D6\u05E8 \u05D0\u05EA \u05D4\u05E4\u05D5\u05E1\u05D8.",
      "Could not clear hidden posts.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E0\u05E7\u05D5\u05EA \u05D0\u05EA \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E1\u05EA\u05E8\u05D9\u05DD.",
      "Saving...": "\u05E9\u05D5\u05DE\u05E8...",
      "Could not save settings. Try again.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E9\u05DE\u05D5\u05E8 \u05D0\u05EA \u05D4\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA. \u05E0\u05E1\u05D4 \u05E9\u05D5\u05D1.",
      "Theme": "\u05E2\u05E8\u05DB\u05EA \u05E0\u05D5\u05E9\u05D0",
      "Dim": "\u05E2\u05DE\u05D5\u05DD",
      "Lights out": "\u05DB\u05D9\u05D1\u05D5\u05D9 \u05D0\u05D5\u05E8\u05D5\u05EA",
      "Graphite": "\u05D2\u05E8\u05E4\u05D9\u05D8",
      "Plum": "\u05E9\u05D6\u05D9\u05E3",
      "Midnight": "\u05D7\u05E6\u05D5\u05EA",
      "Dense mode": "\u05DE\u05E6\u05D1 \u05E6\u05E4\u05D5\u05E3",
      "Tighten timeline spacing for scanning.": "\u05DE\u05E6\u05DE\u05E6\u05DD \u05D0\u05EA \u05D4\u05E8\u05D9\u05D5\u05D5\u05D7 \u05D1\u05E6\u05D9\u05E8 \u05D4\u05D6\u05DE\u05DF \u05DC\u05E1\u05E8\u05D9\u05E7\u05D4 \u05DE\u05D4\u05D9\u05E8\u05D4.",
      "Hide engagement counts": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05DE\u05D5\u05E0\u05D9 \u05DE\u05E2\u05D5\u05E8\u05D1\u05D5\u05EA",
      "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.": "\u05DE\u05E1\u05EA\u05D9\u05E8 \u05D0\u05EA \u05DE\u05E1\u05E4\u05E8\u05D9 \u05D4\u05EA\u05D2\u05D5\u05D1\u05D5\u05EA, \u05D4\u05E9\u05D9\u05EA\u05D5\u05E4\u05D9\u05DD \u05D5\u05D4\u05DC\u05D9\u05D9\u05E7\u05D9\u05DD. \u05D4\u05DB\u05E4\u05EA\u05D5\u05E8\u05D9\u05DD \u05DE\u05DE\u05E9\u05D9\u05DB\u05D9\u05DD \u05DC\u05E4\u05E2\u05D5\u05DC \u05D5\u05E7\u05D5\u05E8\u05D0\u05D9 \u05DE\u05E1\u05DA \u05DE\u05DE\u05E9\u05D9\u05DB\u05D9\u05DD \u05DC\u05D4\u05E7\u05E8\u05D9\u05D0 \u05D0\u05EA \u05D4\u05E1\u05DB\u05D5\u05DE\u05D9\u05DD.",
      "Hide row borders": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05D2\u05D1\u05D5\u05DC\u05D5\u05EA \u05E9\u05D5\u05E8\u05D5\u05EA",
      "Remove the 1px divider under each timeline post and the primary column's side rules.": "\u05DE\u05E1\u05D9\u05E8 \u05D0\u05EA \u05E7\u05D5 \u05D4\u05D4\u05E4\u05E8\u05D3\u05D4 \u05D1\u05E2\u05D5\u05D1\u05D9 \u05E4\u05D9\u05E7\u05E1\u05DC \u05DE\u05EA\u05D7\u05EA \u05DC\u05DB\u05DC \u05E4\u05D5\u05E1\u05D8, \u05D5\u05D0\u05EA \u05D4\u05E7\u05D5\u05D5\u05D9\u05DD \u05D1\u05E6\u05D3\u05D9 \u05D4\u05E2\u05DE\u05D5\u05D3\u05D4 \u05D4\u05E8\u05D0\u05E9\u05D9\u05EA.",
      "High contrast": "\u05E0\u05D9\u05D2\u05D5\u05D3\u05D9\u05D5\u05EA \u05D2\u05D1\u05D5\u05D4\u05D4",
      "Use stronger borders and text contrast.": "\u05DE\u05E9\u05EA\u05DE\u05E9 \u05D1\u05D2\u05D1\u05D5\u05DC\u05D5\u05EA \u05D5\u05D1\u05E0\u05D9\u05D2\u05D5\u05D3\u05D9\u05D5\u05EA \u05D8\u05E7\u05E1\u05D8 \u05D7\u05D6\u05E7\u05D9\u05DD \u05D9\u05D5\u05EA\u05E8.",
      "Reduced motion": "\u05E6\u05DE\u05E6\u05D5\u05DD \u05EA\u05E0\u05D5\u05E2\u05D4",
      "Follow system setting": "\u05DC\u05E4\u05D9 \u05D4\u05D2\u05D3\u05E8\u05EA \u05D4\u05DE\u05E2\u05E8\u05DB\u05EA",
      "Always reduce": "\u05DC\u05E6\u05DE\u05E6\u05DD \u05EA\u05DE\u05D9\u05D3",
      "Never reduce": "\u05DC\u05D0 \u05DC\u05E6\u05DE\u05E6\u05DD",
      "Hide right sidebar": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05E1\u05E8\u05D2\u05DC \u05D4\u05E6\u05D3",
      "Reduce trends, recommendations, and footer noise.": "\u05DE\u05E4\u05D7\u05D9\u05EA \u05E8\u05E2\u05E9 \u05E9\u05DC \u05DE\u05D2\u05DE\u05D5\u05EA, \u05D4\u05DE\u05DC\u05E6\u05D5\u05EA \u05D5\u05DB\u05D5\u05EA\u05E8\u05EA \u05EA\u05D7\u05EA\u05D5\u05E0\u05D4.",
      "Hide trends": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05DE\u05D2\u05DE\u05D5\u05EA",
      "Remove trending topics and news modules.": "\u05DE\u05E1\u05D9\u05E8 \u05D0\u05EA \u05D4\u05E0\u05D5\u05E9\u05D0\u05D9\u05DD \u05D4\u05D7\u05DE\u05D9\u05DD \u05D5\u05DE\u05D5\u05D3\u05D5\u05DC\u05D9 \u05D4\u05D7\u05D3\u05E9\u05D5\u05EA.",
      "Hide Grok surfaces": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05E8\u05DB\u05D9\u05D1\u05D9 Grok",
      "Remove Grok drawer and composer buttons where detected.": "\u05DE\u05E1\u05D9\u05E8 \u05D0\u05EA \u05DE\u05D2\u05D9\u05E8\u05EA Grok \u05D5\u05D0\u05EA \u05DB\u05E4\u05EA\u05D5\u05E8\u05D9\u05D5 \u05D1\u05D7\u05DC\u05D5\u05DF \u05D4\u05DB\u05EA\u05D9\u05D1\u05D4, \u05D4\u05D9\u05DB\u05DF \u05E9\u05D6\u05D5\u05D4\u05D5.",
      "Writer mode": "\u05DE\u05E6\u05D1 \u05DB\u05EA\u05D9\u05D1\u05D4",
      "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.": "\u05DB\u05DC \u05E2\u05D5\u05D3 \u05D4\u05DE\u05D9\u05E7\u05D5\u05D3 \u05D1\u05D7\u05DC\u05D5\u05DF \u05D4\u05DB\u05EA\u05D9\u05D1\u05D4, \u05E1\u05E8\u05D2\u05DC \u05D4\u05E6\u05D3 \u05D5\u05E6\u05D9\u05E8 \u05D4\u05D6\u05DE\u05DF \u05E9\u05DE\u05D0\u05D7\u05D5\u05E8\u05D9\u05D5 \u05DE\u05EA\u05E2\u05DE\u05E2\u05DE\u05D9\u05DD. \u05D4\u05DB\u05D5\u05DC \u05D7\u05D5\u05D6\u05E8 \u05D1\u05E8\u05D2\u05E2 \u05E9\u05DC\u05D5\u05D7\u05E6\u05D9\u05DD \u05D1\u05DE\u05E7\u05D5\u05DD \u05D0\u05D7\u05E8.",
      "Enable filters": "\u05D4\u05E4\u05E2\u05DC\u05EA \u05DE\u05E1\u05E0\u05E0\u05D9\u05DD",
      "Master switch for keyword, regex, premium, and media filters.": "\u05DE\u05EA\u05D2 \u05E8\u05D0\u05E9\u05D9 \u05DC\u05DE\u05E1\u05E0\u05E0\u05D9 \u05DE\u05D9\u05DC\u05D5\u05EA \u05DE\u05E4\u05EA\u05D7, \u05D1\u05D9\u05D8\u05D5\u05D9\u05D9\u05DD \u05E8\u05D2\u05D5\u05DC\u05E8\u05D9\u05D9\u05DD, \u05E4\u05E8\u05D9\u05DE\u05D9\u05D5\u05DD \u05D5\u05DE\u05D3\u05D9\u05D4.",
      "Keyword rules": "\u05DB\u05DC\u05DC\u05D9 \u05DE\u05D9\u05DC\u05D5\u05EA \u05DE\u05E4\u05EA\u05D7",
      "One keyword or phrase per line. Case-insensitive substring match.": "\u05DE\u05D9\u05DC\u05D4 \u05D0\u05D5 \u05D1\u05D9\u05D8\u05D5\u05D9 \u05D0\u05D7\u05D3 \u05D1\u05DB\u05DC \u05E9\u05D5\u05E8\u05D4. \u05D4\u05EA\u05D0\u05DE\u05D4 \u05D7\u05DC\u05E7\u05D9\u05EA \u05DC\u05DC\u05D0 \u05D4\u05D1\u05D7\u05E0\u05D4 \u05D1\u05D9\u05DF \u05D0\u05D5\u05EA\u05D9\u05D5\u05EA \u05D2\u05D3\u05D5\u05DC\u05D5\u05EA \u05DC\u05E7\u05D8\u05E0\u05D5\u05EA.",
      "Save list": "\u05E9\u05DE\u05D9\u05E8\u05EA \u05D4\u05E8\u05E9\u05D9\u05DE\u05D4",
      "Regex rules": "\u05DB\u05DC\u05DC\u05D9 \u05D1\u05D9\u05D8\u05D5\u05D9\u05D9\u05DD \u05E8\u05D2\u05D5\u05DC\u05E8\u05D9\u05D9\u05DD",
      "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).": "\u05EA\u05D1\u05E0\u05D9\u05EA \u05D0\u05D7\u05EA \u05D1\u05DB\u05DC \u05E9\u05D5\u05E8\u05D4. \u05D0\u05E4\u05E9\u05E8 \u200E/pattern/flags\u200E \u05D0\u05D5 \u05EA\u05D1\u05E0\u05D9\u05EA \u05D1\u05DC\u05D1\u05D3 (\u05DC\u05DC\u05D0 \u05D4\u05D1\u05D7\u05E0\u05D4 \u05D1\u05D9\u05DF \u05D0\u05D5\u05EA\u05D9\u05D5\u05EA \u05D2\u05D3\u05D5\u05DC\u05D5\u05EA \u05DC\u05E7\u05D8\u05E0\u05D5\u05EA).",
      "Whitelist handles": "\u05D7\u05E9\u05D1\u05D5\u05E0\u05D5\u05EA \u05DE\u05D5\u05D7\u05E8\u05D2\u05D9\u05DD",
      "Handles (one per line, no @) that are never filtered.": "\u05E9\u05DE\u05D5\u05EA \u05D7\u05E9\u05D1\u05D5\u05E0\u05D5\u05EA (\u05D0\u05D7\u05D3 \u05D1\u05DB\u05DC \u05E9\u05D5\u05E8\u05D4, \u05D1\u05DC\u05D9 @) \u05E9\u05DC\u05E2\u05D5\u05DC\u05DD \u05D0\u05D9\u05E0\u05DD \u05DE\u05E1\u05D5\u05E0\u05E0\u05D9\u05DD.",
      "Premium / verified posts": "\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E9\u05DC \u05E4\u05E8\u05D9\u05DE\u05D9\u05D5\u05DD \u05D5\u05DE\u05D0\u05D5\u05DE\u05EA\u05D9\u05DD",
      "Off": "\u05DB\u05D1\u05D5\u05D9",
      "Hide": "\u05D4\u05E1\u05EA\u05E8\u05D4",
      "Hide posts with photos": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E2\u05DD \u05EA\u05DE\u05D5\u05E0\u05D5\u05EA",
      "Filter posts containing photos.": "\u05DE\u05E1\u05E0\u05DF \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E9\u05DE\u05DB\u05D9\u05DC\u05D9\u05DD \u05EA\u05DE\u05D5\u05E0\u05D5\u05EA.",
      "Hide posts with videos": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E2\u05DD \u05E1\u05E8\u05D8\u05D5\u05E0\u05D9\u05DD",
      "Filter posts containing videos.": "\u05DE\u05E1\u05E0\u05DF \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E9\u05DE\u05DB\u05D9\u05DC\u05D9\u05DD \u05E1\u05E8\u05D8\u05D5\u05E0\u05D9\u05DD.",
      "Hide posts with gifs": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E2\u05DD GIF",
      "Filter posts containing gifs.": "\u05DE\u05E1\u05E0\u05DF \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E9\u05DE\u05DB\u05D9\u05DC\u05D9\u05DD GIF.",
      "Active on": "\u05E4\u05E2\u05D9\u05DC \u05D1\u05E2\u05DE\u05D5\u05D3\u05D9\u05DD",
      "Routes where filters run.": "\u05D4\u05E2\u05DE\u05D5\u05D3\u05D9\u05DD \u05E9\u05D1\u05D4\u05DD \u05D4\u05DE\u05E1\u05E0\u05E0\u05D9\u05DD \u05E4\u05D5\u05E2\u05DC\u05D9\u05DD.",
      "Home": "\u05D1\u05D9\u05EA",
      "Status": "\u05E4\u05D5\u05E1\u05D8",
      "Profile": "\u05E4\u05E8\u05D5\u05E4\u05D9\u05DC",
      "Search": "\u05D7\u05D9\u05E4\u05D5\u05E9",
      "Notifications": "\u05D4\u05EA\u05E8\u05D0\u05D5\u05EA",
      "Messages": "\u05D4\u05D5\u05D3\u05E2\u05D5\u05EA",
      "Blocked accounts / self-reposts": "\u05D7\u05E9\u05D1\u05D5\u05E0\u05D5\u05EA \u05D7\u05E1\u05D5\u05DE\u05D9\u05DD \u05D5\u05E9\u05D9\u05EA\u05D5\u05E4\u05D9\u05DD \u05E2\u05E6\u05DE\u05D9\u05D9\u05DD",
      "Pending an authenticated fixture; controls stay disabled.": "\u05DE\u05DE\u05EA\u05D9\u05DF \u05DC\u05D3\u05D5\u05D2\u05DE\u05D9\u05EA \u05DE\u05D0\u05D5\u05DE\u05EA\u05EA; \u05D4\u05E4\u05E7\u05D3\u05D9\u05DD \u05E0\u05E9\u05D0\u05E8\u05D9\u05DD \u05DE\u05D5\u05E9\u05D1\u05EA\u05D9\u05DD.",
      "Hide dismissed posts": "\u05D4\u05E1\u05EA\u05E8\u05EA \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E9\u05E0\u05E1\u05D2\u05E8\u05D5",
      "Keep posts you hid collapsed so the next post rises to the top.": "\u05DE\u05E9\u05D0\u05D9\u05E8 \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05E9\u05D4\u05E1\u05EA\u05E8\u05EA \u05DE\u05DB\u05D5\u05D5\u05E6\u05D9\u05DD, \u05DB\u05DA \u05E9\u05D4\u05E4\u05D5\u05E1\u05D8 \u05D4\u05D1\u05D0 \u05E2\u05D5\u05DC\u05D4 \u05DC\u05DE\u05E2\u05DC\u05D4.",
      "Show hide buttons": "\u05D4\u05E6\u05D2\u05EA \u05DB\u05E4\u05EA\u05D5\u05E8\u05D9 \u05D4\u05E1\u05EA\u05E8\u05D4",
      "Adds a Hide control to every post next to the More menu.": "\u05DE\u05D5\u05E1\u05D9\u05E3 \u05DB\u05E4\u05EA\u05D5\u05E8 \u05D4\u05E1\u05EA\u05E8\u05D4 \u05DC\u05DB\u05DC \u05E4\u05D5\u05E1\u05D8, \u05DC\u05E6\u05D3 \u05EA\u05E4\u05E8\u05D9\u05D8 \u05D4\u05E2\u05D5\u05D3.",
      "Routes where hiding and the Hide button apply.": "\u05D4\u05E2\u05DE\u05D5\u05D3\u05D9\u05DD \u05E9\u05D1\u05D4\u05DD \u05D4\u05D4\u05E1\u05EA\u05E8\u05D4 \u05D5\u05D4\u05DB\u05E4\u05EA\u05D5\u05E8 \u05E4\u05D5\u05E2\u05DC\u05D9\u05DD.",
      "Maximum remembered posts": "\u05DE\u05E1\u05E4\u05E8 \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05E8\u05D1\u05D9 \u05DC\u05E9\u05DE\u05D9\u05E8\u05D4",
      "Oldest entries are dropped once the store passes this size (100-50000).": "\u05D4\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD \u05D4\u05D9\u05E9\u05E0\u05D9\u05DD \u05E0\u05DE\u05D7\u05E7\u05D9\u05DD \u05DB\u05E9\u05D4\u05DE\u05D0\u05D2\u05E8 \u05D7\u05D5\u05E8\u05D2 \u05DE\u05D2\u05D5\u05D3\u05DC \u05D6\u05D4 (100\u200F-50000).",
      "Save": "\u05E9\u05DE\u05D9\u05E8\u05D4",
      "Hidden posts stored": "\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05DE\u05D5\u05E1\u05EA\u05E8\u05D9\u05DD \u05E9\u05E0\u05E9\u05DE\u05E8\u05D5",
      "Undo last hide": "\u05D1\u05D9\u05D8\u05D5\u05DC \u05D4\u05D4\u05E1\u05EA\u05E8\u05D4 \u05D4\u05D0\u05D7\u05E8\u05D5\u05E0\u05D4",
      "Restores the most recently hidden post.": "\u05DE\u05E9\u05D7\u05D6\u05E8 \u05D0\u05EA \u05D4\u05E4\u05D5\u05E1\u05D8 \u05D4\u05D0\u05D7\u05E8\u05D5\u05DF \u05E9\u05D4\u05D5\u05E1\u05EA\u05E8.",
      "Restore": "\u05E9\u05D7\u05D6\u05D5\u05E8",
      "Clear hidden posts": "\u05E0\u05D9\u05E7\u05D5\u05D9 \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E1\u05EA\u05E8\u05D9\u05DD",
      "Forgets every hidden post and brings them all back.": "\u05E9\u05D5\u05DB\u05D7 \u05D0\u05EA \u05DB\u05DC \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E1\u05EA\u05E8\u05D9\u05DD \u05D5\u05DE\u05D7\u05D6\u05D9\u05E8 \u05D0\u05EA \u05DB\u05D5\u05DC\u05DD.",
      "Show download buttons": "\u05D4\u05E6\u05D2\u05EA \u05DB\u05E4\u05EA\u05D5\u05E8\u05D9 \u05D4\u05D5\u05E8\u05D3\u05D4",
      "Inject Save and Thumb buttons over tweet photos and video thumbnails.": "\u05DE\u05D5\u05E1\u05D9\u05E3 \u05DB\u05E4\u05EA\u05D5\u05E8\u05D9 \u05E9\u05DE\u05D9\u05E8\u05D4 \u05D5\u05EA\u05DE\u05D5\u05E0\u05D4 \u05DE\u05DE\u05D5\u05D6\u05E2\u05E8\u05EA \u05DE\u05E2\u05DC \u05EA\u05DE\u05D5\u05E0\u05D5\u05EA \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D5\u05EA\u05E7\u05E6\u05D9\u05E8\u05D9 \u05D4\u05D5\u05D5\u05D9\u05D3\u05D0\u05D5.",
      "Prefer original quality": "\u05D4\u05E2\u05D3\u05E4\u05EA \u05D0\u05D9\u05DB\u05D5\u05EA \u05DE\u05E7\u05D5\u05E8\u05D9\u05EA",
      "Rewrite image URLs to name=orig before downloading.": "\u05DE\u05E9\u05DB\u05EA\u05D1 \u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05EA\u05DE\u05D5\u05E0\u05D4 \u05DC\u2011name=orig \u05DC\u05E4\u05E0\u05D9 \u05D4\u05D4\u05D5\u05E8\u05D3\u05D4.",
      "Filename template": "\u05EA\u05D1\u05E0\u05D9\u05EA \u05E9\u05DD \u05E7\u05D5\u05D1\u05E5",
      "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.": "\u05E9\u05D3\u05D5\u05EA: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.",
      "Duplicate history": "\u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D9\u05EA \u05DB\u05E4\u05D9\u05DC\u05D5\u05D9\u05D5\u05EA",
      "Skip downloads of media you have already saved from this browser.": "\u05DE\u05D3\u05DC\u05D2 \u05E2\u05DC \u05D4\u05D5\u05E8\u05D3\u05EA \u05DE\u05D3\u05D9\u05D4 \u05E9\u05DB\u05D1\u05E8 \u05E0\u05E9\u05DE\u05E8\u05D4 \u05DE\u05D3\u05E4\u05D3\u05E4\u05DF \u05D6\u05D4.",
      "Sensitive content": "\u05EA\u05D5\u05DB\u05DF \u05E8\u05D2\u05D9\u05E9",
      "Default (X choice)": "\u05D1\u05E8\u05D9\u05E8\u05EA \u05DE\u05D7\u05D3\u05DC (\u05D4\u05D2\u05D3\u05E8\u05EA X)",
      "Always reveal": "\u05DC\u05D4\u05E6\u05D9\u05D2 \u05EA\u05DE\u05D9\u05D3",
      "Blur until hovered": "\u05DC\u05D8\u05E9\u05D8\u05E9 \u05E2\u05D3 \u05DC\u05DE\u05E2\u05D1\u05E8 \u05E2\u05DB\u05D1\u05E8",
      "Always hide": "\u05DC\u05D4\u05E1\u05EA\u05D9\u05E8 \u05EA\u05DE\u05D9\u05D3",
      "Media layout": "\u05E4\u05E8\u05D9\u05E1\u05EA \u05DE\u05D3\u05D9\u05D4",
      "Default grid": "\u05E8\u05E9\u05EA \u05D1\u05E8\u05D9\u05E8\u05EA \u05DE\u05D7\u05D3\u05DC",
      "Stacked": "\u05DE\u05D5\u05E2\u05E8\u05DD",
      "Strict grid": "\u05E8\u05E9\u05EA \u05D0\u05D7\u05D9\u05D3\u05D4",
      "Download status": "\u05DE\u05E6\u05D1 \u05D4\u05D4\u05D5\u05E8\u05D3\u05D5\u05EA",
      "History entries": "\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05D1\u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D4",
      "Clear download history": "\u05E0\u05D9\u05E7\u05D5\u05D9 \u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D9\u05EA \u05D4\u05D4\u05D5\u05E8\u05D3\u05D5\u05EA",
      "Reset the local dedup index.": "\u05DE\u05D0\u05E4\u05E1 \u05D0\u05EA \u05D0\u05D9\u05E0\u05D3\u05E7\u05E1 \u05D4\u05DB\u05E4\u05D9\u05DC\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05E7\u05D5\u05DE\u05D9.",
      "Download all visible media": "\u05D4\u05D5\u05E8\u05D3\u05EA \u05DB\u05DC \u05D4\u05DE\u05D3\u05D9\u05D4 \u05D4\u05DE\u05D5\u05E6\u05D2\u05EA",
      "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.": "\u05E2\u05D5\u05D1\u05E8 \u05E2\u05DC \u05DB\u05DC \u05E4\u05D5\u05E1\u05D8 \u05E9\u05DE\u05D5\u05E6\u05D2 \u05D1\u05E2\u05DE\u05D5\u05D3 \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9 \u05D5\u05DE\u05D5\u05E1\u05D9\u05E3 \u05DB\u05DC \u05EA\u05DE\u05D5\u05E0\u05D4, \u05E1\u05E8\u05D8\u05D5\u05DF, GIF \u05D5\u05EA\u05DE\u05D5\u05E0\u05D4 \u05DE\u05DE\u05D5\u05D6\u05E2\u05E8\u05EA \u05DC\u05EA\u05D5\u05E8 \u05D4\u05D4\u05D5\u05E8\u05D3\u05D5\u05EA \u05D4\u05E7\u05D9\u05D9\u05DD.",
      "Capture visible tweets": "\u05D0\u05D9\u05E1\u05D5\u05E3 \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E6\u05D2\u05D9\u05DD",
      "Accumulate tweets visible on the active page for the next export run.": "\u05D0\u05D5\u05E1\u05E3 \u05D0\u05EA \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E6\u05D2\u05D9\u05DD \u05D1\u05E2\u05DE\u05D5\u05D3 \u05DC\u05E7\u05E8\u05D0\u05EA \u05D4\u05D9\u05D9\u05E6\u05D5\u05D0 \u05D4\u05D1\u05D0.",
      "Export formats": "\u05E4\u05D5\u05E8\u05DE\u05D8\u05D9 \u05D9\u05D9\u05E6\u05D5\u05D0",
      "Comma-separated list. Supported: json, csv, html, markdown, xlsx.": "\u05E8\u05E9\u05D9\u05DE\u05D4 \u05DE\u05D5\u05E4\u05E8\u05D3\u05EA \u05D1\u05E4\u05E1\u05D9\u05E7\u05D9\u05DD. \u05E0\u05EA\u05DE\u05DB\u05D9\u05DD: json, csv, html, markdown, xlsx.",
      "Preserve raw payloads": "\u05E9\u05DE\u05D9\u05E8\u05EA \u05D4\u05EA\u05E9\u05D5\u05D1\u05D5\u05EA \u05D4\u05D2\u05D5\u05DC\u05DE\u05D9\u05D5\u05EA",
      "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.": "\u05E9\u05D5\u05DE\u05E8 \u05D2\u05DD \u05D0\u05EA \u05EA\u05E9\u05D5\u05D1\u05D5\u05EA \u05D4\u2011GraphQL \u05D4\u05D2\u05D5\u05DC\u05DE\u05D9\u05D5\u05EA \u05E9\u2011X \u05E9\u05D5\u05DC\u05D7 \u05DC\u05DC\u05E9\u05D5\u05E0\u05D9\u05EA, \u05DB\u05D3\u05D9 \u05DC\u05D0\u05E4\u05E9\u05E8 \u05E0\u05D9\u05EA\u05D5\u05D7 \u05DE\u05D7\u05D3\u05E9 \u05D1\u05D4\u05DE\u05E9\u05DA. \u05D0\u05E1\u05D9\u05DE\u05D5\u05E0\u05D9 \u05D4\u05E4\u05E2\u05DC\u05D4 \u05DE\u05D5\u05E1\u05E8\u05D9\u05DD \u05DC\u05E4\u05E0\u05D9 \u05D4\u05DB\u05EA\u05D9\u05D1\u05D4.",
      "Auto-discover query IDs": "\u05D6\u05D9\u05D4\u05D5\u05D9 \u05D0\u05D5\u05D8\u05D5\u05DE\u05D8\u05D9 \u05E9\u05DC \u05DE\u05D6\u05D4\u05D9 \u05E9\u05D0\u05D9\u05DC\u05EA\u05D4",
      "Scan loaded scripts for X GraphQL operation IDs and cache them locally.": "\u05E1\u05D5\u05E8\u05E7 \u05D0\u05EA \u05D4\u05E1\u05E7\u05E8\u05D9\u05E4\u05D8\u05D9\u05DD \u05E9\u05E0\u05D8\u05E2\u05E0\u05D5 \u05DC\u05D0\u05D9\u05EA\u05D5\u05E8 \u05DE\u05D6\u05D4\u05D9 \u05E4\u05E2\u05D5\u05DC\u05D5\u05EA GraphQL \u05E9\u05DC X \u05D5\u05E9\u05D5\u05DE\u05E8 \u05D0\u05D5\u05EA\u05DD \u05DE\u05E7\u05D5\u05DE\u05D9\u05EA.",
      "Save folder hint": "\u05EA\u05D9\u05E7\u05D9\u05D9\u05EA \u05E9\u05DE\u05D9\u05E8\u05D4",
      "Folder name (or path) used as the export ZIP root and download prefix.": "\u05E9\u05DD \u05D4\u05EA\u05D9\u05E7\u05D9\u05D9\u05D4 (\u05D0\u05D5 \u05D4\u05E0\u05EA\u05D9\u05D1) \u05E9\u05D9\u05E9\u05DE\u05E9 \u05DB\u05E9\u05D5\u05E8\u05E9 \u05E7\u05D5\u05D1\u05E5 \u05D4\u2011ZIP \u05D5\u05DB\u05EA\u05D7\u05D9\u05DC\u05D9\u05EA \u05DC\u05D4\u05D5\u05E8\u05D3\u05D5\u05EA.",
      "Export status": "\u05DE\u05E6\u05D1 \u05D4\u05D9\u05D9\u05E6\u05D5\u05D0",
      "Export visible tweets": "\u05D9\u05D9\u05E6\u05D5\u05D0 \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E6\u05D2\u05D9\u05DD",
      "Collect the currently rendered tweets and download a ZIP.": "\u05D0\u05D5\u05E1\u05E3 \u05D0\u05EA \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E6\u05D2\u05D9\u05DD \u05D5\u05DE\u05D5\u05E8\u05D9\u05D3 \u05E7\u05D5\u05D1\u05E5 ZIP.",
      "Copy diagnostics": "\u05D4\u05E2\u05EA\u05E7\u05EA \u05E0\u05EA\u05D5\u05E0\u05D9 \u05D0\u05D1\u05D7\u05D5\u05DF",
      "Copy support diagnostics (version, route, recent log).": "\u05DE\u05E2\u05EA\u05D9\u05E7 \u05E0\u05EA\u05D5\u05E0\u05D9 \u05D0\u05D1\u05D7\u05D5\u05DF \u05DC\u05EA\u05DE\u05D9\u05DB\u05D4 (\u05D2\u05E8\u05E1\u05D4, \u05E2\u05DE\u05D5\u05D3, \u05D9\u05D5\u05DE\u05DF \u05D0\u05D7\u05E8\u05D5\u05DF).",
      "Download as WARC": "\u05D4\u05D5\u05E8\u05D3\u05D4 \u05DB\u2011WARC",
      "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.": "\u05E2\u05D5\u05D8\u05E3 \u05D0\u05EA \u05D4\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05E9\u05E0\u05D0\u05E1\u05E4\u05D5 \u05D1\u05E7\u05D5\u05D1\u05E5 WARC \u05DC\u05E4\u05D9 ISO-28500 \u05E2\u05D1\u05D5\u05E8 \u05DB\u05DC\u05D9 \u05DE\u05D7\u05E7\u05E8 \u05D5\u05E9\u05D9\u05DE\u05D5\u05E8.",
      "Copy as Markdown": "\u05D4\u05E2\u05EA\u05E7\u05D4 \u05DB\u2011Markdown",
      "Push a plain Markdown export onto the clipboard.": "\u05DE\u05E2\u05EA\u05D9\u05E7 \u05D9\u05D9\u05E6\u05D5\u05D0 Markdown \u05E4\u05E9\u05D5\u05D8 \u05DC\u05DC\u05D5\u05D7.",
      "Save Obsidian Markdown": "\u05E9\u05DE\u05D9\u05E8\u05EA Markdown \u05DC\u2011Obsidian",
      "Markdown with YAML frontmatter and Aviary tags.": "\u200FMarkdown \u05E2\u05DD \u05DB\u05D5\u05EA\u05E8\u05EA YAML \u05D5\u05EA\u05D2\u05D9\u05D5\u05EA Aviary.",
      "Save Notion Markdown": "\u05E9\u05DE\u05D9\u05E8\u05EA Markdown \u05DC\u2011Notion",
      "Heading-first Markdown that Notion imports cleanly.": "\u200FMarkdown \u05DE\u05D1\u05D5\u05E1\u05E1 \u05DB\u05D5\u05EA\u05E8\u05D5\u05EA \u05E9\u2011Notion \u05DE\u05D9\u05D9\u05D1\u05D0 \u05D1\u05E6\u05D5\u05E8\u05D4 \u05E0\u05E7\u05D9\u05D9\u05D4.",
      "Save records JSON": "\u05E9\u05DE\u05D9\u05E8\u05EA \u05D4\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05DB\u2011JSON",
      "Raw ExportRecord[] JSON without ZIP wrapping.": "\u200FJSON \u05D2\u05D5\u05DC\u05DE\u05D9 \u05DE\u05E1\u05D5\u05D2 ExportRecord[] \u05DC\u05DC\u05D0 \u05E2\u05D8\u05D9\u05E4\u05EA ZIP.",
      "Records per ZIP": "\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05DC\u05DB\u05DC ZIP",
      "Split a long export across several archives instead of one huge file (25-1000).": "\u05DE\u05E4\u05E6\u05DC \u05D9\u05D9\u05E6\u05D5\u05D0 \u05D0\u05E8\u05D5\u05DA \u05DC\u05DB\u05DE\u05D4 \u05D0\u05E8\u05DB\u05D9\u05D5\u05E0\u05D9\u05DD \u05D1\u05DE\u05E7\u05D5\u05DD \u05E7\u05D5\u05D1\u05E5 \u05E2\u05E0\u05E7 \u05D0\u05D7\u05D3 (25-1000).",
      "Maximum export jobs": "\u05DE\u05E1\u05E4\u05E8 \u05DE\u05E8\u05D1\u05D9 \u05E9\u05DC \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05D9\u05D9\u05E6\u05D5\u05D0",
      "Keep the newest jobs. Use 0 for unlimited.": "\u05E9\u05D5\u05DE\u05E8 \u05D0\u05EA \u05D4\u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05D4\u05D7\u05D3\u05E9\u05D5\u05EA. 0 \u05DE\u05D1\u05D8\u05DC \u05D0\u05EA \u05D4\u05DE\u05D2\u05D1\u05DC\u05D4.",
      "Maximum records per job": "\u05DE\u05E1\u05E4\u05E8 \u05DE\u05E8\u05D1\u05D9 \u05E9\u05DC \u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05DC\u05DE\u05E9\u05D9\u05DE\u05D4",
      "Keep the newest records in each job. Use 0 for unlimited.": "\u05E9\u05D5\u05DE\u05E8 \u05D0\u05EA \u05D4\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05D4\u05D7\u05D3\u05E9\u05D5\u05EA \u05D1\u05DB\u05DC \u05DE\u05E9\u05D9\u05DE\u05D4. 0 \u05DE\u05D1\u05D8\u05DC \u05D0\u05EA \u05D4\u05DE\u05D2\u05D1\u05DC\u05D4.",
      "Maximum export age (days)": "\u05D2\u05D9\u05DC \u05D9\u05D9\u05E6\u05D5\u05D0 \u05DE\u05E8\u05D1\u05D9 (\u05D9\u05DE\u05D9\u05DD)",
      "Remove older jobs at boot. Use 0 to disable age-based cleanup.": "\u05DE\u05D5\u05D7\u05E7 \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05D9\u05E9\u05E0\u05D5\u05EA \u05D1\u05D4\u05E4\u05E2\u05DC\u05D4. 0 \u05DE\u05D1\u05D8\u05DC \u05E0\u05D9\u05E7\u05D5\u05D9 \u05DC\u05E4\u05D9 \u05D2\u05D9\u05DC.",
      "Unshorten t.co links": "\u05E4\u05EA\u05D9\u05D7\u05EA \u05E7\u05D9\u05E9\u05D5\u05E8\u05D9 t.co",
      "Replace short `t.co` redirects with the destination from aria-labels and titles.": "\u05DE\u05D7\u05DC\u05D9\u05E3 \u05E7\u05D9\u05E9\u05D5\u05E8\u05D9 `t.co` \u05DE\u05E7\u05D5\u05E6\u05E8\u05D9\u05DD \u05D1\u05D9\u05E2\u05D3 \u05E9\u05DE\u05D5\u05E4\u05D9\u05E2 \u05D1\u2011aria-label \u05D5\u05D1\u05DB\u05D5\u05EA\u05E8\u05D5\u05EA.",
      "Clean tracking from links": "\u05E0\u05D9\u05E7\u05D5\u05D9 \u05DE\u05E2\u05E7\u05D1 \u05DE\u05E7\u05D9\u05E9\u05D5\u05E8\u05D9\u05DD",
      "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.": "\u05DE\u05E1\u05D9\u05E8 \u05D0\u05E1\u05D9\u05DE\u05D5\u05E0\u05D9 \u05E9\u05D9\u05EA\u05D5\u05E3 \u05D5\u05E4\u05E8\u05DE\u05D8\u05E8\u05D9 \u05E7\u05DE\u05E4\u05D9\u05D9\u05DF (utm_*, fbclid, \u05D5\u05D4\u2011t/s \u05E9\u05DC X \u05E2\u05E6\u05DE\u05D4) \u05DE\u05E7\u05D9\u05E9\u05D5\u05E8\u05D9\u05DD \u05D1\u05E6\u05D9\u05E8 \u05D4\u05D6\u05DE\u05DF, \u05DB\u05DA \u05E9\u05DE\u05D4 \u05E9\u05EA\u05E2\u05EA\u05D9\u05E7 \u05D4\u05D5\u05D0 \u05D4\u05DB\u05EA\u05D5\u05D1\u05EA \u05D4\u05E0\u05E7\u05D9\u05D9\u05D4.",
      "Account notes": "\u05D4\u05E2\u05E8\u05D5\u05EA \u05E2\u05DC \u05D7\u05E9\u05D1\u05D5\u05E0\u05D5\u05EA",
      "Format: handle: note. One per line. Empty notes remove the entry.": "\u05DE\u05D1\u05E0\u05D4: \u05D7\u05E9\u05D1\u05D5\u05DF: \u05D4\u05E2\u05E8\u05D4. \u05D0\u05D7\u05EA \u05D1\u05DB\u05DC \u05E9\u05D5\u05E8\u05D4. \u05D4\u05E2\u05E8\u05D4 \u05E8\u05D9\u05E7\u05D4 \u05DE\u05D5\u05D7\u05E7\u05EA \u05D0\u05EA \u05D4\u05E8\u05E9\u05D5\u05DE\u05D4.",
      "Clear all account notes": "\u05E0\u05D9\u05E7\u05D5\u05D9 \u05DB\u05DC \u05D4\u05D4\u05E2\u05E8\u05D5\u05EA",
      "Drop every persisted note.": "\u05DE\u05D5\u05D7\u05E7 \u05D0\u05EA \u05DB\u05DC \u05D4\u05D4\u05E2\u05E8\u05D5\u05EA \u05D4\u05E9\u05DE\u05D5\u05E8\u05D5\u05EA.",
      "Composer snippets": "\u05E7\u05D8\u05E2\u05D9 \u05D8\u05E7\u05E1\u05D8",
      "One snippet per line. Reusable replies / templates (insertion landing in a later release).": "\u05E7\u05D8\u05E2 \u05D0\u05D7\u05D3 \u05D1\u05DB\u05DC \u05E9\u05D5\u05E8\u05D4. \u05EA\u05D2\u05D5\u05D1\u05D5\u05EA \u05D5\u05EA\u05D1\u05E0\u05D9\u05D5\u05EA \u05DC\u05E9\u05D9\u05DE\u05D5\u05E9 \u05D7\u05D5\u05D6\u05E8 (\u05D4\u05D4\u05D5\u05E1\u05E4\u05D4 \u05D4\u05D0\u05D5\u05D8\u05D5\u05DE\u05D8\u05D9\u05EA \u05D1\u05D2\u05E8\u05E1\u05D4 \u05E2\u05EA\u05D9\u05D3\u05D9\u05EA).",
      "Snapshots stored": "\u05EA\u05E6\u05DC\u05D5\u05DE\u05D9 \u05DE\u05E6\u05D1 \u05E9\u05E0\u05E9\u05DE\u05E8\u05D5",
      "Capture followers from this view": "\u05D0\u05D9\u05E1\u05D5\u05E3 \u05E2\u05D5\u05E7\u05D1\u05D9\u05DD \u05DE\u05D4\u05E2\u05DE\u05D5\u05D3 \u05D4\u05D6\u05D4",
      "Walks UserCell rows on the current page. Open a /handle/followers view first.": "\u05E2\u05D5\u05D1\u05E8 \u05E2\u05DC \u05E9\u05D5\u05E8\u05D5\u05EA UserCell \u05D1\u05E2\u05DE\u05D5\u05D3 \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9. \u05E4\u05EA\u05D7 \u05EA\u05D7\u05D9\u05DC\u05D4 \u05E2\u05DE\u05D5\u05D3 \u200E/\u05D7\u05E9\u05D1\u05D5\u05DF/followers\u200E.",
      "Capture following from this view": "\u05D0\u05D9\u05E1\u05D5\u05E3 \u05E0\u05E2\u05E7\u05D1\u05D9\u05DD \u05DE\u05D4\u05E2\u05DE\u05D5\u05D3 \u05D4\u05D6\u05D4",
      "Walks UserCell rows on the current page. Open a /handle/following view first.": "\u05E2\u05D5\u05D1\u05E8 \u05E2\u05DC \u05E9\u05D5\u05E8\u05D5\u05EA UserCell \u05D1\u05E2\u05DE\u05D5\u05D3 \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9. \u05E4\u05EA\u05D7 \u05EA\u05D7\u05D9\u05DC\u05D4 \u05E2\u05DE\u05D5\u05D3 \u200E/\u05D7\u05E9\u05D1\u05D5\u05DF/following\u200E.",
      "Clear all snapshots": "\u05E0\u05D9\u05E7\u05D5\u05D9 \u05DB\u05DC \u05EA\u05E6\u05DC\u05D5\u05DE\u05D9 \u05D4\u05DE\u05E6\u05D1",
      "Drop every stored follower/following snapshot.": "\u05DE\u05D5\u05D7\u05E7 \u05D0\u05EA \u05DB\u05DC \u05EA\u05E6\u05DC\u05D5\u05DE\u05D9 \u05D4\u05E2\u05D5\u05E7\u05D1\u05D9\u05DD \u05D5\u05D4\u05E0\u05E2\u05E7\u05D1\u05D9\u05DD \u05E9\u05E0\u05E9\u05DE\u05E8\u05D5.",
      "Download Markdown report": "\u05D4\u05D5\u05E8\u05D3\u05EA \u05D3\u05D5\u05D7 Markdown",
      "Audit log + snapshot diff + cleanup preview.": "\u05D9\u05D5\u05DE\u05DF \u05D1\u05D9\u05E7\u05D5\u05E8\u05EA, \u05D4\u05E9\u05D5\u05D5\u05D0\u05EA \u05EA\u05E6\u05DC\u05D5\u05DE\u05D9 \u05DE\u05E6\u05D1 \u05D5\u05EA\u05E6\u05D5\u05D2\u05D4 \u05DE\u05E7\u05D3\u05D9\u05DE\u05D4 \u05E9\u05DC \u05E0\u05D9\u05E7\u05D5\u05D9.",
      "Cleanup review queue": "\u05EA\u05D5\u05E8 \u05DC\u05D1\u05D3\u05D9\u05E7\u05EA \u05E0\u05D9\u05E7\u05D5\u05D9",
      "Destructive actions": "\u05E4\u05E2\u05D5\u05DC\u05D5\u05EA \u05D4\u05E8\u05E1\u05E0\u05D9\u05D5\u05EA",
      "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log.": "\u200FAviary \u05DC\u05E2\u05D5\u05DC\u05DD \u05D0\u05D9\u05E0\u05D5 \u05DE\u05D5\u05D7\u05E7 \u05E4\u05D5\u05E1\u05D8\u05D9\u05DD, \u05DC\u05D9\u05D9\u05E7\u05D9\u05DD \u05D0\u05D5 \u05E2\u05D5\u05E7\u05D1\u05D9\u05DD. \u05D4\u05EA\u05D5\u05E8 \u05D4\u05D5\u05D0 \u05E8\u05E9\u05D9\u05DE\u05EA \u05D1\u05D3\u05D9\u05E7\u05D4 \u05D1\u05DC\u05D1\u05D3; \u05D0\u05D9\u05E9\u05D5\u05E8 \u05D0\u05D5 \u05D3\u05D9\u05DC\u05D5\u05D2 \u05E0\u05E8\u05E9\u05DE\u05D9\u05DD \u05E8\u05E7 \u05D1\u05D9\u05D5\u05DE\u05DF \u05D4\u05D1\u05D9\u05E7\u05D5\u05E8\u05EA.",
      "Enqueue cleanup preview for review": "\u05D4\u05D5\u05E1\u05E4\u05EA \u05EA\u05E6\u05D5\u05D2\u05EA \u05D4\u05E0\u05D9\u05E7\u05D5\u05D9 \u05DC\u05EA\u05D5\u05E8",
      "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).": "\u05DE\u05D5\u05E1\u05D9\u05E3 \u05DC\u05EA\u05D5\u05E8 \u05D0\u05EA \u05DB\u05DC \u05D4\u05DE\u05D5\u05E2\u05DE\u05D3\u05D9\u05DD \u05D4\u05DC\u05D0 \u05DE\u05D5\u05D2\u05E0\u05D9\u05DD \u05DE\u05D4\u05EA\u05E6\u05D5\u05D2\u05D4 \u05D4\u05D0\u05D7\u05E8\u05D5\u05E0\u05D4 (\u05DC\u05DC\u05D0 \u05E4\u05E2\u05D5\u05DC\u05D4 \u05D4\u05E8\u05E1\u05E0\u05D9\u05EA).",
      "Clear cleanup queue": "\u05E8\u05D9\u05E7\u05D5\u05DF \u05EA\u05D5\u05E8 \u05D4\u05E0\u05D9\u05E7\u05D5\u05D9",
      "Drop every queued item without touching account data.": "\u05DE\u05D5\u05D7\u05E7 \u05D0\u05EA \u05DB\u05DC \u05D4\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD \u05D1\u05EA\u05D5\u05E8 \u05D1\u05DC\u05D9 \u05DC\u05D2\u05E2\u05EA \u05D1\u05E0\u05EA\u05D5\u05E0\u05D9 \u05D4\u05D7\u05E9\u05D1\u05D5\u05DF.",
      "Aria2 handoff": "\u05D4\u05E2\u05D1\u05E8\u05D4 \u05DC\u2011Aria2",
      "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.": "\u05E9\u05D5\u05DC\u05D7 \u05D4\u05D5\u05E8\u05D3\u05D5\u05EA \u05DE\u05D3\u05D9\u05D4 \u05D2\u05D3\u05D5\u05DC\u05D5\u05EA \u05DC\u05E0\u05E7\u05D5\u05D3\u05EA \u05E7\u05E6\u05D4 Aria2 \u05DE\u05E1\u05D5\u05D2 JSON-RPC \u05E9\u05D0\u05EA\u05D4 \u05DE\u05D0\u05E8\u05D7.",
      "Aria2 endpoint": "\u05E0\u05E7\u05D5\u05D3\u05EA \u05D4\u05E7\u05E6\u05D4 \u05E9\u05DC Aria2",
      "http://localhost:6800 (no trailing slash needed)": "\u200Fhttp://localhost:6800 (\u05DC\u05DC\u05D0 \u05DC\u05D5\u05DB\u05E1\u05DF \u05D1\u05E1\u05D5\u05E3)",
      "Aria2 RPC secret": "\u05E1\u05D5\u05D3 \u05D4\u2011RPC \u05E9\u05DC Aria2",
      "Optional shared secret for token: auth.": "\u05E1\u05D5\u05D3 \u05DE\u05E9\u05D5\u05EA\u05E3 \u05D0\u05D5\u05E4\u05E6\u05D9\u05D5\u05E0\u05DC\u05D9 \u05DC\u05D0\u05D9\u05DE\u05D5\u05EA token:.",
      "Show": "\u05D4\u05E6\u05D2\u05D4",
      "Test Aria2 connection": "\u05D1\u05D3\u05D9\u05E7\u05EA \u05D4\u05D7\u05D9\u05D1\u05D5\u05E8 \u05DC\u2011Aria2",
      "Sends a trivial JSON-RPC call.": "\u05E9\u05D5\u05DC\u05D7 \u05E7\u05E8\u05D9\u05D0\u05EA JSON-RPC \u05E4\u05E9\u05D5\u05D8\u05D4.",
      "Refresh": "\u05E8\u05E2\u05E0\u05D5\u05DF",
      "Bluesky crosspost": "\u05E4\u05E8\u05E1\u05D5\u05DD \u05DE\u05E7\u05D1\u05D9\u05DC \u05D1\u2011Bluesky",
      "Post composer text to your Bluesky account on demand.": "\u05DE\u05E4\u05E8\u05E1\u05DD \u05D0\u05EA \u05D4\u05D8\u05E7\u05E1\u05D8 \u05DE\u05D7\u05DC\u05D5\u05DF \u05D4\u05DB\u05EA\u05D9\u05D1\u05D4 \u05DC\u05D7\u05E9\u05D1\u05D5\u05DF Bluesky \u05E9\u05DC\u05DA \u05DC\u05E4\u05D9 \u05D3\u05E8\u05D9\u05E9\u05D4.",
      "Bluesky service URL": "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E9\u05D9\u05E8\u05D5\u05EA Bluesky",
      "Default: https://bsky.social": "\u05D1\u05E8\u05D9\u05E8\u05EA \u05DE\u05D7\u05D3\u05DC: https://bsky.social",
      "Bluesky handle": "\u05D7\u05E9\u05D1\u05D5\u05DF Bluesky",
      "Your handle (no @, e.g. you.bsky.social)": "\u05E9\u05DD \u05D4\u05D7\u05E9\u05D1\u05D5\u05DF \u05E9\u05DC\u05DA (\u05D1\u05DC\u05D9 @, \u05DC\u05DE\u05E9\u05DC you.bsky.social)",
      "Bluesky app password": "\u05E1\u05D9\u05E1\u05DE\u05EA \u05D0\u05E4\u05DC\u05D9\u05E7\u05E6\u05D9\u05D4 \u05DC\u2011Bluesky",
      "App password from your account settings \u2014 never your main password.": "\u05E1\u05D9\u05E1\u05DE\u05EA \u05D0\u05E4\u05DC\u05D9\u05E7\u05E6\u05D9\u05D4 \u05DE\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05D4\u05D7\u05E9\u05D1\u05D5\u05DF \u2014 \u05DC\u05E2\u05D5\u05DC\u05DD \u05DC\u05D0 \u05D4\u05E1\u05D9\u05E1\u05DE\u05D4 \u05D4\u05E8\u05D0\u05E9\u05D9\u05EA.",
      "Mastodon crosspost": "\u05E4\u05E8\u05E1\u05D5\u05DD \u05DE\u05E7\u05D1\u05D9\u05DC \u05D1\u2011Mastodon",
      "Post composer text to your Mastodon account on demand.": "\u05DE\u05E4\u05E8\u05E1\u05DD \u05D0\u05EA \u05D4\u05D8\u05E7\u05E1\u05D8 \u05DE\u05D7\u05DC\u05D5\u05DF \u05D4\u05DB\u05EA\u05D9\u05D1\u05D4 \u05DC\u05D7\u05E9\u05D1\u05D5\u05DF Mastodon \u05E9\u05DC\u05DA \u05DC\u05E4\u05D9 \u05D3\u05E8\u05D9\u05E9\u05D4.",
      "Mastodon instance": "\u05E9\u05E8\u05EA Mastodon",
      "https://mastodon.social": "https://mastodon.social",
      "Mastodon access token": "\u05D0\u05E1\u05D9\u05DE\u05D5\u05DF \u05D2\u05D9\u05E9\u05D4 \u05DC\u2011Mastodon",
      "Bearer token with write:statuses scope.": "\u05D0\u05E1\u05D9\u05DE\u05D5\u05DF Bearer \u05E2\u05DD \u05D4\u05E8\u05E9\u05D0\u05EA write:statuses.",
      "Attach last download": "\u05E6\u05D9\u05E8\u05D5\u05E3 \u05D4\u05D4\u05D5\u05E8\u05D3\u05D4 \u05D4\u05D0\u05D7\u05E8\u05D5\u05E0\u05D4",
      "Upload the last successful Aviary media download with the first post in an explicit crosspost.": "\u05DE\u05E2\u05DC\u05D4 \u05D0\u05EA \u05D4\u05DE\u05D3\u05D9\u05D4 \u05D4\u05D0\u05D7\u05E8\u05D5\u05E0\u05D4 \u05E9\u2011Aviary \u05D4\u05D5\u05E8\u05D9\u05D3 \u05D1\u05D4\u05E6\u05DC\u05D7\u05D4 \u05D9\u05D7\u05D3 \u05E2\u05DD \u05D4\u05E4\u05D5\u05E1\u05D8 \u05D4\u05E8\u05D0\u05E9\u05D5\u05DF \u05D1\u05E4\u05E8\u05E1\u05D5\u05DD \u05DE\u05E7\u05D1\u05D9\u05DC.",
      "Crosspost composer \u2192 Bluesky": "\u05E4\u05E8\u05E1\u05D5\u05DD \u05D7\u05DC\u05D5\u05DF \u05D4\u05DB\u05EA\u05D9\u05D1\u05D4 \u05D1\u2011Bluesky",
      "Uses the current composer text.": "\u05DE\u05E9\u05EA\u05DE\u05E9 \u05D1\u05D8\u05E7\u05E1\u05D8 \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9 \u05D1\u05D7\u05DC\u05D5\u05DF \u05D4\u05DB\u05EA\u05D9\u05D1\u05D4.",
      "Crosspost composer \u2192 Mastodon": "\u05E4\u05E8\u05E1\u05D5\u05DD \u05D7\u05DC\u05D5\u05DF \u05D4\u05DB\u05EA\u05D9\u05D1\u05D4 \u05D1\u2011Mastodon",
      "AI provider runs": "\u05D4\u05E8\u05E6\u05D5\u05EA \u05E1\u05E4\u05E7 \u05D1\u05D9\u05E0\u05D4 \u05DE\u05DC\u05D0\u05DB\u05D5\u05EA\u05D9\u05EA",
      "Let the AI command menu POST prompts to your configured provider.": "\u05DE\u05D0\u05E4\u05E9\u05E8 \u05DC\u05EA\u05E4\u05E8\u05D9\u05D8 \u05D4\u05E4\u05E7\u05D5\u05D3\u05D5\u05EA \u05DC\u05E9\u05DC\u05D5\u05D7 \u05D1\u05E7\u05E9\u05D5\u05EA \u05DC\u05E1\u05E4\u05E7 \u05E9\u05D4\u05D2\u05D3\u05E8\u05EA.",
      "AI provider": "\u05E1\u05E4\u05E7 \u05D1\u05D9\u05E0\u05D4 \u05DE\u05DC\u05D0\u05DB\u05D5\u05EA\u05D9\u05EA",
      "Anthropic Messages API": "Anthropic Messages API",
      "OpenAI Chat Completions": "OpenAI Chat Completions",
      "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)": "\u05EA\u05D5\u05D0\u05DD OpenAI \u200F(LocalAI, \u05E4\u05E8\u05D5\u05E7\u05E1\u05D9 Ollama, \u2026)",
      "AI endpoint (optional)": "\u05E0\u05E7\u05D5\u05D3\u05EA \u05E7\u05E6\u05D4 (\u05D0\u05D5\u05E4\u05E6\u05D9\u05D5\u05E0\u05DC\u05D9)",
      "Override the default endpoint for the chosen provider.": "\u05E2\u05D5\u05E7\u05E3 \u05D0\u05EA \u05E0\u05E7\u05D5\u05D3\u05EA \u05D4\u05E7\u05E6\u05D4 \u05E9\u05D1\u05D1\u05E8\u05D9\u05E8\u05EA \u05DE\u05D7\u05D3\u05DC \u05E2\u05D1\u05D5\u05E8 \u05D4\u05E1\u05E4\u05E7 \u05E9\u05E0\u05D1\u05D7\u05E8.",
      "AI model": "\u05DE\u05D5\u05D3\u05DC",
      "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b": "\u05DC\u05D3\u05D5\u05D2\u05DE\u05D4: claude-sonnet-4-6, gpt-4o, llama3.1:8b",
      "AI API key": "\u05DE\u05E4\u05EA\u05D7 API",
      "Stored locally only. Aviary never sends this except as the auth header to your provider.": "\u05E0\u05E9\u05DE\u05E8 \u05DE\u05E7\u05D5\u05DE\u05D9\u05EA \u05D1\u05DC\u05D1\u05D3. \u200FAviary \u05E9\u05D5\u05DC\u05D7 \u05D0\u05D5\u05EA\u05D5 \u05E8\u05E7 \u05DB\u05DB\u05D5\u05EA\u05E8\u05EA \u05D0\u05D9\u05DE\u05D5\u05EA \u05D0\u05DC \u05D4\u05E1\u05E4\u05E7 \u05E9\u05DC\u05DA.",
      "Semantic search": "\u05D7\u05D9\u05E4\u05D5\u05E9 \u05E1\u05DE\u05E0\u05D8\u05D9",
      "Embed CheckpointStore records via your provider for similarity search.": "\u05DE\u05D8\u05DE\u05D9\u05E2 \u05D0\u05EA \u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05D4\u2011CheckpointStore \u05D3\u05E8\u05DA \u05D4\u05E1\u05E4\u05E7 \u05E9\u05DC\u05DA \u05DC\u05E6\u05D5\u05E8\u05DA \u05D7\u05D9\u05E4\u05D5\u05E9 \u05D3\u05DE\u05D9\u05D5\u05DF.",
      "Embedding endpoint": "\u05E0\u05E7\u05D5\u05D3\u05EA \u05E7\u05E6\u05D4 \u05DC\u05D4\u05D8\u05DE\u05E2\u05D4",
      "POST endpoint that returns {data: [{embedding: number[]}]}": "\u05E0\u05E7\u05D5\u05D3\u05EA POST \u05E9\u05DE\u05D7\u05D6\u05D9\u05E8\u05D4 {data: [{embedding: number[]}]}",
      "Embedding model": "\u05DE\u05D5\u05D3\u05DC \u05D4\u05D8\u05DE\u05E2\u05D4",
      "e.g. text-embedding-3-small": "\u05DC\u05D3\u05D5\u05D2\u05DE\u05D4: text-embedding-3-small",
      "Embedding API key": "\u05DE\u05E4\u05EA\u05D7 API \u05DC\u05D4\u05D8\u05DE\u05E2\u05D4",
      "Stored locally; used only as the Authorization header.": "\u05E0\u05E9\u05DE\u05E8 \u05DE\u05E7\u05D5\u05DE\u05D9\u05EA \u05D5\u05DE\u05E9\u05DE\u05E9 \u05E8\u05E7 \u05DB\u05DB\u05D5\u05EA\u05E8\u05EA Authorization.",
      "Auto-embed every export": "\u05D4\u05D8\u05DE\u05E2\u05D4 \u05D0\u05D5\u05D8\u05D5\u05DE\u05D8\u05D9\u05EA \u05D1\u05DB\u05DC \u05D9\u05D9\u05E6\u05D5\u05D0",
      "After each export run, kick the embedding job in the background. Off by default.": "\u05D0\u05D7\u05E8\u05D9 \u05DB\u05DC \u05D9\u05D9\u05E6\u05D5\u05D0, \u05DE\u05E4\u05E2\u05D9\u05DC \u05D0\u05EA \u05DE\u05E9\u05D9\u05DE\u05EA \u05D4\u05D4\u05D8\u05DE\u05E2\u05D4 \u05D1\u05E8\u05E7\u05E2. \u05DB\u05D1\u05D5\u05D9 \u05DB\u05D1\u05E8\u05D9\u05E8\u05EA \u05DE\u05D7\u05D3\u05DC.",
      "Rebuild semantic index": "\u05D1\u05E0\u05D9\u05D9\u05D4 \u05DE\u05D7\u05D3\u05E9 \u05E9\u05DC \u05D4\u05D0\u05D9\u05E0\u05D3\u05E7\u05E1 \u05D4\u05E1\u05DE\u05E0\u05D8\u05D9",
      "Embed every captured record. Re-running is cheap because cached entries are skipped.": "\u05DE\u05D8\u05DE\u05D9\u05E2 \u05DB\u05DC \u05E8\u05E9\u05D5\u05DE\u05D4 \u05E9\u05E0\u05D0\u05E1\u05E4\u05D4. \u05D4\u05E8\u05E6\u05D4 \u05D7\u05D5\u05D6\u05E8\u05EA \u05D6\u05D5\u05DC\u05D4 \u05DB\u05D9 \u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05E9\u05DB\u05D1\u05E8 \u05D1\u05DE\u05D8\u05DE\u05D5\u05DF \u05DE\u05D3\u05D5\u05DC\u05D2\u05D5\u05EA.",
      "Clear semantic index": "\u05E0\u05D9\u05E7\u05D5\u05D9 \u05D4\u05D0\u05D9\u05E0\u05D3\u05E7\u05E1 \u05D4\u05E1\u05DE\u05E0\u05D8\u05D9",
      "Forget every embedded record.": "\u05E9\u05D5\u05DB\u05D7 \u05D0\u05EA \u05DB\u05DC \u05D4\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05E9\u05D4\u05D5\u05D8\u05DE\u05E2\u05D5.",
      "Integration status": "\u05DE\u05E6\u05D1 \u05D4\u05D0\u05D9\u05E0\u05D8\u05D2\u05E8\u05E6\u05D9\u05D5\u05EA",
      "Export settings": "\u05D9\u05D9\u05E6\u05D5\u05D0 \u05D4\u05D2\u05D3\u05E8\u05D5\u05EA",
      "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.": "\u05DE\u05D5\u05E8\u05D9\u05D3 \u05D0\u05EA \u05D4\u05D4\u05E2\u05D3\u05E4\u05D5\u05EA \u05E9\u05DC\u05DA \u05DB\u2011JSON. \u05DE\u05E4\u05EA\u05D7\u05D5\u05EA API \u05D5\u05E1\u05D9\u05E1\u05DE\u05D0\u05D5\u05EA \u05DE\u05D5\u05D7\u05DC\u05E4\u05D9\u05DD \u05D1\u05DE\u05E6\u05D9\u05D9\u05DF \u05DE\u05E7\u05D5\u05DD, \u05DB\u05DA \u05E9\u05D4\u05E7\u05D5\u05D1\u05E5 \u05D1\u05D8\u05D5\u05D7 \u05DC\u05E9\u05D9\u05EA\u05D5\u05E3; \u05D9\u05D9\u05D1\u05D5\u05D0 \u05DB\u05D0\u05DF \u05DE\u05E9\u05DE\u05E8 \u05D0\u05EA \u05E4\u05E8\u05D8\u05D9 \u05D4\u05D2\u05D9\u05E9\u05D4 \u05D4\u05E9\u05DE\u05D5\u05E8\u05D9\u05DD \u05D1\u05DE\u05D7\u05E9\u05D1 \u05D6\u05D4.",
      "Import settings (JSON)": "\u05D9\u05D9\u05D1\u05D5\u05D0 \u05D4\u05D2\u05D3\u05E8\u05D5\u05EA (JSON)",
      "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.": "\u05D4\u05D3\u05D1\u05E7 \u05E7\u05D5\u05D1\u05E5 \u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05E9\u05D9\u05D5\u05E6\u05D0 \u05DE\u2011Aviary \u05D5\u05D1\u05D7\u05E8 \u05D9\u05D9\u05D1\u05D5\u05D0. \u05E4\u05E8\u05D8\u05D9 \u05D2\u05D9\u05E9\u05D4 \u05DE\u05D5\u05E1\u05EA\u05E8\u05D9\u05DD \u05D9\u05E9\u05DE\u05E8\u05D5 \u05E2\u05DC \u05D4\u05E2\u05E8\u05DB\u05D9\u05DD \u05D4\u05E7\u05D9\u05D9\u05DE\u05D9\u05DD \u05DB\u05D0\u05DF.",
      "Import": "\u05D9\u05D9\u05D1\u05D5\u05D0",
      "Keep a local action log": "\u05E9\u05DE\u05D9\u05E8\u05EA \u05D9\u05D5\u05DE\u05DF \u05E4\u05E2\u05D5\u05DC\u05D5\u05EA \u05DE\u05E7\u05D5\u05DE\u05D9",
      "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.": "\u05DE\u05EA\u05E2\u05D3 \u05D4\u05D5\u05E8\u05D3\u05D5\u05EA, \u05D9\u05D9\u05E6\u05D5\u05D0 \u05D5\u05E9\u05D9\u05E0\u05D5\u05D9\u05D9 \u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05D1\u05DE\u05DB\u05E9\u05D9\u05E8 \u05D4\u05D6\u05D4 \u05DB\u05D3\u05D9 \u05E9\u05EA\u05D5\u05DB\u05DC \u05DC\u05D1\u05D3\u05D5\u05E7 \u05DE\u05D4 Aviary \u05E2\u05E9\u05D4. \u05E9\u05D5\u05DD \u05D3\u05D1\u05E8 \u05DC\u05D0 \u05E0\u05E9\u05DC\u05D7 \u05DC\u05E9\u05D5\u05DD \u05DE\u05E7\u05D5\u05DD. \u05DB\u05D9\u05D1\u05D5\u05D9 \u05E2\u05D5\u05E6\u05E8 \u05DE\u05D9\u05D3 \u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05D7\u05D3\u05E9\u05D5\u05EA; \u05D4\u05E7\u05D9\u05D9\u05DE\u05D5\u05EA \u05E0\u05E9\u05D0\u05E8\u05D5\u05EA \u05E2\u05D3 \u05E9\u05EA\u05DE\u05D7\u05E7 \u05D0\u05D5\u05EA\u05DF.",
      "Audit entries": "\u05E8\u05E9\u05D5\u05DE\u05D5\u05EA \u05D1\u05D9\u05E7\u05D5\u05E8\u05EA",
      "Clear audit log": "\u05E0\u05D9\u05E7\u05D5\u05D9 \u05D9\u05D5\u05DE\u05DF \u05D4\u05D1\u05D9\u05E7\u05D5\u05E8\u05EA",
      "Drop the local action log.": "\u05DE\u05D5\u05D7\u05E7 \u05D0\u05EA \u05D9\u05D5\u05DE\u05DF \u05D4\u05E4\u05E2\u05D5\u05DC\u05D5\u05EA \u05D4\u05DE\u05E7\u05D5\u05DE\u05D9.",
      "Storage": "\u05D0\u05D7\u05E1\u05D5\u05DF",
      "Settings stay in this browser.": "\u05D4\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05E0\u05E9\u05D0\u05E8\u05D5\u05EA \u05D1\u05D3\u05E4\u05D3\u05E4\u05DF \u05D4\u05D6\u05D4.",
      "Local-only mode": "\u05DE\u05E6\u05D1 \u05DE\u05E7\u05D5\u05DE\u05D9 \u05D1\u05DC\u05D1\u05D3",
      "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.": "\u05D7\u05D5\u05E1\u05DD \u05DB\u05DC \u05D1\u05E7\u05E9\u05D4 \u05D9\u05D5\u05E6\u05D0\u05EA, \u05DB\u05D5\u05DC\u05DC \u05D4\u05D0\u05D9\u05E0\u05D8\u05D2\u05E8\u05E6\u05D9\u05D5\u05EA \u05E9\u05D4\u05D2\u05D3\u05E8\u05EA. \u05DE\u05D5\u05E4\u05E2\u05DC \u05DB\u05D1\u05E8\u05D9\u05E8\u05EA \u05DE\u05D7\u05D3\u05DC; \u05D4\u05E4\u05E2\u05DC\u05EA \u05D0\u05D9\u05E0\u05D8\u05D2\u05E8\u05E6\u05D9\u05D4 \u05D4\u05D9\u05D0 \u05DE\u05D4 \u05E9\u05DE\u05DB\u05D1\u05D4 \u05D0\u05D5\u05EA\u05D5.",
      "Some changes could not be saved \u2014 the browser store may be full.": "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05D4\u05D9\u05D4 \u05DC\u05E9\u05DE\u05D5\u05E8 \u05D7\u05DC\u05E7 \u05DE\u05D4\u05E9\u05D9\u05E0\u05D5\u05D9\u05D9\u05DD \u2014 \u05D9\u05D9\u05EA\u05DB\u05DF \u05E9\u05D0\u05D7\u05E1\u05D5\u05DF \u05D4\u05D3\u05E4\u05D3\u05E4\u05DF \u05DE\u05DC\u05D0.",
      "Saving": "\u05E9\u05DE\u05D9\u05E8\u05D4",
      "Telemetry": "\u05E0\u05EA\u05D5\u05E0\u05D9 \u05E9\u05D9\u05DE\u05D5\u05E9",
      "Disabled": "\u05DE\u05D5\u05E9\u05D1\u05EA",
      "Panel language": "\u05E9\u05E4\u05EA \u05D4\u05E4\u05D0\u05E0\u05DC",
      "Selector health": "\u05EA\u05E7\u05D9\u05E0\u05D5\u05EA \u05D4\u05E1\u05DC\u05E7\u05D8\u05D5\u05E8\u05D9\u05DD",
      "Working \u2014 every change has been written.": "\u05EA\u05E7\u05D9\u05DF \u2014 \u05DB\u05DC \u05D4\u05E9\u05D9\u05E0\u05D5\u05D9\u05D9\u05DD \u05E0\u05E9\u05DE\u05E8\u05D5.",
      "Monitoring active": "\u05D4\u05E0\u05D9\u05D8\u05D5\u05E8 \u05E4\u05E2\u05D9\u05DC",
      "Preset packs unavailable in this build.": "\u05D4\u05E2\u05E8\u05DB\u05D5\u05EA \u05D4\u05DE\u05D5\u05DB\u05E0\u05D5\u05EA \u05D0\u05D9\u05E0\u05DF \u05D6\u05DE\u05D9\u05E0\u05D5\u05EA \u05D1\u05D2\u05E8\u05E1\u05D4 \u05D6\u05D5.",
      "Hidden post store unavailable in this build.": "\u05DE\u05D0\u05D2\u05E8 \u05D4\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D4\u05DE\u05D5\u05E1\u05EA\u05E8\u05D9\u05DD \u05D0\u05D9\u05E0\u05D5 \u05D6\u05DE\u05D9\u05DF \u05D1\u05D2\u05E8\u05E1\u05D4 \u05D6\u05D5.",
      "Cancel": "\u05D1\u05D9\u05D8\u05D5\u05DC"
    }
  };

  // src/platform/i18n.ts
  var LOCALES = [
    { code: "en", label: "English", direction: "ltr" },
    { code: "es", label: "Espa\xF1ol", direction: "ltr" },
    { code: "pt", label: "Portugu\xEAs", direction: "ltr" },
    { code: "fr", label: "Fran\xE7ais", direction: "ltr" },
    { code: "de", label: "Deutsch", direction: "ltr" },
    { code: "ja", label: "\u65E5\u672C\u8A9E", direction: "ltr" },
    { code: "ko", label: "\uD55C\uAD6D\uC5B4", direction: "ltr" },
    { code: "ar", label: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629", direction: "rtl" },
    { code: "he", label: "\u05E2\u05D1\u05E8\u05D9\u05EA", direction: "rtl" }
  ];
  function translateText(locale, english) {
    if (locale === "en") {
      return english;
    }
    return PANEL_CATALOG[locale]?.[english] ?? english;
  }
  function hasTranslation(locale, english) {
    if (locale === "en") {
      return true;
    }
    return PANEL_CATALOG[locale]?.[english] !== void 0;
  }
  function localeDirection(locale) {
    return LOCALES.find((entry) => entry.code === locale)?.direction ?? "ltr";
  }
  function supportedLocales() {
    return LOCALES.map((entry) => ({ ...entry }));
  }

  // src/platform/settings.ts
  var SETTINGS_KEY = "aviary.settings.v1";
  var THEME_IDS = ["dim", "lightsOut", "graphite", "plum", "midnight"];
  var RATE_LIMIT_MODES = ["conservative", "balanced"];
  var REDUCE_MOTION_MODES = ["system", "always", "never"];
  var FILTER_ACTIONS = ["off", "hide", "dim"];
  var FILTER_SURFACES = [
    "home",
    "status",
    "profile",
    "search",
    "notifications",
    "messages"
  ];
  var SENSITIVE_MODES = ["default", "reveal", "blur", "hide"];
  var MEDIA_LAYOUTS = ["default", "stacked", "grid"];
  var FILTER_MEDIA_KEYS = ["photo", "video", "gif"];
  var EXPORT_FORMATS = ["json", "csv", "html", "markdown", "xlsx"];
  var BLOCKED_OBJECT_KEYS = /* @__PURE__ */ new Set(["__proto__", "prototype", "constructor"]);
  var AI_PROVIDERS = [
    "anthropic",
    "openai",
    "openai-compatible"
  ];
  var MASTODON_VISIBILITIES = [
    "public",
    "unlisted",
    "private",
    "direct"
  ];
  var DEFAULT_SETTINGS = {
    appearance: {
      theme: "dim",
      denseMode: false,
      timelineWidth: "default",
      hideBorders: false,
      hideCounts: false,
      restoreChirp: false
    },
    layout: {
      hideNavItems: [],
      hideRightSidebar: true,
      hideTrends: true,
      hideGrok: true,
      writerMode: false
    },
    filter: {
      enabled: false,
      keywordRules: [],
      regexRules: [],
      premiumRule: "off",
      blockedAccounts: "hide",
      selfRepost: "off",
      whitelist: [],
      mediaTypes: { photo: false, video: false, gif: false },
      surfaces: ["home", "status", "profile", "search"]
    },
    hidden: {
      enabled: true,
      buttons: true,
      surfaces: ["home", "status", "profile", "search", "notifications"],
      maxEntries: 5e3
    },
    media: {
      buttons: true,
      preferOriginalImages: true,
      filenameTemplate: "{handle}_{tweetId}_{index}",
      downloadHistory: true,
      zipChunkSize: 250,
      sensitive: "default",
      layout: "default",
      lastSaveFolder: ""
    },
    jobs: {
      concurrentDownloads: 3,
      rateLimitMode: "conservative"
    },
    export: {
      enabled: false,
      formats: ["json", "csv", "html"],
      preserveRawPayloads: false,
      autoDiscoverQueryIds: true
    },
    links: {
      cleanShareButtons: true,
      expandTco: false
    },
    composer: {
      snippets: []
    },
    privacy: {
      localOnly: true,
      telemetry: false,
      encryptVault: false,
      auditLog: true
    },
    accessibility: {
      reduceMotion: "system",
      highContrast: false
    },
    i18n: {
      locale: "en"
    },
    diagnostics: {
      selectorHealth: true
    },
    integrations: {
      aria2: { enabled: false, endpoint: "", secret: "", minBytes: 5e7 },
      bluesky: { enabled: false, service: "https://bsky.social", handle: "", appPassword: "" },
      mastodon: { enabled: false, instance: "", token: "", visibility: "public" },
      ai: { enabled: false, provider: "anthropic", endpoint: "", apiKey: "", model: "" },
      semanticSearch: { enabled: false, endpoint: "", apiKey: "", model: "", autoIndex: false },
      crosspost: { attachLastDownload: false }
    }
  };
  function normalizeSettings(input) {
    const record = asRecord(input);
    const appearance = asRecord(record.appearance);
    const layout = asRecord(record.layout);
    const filter = asRecord(record.filter);
    const hidden = asRecord(record.hidden);
    const media = asRecord(record.media);
    const jobs = asRecord(record.jobs);
    const exportSettings = asRecord(record.export);
    const links = asRecord(record.links);
    const composer = asRecord(record.composer);
    const privacy = asRecord(record.privacy);
    const accessibility = asRecord(record.accessibility);
    const i18n = asRecord(record.i18n);
    const diagnostics = asRecord(record.diagnostics);
    const integrations = asRecord(record.integrations);
    const integrationsAria = asRecord(integrations.aria2);
    const integrationsBluesky = asRecord(integrations.bluesky);
    const integrationsMastodon = asRecord(integrations.mastodon);
    const integrationsAi = asRecord(integrations.ai);
    const integrationsSemantic = asRecord(integrations.semanticSearch);
    const integrationsCrosspost = asRecord(integrations.crosspost);
    const anyIntegrationEnabled = [
      integrationsAria,
      integrationsBluesky,
      integrationsMastodon,
      integrationsAi,
      integrationsSemantic
    ].some((entry) => entry.enabled === true);
    return {
      appearance: {
        theme: enumValue(appearance.theme, THEME_IDS, DEFAULT_SETTINGS.appearance.theme),
        denseMode: booleanValue(appearance.denseMode, DEFAULT_SETTINGS.appearance.denseMode),
        timelineWidth: enumValue(
          appearance.timelineWidth,
          ["default", "comfortable", "wide"],
          DEFAULT_SETTINGS.appearance.timelineWidth
        ),
        hideBorders: booleanValue(appearance.hideBorders, DEFAULT_SETTINGS.appearance.hideBorders),
        hideCounts: booleanValue(appearance.hideCounts, DEFAULT_SETTINGS.appearance.hideCounts),
        restoreChirp: booleanValue(appearance.restoreChirp, DEFAULT_SETTINGS.appearance.restoreChirp)
      },
      layout: {
        hideNavItems: stringArray(layout.hideNavItems, { maxItems: 24, maxLength: 48 }),
        hideRightSidebar: booleanValue(layout.hideRightSidebar, DEFAULT_SETTINGS.layout.hideRightSidebar),
        hideTrends: booleanValue(layout.hideTrends, DEFAULT_SETTINGS.layout.hideTrends),
        hideGrok: booleanValue(layout.hideGrok, DEFAULT_SETTINGS.layout.hideGrok),
        writerMode: booleanValue(layout.writerMode, DEFAULT_SETTINGS.layout.writerMode)
      },
      filter: {
        enabled: booleanValue(filter.enabled, DEFAULT_SETTINGS.filter.enabled),
        keywordRules: stringArray(filter.keywordRules, { maxItems: 200, maxLength: 180 }),
        regexRules: stringArray(filter.regexRules, { maxItems: 100, maxLength: 240 }),
        premiumRule: enumValue(filter.premiumRule, FILTER_ACTIONS, DEFAULT_SETTINGS.filter.premiumRule),
        blockedAccounts: enumValue(
          filter.blockedAccounts,
          FILTER_ACTIONS,
          DEFAULT_SETTINGS.filter.blockedAccounts
        ),
        selfRepost: enumValue(filter.selfRepost, FILTER_ACTIONS, DEFAULT_SETTINGS.filter.selfRepost),
        whitelist: stringArray(filter.whitelist, { maxItems: 200, maxLength: 80 }),
        mediaTypes: mediaTypeRecord(filter.mediaTypes),
        surfaces: surfaceArray(filter.surfaces)
      },
      hidden: {
        enabled: booleanValue(hidden.enabled, DEFAULT_SETTINGS.hidden.enabled),
        buttons: booleanValue(hidden.buttons, DEFAULT_SETTINGS.hidden.buttons),
        surfaces: surfaceArray(hidden.surfaces, DEFAULT_SETTINGS.hidden.surfaces),
        maxEntries: integerValue(hidden.maxEntries, DEFAULT_SETTINGS.hidden.maxEntries, 100, 5e4)
      },
      media: {
        buttons: booleanValue(media.buttons, DEFAULT_SETTINGS.media.buttons),
        preferOriginalImages: booleanValue(media.preferOriginalImages, DEFAULT_SETTINGS.media.preferOriginalImages),
        filenameTemplate: stringValue(media.filenameTemplate, DEFAULT_SETTINGS.media.filenameTemplate, 160),
        downloadHistory: booleanValue(media.downloadHistory, DEFAULT_SETTINGS.media.downloadHistory),
        zipChunkSize: integerValue(media.zipChunkSize, DEFAULT_SETTINGS.media.zipChunkSize, 25, 1e3),
        sensitive: enumValue(media.sensitive, SENSITIVE_MODES, DEFAULT_SETTINGS.media.sensitive),
        layout: enumValue(media.layout, MEDIA_LAYOUTS, DEFAULT_SETTINGS.media.layout),
        lastSaveFolder: folderHintValue(media.lastSaveFolder, DEFAULT_SETTINGS.media.lastSaveFolder)
      },
      jobs: {
        concurrentDownloads: integerValue(
          jobs.concurrentDownloads,
          DEFAULT_SETTINGS.jobs.concurrentDownloads,
          1,
          6
        ),
        rateLimitMode: enumValue(jobs.rateLimitMode, RATE_LIMIT_MODES, DEFAULT_SETTINGS.jobs.rateLimitMode)
      },
      export: {
        enabled: booleanValue(exportSettings.enabled, DEFAULT_SETTINGS.export.enabled),
        formats: exportFormatArray(exportSettings.formats),
        preserveRawPayloads: booleanValue(
          exportSettings.preserveRawPayloads,
          DEFAULT_SETTINGS.export.preserveRawPayloads
        ),
        autoDiscoverQueryIds: booleanValue(
          exportSettings.autoDiscoverQueryIds,
          DEFAULT_SETTINGS.export.autoDiscoverQueryIds
        )
      },
      links: {
        cleanShareButtons: booleanValue(links.cleanShareButtons, DEFAULT_SETTINGS.links.cleanShareButtons),
        expandTco: booleanValue(links.expandTco, DEFAULT_SETTINGS.links.expandTco)
      },
      composer: {
        snippets: stringArray(composer.snippets, { maxItems: 100, maxLength: 500 })
      },
      privacy: {
        localOnly: anyIntegrationEnabled ? false : booleanValue(privacy.localOnly, DEFAULT_SETTINGS.privacy.localOnly),
        telemetry: false,
        encryptVault: booleanValue(privacy.encryptVault, DEFAULT_SETTINGS.privacy.encryptVault),
        auditLog: booleanValue(privacy.auditLog, DEFAULT_SETTINGS.privacy.auditLog)
      },
      accessibility: {
        reduceMotion: enumValue(
          accessibility.reduceMotion,
          REDUCE_MOTION_MODES,
          DEFAULT_SETTINGS.accessibility.reduceMotion
        ),
        highContrast: booleanValue(accessibility.highContrast, DEFAULT_SETTINGS.accessibility.highContrast)
      },
      i18n: {
        locale: localeValue(i18n.locale, DEFAULT_SETTINGS.i18n.locale)
      },
      diagnostics: {
        selectorHealth: booleanValue(diagnostics.selectorHealth, DEFAULT_SETTINGS.diagnostics.selectorHealth)
      },
      integrations: {
        aria2: {
          enabled: booleanValue(integrationsAria.enabled, DEFAULT_SETTINGS.integrations.aria2.enabled),
          endpoint: urlValue(integrationsAria.endpoint, DEFAULT_SETTINGS.integrations.aria2.endpoint),
          secret: secretValue(integrationsAria.secret, DEFAULT_SETTINGS.integrations.aria2.secret),
          minBytes: integerValue(
            integrationsAria.minBytes,
            DEFAULT_SETTINGS.integrations.aria2.minBytes,
            1e6,
            5e9
          )
        },
        bluesky: {
          enabled: booleanValue(integrationsBluesky.enabled, DEFAULT_SETTINGS.integrations.bluesky.enabled),
          service: urlValue(integrationsBluesky.service, DEFAULT_SETTINGS.integrations.bluesky.service),
          handle: handleOrEmpty(integrationsBluesky.handle),
          appPassword: secretValue(
            integrationsBluesky.appPassword,
            DEFAULT_SETTINGS.integrations.bluesky.appPassword
          )
        },
        mastodon: {
          enabled: booleanValue(
            integrationsMastodon.enabled,
            DEFAULT_SETTINGS.integrations.mastodon.enabled
          ),
          instance: urlValue(
            integrationsMastodon.instance,
            DEFAULT_SETTINGS.integrations.mastodon.instance
          ),
          token: secretValue(integrationsMastodon.token, DEFAULT_SETTINGS.integrations.mastodon.token),
          visibility: enumValue(
            integrationsMastodon.visibility,
            MASTODON_VISIBILITIES,
            DEFAULT_SETTINGS.integrations.mastodon.visibility
          )
        },
        ai: {
          enabled: booleanValue(integrationsAi.enabled, DEFAULT_SETTINGS.integrations.ai.enabled),
          provider: enumValue(integrationsAi.provider, AI_PROVIDERS, DEFAULT_SETTINGS.integrations.ai.provider),
          endpoint: urlValue(integrationsAi.endpoint, DEFAULT_SETTINGS.integrations.ai.endpoint),
          apiKey: secretValue(integrationsAi.apiKey, DEFAULT_SETTINGS.integrations.ai.apiKey),
          model: stringValue(integrationsAi.model, DEFAULT_SETTINGS.integrations.ai.model, 120)
        },
        semanticSearch: {
          enabled: booleanValue(
            integrationsSemantic.enabled,
            DEFAULT_SETTINGS.integrations.semanticSearch.enabled
          ),
          endpoint: urlValue(
            integrationsSemantic.endpoint,
            DEFAULT_SETTINGS.integrations.semanticSearch.endpoint
          ),
          apiKey: secretValue(
            integrationsSemantic.apiKey,
            DEFAULT_SETTINGS.integrations.semanticSearch.apiKey
          ),
          model: stringValue(integrationsSemantic.model, DEFAULT_SETTINGS.integrations.semanticSearch.model, 120),
          autoIndex: booleanValue(
            integrationsSemantic.autoIndex,
            DEFAULT_SETTINGS.integrations.semanticSearch.autoIndex
          )
        },
        crosspost: {
          attachLastDownload: booleanValue(
            integrationsCrosspost.attachLastDownload,
            DEFAULT_SETTINGS.integrations.crosspost.attachLastDownload
          )
        }
      }
    };
  }
  function cloneSettings(settings) {
    return JSON.parse(JSON.stringify(settings));
  }
  function isThemeId(value) {
    return THEME_IDS.includes(value);
  }
  function asRecord(value) {
    return isRecord(value) ? value : {};
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function booleanValue(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function stringValue(value, fallback, maxLength = 500) {
    if (typeof value !== "string") {
      return fallback;
    }
    const normalized = value.replace(/[\u0000-\u001f\u007f]/g, "").trim();
    return normalized.length > 0 ? normalized.slice(0, maxLength) : fallback;
  }
  function enumValue(value, allowed, fallback) {
    return typeof value === "string" && allowed.includes(value) ? value : fallback;
  }
  function stringArray(value, options = {}) {
    if (!Array.isArray(value)) {
      return [];
    }
    const maxItems = options.maxItems ?? 100;
    const maxLength = options.maxLength ?? 180;
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const item of value) {
      if (typeof item !== "string") {
        continue;
      }
      const normalized = item.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, maxLength);
      if (normalized.length === 0 || seen.has(normalized)) {
        continue;
      }
      seen.add(normalized);
      result.push(normalized);
      if (result.length >= maxItems) {
        break;
      }
    }
    return result;
  }
  function booleanRecord(value) {
    if (!isRecord(value)) {
      return {};
    }
    const result = {};
    for (const [key, enabled] of Object.entries(value)) {
      if (!BLOCKED_OBJECT_KEYS.has(key) && /^[a-z0-9_-]{1,40}$/i.test(key) && typeof enabled === "boolean") {
        result[key] = enabled;
      }
    }
    return result;
  }
  function mediaTypeRecord(value) {
    const record = booleanRecord(value);
    const result = {};
    for (const key of FILTER_MEDIA_KEYS) {
      result[key] = record[key] ?? DEFAULT_SETTINGS.filter.mediaTypes[key] ?? false;
    }
    for (const [key, enabled] of Object.entries(record)) {
      if (!(key in result)) {
        result[key] = enabled;
      }
    }
    return result;
  }
  function surfaceArray(value, fallback = DEFAULT_SETTINGS.filter.surfaces) {
    if (!Array.isArray(value)) {
      return [...fallback];
    }
    const seen = /* @__PURE__ */ new Set();
    for (const item of value) {
      if (typeof item === "string" && FILTER_SURFACES.includes(item)) {
        seen.add(item);
      }
    }
    return seen.size > 0 ? [...seen] : [...fallback];
  }
  function integerValue(value, fallback, min, max) {
    if (typeof value !== "number" || !Number.isFinite(value)) {
      return fallback;
    }
    return Math.max(min, Math.min(max, Math.trunc(value)));
  }
  function exportFormatArray(value) {
    if (!Array.isArray(value)) {
      return [...DEFAULT_SETTINGS.export.formats];
    }
    const formats = value.filter((item) => {
      return typeof item === "string" && EXPORT_FORMATS.includes(item);
    });
    return formats.length > 0 ? [...new Set(formats)] : [...DEFAULT_SETTINGS.export.formats];
  }
  function urlValue(value, fallback) {
    if (typeof value !== "string") return fallback;
    const trimmed = value.trim();
    if (trimmed.length === 0) return fallback === "" ? "" : fallback;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return fallback;
      return parsed.toString().replace(/\/$/, "");
    } catch {
      return fallback;
    }
  }
  function secretValue(value, fallback) {
    if (typeof value !== "string") return fallback;
    const cleaned = value.replace(/[\u0000-\u001f\u007f]/g, "").trim();
    return cleaned.length === 0 ? fallback : cleaned.slice(0, 4096);
  }
  function handleOrEmpty(value) {
    if (typeof value !== "string") return "";
    const cleaned = value.replace(/^@/, "").trim();
    if (cleaned.length === 0) return "";
    return /^[A-Za-z0-9._-]{1,253}$/.test(cleaned) ? cleaned : "";
  }
  function folderHintValue(value, fallback) {
    if (typeof value !== "string") {
      return fallback;
    }
    const cleaned = value.replace(/[<>:"|?*\u0000-\u001f]/g, "").trim().slice(0, 120);
    return cleaned;
  }
  function localeValue(value, fallback) {
    if (typeof value !== "string") {
      return fallback;
    }
    const normalized = value.trim();
    return /^[a-z]{2,3}(-[A-Za-z0-9]{2,8}){0,2}$/.test(normalized) ? normalized : fallback;
  }

  // src/ui/control-center.ts
  var SENSITIVE_OPTIONS = [
    ["default", "Default (X choice)"],
    ["reveal", "Always reveal"],
    ["blur", "Blur until hovered"],
    ["hide", "Always hide"]
  ];
  var MEDIA_LAYOUT_OPTIONS = [
    ["default", "Default grid"],
    ["stacked", "Stacked"],
    ["grid", "Strict grid"]
  ];
  var FILTER_ACTION_OPTIONS = [
    ["off", "Off"],
    ["hide", "Hide"],
    ["dim", "Dim"]
  ];
  var FILTER_SURFACE_LABELS = {
    home: "Home",
    status: "Status",
    profile: "Profile",
    search: "Search",
    notifications: "Notifications",
    messages: "Messages"
  };
  var FILTER_MEDIA_LABELS = {
    photo: "Photos",
    video: "Videos",
    gif: "GIFs"
  };
  function mountControlCenter(options) {
    const existing = document.getElementById("av-control-center");
    existing?.remove();
    panelLocale = options.settings.i18n.locale;
    resetCoverageTally();
    const host = document.createElement("div");
    host.id = "av-control-center";
    host.dataset.avOwned = "true";
    document.documentElement.append(host);
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = CONTROL_CENTER_CSS;
    const shell = el("div", "av-shell");
    const launcher = button("Aviary", "av-launcher");
    launcher.type = "button";
    launcher.setAttribute("aria-expanded", "false");
    launcher.setAttribute("aria-controls", "av-control-panel");
    const overlay = el("div", "av-overlay");
    overlay.setAttribute("aria-hidden", "true");
    overlay.toggleAttribute("inert", true);
    const panel = el("section", "av-panel");
    panel.id = "av-control-panel";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Aviary settings");
    panel.tabIndex = -1;
    const header = el("header", "av-panel-header");
    const titleWrap = el("div", "av-title-wrap");
    const title = el("h2", "av-title", t("Aviary"));
    const subtitle = el("p", "av-subtitle", t("Local controls for a quieter X."));
    titleWrap.append(title, subtitle);
    const close = button("Close", "av-button av-button-secondary");
    close.type = "button";
    header.append(titleWrap, close);
    const status = el("div", "av-status", t("Saved locally"));
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    const searchBar = el("div", "av-searchbar");
    const search = document.createElement("input");
    search.type = "search";
    search.className = "av-search-input";
    search.placeholder = t("Search settings");
    search.setAttribute("aria-label", t("Search settings"));
    search.spellcheck = false;
    searchBar.append(search);
    const body = el("div", "av-panel-body");
    panel.append(header, searchBar, body, status);
    overlay.append(panel);
    shell.append(launcher, overlay);
    shadow.append(style, shell);
    let open = false;
    let dirtyWhileBusy = false;
    let activeSectionId = "presets";
    let searchQuery = "";
    let lastStatusEnglish = "Saved locally";
    const setOpen = (value) => {
      open = value;
      launcher.setAttribute("aria-expanded", String(open));
      overlay.classList.toggle("is-open", open);
      overlay.setAttribute("aria-hidden", String(!open));
      overlay.toggleAttribute("inert", !open);
      if (open) {
        if (dirtyWhileBusy) {
          dirtyWhileBusy = false;
          render();
        }
        panel.focus({ preventScroll: true });
      } else {
        launcher.focus({ preventScroll: true });
      }
    };
    const isBusy = () => {
      const active = shadow.activeElement;
      if (!active) {
        return false;
      }
      return active !== panel;
    };
    const setStatus = (message) => {
      lastStatusEnglish = message;
      status.textContent = t(message);
    };
    const focusIdentity = (node) => {
      if (!node || !body.contains(node)) {
        return null;
      }
      const row = node.closest(".av-row");
      const sectionTitle = node.closest(".av-section")?.querySelector(".av-section-title")?.textContent ?? "";
      const label = row?.querySelector(".av-row-label")?.textContent ?? "";
      const scope = row ?? body;
      const index = Array.from(scope.querySelectorAll(FOCUSABLE_SELECTOR)).indexOf(
        node
      );
      if (label) {
        return `row|${sectionTitle}|${label}|${node.tagName}|${index}`;
      }
      return `path|${positionalPath(body, node)}`;
    };
    const findByIdentity = (identity) => {
      for (const candidate of Array.from(body.querySelectorAll(FOCUSABLE_SELECTOR))) {
        if (focusIdentity(candidate) === identity) {
          return candidate;
        }
      }
      return null;
    };
    const render = () => {
      const active = shadow.activeElement;
      const identity = focusIdentity(active);
      const selection = captureSelection(active);
      const scrollTop = body.scrollTop;
      panelLocale = options.settings.i18n.locale;
      resetCoverageTally();
      title.textContent = t("Aviary");
      subtitle.textContent = t("Local controls for a quieter X.");
      close.textContent = t("Close");
      launcher.textContent = t("Aviary");
      search.placeholder = t("Search settings");
      search.setAttribute("aria-label", t("Search settings"));
      status.textContent = t(lastStatusEnglish);
      host.dataset.avMotion = prefersReducedMotion(options.settings) ? "reduce" : "full";
      const registry = sectionRegistry();
      if (!registry.some((entry) => entry.id === activeSectionId)) {
        activeSectionId = registry[0]?.id ?? "presets";
      }
      body.replaceChildren(buildNav(registry), buildContent(registry));
      const coverage = body.querySelector(`.${COVERAGE_ROW_CLASS} .av-row-description`);
      if (coverage) {
        coverage.textContent = coverageSummary();
      }
      body.scrollTop = scrollTop;
      if (identity) {
        const target = findByIdentity(identity);
        if (target) {
          target.focus({ preventScroll: true });
          restoreSelection(target, selection);
        }
      }
    };
    const appearanceRows = () => {
      return [
        selectRow("Theme", options.settings.appearance.theme, [
          ["dim", "Dim"],
          ["lightsOut", "Lights out"],
          ["graphite", "Graphite"],
          ["plum", "Plum"],
          ["midnight", "Midnight"]
        ], async (value) => {
          if (!isThemeId(value)) {
            setStatus("Theme value is not supported.");
            return;
          }
          options.settings.appearance.theme = value;
          await save("Theme updated");
        }),
        toggleRow("Dense mode", "Tighten timeline spacing for scanning.", options.settings.appearance.denseMode, async (checked) => {
          options.settings.appearance.denseMode = checked;
          await save("Density updated");
        }),
        toggleRow(
          "Hide engagement counts",
          "Hide reply, repost, and like numbers. The buttons still work and screen readers still announce the totals.",
          options.settings.appearance.hideCounts,
          async (checked) => {
            options.settings.appearance.hideCounts = checked;
            await save(checked ? "Engagement counts hidden" : "Engagement counts shown");
          }
        ),
        toggleRow(
          "Hide row borders",
          "Remove the 1px divider under each timeline post and the primary column's side rules.",
          options.settings.appearance.hideBorders,
          async (checked) => {
            options.settings.appearance.hideBorders = checked;
            await save(checked ? "Row borders hidden" : "Row borders restored");
          }
        ),
        toggleRow("High contrast", "Use stronger borders and text contrast.", options.settings.accessibility.highContrast, async (checked) => {
          options.settings.accessibility.highContrast = checked;
          await save("Contrast preference saved");
        }),
        selectRow(
          "Reduced motion",
          options.settings.accessibility.reduceMotion,
          [
            ["system", "Follow system setting"],
            ["always", "Always reduce"],
            ["never", "Never reduce"]
          ],
          async (value) => {
            options.settings.accessibility.reduceMotion = coerceReduceMotion(value);
            await save("Motion preference saved");
          }
        )
      ];
    };
    const layoutRows = () => {
      return [
        toggleRow("Hide right sidebar", "Reduce trends, recommendations, and footer noise.", options.settings.layout.hideRightSidebar, async (checked) => {
          options.settings.layout.hideRightSidebar = checked;
          await save("Sidebar preference saved");
        }),
        toggleRow("Hide trends", "Remove trending topics and news modules.", options.settings.layout.hideTrends, async (checked) => {
          options.settings.layout.hideTrends = checked;
          await save("Trend preference saved");
        }),
        toggleRow("Hide Grok surfaces", "Remove Grok drawer and composer buttons where detected.", options.settings.layout.hideGrok, async (checked) => {
          options.settings.layout.hideGrok = checked;
          await save("Grok preference saved");
        }),
        toggleRow(
          "Writer mode",
          "While focus is in the composer, fade the sidebar and the timeline behind it. Everything returns the moment you click away.",
          options.settings.layout.writerMode,
          async (checked) => {
            options.settings.layout.writerMode = checked;
            await save(checked ? "Writer mode on" : "Writer mode off");
          }
        )
      ];
    };
    const trustRows = () => {
      return [
        readonlyRow("Storage", "Settings stay in this browser."),
        toggleRow(
          "Local-only mode",
          "Blocks every outbound request, including the integrations you configured. On by default; turning an integration on is what turns this off.",
          options.settings.privacy.localOnly,
          async (checked) => {
            options.settings.privacy.localOnly = checked;
            await save(checked ? "Local-only mode on" : "Local-only mode off");
          }
        ),
        storageHealthRow(),
        readonlyRow("Telemetry", options.settings.privacy.telemetry ? "Enabled" : "Disabled"),
        coverageRow(),
        dataRow("Selector health", selectorSummary())
      ];
    };
    const sectionRegistry = () => [
      { id: "presets", title: "Presets", group: "Start", build: presetRows },
      { id: "appearance", title: "Appearance", group: "Reading", build: appearanceRows },
      { id: "layout", title: "Layout", group: "Reading", build: layoutRows },
      { id: "filtering", title: "Filtering", group: "Reading", build: filterRows },
      { id: "hidden", title: "Hidden posts", group: "Reading", build: hiddenPostRows },
      { id: "media", title: "Media", group: "Data", build: mediaRows },
      { id: "export", title: "Export", group: "Data", build: exportRows },
      { id: "library", title: "Library", group: "Data", build: libraryRows },
      { id: "snapshots", title: "Snapshots & Archive", group: "Data", build: snapshotRows },
      { id: "integrations", title: "Integrations", group: "Advanced", build: integrationRows },
      { id: "backup", title: "Backup & Audit", group: "Advanced", build: backupRows },
      { id: "trust", title: "Trust", group: "Advanced", build: trustRows }
    ];
    const buildNav = (registry) => {
      const nav = el("nav", "av-nav");
      nav.setAttribute("aria-label", t("Settings sections"));
      let currentGroup = "";
      for (const entry of registry) {
        if (entry.group !== currentGroup) {
          currentGroup = entry.group;
          nav.append(el("p", "av-nav-group", t(currentGroup)));
        }
        const item = el("button", "av-nav-item", t(entry.title));
        item.type = "button";
        item.dataset.avSection = entry.id;
        const selected = searchQuery.length === 0 && entry.id === activeSectionId;
        item.classList.toggle("is-active", selected);
        item.setAttribute("aria-current", selected ? "true" : "false");
        item.addEventListener("click", () => {
          activeSectionId = entry.id;
          searchQuery = "";
          search.value = "";
          render();
        });
        nav.append(item);
      }
      return nav;
    };
    const buildContent = (registry) => {
      const content = el("div", "av-content");
      if (searchQuery.length > 0) {
        content.append(...searchResults(registry));
        return content;
      }
      const entry = registry.find((candidate) => candidate.id === activeSectionId) ?? registry[0];
      content.append(section(entry.title, entry.build()));
      return content;
    };
    const searchResults = (registry) => {
      const needle = searchQuery.trim().toLowerCase();
      const out = [];
      let matches = 0;
      for (const entry of registry) {
        const hits = entry.build().filter((row) => (row.textContent ?? "").toLowerCase().includes(needle));
        if (hits.length === 0) {
          continue;
        }
        matches += hits.length;
        out.push(section(entry.title, hits));
      }
      if (matches === 0) {
        const empty = el("div", "av-empty");
        empty.append(
          el("p", "av-empty-title", t("Nothing matches that search.")),
          el("p", "av-empty-hint", t("Try a shorter word, or pick a section on the left."))
        );
        return [empty];
      }
      return out;
    };
    const presetRows = () => {
      const rows = [];
      if (!options.listPresets || !options.applyPreset) {
        rows.push(readonlyRow("Presets", "Preset packs unavailable in this build."));
        return rows;
      }
      for (const preset of options.listPresets()) {
        const row = el("div", "av-row av-row-stack");
        const copy = el("span", "av-row-copy");
        copy.append(
          el("span", "av-row-label", preset.label),
          el("span", "av-row-description", preset.description)
        );
        const apply = el("button", "av-button av-button-secondary", t("Apply"));
        apply.type = "button";
        apply.addEventListener("click", () => {
          apply.disabled = true;
          void options.applyPreset(preset.id).then((result) => {
            if (result.applied) {
              setStatus(`Applied "${preset.label}" \u2014 ${result.changes.length} changes`);
            } else {
              setStatus(`Preset "${preset.label}" unchanged.`);
            }
          }).catch((error) => {
            options.onError("Could not apply preset", error);
            setStatus("Could not apply preset.");
          }).finally(() => {
            apply.disabled = false;
          });
        });
        row.append(copy, apply);
        rows.push(row);
      }
      if (options.listLocales && options.setLocale) {
        rows.push(
          selectRow(
            "Locale",
            options.settings.i18n.locale,
            options.listLocales().map((entry) => [entry.code, entry.label]),
            async (value) => {
              await options.setLocale(value);
              const entry = options.listLocales?.().find((locale) => locale.code === value);
              await save(`Locale set to ${entry?.label ?? value}`);
            },
            "Translates the panel and sets reading direction \u2014 right-to-left for Arabic and Hebrew. Trust shows how much of the chosen locale is filled in; anything missing stays English.",
            false
          )
        );
      }
      return rows;
    };
    const snapshotRows = () => {
      const rows = [];
      if (options.getSnapshotStatus) {
        const status2 = options.getSnapshotStatus();
        rows.push(
          dataRow(
            "Snapshots stored",
            `${status2.total} entries${status2.latestAt ? ` \xB7 latest ${status2.latestKind} of ${status2.latestCount} @ ${status2.latestAt}` : ""}`
          )
        );
      }
      if (options.captureSnapshot) {
        rows.push(
          actionRow(
            "Capture followers from this view",
            "Walks UserCell rows on the current page. Open a /handle/followers view first.",
            async () => {
              try {
                const result = await options.captureSnapshot("followers");
                setStatus(result ? `Captured ${result.count} followers for @${result.handle}.` : "No UserCell rows found.");
              } catch (error) {
                options.onError("Snapshot failed", error);
                setStatus("Snapshot failed.");
              }
            }
          )
        );
        rows.push(
          actionRow(
            "Capture following from this view",
            "Walks UserCell rows on the current page. Open a /handle/following view first.",
            async () => {
              try {
                const result = await options.captureSnapshot("following");
                setStatus(result ? `Captured ${result.count} following for @${result.handle}.` : "No UserCell rows found.");
              } catch (error) {
                options.onError("Snapshot failed", error);
                setStatus("Snapshot failed.");
              }
            }
          )
        );
      }
      if (options.clearSnapshots) {
        rows.push(
          actionRow("Clear all snapshots", "Drop every stored follower/following snapshot.", async () => {
            try {
              await options.clearSnapshots();
              await save("Snapshots cleared");
            } catch (error) {
              options.onError("Could not clear snapshots", error);
              setStatus("Could not clear snapshots.");
            }
          })
        );
      }
      if (options.importArchive) {
        const row = el("div", "av-row av-row-stack");
        const copy = el("span", "av-row-copy");
        copy.append(
          el("span", "av-row-label", "Import official X archive"),
          el("span", "av-row-description", "Pick a ZIP exported from x.com. STORE-only entries only; compressed archives are rejected.")
        );
        const input = document.createElement("input");
        input.type = "file";
        input.accept = ".zip,application/zip";
        input.className = "av-file-input";
        input.addEventListener("change", () => {
          const file = input.files?.[0];
          if (!file) return;
          void (async () => {
            setStatus("Reading archive \u2014 large files take a moment\u2026");
            try {
              const result = await options.importArchive(file);
              const warningsLabel = result.warnings > 0 || result.errors > 0 ? ` (${result.warnings} warning${result.warnings === 1 ? "" : "s"}, ${result.errors} error${result.errors === 1 ? "" : "s"})` : "";
              setStatus(`Imported ${result.records} records${warningsLabel}.`);
            } catch (error) {
              options.onError("Archive import failed", error);
              setStatus("Archive import failed.");
            } finally {
              input.value = "";
            }
          })();
        });
        row.append(copy, input);
        rows.push(row);
      }
      if (options.searchArchive) {
        const row = el("div", "av-row av-row-stack");
        const copy = el("span", "av-row-copy");
        copy.append(
          el("span", "av-row-label", "Search captured records"),
          el("span", "av-row-description", "Full-text search across the latest export collector run.")
        );
        const input = document.createElement("input");
        input.type = "search";
        input.placeholder = "@handle, keyword, phrase\u2026";
        input.className = "av-text-input";
        const results = el("div", "av-search-results");
        results.setAttribute("role", "list");
        results.setAttribute("aria-live", "polite");
        const runSearch = () => {
          const query = input.value.trim();
          results.replaceChildren();
          if (query.length === 0) {
            results.append(
              el("div", "av-row-description", "Type to search the records captured by export runs.")
            );
            return;
          }
          const hits = options.searchArchive(query);
          if (hits.length === 0) {
            results.append(el("div", "av-row-description", `No captured records match \u201C${query}\u201D.`));
            return;
          }
          for (const hit of hits.slice(0, 10)) {
            const item = el("div", "av-search-hit");
            item.setAttribute("role", "listitem");
            const head = el("span", "av-row-label", `@${hit.handle ?? "anon"} \xB7 ${hit.tweetId ?? "\u2014"}`);
            const body2 = el("span", "av-row-description", hit.text.slice(0, 140));
            item.append(head, body2);
            results.append(item);
          }
        };
        let searchTimer;
        input.addEventListener("input", () => {
          if (searchTimer !== void 0) {
            clearTimeout(searchTimer);
          }
          searchTimer = setTimeout(runSearch, 180);
        });
        runSearch();
        row.append(copy, input, results);
        rows.push(row);
      }
      if (options.downloadReport) {
        rows.push(
          actionRow("Download Markdown report", "Audit log + snapshot diff + cleanup preview.", async () => {
            setStatus("Building report\u2026");
            try {
              await options.downloadReport();
              setStatus("Report downloaded.");
            } catch (error) {
              options.onError("Could not build report", error);
              setStatus("Could not build report.");
            }
          })
        );
      }
      if (options.getCleanupQueueSize) {
        const queueStatus = options.getCleanupQueueSize();
        rows.push(
          dataRow(
            "Cleanup review queue",
            `${queueStatus.total} items \xB7 queued ${queueStatus.queued} \xB7 approved ${queueStatus.approved} \xB7 skipped ${queueStatus.skipped}`
          )
        );
        rows.push(
          readonlyRow(
            "Destructive actions",
            "Aviary never deletes posts, likes, or follows. The queue is a review list; approving or skipping only writes to the audit log."
          )
        );
      }
      if (options.enqueueCleanupReview) {
        rows.push(
          actionRow(
            "Enqueue cleanup preview for review",
            "Append every non-protected candidate from the latest cleanup preview to the queue (no destructive action).",
            async () => {
              setStatus("Building cleanup preview\u2026");
              try {
                const result = await options.enqueueCleanupReview();
                setStatus(`Enqueued ${result.added} items (${result.protected} protected skipped).`);
              } catch (error) {
                options.onError("Could not enqueue cleanup", error);
                setStatus("Could not enqueue cleanup.");
              }
            }
          )
        );
      }
      if (options.clearCleanupQueue) {
        rows.push(
          actionRow("Clear cleanup queue", "Drop every queued item without touching account data.", async () => {
            try {
              await options.clearCleanupQueue();
              await save("Cleanup queue cleared");
            } catch (error) {
              options.onError("Could not clear cleanup queue", error);
              setStatus("Could not clear queue.");
            }
          })
        );
      }
      return rows;
    };
    const integrationRows = () => {
      const rows = [];
      const status2 = options.getIntegrationStatus?.();
      const integrations = options.settings.integrations;
      rows.push(
        toggleRow(
          "Aria2 handoff",
          "Send large media downloads to a self-hosted Aria2 JSON-RPC endpoint.",
          integrations.aria2.enabled,
          async (checked) => {
            integrations.aria2.enabled = checked;
            await save(checked ? "Aria2 handoff on" : "Aria2 handoff off");
          }
        )
      );
      rows.push(
        textInputRow(
          "Aria2 endpoint",
          "http://localhost:6800 (no trailing slash needed)",
          integrations.aria2.endpoint,
          async (value) => {
            integrations.aria2.endpoint = value;
            await save("Aria2 endpoint saved");
          }
        )
      );
      rows.push(
        secretInputRow(
          "Aria2 RPC secret",
          "Optional shared secret for token: auth.",
          integrations.aria2.secret,
          async (value) => {
            integrations.aria2.secret = value;
            await save("Aria2 secret saved");
          }
        )
      );
      if (options.pingAria2) {
        rows.push(
          actionRow("Test Aria2 connection", "Sends a trivial JSON-RPC call.", async () => {
            const result = await options.pingAria2();
            setStatus(result.ok ? "Aria2 reachable." : `Aria2 unreachable: ${result.error}`);
          })
        );
      }
      if (options.listAria2Active && options.cancelAria2) {
        const row = el("div", "av-row av-row-stack");
        const copy = el("span", "av-row-copy");
        copy.append(
          el("span", "av-row-label", "Aria2 active downloads"),
          el("span", "av-row-description", "Refresh to list in-flight transfers; tap Cancel to abort one.")
        );
        const list = el("div", "av-search-results");
        const refresh = async () => {
          try {
            const active = await options.listAria2Active();
            list.replaceChildren();
            if (active.length === 0) {
              list.append(el("div", "av-row-description", "No active downloads."));
              return;
            }
            for (const job of active) {
              const item = el("div", "av-search-hit");
              const total = job.totalLength > 0 ? `${Math.round(job.completedLength / job.totalLength * 100)}%` : "?";
              item.append(
                el("span", "av-row-label", `${job.path || job.gid} \xB7 ${total}`),
                el("span", "av-row-description", `gid ${job.gid} \xB7 ${job.status}`)
              );
              const cancel = el("button", "av-button av-button-secondary", t("Cancel"));
              cancel.type = "button";
              cancel.addEventListener("click", async () => {
                cancel.disabled = true;
                const result = await options.cancelAria2(job.gid);
                cancel.disabled = false;
                if (result.ok) {
                  setStatus(`Cancelled ${job.gid}.`);
                  await refresh();
                } else {
                  setStatus(`Aria2 cancel failed: ${result.error}`);
                }
              });
              item.append(cancel);
              list.append(item);
            }
          } catch (error) {
            options.onError("Aria2 sweep failed", error);
            setStatus("Aria2 sweep failed.");
          }
        };
        const refreshBtn = el("button", "av-button av-button-secondary", t("Refresh"));
        refreshBtn.type = "button";
        refreshBtn.addEventListener("click", () => void refresh());
        row.append(copy, refreshBtn, list);
        rows.push(row);
      }
      rows.push(
        toggleRow(
          "Bluesky crosspost",
          "Post composer text to your Bluesky account on demand.",
          integrations.bluesky.enabled,
          async (checked) => {
            integrations.bluesky.enabled = checked;
            await save(checked ? "Bluesky on" : "Bluesky off");
          }
        )
      );
      rows.push(
        textInputRow(
          "Bluesky service URL",
          "Default: https://bsky.social",
          integrations.bluesky.service,
          async (value) => {
            integrations.bluesky.service = value;
            await save("Bluesky service saved");
          }
        )
      );
      rows.push(
        textInputRow(
          "Bluesky handle",
          "Your handle (no @, e.g. you.bsky.social)",
          integrations.bluesky.handle,
          async (value) => {
            integrations.bluesky.handle = value;
            await save("Bluesky handle saved");
          }
        )
      );
      rows.push(
        secretInputRow(
          "Bluesky app password",
          "App password from your account settings \u2014 never your main password.",
          integrations.bluesky.appPassword,
          async (value) => {
            integrations.bluesky.appPassword = value;
            await save("Bluesky app password saved");
          }
        )
      );
      rows.push(
        toggleRow(
          "Mastodon crosspost",
          "Post composer text to your Mastodon account on demand.",
          integrations.mastodon.enabled,
          async (checked) => {
            integrations.mastodon.enabled = checked;
            await save(checked ? "Mastodon on" : "Mastodon off");
          }
        )
      );
      rows.push(
        textInputRow(
          "Mastodon instance",
          "https://mastodon.social",
          integrations.mastodon.instance,
          async (value) => {
            integrations.mastodon.instance = value;
            await save("Mastodon instance saved");
          }
        )
      );
      rows.push(
        secretInputRow(
          "Mastodon access token",
          "Bearer token with write:statuses scope.",
          integrations.mastodon.token,
          async (value) => {
            integrations.mastodon.token = value;
            await save("Mastodon token saved");
          }
        )
      );
      rows.push(
        toggleRow(
          "Attach last download",
          "Upload the last successful Aviary media download with the first post in an explicit crosspost.",
          integrations.crosspost.attachLastDownload,
          async (checked) => {
            integrations.crosspost.attachLastDownload = checked;
            await save(checked ? "Crosspost attachment on" : "Crosspost attachment off");
          }
        )
      );
      if (options.crosspost) {
        const threadRow = el("div", "av-row");
        const copy = el("span", "av-row-copy");
        copy.append(
          el("span", "av-row-label", "Crosspost as thread"),
          el("span", "av-row-description", "Split on blank lines and reply each segment to the previous one.")
        );
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        threadRow.append(copy, checkbox);
        rows.push(threadRow);
        rows.push(
          actionRow("Crosspost composer \u2192 Bluesky", "Uses the current composer text.", async () => {
            const result = await options.crosspost("bluesky", { asThread: checkbox.checked });
            setStatus(
              result.ok ? `Posted ${result.posts ?? 1} to Bluesky.${result.url ? ` ${result.url}` : ""}` : `Bluesky failed: ${result.error}`
            );
          })
        );
        rows.push(
          actionRow("Crosspost composer \u2192 Mastodon", "Uses the current composer text.", async () => {
            const result = await options.crosspost("mastodon", { asThread: checkbox.checked });
            setStatus(
              result.ok ? `Posted ${result.posts ?? 1} to Mastodon.${result.url ? ` ${result.url}` : ""}` : `Mastodon failed: ${result.error}`
            );
          })
        );
      }
      rows.push(
        toggleRow(
          "AI provider runs",
          "Let the AI command menu POST prompts to your configured provider.",
          integrations.ai.enabled,
          async (checked) => {
            integrations.ai.enabled = checked;
            await save(checked ? "AI runs on" : "AI runs off");
          }
        )
      );
      rows.push(
        selectRow(
          "AI provider",
          integrations.ai.provider,
          [
            ["anthropic", "Anthropic Messages API"],
            ["openai", "OpenAI Chat Completions"],
            ["openai-compatible", "OpenAI-compatible (LocalAI, Ollama proxy, \u2026)"]
          ],
          async (value) => {
            if (value === "anthropic" || value === "openai" || value === "openai-compatible") {
              integrations.ai.provider = value;
              await save(`AI provider set to ${value}`);
            }
          }
        )
      );
      rows.push(
        textInputRow(
          "AI endpoint (optional)",
          "Override the default endpoint for the chosen provider.",
          integrations.ai.endpoint,
          async (value) => {
            integrations.ai.endpoint = value;
            await save("AI endpoint saved");
          }
        )
      );
      rows.push(
        textInputRow(
          "AI model",
          "e.g. claude-sonnet-4-6, gpt-4o, llama3.1:8b",
          integrations.ai.model,
          async (value) => {
            integrations.ai.model = value;
            await save("AI model saved");
          }
        )
      );
      rows.push(
        secretInputRow(
          "AI API key",
          "Stored locally only. Aviary never sends this except as the auth header to your provider.",
          integrations.ai.apiKey,
          async (value) => {
            integrations.ai.apiKey = value;
            await save("AI API key saved");
          }
        )
      );
      rows.push(
        toggleRow(
          "Semantic search",
          "Embed CheckpointStore records via your provider for similarity search.",
          integrations.semanticSearch.enabled,
          async (checked) => {
            integrations.semanticSearch.enabled = checked;
            await save(checked ? "Semantic search on" : "Semantic search off");
          }
        )
      );
      rows.push(
        textInputRow(
          "Embedding endpoint",
          "POST endpoint that returns {data: [{embedding: number[]}]}",
          integrations.semanticSearch.endpoint,
          async (value) => {
            integrations.semanticSearch.endpoint = value;
            await save("Embedding endpoint saved");
          }
        )
      );
      rows.push(
        textInputRow(
          "Embedding model",
          "e.g. text-embedding-3-small",
          integrations.semanticSearch.model,
          async (value) => {
            integrations.semanticSearch.model = value;
            await save("Embedding model saved");
          }
        )
      );
      rows.push(
        secretInputRow(
          "Embedding API key",
          "Stored locally; used only as the Authorization header.",
          integrations.semanticSearch.apiKey,
          async (value) => {
            integrations.semanticSearch.apiKey = value;
            await save("Embedding API key saved");
          }
        )
      );
      rows.push(
        toggleRow(
          "Auto-embed every export",
          "After each export run, kick the embedding job in the background. Off by default.",
          integrations.semanticSearch.autoIndex,
          async (checked) => {
            integrations.semanticSearch.autoIndex = checked;
            await save(checked ? "Auto-embed on" : "Auto-embed off");
          }
        )
      );
      if (options.rebuildSemanticIndex) {
        rows.push(
          actionRow(
            "Rebuild semantic index",
            "Embed every captured record. Re-running is cheap because cached entries are skipped.",
            async () => {
              setStatus("Rebuilding semantic index\u2026");
              try {
                const result = await options.rebuildSemanticIndex();
                setStatus(
                  `Indexed: +${result.added} new \xB7 skipped ${result.skipped} \xB7 errors ${result.errors} \xB7 total ${result.total}.`
                );
              } catch (error) {
                options.onError("Embedding failed", error);
                setStatus("Embedding failed.");
              }
            }
          )
        );
      }
      if (options.semanticSearchQuery) {
        const row = el("div", "av-row av-row-stack");
        const copy = el("span", "av-row-copy");
        copy.append(
          el("span", "av-row-label", "Semantic search"),
          el("span", "av-row-description", "Vector similarity over captured records. Embeddings run on demand.")
        );
        const input = document.createElement("input");
        input.type = "search";
        input.placeholder = "Describe what you're looking for\u2026";
        input.className = "av-text-input";
        const results = el("div", "av-search-results");
        let pending;
        input.addEventListener("input", () => {
          if (pending !== void 0) clearTimeout(pending);
          pending = setTimeout(() => {
            void options.semanticSearchQuery(input.value.trim()).then((hits) => {
              results.replaceChildren();
              if (hits.length === 0) {
                results.append(el("div", "av-row-description", "No matches (or integration disabled)."));
                return;
              }
              for (const hit of hits) {
                const item = el("div", "av-search-hit");
                item.append(
                  el("span", "av-row-label", `@${hit.handle ?? "anon"} \xB7 ${hit.tweetId ?? "\u2014"} \xB7 score ${hit.score.toFixed(3)}`),
                  el("span", "av-row-description", hit.text.slice(0, 200))
                );
                results.append(item);
              }
            }).catch((error) => {
              options.onError("Semantic search failed", error);
            });
          }, 220);
        });
        row.append(copy, input, results);
        rows.push(row);
      }
      if (options.clearSemanticIndex) {
        rows.push(
          actionRow("Clear semantic index", "Forget every embedded record.", async () => {
            await options.clearSemanticIndex();
            await save("Semantic index cleared");
          })
        );
      }
      if (status2) {
        const lines = [
          `Aria2: ${status2.aria2.enabled ? "on" : "off"} \xB7 ${status2.aria2.configured ? "configured" : "missing endpoint"}`,
          `Bluesky: ${status2.bluesky.enabled ? "on" : "off"} \xB7 ${status2.bluesky.configured ? "configured" : "missing credentials"}`,
          `Mastodon: ${status2.mastodon.enabled ? "on" : "off"} \xB7 ${status2.mastodon.configured ? "configured" : "missing credentials"}`,
          `AI: ${status2.ai.enabled ? "on" : "off"} \xB7 ${status2.ai.configured ? "configured" : "missing key/model"}`,
          `Semantic: ${status2.semanticSearch.enabled ? "on" : "off"} \xB7 ${status2.semanticSearch.indexed} indexed`
        ];
        rows.push(dataRow("Integration status", lines.join(" \xB7 ")));
      }
      if (options.recentIntegrationErrors) {
        const errors = options.recentIntegrationErrors();
        if (errors.length === 0) {
          rows.push(readonlyRow("Recent integration errors", "None recorded."));
        } else {
          const row = el("div", "av-row av-row-stack");
          const copy = el("span", "av-row-copy");
          copy.append(
            el("span", "av-row-label", "Recent integration errors"),
            el("span", "av-row-description", "Drawn from the audit log; only failed integration calls show up.")
          );
          const list = el("div", "av-search-results");
          for (const error of errors.slice(0, 8)) {
            const item = el("div", "av-search-hit");
            item.append(
              el("span", "av-row-label", `${error.kind} \xB7 ${error.at}`),
              el("span", "av-row-description", error.message.slice(0, 200))
            );
            list.append(item);
          }
          row.append(copy, list);
          rows.push(row);
        }
      }
      return rows;
    };
    const libraryRows = () => {
      const rows = [];
      rows.push(
        toggleRow(
          "Unshorten t.co links",
          "Replace short `t.co` redirects with the destination from aria-labels and titles.",
          options.settings.links.expandTco,
          async (checked) => {
            options.settings.links.expandTco = checked;
            await save(checked ? "Unshorten on" : "Unshorten off");
          }
        )
      );
      rows.push(
        toggleRow(
          "Clean tracking from links",
          "Strips share tokens and campaign parameters (utm_*, fbclid, and X's own t/s) from links in the timeline, so what you copy is the plain address.",
          options.settings.links.cleanShareButtons,
          async (checked) => {
            options.settings.links.cleanShareButtons = checked;
            await save(checked ? "Link cleaning on" : "Link cleaning off");
          }
        )
      );
      if (options.getUserNotes && options.setUserNote) {
        const notes = options.getUserNotes();
        const serialized = Object.entries(notes).map(([handle, note]) => `${handle}: ${note}`).sort();
        rows.push(
          textareaRow(
            "Account notes",
            "Format: handle: note. One per line. Empty notes remove the entry.",
            serialized,
            async (lines) => {
              const seen = /* @__PURE__ */ new Set();
              for (const line of lines) {
                const match = /^@?([A-Za-z0-9_]{1,15})\s*[:\-]\s*(.*)$/.exec(line);
                if (!match) continue;
                const [, handle, note] = match;
                if (handle) {
                  seen.add(handle.toLowerCase());
                  await options.setUserNote(handle, note ?? "");
                }
              }
              for (const handle of Object.keys(notes)) {
                if (!seen.has(handle)) {
                  await options.setUserNote(handle, "");
                }
              }
              await save(`${seen.size} account note${seen.size === 1 ? "" : "s"} saved`);
            }
          )
        );
      }
      if (options.clearUserNotes) {
        rows.push(
          actionRow("Clear all account notes", "Drop every persisted note.", async () => {
            try {
              await options.clearUserNotes();
              await save("Account notes cleared");
            } catch (error) {
              options.onError("Could not clear account notes", error);
              setStatus("Could not clear notes.");
            }
          })
        );
      }
      rows.push(
        textareaRow(
          "Composer snippets",
          "One snippet per line. Reusable replies / templates (insertion landing in a later release).",
          options.settings.composer.snippets,
          async (lines) => {
            options.settings.composer.snippets = lines.map((line) => line.trim()).filter((line) => line.length > 0).slice(0, 100);
            await save(`${options.settings.composer.snippets.length} snippet${options.settings.composer.snippets.length === 1 ? "" : "s"} saved`);
          }
        )
      );
      return rows;
    };
    const backupRows = () => {
      const rows = [];
      if (options.exportSettings) {
        rows.push(
          actionRow("Export settings", "Downloads your preferences as JSON. API keys and passwords are replaced with a placeholder, so the file is safe to share; importing it here keeps the credentials already saved on this machine.", async () => {
            try {
              await options.exportSettings();
              setStatus("Settings exported.");
            } catch (error) {
              options.onError("Could not export settings", error);
              setStatus("Could not export settings.");
            }
          })
        );
      }
      if (options.importSettings) {
        rows.push(
          textareaRow(
            "Import settings (JSON)",
            "Paste a settings file exported from Aviary, then choose Import. Redacted credentials keep the values already saved here.",
            [],
            async (lines) => {
              const payload = lines.join("\n");
              try {
                const report = await options.importSettings(payload);
                if (report.applied) {
                  const [first, ...rest] = report.warnings;
                  const extra = rest.length > 0 ? ` (+${rest.length} more)` : "";
                  setStatus(first ? `Settings imported. ${first}${extra}` : "Settings imported.");
                } else {
                  setStatus(`Import failed: ${report.errors.join("; ")}`);
                }
              } catch (error) {
                options.onError("Could not import settings", error);
                setStatus("Could not import settings.");
              }
            },
            "Import"
          )
        );
      }
      if (options.getAuditSize) {
        rows.push(
          toggleRow(
            "Keep a local action log",
            "Records downloads, exports and settings changes on this device so you can review what Aviary did. Nothing is sent anywhere. Turning this off stops new entries immediately; existing ones stay until you clear them.",
            options.settings.privacy.auditLog,
            async (value) => {
              options.settings.privacy.auditLog = value;
              await save(value ? "Action log on" : "Action log off");
            }
          )
        );
        rows.push(dataRow("Audit entries", String(options.getAuditSize())));
      }
      if (options.clearAuditLog) {
        rows.push(
          actionRow("Clear audit log", "Drop the local action log.", async () => {
            try {
              await options.clearAuditLog();
              await save("Audit log cleared");
            } catch (error) {
              options.onError("Could not clear audit log", error);
              setStatus("Could not clear audit log.");
            }
          })
        );
      }
      return rows;
    };
    const exportRows = () => {
      const rows = [];
      rows.push(
        toggleRow(
          "Capture visible tweets",
          "Accumulate tweets visible on the active page for the next export run.",
          options.settings.export.enabled,
          async (checked) => {
            options.settings.export.enabled = checked;
            await save(checked ? "Export capture on" : "Export capture off");
          }
        )
      );
      rows.push(
        textInputRow(
          "Export formats",
          "Comma-separated list. Supported: json, csv, html, markdown, xlsx.",
          options.settings.export.formats.join(","),
          async (value) => {
            const parsed = value.split(/[\s,]+/).map((entry) => entry.trim().toLowerCase()).filter((entry) => entry.length > 0);
            const supported = /* @__PURE__ */ new Set(["json", "csv", "html", "markdown", "xlsx"]);
            options.settings.export.formats = parsed.filter((entry) => supported.has(entry));
            if (options.settings.export.formats.length === 0) {
              options.settings.export.formats = ["json"];
            }
            await save(`Export formats: ${options.settings.export.formats.join(", ")}`);
          }
        )
      );
      rows.push(
        toggleRow(
          "Preserve raw payloads",
          "Also store the raw GraphQL responses X sends this tab, so records can be re-parsed later. Session tokens are stripped before anything is written.",
          options.settings.export.preserveRawPayloads,
          async (checked) => {
            options.settings.export.preserveRawPayloads = checked;
            await save("Raw payload preference saved");
          }
        )
      );
      rows.push(
        toggleRow(
          "Auto-discover query IDs",
          "Scan loaded scripts for X GraphQL operation IDs and cache them locally.",
          options.settings.export.autoDiscoverQueryIds,
          async (checked) => {
            options.settings.export.autoDiscoverQueryIds = checked;
            await save("Query discovery preference saved");
          }
        )
      );
      rows.push(
        textInputRow(
          "Save folder hint",
          "Folder name (or path) used as the export ZIP root and download prefix.",
          options.settings.media.lastSaveFolder,
          async (value) => {
            options.settings.media.lastSaveFolder = value;
            await save("Save folder hint saved");
          }
        )
      );
      const status2 = options.getExportStatus?.();
      if (status2) {
        rows.push(
          dataRow(
            "Export status",
            `${status2.jobCount} jobs tracked \xB7 ${status2.knownQueries} GraphQL IDs cached`
          )
        );
      }
      if (options.runExport) {
        rows.push(
          actionRow("Export visible tweets", "Collect the currently rendered tweets and download a ZIP.", async () => {
            setStatus("Collecting visible posts\u2026");
            try {
              const result = await options.runExport();
              const files = result.files ?? 1;
              setStatus(
                result.records === 0 ? "No posts found on this view. Scroll the timeline to load some, then export again." : files > 1 ? `Exported ${result.records} records across ${files} ZIPs \u2192 ${result.filename}` : `Exported ${result.records} record${result.records === 1 ? "" : "s"} \u2192 ${result.filename}`
              );
            } catch (error) {
              options.onError("Export failed", error);
              setStatus("Export failed. See diagnostics.");
            }
          })
        );
      }
      if (options.copyDiagnostics) {
        rows.push(
          actionRow("Copy diagnostics", "Copy support diagnostics (version, route, recent log).", async () => {
            try {
              await options.copyDiagnostics();
              setStatus("Diagnostics copied to clipboard.");
            } catch (error) {
              options.onError("Could not copy diagnostics", error);
              setStatus("Could not copy diagnostics.");
            }
          })
        );
      }
      if (options.downloadWarc) {
        rows.push(
          actionRow(
            "Download as WARC",
            "Wrap captured records into an ISO-28500 WARC file for research / preservation tooling.",
            async () => {
              setStatus("Building WARC archive\u2026");
              try {
                const result = await options.downloadWarc();
                setStatus(`WARC downloaded (${result.records} records).`);
              } catch (error) {
                options.onError("WARC export failed", error);
                setStatus("WARC export failed.");
              }
            }
          )
        );
      }
      if (options.exportToTarget) {
        const targets = [
          { id: "clipboard-markdown", label: "Copy as Markdown", description: "Push a plain Markdown export onto the clipboard." },
          { id: "obsidian", label: "Save Obsidian Markdown", description: "Markdown with YAML frontmatter and Aviary tags." },
          { id: "notion", label: "Save Notion Markdown", description: "Heading-first Markdown that Notion imports cleanly." },
          { id: "raw-json", label: "Save records JSON", description: "Raw ExportRecord[] JSON without ZIP wrapping." }
        ];
        for (const target of targets) {
          rows.push(
            actionRow(target.label, target.description, async () => {
              try {
                const result = await options.exportToTarget(target.id);
                setStatus(
                  result.copied ? `Copied ${result.records} records to clipboard.` : `Exported ${result.records} records \u2192 ${target.label.toLowerCase()}.`
                );
              } catch (error) {
                options.onError("External export failed", error);
                setStatus("External export failed.");
              }
            })
          );
        }
      }
      if (options.getRetentionPolicy && options.saveRetentionPolicy) {
        rows.push(
          integerInputRow(
            "Records per ZIP",
            "Split a long export across several archives instead of one huge file (25-1000).",
            options.settings.media.zipChunkSize,
            async (value) => {
              options.settings.media.zipChunkSize = value;
              await save("Records per ZIP saved");
            }
          )
        );
        const policy = options.getRetentionPolicy();
        rows.push(
          integerInputRow(
            "Maximum export jobs",
            "Keep the newest jobs. Use 0 for unlimited.",
            policy.maxJobs,
            async (value) => {
              await options.saveRetentionPolicy({ ...options.getRetentionPolicy(), maxJobs: value });
              render();
              setStatus("Export job retention saved");
            }
          )
        );
        rows.push(
          integerInputRow(
            "Maximum records per job",
            "Keep the newest records in each job. Use 0 for unlimited.",
            policy.maxRecordsPerJob,
            async (value) => {
              await options.saveRetentionPolicy({ ...options.getRetentionPolicy(), maxRecordsPerJob: value });
              render();
              setStatus("Record retention saved");
            }
          )
        );
        rows.push(
          integerInputRow(
            "Maximum export age (days)",
            "Remove older jobs at boot. Use 0 to disable age-based cleanup.",
            policy.maxAgeDays,
            async (value) => {
              await options.saveRetentionPolicy({ ...options.getRetentionPolicy(), maxAgeDays: value });
              render();
              setStatus("Age-based retention saved");
            }
          )
        );
      }
      return rows;
    };
    const mediaRows = () => {
      const rows = [];
      rows.push(
        toggleRow(
          "Show download buttons",
          "Inject Save and Thumb buttons over tweet photos and video thumbnails.",
          options.settings.media.buttons,
          async (checked) => {
            options.settings.media.buttons = checked;
            await save(checked ? "Media buttons on" : "Media buttons off");
          }
        )
      );
      rows.push(
        toggleRow(
          "Prefer original quality",
          "Rewrite image URLs to name=orig before downloading.",
          options.settings.media.preferOriginalImages,
          async (checked) => {
            options.settings.media.preferOriginalImages = checked;
            await save("Original quality preference saved");
          }
        )
      );
      rows.push(
        textInputRow(
          "Filename template",
          "Fields: {handle}, {tweetId}, {mediaId}, {index}, {total}, {date}, {text}, {ext}.",
          options.settings.media.filenameTemplate,
          async (value) => {
            options.settings.media.filenameTemplate = value.length > 0 ? value : "{handle}_{tweetId}_{index}";
            await save("Filename template saved");
          }
        )
      );
      rows.push(
        toggleRow(
          "Duplicate history",
          "Skip downloads of media you have already saved from this browser.",
          options.settings.media.downloadHistory,
          async (checked) => {
            options.settings.media.downloadHistory = checked;
            await save(checked ? "Duplicate history on" : "Duplicate history off");
          }
        )
      );
      rows.push(
        selectRow(
          "Sensitive content",
          options.settings.media.sensitive,
          SENSITIVE_OPTIONS,
          async (value) => {
            options.settings.media.sensitive = coerceSensitive(value);
            await save("Sensitive content preference saved");
          }
        )
      );
      rows.push(
        selectRow(
          "Media layout",
          options.settings.media.layout,
          MEDIA_LAYOUT_OPTIONS,
          async (value) => {
            options.settings.media.layout = coerceLayout(value);
            await save("Media layout saved");
          }
        )
      );
      const status2 = options.getMediaStatus?.();
      if (status2) {
        rows.push(
          dataRow(
            "Download status",
            `${status2.running} running / ${status2.completed} done / ${status2.duplicate} dup / ${status2.failed} failed`
          )
        );
        rows.push(dataRow("History entries", String(status2.historySize)));
      }
      if (options.clearMediaHistory) {
        rows.push(
          actionRow("Clear download history", "Reset the local dedup index.", async () => {
            try {
              await options.clearMediaHistory?.();
              await save("History cleared");
            } catch (error) {
              options.onError("Could not clear download history", error);
              setStatus("Could not clear history.");
            }
          })
        );
      }
      if (options.runMediaBatch) {
        rows.push(
          actionRow(
            "Download all visible media",
            "Walks every tweet rendered on the current page and queues every photo/video/GIF/thumbnail through the existing download pipeline.",
            async () => {
              setStatus("Downloading media from this view\u2026");
              try {
                const result = await options.runMediaBatch();
                setStatus(
                  `Batch finished: ${result.downloaded} saved / ${result.duplicate} dup / ${result.failed} failed (of ${result.total}).`
                );
              } catch (error) {
                options.onError("Batch download failed", error);
                setStatus("Batch download failed.");
              }
            }
          )
        );
      }
      return rows;
    };
    const filterRows = () => {
      const rows = [];
      rows.push(
        toggleRow(
          "Enable filters",
          "Master switch for keyword, regex, premium, and media filters.",
          options.settings.filter.enabled,
          async (checked) => {
            options.settings.filter.enabled = checked;
            await save(checked ? "Filters enabled" : "Filters disabled");
          }
        )
      );
      rows.push(
        textareaRow(
          "Keyword rules",
          "One keyword or phrase per line. Case-insensitive substring match.",
          options.settings.filter.keywordRules,
          async (lines) => {
            options.settings.filter.keywordRules = lines.slice(0, 200);
            await save(`Saved ${options.settings.filter.keywordRules.length} keyword rules`);
          }
        )
      );
      rows.push(
        textareaRow(
          "Regex rules",
          "One pattern per line. Use /pattern/flags or a bare pattern (case-insensitive).",
          options.settings.filter.regexRules,
          async (lines) => {
            options.settings.filter.regexRules = lines.slice(0, 100);
            await save(`Saved ${options.settings.filter.regexRules.length} regex rules`);
          }
        )
      );
      rows.push(
        textareaRow(
          "Whitelist handles",
          "Handles (one per line, no @) that are never filtered.",
          options.settings.filter.whitelist,
          async (lines) => {
            options.settings.filter.whitelist = lines.map((line) => line.replace(/^@/, "").trim()).filter((line) => /^[A-Za-z0-9_]{1,15}$/.test(line)).slice(0, 200);
            await save(`Saved ${options.settings.filter.whitelist.length} whitelist handles`);
          }
        )
      );
      rows.push(
        selectRow(
          "Premium / verified posts",
          options.settings.filter.premiumRule,
          FILTER_ACTION_OPTIONS,
          async (value) => {
            options.settings.filter.premiumRule = coerceFilterAction(value);
            await save("Premium filter saved");
          }
        )
      );
      for (const key of FILTER_MEDIA_KEYS) {
        const label = FILTER_MEDIA_LABELS[key];
        const current = options.settings.filter.mediaTypes[key] === true;
        rows.push(
          toggleRow(
            `Hide posts with ${label.toLowerCase()}`,
            `Filter posts containing ${label.toLowerCase()}.`,
            current,
            async (checked) => {
              options.settings.filter.mediaTypes = {
                ...options.settings.filter.mediaTypes,
                [key]: checked
              };
              await save(`${label} filter ${checked ? "on" : "off"}`);
            }
          )
        );
      }
      rows.push(
        surfaceRow(
          "Active on",
          "Routes where filters run.",
          options.settings.filter.surfaces,
          async (next) => {
            options.settings.filter.surfaces = next;
            await save(
              next.length > 0 ? `Filters active on ${next.length} route${next.length === 1 ? "" : "s"}` : "Filters off on every route"
            );
          }
        )
      );
      rows.push(
        readonlyRow(
          "Blocked accounts / self-reposts",
          "Pending an authenticated fixture; controls stay disabled."
        )
      );
      return rows;
    };
    const hiddenPostRows = () => {
      const rows = [];
      rows.push(
        toggleRow(
          "Hide dismissed posts",
          "Keep posts you hid collapsed so the next post rises to the top.",
          options.settings.hidden.enabled,
          async (checked) => {
            options.settings.hidden.enabled = checked;
            await save(checked ? "Hidden posts applied" : "Hidden posts revealed");
          }
        )
      );
      rows.push(
        toggleRow(
          "Show hide buttons",
          "Adds a Hide control to every post next to the More menu.",
          options.settings.hidden.buttons,
          async (checked) => {
            options.settings.hidden.buttons = checked;
            await save(checked ? "Hide buttons on" : "Hide buttons off");
          }
        )
      );
      rows.push(
        surfaceRow(
          "Active on",
          "Routes where hiding and the Hide button apply.",
          options.settings.hidden.surfaces,
          async (next) => {
            options.settings.hidden.surfaces = next;
            await save(
              next.length > 0 ? `Hiding active on ${next.length} route${next.length === 1 ? "" : "s"}` : "Hiding off on every route"
            );
          }
        )
      );
      rows.push(
        integerInputRow(
          "Maximum remembered posts",
          "Oldest entries are dropped once the store passes this size (100-50000).",
          options.settings.hidden.maxEntries,
          async (value) => {
            options.settings.hidden.maxEntries = value;
            await save(`Hidden post limit set to ${options.settings.hidden.maxEntries}`);
          }
        )
      );
      const status2 = options.getHiddenPostsStatus?.();
      if (!status2) {
        rows.push(readonlyRow("Hidden posts", "Hidden post store unavailable in this build."));
        return rows;
      }
      rows.push(
        dataRow(
          "Hidden posts stored",
          `${status2.total}${status2.updatedAt ? ` \xB7 updated ${status2.updatedAt}` : ""}`
        )
      );
      if (options.undoLastHide) {
        rows.push(
          actionRow("Undo last hide", "Restores the most recently hidden post.", async () => {
            try {
              const result = await options.undoLastHide();
              setStatus(
                result.restored ? `Restored ${result.handle ? `@${result.handle}` : "the last hidden post"}.` : "Nothing left to restore."
              );
              render();
            } catch (error) {
              options.onError("Could not undo the last hide", error);
              setStatus("Could not undo the last hide.");
            }
          })
        );
      }
      for (const entry of status2.recent) {
        const row = el("div", "av-row av-row-stack");
        const copy = el("span", "av-row-copy");
        copy.append(
          el("span", "av-row-label", entry.handle ? `@${entry.handle}` : "Unknown account"),
          el(
            "span",
            "av-row-description",
            `${entry.hiddenAt} \u2014 ${entry.text.length > 0 ? entry.text : "(no text)"}`
          )
        );
        const restore = el("button", "av-button av-button-secondary", t("Restore"));
        restore.type = "button";
        restore.addEventListener("click", () => {
          restore.disabled = true;
          void options.unhidePost?.(entry.key).then((restored) => {
            setStatus(restored ? "Post restored." : "That post was already restored.");
            render();
          }).catch((error) => {
            options.onError("Could not restore the post", error);
            setStatus("Could not restore the post.");
            restore.disabled = false;
          });
        });
        row.append(copy, restore);
        rows.push(row);
      }
      if (options.clearHiddenPosts && status2.total > 0) {
        rows.push(
          actionRow(
            "Clear hidden posts",
            "Forgets every hidden post and brings them all back.",
            async () => {
              try {
                const removed = await options.clearHiddenPosts();
                setStatus(`Cleared ${removed} hidden post${removed === 1 ? "" : "s"}.`);
                render();
              } catch (error) {
                options.onError("Could not clear hidden posts", error);
                setStatus("Could not clear hidden posts.");
              }
            }
          )
        );
      }
      return rows;
    };
    const save = async (message) => {
      setStatus("Saving...");
      try {
        await options.onChange();
        render();
        setStatus(message);
      } catch (error) {
        options.onError("Control Center could not save settings", error);
        setStatus("Could not save settings. Try again.");
      }
    };
    const coverageRow = () => {
      const row = dataRow("Panel language", "");
      row.classList.add(COVERAGE_ROW_CLASS);
      return row;
    };
    const coverageSummary = () => {
      const label = options.listLocales?.().find((entry) => entry.code === panelLocale)?.label ?? panelLocale;
      if (renderedStrings === 0) {
        return label;
      }
      const percent = Math.round(translatedStrings / renderedStrings * 100);
      if (translatedStrings === renderedStrings) {
        return `${label} \u2014 every panel string translated (${renderedStrings}).`;
      }
      return `${label} \u2014 ${translatedStrings} of ${renderedStrings} panel strings translated (${percent}%). The rest fall back to English.`;
    };
    const storageHealthRow = () => {
      const failures = options.diagnostics().filter((event) => event.level === "error" && event.message.includes("failed to save"));
      if (failures.length === 0) {
        return readonlyRow("Saving", "Working \u2014 every change has been written.");
      }
      const last = failures[failures.length - 1]?.message ?? "";
      return dataRow(
        "Saving",
        `${t("Some changes could not be saved \u2014 the browser store may be full.")} ${last} (${failures.length})`
      );
    };
    const selectorSummary = () => {
      const last = [...options.diagnostics()].reverse().find((event) => event.message.includes("Selector"));
      return last?.message ?? "Monitoring active";
    };
    launcher.addEventListener("click", () => setOpen(!open));
    close.addEventListener("click", () => setOpen(false));
    search.addEventListener("input", () => {
      searchQuery = search.value;
      render();
    });
    render();
    return {
      destroy() {
        host.remove();
      },
      refresh() {
        if (!open || isBusy()) {
          dirtyWhileBusy = true;
          return;
        }
        render();
      }
    };
  }
  var FOCUSABLE_SELECTOR = "button, input, select, textarea, a[href], [tabindex]:not([tabindex='-1'])";
  var COVERAGE_ROW_CLASS = "av-locale-coverage";
  var panelLocale = "en";
  var seenStrings = /* @__PURE__ */ new Set();
  var renderedStrings = 0;
  var translatedStrings = 0;
  function resetCoverageTally() {
    seenStrings.clear();
    renderedStrings = 0;
    translatedStrings = 0;
  }
  function t(text) {
    if (text.length > 0 && !seenStrings.has(text)) {
      seenStrings.add(text);
      renderedStrings += 1;
      if (hasTranslation(panelLocale, text)) {
        translatedStrings += 1;
      }
    }
    return translateText(panelLocale, text);
  }
  function captureSelection(node) {
    if (!isTextField(node)) {
      return null;
    }
    return { start: node.selectionStart, end: node.selectionEnd };
  }
  function restoreSelection(node, selection) {
    if (!selection || !isTextField(node) || selection.start === null || selection.end === null) {
      return;
    }
    try {
      node.setSelectionRange(selection.start, selection.end);
    } catch {
    }
  }
  function isTextField(node) {
    if (node instanceof HTMLTextAreaElement) {
      return true;
    }
    return node instanceof HTMLInputElement && node.type !== "checkbox" && node.type !== "radio";
  }
  function positionalPath(root, node) {
    const steps = [];
    let current = node;
    while (current && current !== root) {
      const parent = current.parentElement;
      if (!parent) break;
      steps.unshift(Array.prototype.indexOf.call(parent.children, current));
      current = parent;
    }
    return steps.join(".");
  }
  function prefersReducedMotion(settings) {
    if (settings.accessibility.reduceMotion === "always") return true;
    if (settings.accessibility.reduceMotion === "never") return false;
    return globalThis.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  }
  function section(title, rows) {
    const node = el("section", "av-section");
    node.append(el("h3", "av-section-title", t(title)), ...rows);
    return node;
  }
  function toggleRow(label, description, checked, onChange) {
    const row = el("label", "av-row");
    const copy = el("span", "av-row-copy");
    copy.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(description)));
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = checked;
    input.addEventListener("change", () => {
      void onChange(input.checked);
    });
    row.append(copy, input);
    return row;
  }
  function selectRow(label, value, options, onChange, description, translateOptions = true) {
    const row = el("label", "av-row");
    if (description) {
      const copy = el("span", "av-row-copy");
      copy.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(description)));
      row.append(copy);
    } else {
      row.append(el("span", "av-row-label", t(label)));
    }
    const select = document.createElement("select");
    select.className = "av-select";
    for (const [optionValue, optionLabel] of options) {
      const option = document.createElement("option");
      option.value = optionValue;
      option.textContent = translateOptions ? t(optionLabel) : optionLabel;
      option.selected = optionValue === value;
      select.append(option);
    }
    select.addEventListener("change", () => {
      void onChange(select.value);
    });
    row.append(select);
    return row;
  }
  function readonlyRow(label, value) {
    const row = el("div", "av-row av-row-readonly");
    row.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(value)));
    return row;
  }
  function dataRow(label, value) {
    const row = el("div", "av-row av-row-readonly");
    row.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", value));
    return row;
  }
  function textInputRow(label, description, value, onChange) {
    const row = el("div", "av-row av-row-stack");
    const copy = el("span", "av-row-copy");
    copy.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(description)));
    row.append(copy);
    const input = document.createElement("input");
    input.type = "text";
    input.className = "av-text-input";
    input.value = value;
    input.spellcheck = false;
    input.setAttribute("aria-label", t(label));
    const apply = el("button", "av-button av-button-secondary", t("Save"));
    apply.type = "button";
    apply.addEventListener("click", () => {
      void onChange(input.value.trim());
    });
    row.append(input, apply);
    return row;
  }
  function secretInputRow(label, description, value, onChange) {
    const row = el("div", "av-row av-row-stack");
    const copy = el("span", "av-row-copy");
    copy.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(description)));
    row.append(copy);
    const input = document.createElement("input");
    input.type = "password";
    input.className = "av-text-input";
    input.value = value;
    input.spellcheck = false;
    input.autocomplete = "off";
    input.setAttribute("aria-label", t(label));
    const controls = el("div", "av-inline-controls");
    const reveal2 = el("button", "av-button av-button-secondary", t("Show"));
    reveal2.type = "button";
    reveal2.setAttribute("aria-label", `${t("Show")} ${t(label)}`);
    reveal2.setAttribute("aria-pressed", "false");
    reveal2.addEventListener("click", () => {
      const masked = input.type === "password";
      input.type = masked ? "text" : "password";
      reveal2.textContent = masked ? t("Hide") : t("Show");
      reveal2.setAttribute("aria-pressed", String(masked));
      reveal2.setAttribute("aria-label", `${masked ? t("Hide") : t("Show")} ${t(label)}`);
    });
    const apply = el("button", "av-button av-button-secondary", t("Save"));
    apply.type = "button";
    apply.addEventListener("click", () => {
      void onChange(input.value.trim());
    });
    controls.append(reveal2, apply);
    row.append(input, controls);
    return row;
  }
  function integerInputRow(label, description, value, onChange) {
    const row = el("div", "av-row av-row-stack");
    const copy = el("span", "av-row-copy");
    copy.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(description)));
    row.append(copy);
    const input = document.createElement("input");
    input.type = "number";
    input.min = "0";
    input.step = "1";
    input.className = "av-text-input";
    input.value = String(value);
    input.setAttribute("aria-label", t(label));
    const apply = el("button", "av-button av-button-secondary", t("Save"));
    apply.type = "button";
    apply.addEventListener("click", () => {
      const parsed = Number.parseInt(input.value, 10);
      void onChange(Number.isFinite(parsed) ? parsed : 0);
    });
    row.append(input, apply);
    return row;
  }
  function actionRow(label, description, onClick) {
    const row = el("div", "av-row");
    const copy = el("span", "av-row-copy");
    copy.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(description)));
    row.append(copy);
    const button2 = el("button", "av-button av-button-secondary", t(label));
    button2.type = "button";
    button2.addEventListener("click", () => {
      button2.disabled = true;
      void onClick().finally(() => {
        button2.disabled = false;
      });
    });
    row.append(button2);
    return row;
  }
  function textareaRow(label, description, lines, onChange, actionLabel = "Save list") {
    const row = el("div", "av-row av-row-stack");
    const copy = el("span", "av-row-copy");
    copy.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(description)));
    row.append(copy);
    const textarea = document.createElement("textarea");
    textarea.className = "av-textarea";
    textarea.value = lines.join("\n");
    textarea.spellcheck = false;
    textarea.rows = 4;
    textarea.setAttribute("aria-label", t(label));
    const apply = el("button", "av-button av-button-secondary", t(actionLabel));
    apply.type = "button";
    apply.addEventListener("click", () => {
      const next = textarea.value.split(/\r?\n/).map((line) => line.trim()).filter((line, index, array) => line.length > 0 && array.indexOf(line) === index);
      void onChange(next);
    });
    row.append(textarea, apply);
    return row;
  }
  function surfaceRow(label, description, selected, onChange) {
    const row = el("div", "av-row av-row-stack");
    const copy = el("span", "av-row-copy");
    copy.append(el("span", "av-row-label", t(label)), el("span", "av-row-description", t(description)));
    row.append(copy);
    const group = el("div", "av-chip-group");
    group.setAttribute("role", "group");
    group.setAttribute("aria-label", t(label));
    const state = new Set(selected);
    for (const surface of FILTER_SURFACES) {
      const chip = document.createElement("label");
      chip.className = "av-chip";
      const input = document.createElement("input");
      input.type = "checkbox";
      input.checked = state.has(surface);
      input.value = surface;
      input.addEventListener("change", () => {
        if (input.checked) {
          state.add(surface);
        } else {
          state.delete(surface);
        }
        void onChange(FILTER_SURFACES.filter((value) => state.has(value)));
      });
      const text = el("span", "av-chip-label", t(FILTER_SURFACE_LABELS[surface]));
      chip.append(input, text);
      group.append(chip);
    }
    row.append(group);
    return row;
  }
  function coerceReduceMotion(value) {
    return value === "always" || value === "never" ? value : "system";
  }
  function coerceFilterAction(value) {
    return value === "hide" || value === "dim" ? value : "off";
  }
  function coerceSensitive(value) {
    return value === "reveal" || value === "blur" || value === "hide" ? value : "default";
  }
  function coerceLayout(value) {
    return value === "stacked" || value === "grid" ? value : "default";
  }
  function button(label, className) {
    const node = document.createElement("button");
    node.className = className;
    node.textContent = t(label);
    return node;
  }
  function el(tag, className, text) {
    const node = document.createElement(tag);
    node.className = className;
    if (text !== void 0) {
      node.textContent = text;
    }
    return node;
  }
  var CONTROL_CENTER_CSS = `
:host {
  color-scheme: dark;
  font-family: TwitterChirp, Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.av-shell {
  position: fixed;
  inset: 0;
  z-index: 2147482600;
  pointer-events: none;
}

.av-launcher {
  position: fixed;
  right: 18px;
  bottom: 18px;
  min-width: 78px;
  min-height: 42px;
  border: 1px solid color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 70%, transparent);
  border-radius: 8px;
  /* Follows the active theme's accent \u2014 this was pinned to X blue in every theme. */
  background: linear-gradient(
    180deg,
    color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 22%, transparent),
    color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 12%, transparent)
  );
  color: var(--av-text, rgb(239, 243, 244));
  box-shadow: 0 12px 34px rgba(0, 0, 0, 0.42);
  cursor: pointer;
  font: 700 13px/1.1 inherit;
  letter-spacing: 0;
  pointer-events: auto;
  transition: transform 140ms ease, border-color 140ms ease, background 140ms ease;
}

.av-launcher:hover {
  transform: translateY(-1px);
  border-color: var(--av-accent, rgb(29, 155, 240));
}

.av-launcher:focus-visible,
.av-button:focus-visible,
.av-select:focus-visible,
input:focus-visible {
  outline: 2px solid var(--av-accent, rgb(29, 155, 240));
  outline-offset: 3px;
}

.av-overlay {
  position: fixed;
  inset: 0;
  display: grid;
  justify-content: end;
  align-items: end;
  padding: 72px 18px 72px;
  opacity: 0;
  pointer-events: none;
  /* Belt and braces with [inert]: keeps the closed panel out of the tab order even where
     inert is unsupported. Delayed so the fade-out still runs. */
  visibility: hidden;
  transform: translateY(8px);
  transition: opacity 160ms ease, transform 160ms ease, visibility 0s linear 160ms;
}

.av-overlay.is-open {
  opacity: 1;
  pointer-events: none;
  visibility: visible;
  transform: translateY(0);
  transition: opacity 160ms ease, transform 160ms ease, visibility 0s;
}

.av-panel {
  /* Was 386px for all twelve sections stacked in one column. The rail needs room beside the
     content, and the content itself reads badly at ~350px once descriptions wrap to four
     lines. */
  width: min(780px, calc(100vw - 36px));
  max-height: min(720px, calc(100vh - 96px));
  overflow: hidden;
  display: flex;
  flex-direction: column;
  border: 1px solid var(--av-border, rgb(47, 51, 54));
  border-radius: 12px;
  background: color-mix(in srgb, var(--av-surface, rgb(15, 20, 25)) 96%, black);
  box-shadow: 0 22px 70px rgba(0, 0, 0, 0.58);
  pointer-events: auto;
}

/* The panel takes focus when it opens; the UA default paints a hard white halo around the
   whole dialog. Keep the indicator, make it read as a highlighted edge instead. */
.av-panel:focus-visible {
  outline: 2px solid color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 70%, transparent);
  outline-offset: -2px;
}

.av-panel-header {
  display: flex;
  align-items: start;
  justify-content: space-between;
  gap: 16px;
  padding: 18px 18px 14px;
  border-bottom: 1px solid var(--av-border, rgb(47, 51, 54));
}

.av-title {
  margin: 0;
  color: var(--av-text, rgb(239, 243, 244));
  font-size: 18px;
  line-height: 1.25;
}

.av-subtitle {
  margin: 4px 0 0;
  color: var(--av-muted, rgb(113, 118, 123));
  font-size: 13px;
  line-height: 1.35;
}

.av-button,
.av-select {
  min-height: 34px;
  border: 1px solid var(--av-border, rgb(47, 51, 54));
  border-radius: 8px;
  background: var(--av-surface-raised, rgb(22, 24, 28));
  color: var(--av-text, rgb(239, 243, 244));
  font: 650 13px/1.2 inherit;
}

.av-button {
  padding: 0 12px;
  cursor: pointer;
}

.av-searchbar {
  padding: 12px 18px;
  border-bottom: 1px solid var(--av-border, rgb(47, 51, 54));
}

.av-search-input {
  width: 100%;
  height: 36px;
  padding: 0 12px;
  border: 1px solid var(--av-border, rgb(47, 51, 54));
  border-radius: 8px;
  background: var(--av-surface, rgb(15, 20, 25));
  color: var(--av-text, rgb(239, 243, 244));
  font: 13px/1.4 inherit;
}

.av-search-input::placeholder {
  color: var(--av-muted, rgb(113, 118, 123));
}

/* Two panes: a fixed rail and a scrolling content column. Each scrolls independently, so
   moving through a long section never scrolls the section list out of reach. */
.av-panel-body {
  display: grid;
  grid-template-columns: 196px minmax(0, 1fr);
  min-height: 0;
  flex: 1;
  overflow: hidden;
}

.av-nav {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 12px 8px;
  overflow-y: auto;
  border-right: 1px solid var(--av-border, rgb(47, 51, 54));
}

.av-nav-group {
  /* The rail is sized so all twelve sections fit without scrolling at the default panel
     height; a sliced-in-half last item reads as a rendering bug rather than as "more below". */
  margin: 6px 0 2px;
  padding: 0 8px;
  color: var(--av-muted, rgb(113, 118, 123));
  font-size: 10px;
  font-weight: 800;
  line-height: 1.2;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}

.av-nav-group:first-child {
  margin-top: 0;
}

.av-nav-item {
  min-height: 32px;
  padding: 0 10px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: var(--av-muted, rgb(113, 118, 123));
  font: 600 13px/1.2 inherit;
  text-align: left;
  cursor: pointer;
}

.av-nav-item:hover {
  background: var(--av-surface-raised, rgb(22, 24, 28));
  color: var(--av-text, rgb(239, 243, 244));
}

.av-nav-item.is-active {
  border-color: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 45%, transparent);
  background: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 16%, transparent);
  color: var(--av-text, rgb(239, 243, 244));
}

.av-content {
  display: grid;
  align-content: start;
  gap: 14px;
  padding: 16px;
  overflow-y: auto;
  min-height: 0;
}

.av-empty {
  display: grid;
  gap: 6px;
  padding: 24px 4px;
}

.av-empty-title {
  margin: 0;
  color: var(--av-text, rgb(239, 243, 244));
  font-size: 14px;
}

.av-empty-hint {
  margin: 0;
  color: var(--av-muted, rgb(113, 118, 123));
  font-size: 13px;
  line-height: 1.4;
}

.av-section {
  display: grid;
  gap: 8px;
}

.av-section-title {
  margin: 0;
  color: var(--av-muted, rgb(113, 118, 123));
  font-size: 11px;
  font-weight: 800;
  line-height: 1.2;
  text-transform: uppercase;
}

.av-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  min-height: 48px;
  padding: 10px 12px;
  /* The border token alone sits near 1.4:1 against the row fill, which reads as no border at
     all across ~100 rows. Lifted toward the text token so grouping is actually visible. */
  border: 1px solid color-mix(in srgb, var(--av-border, rgb(47, 51, 54)), var(--av-text, rgb(239, 243, 244)) 18%);
  border-radius: 10px;
  background: color-mix(in srgb, var(--av-surface-raised, rgb(22, 24, 28)) 62%, transparent);
}

.av-row-stack {
  flex-direction: column;
  align-items: stretch;
  gap: 8px;
}

/* Text fields and textareas want the full row width; an action button does not. At the old
   386px panel a stretched button looked deliberate \u2014 at 780px it reads as a banner. */
.av-row-stack > .av-button {
  align-self: start;
  width: auto;
  min-width: 132px;
}

.av-textarea,
.av-text-input {
  width: 100%;
  padding: 8px 10px;
  border: 1px solid var(--av-border, rgb(47, 51, 54));
  border-radius: 8px;
  background: var(--av-surface, rgb(15, 20, 25));
  color: var(--av-text, rgb(239, 243, 244));
  font: 12px/1.4 ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
}

.av-textarea {
  min-height: 96px;
  resize: vertical;
}

.av-text-input {
  height: 34px;
}

.av-file-input {
  width: 100%;
  color: var(--av-text, rgb(239, 243, 244));
  font: 12px/1.4 ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
}

.av-search-results {
  display: grid;
  gap: 6px;
  max-height: 220px;
  overflow: auto;
}

.av-search-hit {
  display: grid;
  gap: 2px;
  padding: 6px 8px;
  border: 1px solid color-mix(in srgb, var(--av-border, rgb(47, 51, 54)) 70%, transparent);
  border-radius: 8px;
  background: color-mix(in srgb, var(--av-surface, rgb(15, 20, 25)) 70%, transparent);
}

.av-textarea:focus-visible {
  outline: 2px solid var(--av-accent, rgb(29, 155, 240));
  outline-offset: 2px;
}

.av-chip-group {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.av-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 30px;
  padding: 4px 10px;
  border: 1px solid var(--av-border, rgb(47, 51, 54));
  border-radius: 6px;
  background: color-mix(in srgb, var(--av-surface-raised, rgb(22, 24, 28)) 70%, transparent);
  color: var(--av-text, rgb(239, 243, 244));
  cursor: pointer;
  font-size: 12px;
  line-height: 1.2;
}

.av-chip input[type="checkbox"] {
  width: 14px;
  height: 14px;
}

.av-chip-label {
  font-weight: 650;
}

.av-row-copy {
  display: grid;
  gap: 3px;
}

.av-inline-controls {
  display: flex;
  gap: 8px;
}

.av-inline-controls .av-button {
  flex: 1 1 auto;
}

.av-row-label {
  color: var(--av-text, rgb(239, 243, 244));
  font-size: 13px;
  font-weight: 720;
  line-height: 1.25;
}

.av-row-description {
  color: var(--av-muted, rgb(113, 118, 123));
  font-size: 12px;
  line-height: 1.35;
}

input[type="checkbox"] {
  width: 18px;
  height: 18px;
  accent-color: var(--av-accent, rgb(29, 155, 240));
}

.av-select {
  max-width: 150px;
  padding: 0 10px;
}

.av-status {
  min-height: 35px;
  padding: 10px 16px 14px;
  border-top: 1px solid var(--av-border, rgb(47, 51, 54));
  color: var(--av-muted, rgb(113, 118, 123));
  font-size: 12px;
  line-height: 1.3;
}

/* Touch and viewport rules must live in this stylesheet: a sheet in document.head cannot
   reach into the shadow root, so the page-level av-touch / av-mobile classes never styled
   these controls. Media queries evaluate against the viewport and do work here. */
@media (pointer: coarse) {
  .av-row {
    min-height: 56px;
  }

  .av-button,
  .av-select {
    min-height: 44px;
  }

  .av-chip {
    min-height: 44px;
  }

  .av-text-input {
    height: 44px;
  }

  input[type="checkbox"] {
    width: 24px;
    height: 24px;
  }

  .av-chip input[type="checkbox"] {
    width: 18px;
    height: 18px;
  }
}

@media (max-width: 760px) {
  .av-launcher {
    right: 12px;
    bottom: 12px;
    min-width: 92px;
    min-height: 48px;
  }

  .av-overlay {
    padding: 16px 8px 84px;
  }

  .av-panel {
    width: min(420px, calc(100vw - 16px));
    max-height: min(85vh, calc(100vh - 64px));
  }

  /* No room for a side rail. It becomes a horizontal strip of chips above the content, which
     keeps every section one tap away instead of hiding them behind a menu. */
  .av-panel-body {
    grid-template-columns: minmax(0, 1fr);
    grid-template-rows: auto minmax(0, 1fr);
  }

  .av-nav {
    flex-direction: row;
    gap: 6px;
    padding: 10px 12px;
    overflow-x: auto;
    overflow-y: hidden;
    border-right: 0;
    border-bottom: 1px solid var(--av-border, rgb(47, 51, 54));
  }

  .av-nav-item {
    flex: 0 0 auto;
    min-height: 44px;
  }

  /* The group headings only make sense stacked; the chip order still follows them. */
  .av-nav-group {
    display: none;
  }
}

@media (prefers-reduced-motion: reduce) {
  .av-launcher,
  .av-overlay {
    transition: none;
  }
}

/* The reduceMotion setting can force reduction with no OS preference set, and a page-level
   class cannot cross into this shadow tree \u2014 the host carries the state instead. */
:host([data-av-motion="reduce"]) .av-launcher,
:host([data-av-motion="reduce"]) .av-launcher:hover,
:host([data-av-motion="reduce"]) .av-overlay {
  transition: none;
  transform: none;
}
`;

  // src/features/core/presets.ts
  var PRESETS = [
    {
      id: "quiet-reader",
      label: "Quiet Reader",
      description: "Hide trends and row borders, dim premium posts, strip t.co, dense + dim theme.",
      overrides: {
        appearance: { theme: "dim", denseMode: true, hideCounts: true, hideBorders: true },
        layout: { hideRightSidebar: true, hideTrends: true, hideGrok: true },
        filter: { enabled: true, premiumRule: "dim" },
        links: { expandTco: true, cleanShareButtons: true }
      }
    },
    {
      id: "media-archivist",
      label: "Media Archivist",
      description: "Original-quality downloads, deterministic filenames, dedup history, sensitive blur.",
      overrides: {
        appearance: { theme: "lightsOut" },
        media: {
          buttons: true,
          preferOriginalImages: true,
          downloadHistory: true,
          sensitive: "blur",
          layout: "stacked"
        },
        filter: { enabled: false }
      }
    },
    {
      id: "creator",
      label: "Creator",
      description: "Writer mode, composer snippets, share-button cleanup, sidebar and trends hidden.",
      overrides: {
        appearance: { theme: "midnight" },
        layout: { hideRightSidebar: true, hideTrends: true, hideGrok: true, writerMode: true },
        media: { layout: "grid" },
        links: { cleanShareButtons: true, expandTco: true }
      }
    },
    {
      id: "researcher",
      label: "Researcher",
      description: "Export capture on, JSON+CSV+HTML+MD formats, auto-discover query IDs, raw payloads.",
      overrides: {
        filter: { enabled: false },
        export: {
          enabled: true,
          formats: ["json", "csv", "html", "markdown"],
          preserveRawPayloads: true,
          autoDiscoverQueryIds: true
        },
        media: { sensitive: "default", layout: "default" },
        links: { cleanShareButtons: true }
      }
    },
    {
      id: "classic",
      label: "Classic",
      description: "Restore dim, keep sidebar, hide Grok only, no premium filtering.",
      overrides: {
        appearance: { theme: "dim", denseMode: false },
        layout: {
          hideRightSidebar: false,
          hideTrends: false,
          hideGrok: true
        },
        filter: { enabled: false, premiumRule: "off" }
      }
    },
    {
      id: "minimal",
      label: "Minimal",
      description: "Maximum declutter: no counts, no borders, no trends, big text safe zones.",
      overrides: {
        appearance: { theme: "lightsOut", denseMode: false, hideCounts: true, hideBorders: true },
        layout: { hideRightSidebar: true, hideTrends: true, hideGrok: true },
        filter: { enabled: true, premiumRule: "hide" },
        accessibility: { reduceMotion: "always" }
      }
    }
  ];
  function listPresets() {
    return PRESETS.map((preset) => ({ ...preset, overrides: cloneOverrides(preset.overrides) }));
  }
  function getPreset(id) {
    return listPresets().find((preset) => preset.id === id);
  }
  function applyPreset(current, preset) {
    const next = cloneSettings(current);
    for (const [section2, overrides] of Object.entries(preset.overrides)) {
      if (!overrides) continue;
      const target = next[section2];
      if (!target) continue;
      for (const [key, value] of Object.entries(overrides)) {
        target[key] = value;
      }
    }
    return normalizeSettings(next);
  }
  function describePresetDelta(current, preset) {
    const result = [];
    const next = applyPreset(current, preset);
    for (const section2 of Object.keys(preset.overrides)) {
      const currentSection = current[section2] ?? {};
      const nextSection = next[section2] ?? {};
      for (const key of Object.keys(preset.overrides[section2] ?? {})) {
        const before = JSON.stringify(currentSection[key]);
        const after = JSON.stringify(nextSection[key]);
        if (before !== after) {
          result.push(`${section2}.${key}: ${before} \u2192 ${after}`);
        }
      }
    }
    return result;
  }
  function cloneOverrides(overrides) {
    return JSON.parse(JSON.stringify(overrides));
  }

  // src/features/integrations/network-policy.ts
  var LocalOnlyError = class extends Error {
    constructor(what) {
      super(
        `${what} was blocked: Aviary is in local-only mode. Turn off "Local-only mode" in Trust to let configured integrations reach the network.`
      );
      this.name = "LocalOnlyError";
    }
  };
  var localOnly = () => false;
  function setLocalOnlyPolicy(predicate) {
    localOnly = predicate;
  }
  function assertOutboundAllowed(what) {
    if (localOnly()) {
      throw new LocalOnlyError(what);
    }
  }

  // src/features/integrations/semantic-search.ts
  var SEMANTIC_INDEX_KEY = "aviary.semanticIndex.v1";
  var EMPTY = { entries: [], model: "" };
  var SemanticIndex = class {
    #storage;
    #state = EMPTY;
    #loaded = false;
    constructor(storage) {
      this.#storage = storage;
    }
    async load() {
      if (this.#loaded) return;
      const stored = await this.#storage.get(SEMANTIC_INDEX_KEY, EMPTY);
      this.#state = {
        entries: Array.isArray(stored?.entries) ? stored.entries.filter(isEntry) : [],
        model: typeof stored?.model === "string" ? stored.model : ""
      };
      this.#loaded = true;
    }
    size() {
      return this.#state.entries.length;
    }
    model() {
      return this.#state.model;
    }
    async embedAndIndex(config, records) {
      if (!config.enabled || !config.endpoint || !config.apiKey || !config.model) {
        return { added: 0, skipped: records.length, errors: 0 };
      }
      await this.load();
      if (this.#state.model && this.#state.model !== config.model) {
        this.#state = { entries: [], model: config.model };
      } else {
        this.#state.model = config.model;
      }
      const known = new Set(this.#state.entries.map((entry) => entry.id));
      let added = 0;
      let skipped = 0;
      let errors = 0;
      for (const record of records) {
        const id = `${record.tweetId ?? "no-id"}:${(record.text || "").slice(0, 80)}`;
        if (known.has(id) || record.text.length === 0) {
          skipped += 1;
          continue;
        }
        const vector = await fetchEmbedding(config, record.text);
        if (!vector) {
          errors += 1;
          continue;
        }
        this.#state.entries.push({
          id,
          tweetId: record.tweetId,
          handle: record.handle,
          text: record.text,
          vector,
          embeddedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        known.add(id);
        added += 1;
      }
      await this.#persist();
      return { added, skipped, errors };
    }
    async search(config, query, limit = 10) {
      if (!config.enabled || !config.endpoint || !config.apiKey || !config.model || query.trim().length === 0) {
        return [];
      }
      await this.load();
      if (this.#state.entries.length === 0) return [];
      const queryVector = await fetchEmbedding(config, query);
      if (!queryVector) return [];
      const hits = this.#state.entries.map((entry) => ({ entry, score: cosineSimilarity(queryVector, entry.vector) })).sort((a, b) => b.score - a.score).slice(0, limit);
      return hits;
    }
    async clear() {
      this.#state = { entries: [], model: this.#state.model };
      this.#loaded = true;
      await this.#persist();
    }
    async #persist() {
      try {
        await this.#storage.set(SEMANTIC_INDEX_KEY, this.#state);
      } catch {
      }
    }
  };
  async function fetchEmbedding(config, text) {
    assertOutboundAllowed("Embedding");
    try {
      const response = await fetch(config.endpoint, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${config.apiKey}`
        },
        body: JSON.stringify({ model: config.model, input: text })
      });
      if (!response.ok) return null;
      const payload = await response.json();
      if (Array.isArray(payload?.embedding)) return payload.embedding;
      const vector = payload?.data?.[0]?.embedding;
      return Array.isArray(vector) ? vector : null;
    } catch {
      return null;
    }
  }
  function cosineSimilarity(a, b) {
    const length = Math.min(a.length, b.length);
    if (length === 0) return 0;
    let dot = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < length; i++) {
      const av = a[i];
      const bv = b[i];
      dot += av * bv;
      normA += av * av;
      normB += bv * bv;
    }
    if (normA === 0 || normB === 0) return 0;
    return dot / (Math.sqrt(normA) * Math.sqrt(normB));
  }
  function isEntry(value) {
    if (typeof value !== "object" || value === null) return false;
    const candidate = value;
    return typeof candidate.id === "string" && Array.isArray(candidate.vector);
  }

  // src/features/media/urls.ts
  var IMAGE_HOST = "pbs.twimg.com";
  var FORMAT_PRIORITY = ["jpg", "png", "webp"];
  function normalizeImageUrl(rawUrl, options = {}) {
    let parsed;
    try {
      parsed = new URL(rawUrl, "https://x.com");
    } catch {
      return null;
    }
    if (parsed.hostname !== IMAGE_HOST) {
      return null;
    }
    if (!parsed.pathname.startsWith("/media/")) {
      return null;
    }
    const params = parsed.searchParams;
    const requestedFormat = (params.get("format") ?? "").toLowerCase();
    const format = FORMAT_PRIORITY.includes(requestedFormat) ? requestedFormat : "jpg";
    params.set("format", format);
    if (options.preferOriginal ?? true) {
      params.set("name", "orig");
    } else if (!params.has("name")) {
      params.set("name", "large");
    }
    const mediaId = mediaIdFromPath(parsed.pathname);
    return {
      url: `${parsed.origin}${parsed.pathname}?${params.toString()}`,
      format,
      mediaId
    };
  }
  function mediaIdFromPath(pathname) {
    const match = /\/media\/([A-Za-z0-9_-]{6,})(?:\.[A-Za-z0-9]+)?$/.exec(pathname);
    return match?.[1] ?? null;
  }
  function tweetIdFromHref(href) {
    if (!href) {
      return null;
    }
    const match = /\/status(?:es)?\/(\d{6,})/.exec(href);
    return match?.[1] ?? null;
  }

  // src/features/media/video-extract.ts
  var VIDEO_SELECTOR = '[data-testid="videoPlayer"], [data-testid="videoComponent"]';
  function extractVideos(article) {
    const results = [];
    for (const container of Array.from(article.querySelectorAll(VIDEO_SELECTOR))) {
      const extracted = extractVideo(container);
      if (extracted) {
        results.push(extracted);
      }
    }
    return results;
  }
  function extractVideo(container) {
    const video = container.querySelector("video");
    if (!video) {
      return null;
    }
    const variants = [];
    const seen = /* @__PURE__ */ new Set();
    if (video.currentSrc) {
      pushVariant(variants, seen, video.currentSrc, video.dataset.contentType ?? "video/mp4");
    }
    if (video.src) {
      pushVariant(variants, seen, video.src, "video/mp4");
    }
    for (const source of Array.from(video.querySelectorAll("source"))) {
      pushVariant(
        variants,
        seen,
        source.src,
        source.type || "video/mp4",
        source.dataset.width,
        source.dataset.height,
        source.dataset.bitrate
      );
    }
    if (variants.length === 0) {
      return null;
    }
    const preferred = pickPreferred(variants);
    const poster = video.poster || null;
    const isGif = looksLikeGif(container, video, variants);
    return { container, poster, isGif, variants, preferred };
  }
  function pushVariant(variants, seen, src, type, width, height, bitrate) {
    if (!src || seen.has(src)) {
      return;
    }
    seen.add(src);
    variants.push({
      url: src,
      type,
      width: parsePositiveInt(width),
      height: parsePositiveInt(height),
      bitrate: parsePositiveInt(bitrate)
    });
  }
  function pickPreferred(variants) {
    const sorted = [...variants].sort((a, b) => {
      const bitrateDiff = (b.bitrate ?? 0) - (a.bitrate ?? 0);
      if (bitrateDiff !== 0) {
        return bitrateDiff;
      }
      const aPixels = (a.width ?? 0) * (a.height ?? 0);
      const bPixels = (b.width ?? 0) * (b.height ?? 0);
      return bPixels - aPixels;
    });
    return sorted[0] ?? variants[0];
  }
  function looksLikeGif(container, video, variants) {
    if (video.loop && video.muted) {
      return true;
    }
    const label = (container.getAttribute("aria-label") ?? "").toLowerCase();
    if (label.includes("gif")) {
      return true;
    }
    return variants.some((variant) => variant.url.toLowerCase().includes("tweet_video"));
  }
  function parsePositiveInt(value) {
    if (!value) {
      return null;
    }
    const parsed = Number.parseInt(value, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  }

  // src/features/media/extract.ts
  function extractTweet(article, options = {}) {
    const tweetId = readTweetId(article);
    const handle = readHandle(article);
    const text = readText(article);
    const media = [];
    const imageOptions = { preferOriginal: options.preferOriginalImages ?? true };
    for (const img of Array.from(
      article.querySelectorAll('[data-testid="tweetPhoto"] img')
    )) {
      const normalized = normalizeImageUrl(img.src, imageOptions);
      if (normalized) {
        media.push({ kind: "photo", source: img, image: normalized });
      }
    }
    for (const video of extractVideos(article)) {
      if (video.preferred) {
        media.push({ kind: "video", source: video.container, video });
      }
      if (video.poster) {
        const normalized = normalizeImageUrl(video.poster, imageOptions);
        if (normalized) {
          const fake = document.createElement("img");
          fake.src = video.poster;
          media.push({ kind: "thumbnail", source: fake, image: normalized });
        }
      }
    }
    return { article, tweetId, handle, text, media };
  }
  function readTweetId(article) {
    const links = article.querySelectorAll('a[href*="/status/"]');
    for (const link of Array.from(links)) {
      const candidate = tweetIdFromHref(link.getAttribute("href"));
      if (candidate) {
        return candidate;
      }
    }
    return null;
  }
  function readHandle(article) {
    const userName = article.querySelector('[data-testid="User-Name"]');
    const links = userName?.querySelectorAll('a[href^="/"]') ?? [];
    for (const link of Array.from(links)) {
      const href = link.getAttribute("href") ?? "";
      const match = /^\/([A-Za-z0-9_]{1,15})(?:[/?#]|$)/.exec(href);
      const candidate = match?.[1];
      if (candidate) {
        return candidate;
      }
    }
    return null;
  }
  function readText(article) {
    const text = article.querySelector('[data-testid="tweetText"]');
    return text?.textContent?.trim() ?? "";
  }

  // src/features/export/collector.ts
  function collectExportRecords(root, surface) {
    const articles = root instanceof Element && root.matches('article[data-testid="tweet"]') ? [root] : Array.from(root.querySelectorAll('article[data-testid="tweet"]'));
    const seen = /* @__PURE__ */ new Set();
    const records = [];
    const now = (/* @__PURE__ */ new Date()).toISOString();
    for (const article of articles) {
      const tweet = extractTweet(article);
      const key = `${tweet.tweetId ?? "noid"}:${tweet.handle ?? "noh"}:${(tweet.text || "").slice(0, 60)}`;
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      const media = [];
      for (const item of tweet.media) {
        if (item.kind === "video" && item.video?.preferred) {
          const entry = {
            kind: "video",
            url: item.video.preferred.url,
            type: item.video.preferred.type
          };
          if (item.video.preferred.width !== null) entry.width = item.video.preferred.width;
          if (item.video.preferred.height !== null) entry.height = item.video.preferred.height;
          if (item.video.preferred.bitrate !== null) entry.bitrate = item.video.preferred.bitrate;
          media.push(entry);
        } else if (item.image) {
          const entry = {
            kind: item.kind === "thumbnail" ? "thumbnail" : "photo",
            url: item.image.url,
            type: item.image.format
          };
          if (item.source instanceof HTMLImageElement && item.source.alt) {
            entry.altText = item.source.alt;
          }
          media.push(entry);
        }
      }
      const displayName = readDisplayName(article);
      const permalink = readPermalink(article, tweet.handle, tweet.tweetId);
      const poll = readPoll(article);
      const quote = readQuote(article);
      const articleSummary = readArticle(article);
      const birdwatch = readBirdwatch(article);
      const record = {
        tweetId: tweet.tweetId,
        handle: tweet.handle,
        displayName,
        text: tweet.text,
        capturedAt: now,
        surface,
        media,
        permalink
      };
      if (poll) record.poll = poll;
      if (quote) record.quote = quote;
      if (articleSummary) record.article = articleSummary;
      if (birdwatch) record.birdwatch = birdwatch;
      records.push(record);
    }
    return records;
  }
  function readPoll(article) {
    const bars = Array.from(article.querySelectorAll('[data-testid$="-progress-bar"], [data-testid="cardPoll"] li'));
    if (bars.length === 0) {
      return null;
    }
    const choices = [];
    for (const bar of bars) {
      const label = readFirstText(bar);
      if (!label) continue;
      const percentMatch = /([0-9]+(?:\.[0-9]+)?)\s*%/.exec(bar.textContent ?? "");
      const choice = { label };
      if (percentMatch) {
        choice.percent = Number(percentMatch[1]);
        choice.voteShare = `${percentMatch[1]}%`;
      }
      choices.push(choice);
    }
    if (choices.length === 0) {
      return null;
    }
    const totals = article.querySelector('[data-testid="cardPoll"] span');
    const totalText = totals?.textContent?.trim() ?? "";
    const poll = { choices };
    if (totalText.length > 0) {
      poll.totalVotes = totalText;
    }
    return poll;
  }
  function readQuote(article) {
    const quote = article.querySelector('[data-testid="quoteTweet"], [aria-labelledby="quoted"]');
    if (!quote) {
      return null;
    }
    const handleLink = quote.querySelector('a[href^="/"]');
    const handle = handleLink ? /\/([A-Za-z0-9_]{1,15})/.exec(handleLink.getAttribute("href") ?? "")?.[1] ?? null : null;
    const text = quote.querySelector('[data-testid="tweetText"]')?.textContent?.trim() ?? "";
    return { handle, text };
  }
  function readArticle(article) {
    const card = article.querySelector('[data-testid="card.wrapper"], [data-testid="article"]');
    if (!card) {
      return null;
    }
    const titleNode = card.querySelector('[data-testid="card.layoutLarge.detail"] span, [data-testid="article-title"], h2');
    const link = card.querySelector("a[href]");
    return {
      title: titleNode?.textContent?.trim() ?? null,
      url: link?.href ?? link?.getAttribute("href") ?? null
    };
  }
  function readBirdwatch(article) {
    const pivot = article.querySelector('[data-testid="birdwatch-pivot"]');
    if (!pivot) return void 0;
    return pivot.textContent?.trim() || void 0;
  }
  function readFirstText(node) {
    if (!node) return null;
    const text = node.textContent?.trim() ?? "";
    return text.length > 0 ? text : null;
  }
  function readDisplayName(article) {
    const userName = article.querySelector('[data-testid="User-Name"]');
    if (!userName) {
      return null;
    }
    const spans = Array.from(userName.querySelectorAll("span"));
    for (const span of spans) {
      const text = span.textContent?.trim() ?? "";
      if (text.length > 0 && !text.startsWith("@") && !text.startsWith("\xB7")) {
        return text;
      }
    }
    return null;
  }
  function readPermalink(article, handle, tweetId) {
    if (handle && tweetId) {
      return `https://x.com/${handle}/status/${tweetId}`;
    }
    const link = article.querySelector('a[href*="/status/"]');
    const href = link?.getAttribute("href") ?? null;
    if (href && tweetIdFromHref(href)) {
      return new URL(href, "https://x.com").toString();
    }
    return null;
  }

  // src/features/export/jobs.ts
  var CHECKPOINT_KEY = "aviary.export.checkpoints.v1";
  var RETENTION_KEYS = {
    maxJobs: "aviary.retention.maxJobs",
    maxRecordsPerJob: "aviary.retention.maxRecordsPerJob",
    maxAgeDays: "aviary.retention.maxAgeDays"
  };
  var DEFAULT_RETENTION_POLICY = {
    maxJobs: 0,
    maxRecordsPerJob: 0,
    maxAgeDays: 0
  };
  var EMPTY2 = { jobs: {}, records: {} };
  var CheckpointStore = class {
    #storage;
    #state = EMPTY2;
    #policy = DEFAULT_RETENTION_POLICY;
    #loaded = false;
    constructor(storage) {
      this.#storage = storage;
    }
    async load() {
      if (this.#loaded) return emptySweep(this.#policy, Object.keys(this.#state.jobs).length);
      const raw = await this.#storage.get(CHECKPOINT_KEY, EMPTY2);
      this.#state = {
        jobs: { ...raw?.jobs ?? {} },
        records: { ...raw?.records ?? {} }
      };
      this.#policy = await loadRetentionPolicy(this.#storage);
      this.#loaded = true;
      return this.sweep();
    }
    get retentionPolicy() {
      return { ...this.#policy };
    }
    list() {
      return Object.values(this.#state.jobs);
    }
    records(jobId) {
      return this.#state.records[jobId] ?? [];
    }
    async start(jobId, surface, formats, preserveRawPayloads) {
      await this.load();
      this.#state.jobs[jobId] = {
        jobId,
        startedAt: (/* @__PURE__ */ new Date()).toISOString(),
        surface,
        recordCount: 0,
        done: false,
        formats,
        preserveRawPayloads
      };
      this.#state.records[jobId] = [];
      await this.#persist();
      await this.sweep();
    }
    async append(jobId, batch) {
      await this.load();
      const job = this.#state.jobs[jobId];
      if (!job) return;
      const seen = new Set(this.#state.records[jobId]?.map((entry) => recordKey(entry)) ?? []);
      const records = this.#state.records[jobId] ?? [];
      for (const record of batch) {
        const key = recordKey(record);
        if (!seen.has(key)) {
          seen.add(key);
          records.push(record);
        }
      }
      const retained = this.#policy.maxRecordsPerJob > 0 ? records.slice(-this.#policy.maxRecordsPerJob) : records;
      this.#state.records[jobId] = retained;
      job.recordCount = retained.length;
      await this.#persist();
    }
    async finish(jobId) {
      await this.load();
      const job = this.#state.jobs[jobId];
      if (job) {
        job.done = true;
        await this.#persist();
      }
    }
    async remove(jobId) {
      await this.load();
      delete this.#state.jobs[jobId];
      delete this.#state.records[jobId];
      await this.#persist();
    }
    async sweep(policy) {
      await this.load();
      if (policy) {
        this.#policy = normalizeRetentionPolicy(policy);
      }
      const beforeJobs = Object.keys(this.#state.jobs).length;
      const beforeRecords = Object.values(this.#state.records).reduce(
        (total, records) => total + records.length,
        0
      );
      const removeIds = /* @__PURE__ */ new Set();
      if (this.#policy.maxAgeDays > 0) {
        const cutoff = Date.now() - this.#policy.maxAgeDays * 24 * 60 * 60 * 1e3;
        for (const job of Object.values(this.#state.jobs)) {
          const startedAt = Date.parse(job.startedAt);
          if (Number.isFinite(startedAt) && startedAt < cutoff) {
            removeIds.add(job.jobId);
          }
        }
      }
      if (this.#policy.maxJobs > 0) {
        const newest = Object.values(this.#state.jobs).filter((job) => !removeIds.has(job.jobId)).sort(compareJobs).slice(-this.#policy.maxJobs).map((job) => job.jobId);
        const keepIds = new Set(newest);
        for (const job of Object.values(this.#state.jobs)) {
          if (!removeIds.has(job.jobId) && !keepIds.has(job.jobId)) {
            removeIds.add(job.jobId);
          }
        }
      }
      for (const jobId of removeIds) {
        delete this.#state.jobs[jobId];
        delete this.#state.records[jobId];
      }
      for (const job of Object.values(this.#state.jobs)) {
        const records = this.#state.records[job.jobId] ?? [];
        if (this.#policy.maxRecordsPerJob > 0 && records.length > this.#policy.maxRecordsPerJob) {
          this.#state.records[job.jobId] = records.slice(-this.#policy.maxRecordsPerJob);
        }
        job.recordCount = this.#state.records[job.jobId]?.length ?? 0;
      }
      const afterRecords = Object.values(this.#state.records).reduce(
        (total, records) => total + records.length,
        0
      );
      const result = {
        removedJobs: beforeJobs - Object.keys(this.#state.jobs).length,
        removedRecords: beforeRecords - afterRecords,
        retainedJobs: Object.keys(this.#state.jobs).length,
        policy: this.retentionPolicy
      };
      if (result.removedJobs > 0 || result.removedRecords > 0) {
        await this.#persist();
      }
      return result;
    }
    async #persist() {
      try {
        await this.#storage.set(CHECKPOINT_KEY, this.#state);
      } catch {
      }
    }
  };
  function normalizeRetentionPolicy(input) {
    const record = input && typeof input === "object" ? input : {};
    return {
      maxJobs: retentionNumber(record.maxJobs, DEFAULT_RETENTION_POLICY.maxJobs, 1e4),
      maxRecordsPerJob: retentionNumber(
        record.maxRecordsPerJob,
        DEFAULT_RETENTION_POLICY.maxRecordsPerJob,
        1e5
      ),
      maxAgeDays: retentionNumber(record.maxAgeDays, DEFAULT_RETENTION_POLICY.maxAgeDays, 3650)
    };
  }
  async function loadRetentionPolicy(storage) {
    const [maxJobs, maxRecordsPerJob, maxAgeDays] = await Promise.all([
      storage.get(RETENTION_KEYS.maxJobs, DEFAULT_RETENTION_POLICY.maxJobs),
      storage.get(RETENTION_KEYS.maxRecordsPerJob, DEFAULT_RETENTION_POLICY.maxRecordsPerJob),
      storage.get(RETENTION_KEYS.maxAgeDays, DEFAULT_RETENTION_POLICY.maxAgeDays)
    ]);
    return normalizeRetentionPolicy({ maxJobs, maxRecordsPerJob, maxAgeDays });
  }
  async function saveRetentionPolicy(storage, input) {
    const policy = normalizeRetentionPolicy(input);
    await Promise.all([
      storage.set(RETENTION_KEYS.maxJobs, policy.maxJobs),
      storage.set(RETENTION_KEYS.maxRecordsPerJob, policy.maxRecordsPerJob),
      storage.set(RETENTION_KEYS.maxAgeDays, policy.maxAgeDays)
    ]);
    return policy;
  }
  function retentionNumber(value, fallback, max) {
    if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
    return Math.max(0, Math.min(max, Math.trunc(value)));
  }
  function compareJobs(left, right) {
    const leftAt = Date.parse(left.startedAt);
    const rightAt = Date.parse(right.startedAt);
    if (leftAt !== rightAt) return leftAt - rightAt;
    return left.jobId.localeCompare(right.jobId);
  }
  function emptySweep(policy, retainedJobs) {
    return { removedJobs: 0, removedRecords: 0, retainedJobs, policy: { ...policy } };
  }
  function recordKey(record) {
    return `${record.tweetId ?? ""}|${record.handle ?? ""}|${record.text.slice(0, 80)}`;
  }

  // src/features/export/zip-store.ts
  var CRC32_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) {
        c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
      }
      table[i] = c >>> 0;
    }
    return table;
  })();
  function crc32(data) {
    let c = 4294967295;
    for (let i = 0; i < data.length; i++) {
      c = (CRC32_TABLE[(c ^ data[i]) & 255] ^ c >>> 8) >>> 0;
    }
    return (c ^ 4294967295) >>> 0;
  }
  var FLAG_UTF8_NAMES = 2048;
  var MAX_UINT16 = 65535;
  var MAX_UINT32 = 4294967295;
  function buildStoreZip(entries) {
    const encoder = new TextEncoder();
    const localBlocks = [];
    const centralBlocks = [];
    let offset = 0;
    if (entries.length > MAX_UINT16) {
      throw new RangeError(
        `A STORE zip holds at most ${MAX_UINT16} entries without ZIP64; got ${entries.length}.`
      );
    }
    for (const entry of entries) {
      if (entry.data.length > MAX_UINT32) {
        throw new RangeError(
          `"${entry.filename}" is ${entry.data.length} bytes; a STORE zip entry cannot exceed ${MAX_UINT32} without ZIP64.`
        );
      }
      const nameBytes = encoder.encode(entry.filename);
      if (nameBytes.length > MAX_UINT16) {
        throw new RangeError(`"${entry.filename}" has a name longer than ${MAX_UINT16} bytes.`);
      }
      const crc = crc32(entry.data);
      const size = entry.data.length;
      const date = entry.date ?? /* @__PURE__ */ new Date();
      const dosDate = toDosDate(date);
      const dosTime = toDosTime(date);
      const localHeader = new ArrayBuffer(30 + nameBytes.length);
      const lhView = new DataView(localHeader);
      lhView.setUint32(0, 67324752, true);
      lhView.setUint16(4, 20, true);
      lhView.setUint16(6, FLAG_UTF8_NAMES, true);
      lhView.setUint16(8, 0, true);
      lhView.setUint16(10, dosTime, true);
      lhView.setUint16(12, dosDate, true);
      lhView.setUint32(14, crc, true);
      lhView.setUint32(18, size, true);
      lhView.setUint32(22, size, true);
      lhView.setUint16(26, nameBytes.length, true);
      lhView.setUint16(28, 0, true);
      const localHeaderBytes = new Uint8Array(localHeader);
      localHeaderBytes.set(nameBytes, 30);
      localBlocks.push(localHeaderBytes);
      localBlocks.push(entry.data);
      const centralHeader = new ArrayBuffer(46 + nameBytes.length);
      const chView = new DataView(centralHeader);
      chView.setUint32(0, 33639248, true);
      chView.setUint16(4, 20, true);
      chView.setUint16(6, 20, true);
      chView.setUint16(8, FLAG_UTF8_NAMES, true);
      chView.setUint16(10, 0, true);
      chView.setUint16(12, dosTime, true);
      chView.setUint16(14, dosDate, true);
      chView.setUint32(16, crc, true);
      chView.setUint32(20, size, true);
      chView.setUint32(24, size, true);
      chView.setUint16(28, nameBytes.length, true);
      chView.setUint16(30, 0, true);
      chView.setUint16(32, 0, true);
      chView.setUint16(34, 0, true);
      chView.setUint16(36, 0, true);
      chView.setUint32(38, 0, true);
      chView.setUint32(42, offset, true);
      const centralBytes = new Uint8Array(centralHeader);
      centralBytes.set(nameBytes, 46);
      centralBlocks.push(centralBytes);
      offset += localHeaderBytes.length + entry.data.length;
    }
    const centralStart = offset;
    let centralSize = 0;
    for (const block of centralBlocks) {
      centralSize += block.length;
    }
    if (centralStart > MAX_UINT32 || centralSize > MAX_UINT32) {
      throw new RangeError(
        `The archive is too large for a non-ZIP64 zip (central directory at ${centralStart}, size ${centralSize}).`
      );
    }
    const endRecord = new Uint8Array(22);
    const erView = new DataView(endRecord.buffer);
    erView.setUint32(0, 101010256, true);
    erView.setUint16(4, 0, true);
    erView.setUint16(6, 0, true);
    erView.setUint16(8, entries.length, true);
    erView.setUint16(10, entries.length, true);
    erView.setUint32(12, centralSize, true);
    erView.setUint32(16, centralStart, true);
    erView.setUint16(20, 0, true);
    const total = offset + centralSize + endRecord.length;
    const output = new Uint8Array(total);
    let cursor = 0;
    for (const block of localBlocks) {
      output.set(block, cursor);
      cursor += block.length;
    }
    for (const block of centralBlocks) {
      output.set(block, cursor);
      cursor += block.length;
    }
    output.set(endRecord, cursor);
    return output;
  }
  function toDosDate(date) {
    const year = Math.max(date.getUTCFullYear() - 1980, 0);
    return (year & 127) << 9 | (date.getUTCMonth() + 1 & 15) << 5 | date.getUTCDate() & 31;
  }
  function toDosTime(date) {
    return (date.getUTCHours() & 31) << 11 | (date.getUTCMinutes() & 63) << 5 | Math.floor(date.getUTCSeconds() / 2) & 31;
  }

  // src/features/export/xlsx.ts
  var ENCODER = new TextEncoder();
  function formatXlsx(records) {
    const sheetRows = [
      ["tweetId", "handle", "displayName", "capturedAt", "surface", "permalink", "text", "mediaUrls"]
    ];
    for (const record of records) {
      sheetRows.push([
        record.tweetId ?? "",
        record.handle ?? "",
        record.displayName ?? "",
        record.capturedAt,
        record.surface,
        record.permalink ?? "",
        record.text,
        record.media.map((media) => media.url).join("|")
      ]);
    }
    const sheetXml = buildSheetXml(sheetRows);
    const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Tweets" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const workbookRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
    const rootRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
    const archive = buildStoreZip([
      { filename: "[Content_Types].xml", data: ENCODER.encode(contentTypesXml) },
      { filename: "_rels/.rels", data: ENCODER.encode(rootRelsXml) },
      { filename: "xl/_rels/workbook.xml.rels", data: ENCODER.encode(workbookRelsXml) },
      { filename: "xl/workbook.xml", data: ENCODER.encode(workbookXml) },
      { filename: "xl/worksheets/sheet1.xml", data: ENCODER.encode(sheetXml) }
    ]);
    return {
      filename: "tweets.xlsx",
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      data: archive
    };
  }
  function buildSheetXml(rows) {
    const xmlRows = [];
    for (let r = 0; r < rows.length; r++) {
      const row = rows[r];
      const cells = [];
      for (let c = 0; c < row.length; c++) {
        const value = row[c] ?? "";
        const cellRef = `${columnLetter(c)}${r + 1}`;
        cells.push(`<c r="${cellRef}" t="inlineStr"><is><t xml:space="preserve">${escapeXml(value)}</t></is></c>`);
      }
      xmlRows.push(`<row r="${r + 1}">${cells.join("")}</row>`);
    }
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${xmlRows.join("")}</sheetData></worksheet>`;
  }
  function stripInvalidXmlChars(value) {
    let output = "";
    for (const char of value) {
      const code = char.codePointAt(0) ?? 0;
      const allowed = code === 9 || code === 10 || code === 13 || code >= 32 && code <= 55295 || code >= 57344 && code <= 65533 || code >= 65536 && code <= 1114111;
      if (allowed) {
        output += char;
      }
    }
    return output;
  }
  function columnLetter(index) {
    let label = "";
    let n = index;
    while (n >= 0) {
      label = String.fromCharCode(n % 26 + 65) + label;
      n = Math.floor(n / 26) - 1;
    }
    return label;
  }
  function escapeXml(value) {
    return stripInvalidXmlChars(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
  }

  // src/features/export/formatters.ts
  var TEXT_ENCODER = new TextEncoder();
  function formatExport(format, records) {
    switch (format) {
      case "json":
        return jsonArtifact(records);
      case "csv":
        return csvArtifact(records);
      case "html":
        return htmlArtifact(records);
      case "markdown":
        return markdownArtifact(records);
      case "xlsx":
        return formatXlsx(records);
      default:
        return jsonArtifact(records);
    }
  }
  function jsonArtifact(records) {
    const json = JSON.stringify(
      {
        generator: "Aviary",
        generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        count: records.length,
        records
      },
      null,
      2
    );
    return {
      filename: "tweets.json",
      contentType: "application/json",
      data: TEXT_ENCODER.encode(json)
    };
  }
  function csvArtifact(records) {
    const headers = ["tweetId", "handle", "displayName", "capturedAt", "surface", "permalink", "text", "mediaUrls"];
    const lines = [headers.join(",")];
    for (const record of records) {
      const mediaUrls = record.media.map((media) => media.url).join("|");
      lines.push(
        [
          record.tweetId ?? "",
          record.handle ?? "",
          record.displayName ?? "",
          record.capturedAt,
          record.surface,
          record.permalink ?? "",
          record.text,
          mediaUrls
        ].map(csvCell).join(",")
      );
    }
    return {
      filename: "tweets.csv",
      contentType: "text/csv",
      data: TEXT_ENCODER.encode(`${lines.join("\n")}
`)
    };
  }
  function neutralizeFormula(value) {
    return /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  }
  function csvCell(value) {
    if (value === void 0 || value === null) {
      return "";
    }
    const safe = neutralizeFormula(value);
    const needsQuotes = /[,"\r\n]/.test(safe);
    const escaped = safe.replace(/"/g, '""');
    return needsQuotes ? `"${escaped}"` : escaped;
  }
  function safeHref(value) {
    try {
      const parsed = new URL(value, "https://x.com");
      return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.toString() : "";
    } catch {
      return "";
    }
  }
  function htmlArtifact(records) {
    const rows = records.map((record) => {
      const media = record.media.map((entry) => {
        const href = safeHref(entry.url);
        return href ? `<li><a href="${escapeHtml(href)}" rel="noopener noreferrer">${escapeHtml(entry.kind)}</a></li>` : `<li>${escapeHtml(entry.kind)}</li>`;
      }).join("");
      const permalinkHref = record.permalink ? safeHref(record.permalink) : "";
      const permalink = permalinkHref ? `<a href="${escapeHtml(permalinkHref)}" rel="noopener noreferrer">${escapeHtml(permalinkHref)}</a>` : "";
      return `<article class="record">
  <header>
    <strong>${escapeHtml(record.displayName ?? record.handle ?? "Unknown")}</strong>
    <span class="handle">@${escapeHtml(record.handle ?? "")}</span>
    <time datetime="${escapeHtml(record.capturedAt)}">${escapeHtml(record.capturedAt)}</time>
  </header>
  <p>${escapeHtml(record.text).replace(/\n/g, "<br>")}</p>
  <ul>${media}</ul>
  <footer>${permalink}</footer>
</article>`;
    }).join("\n");
    const html = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8" />
<title>Aviary export</title>
<style>
body { font: 14px/1.5 system-ui, sans-serif; background: #0a0a0a; color: #e7e9ea; padding: 24px; }
article { border: 1px solid #2f3336; border-radius: 12px; padding: 16px; margin-bottom: 16px; }
header { display: flex; gap: 8px; align-items: baseline; margin-bottom: 6px; }
.handle { color: #71767b; }
time { margin-left: auto; color: #71767b; font-size: 12px; }
ul { padding-left: 18px; }
a { color: #1d9bf0; }
</style>
</head><body>
<h1>Aviary export</h1>
<p>${records.length} records, generated ${(/* @__PURE__ */ new Date()).toISOString()}.</p>
${rows}
</body></html>`;
    return {
      filename: "tweets.html",
      contentType: "text/html",
      data: TEXT_ENCODER.encode(html)
    };
  }
  function markdownArtifact(records) {
    const sections = records.map((record) => {
      const header = `## ${record.displayName ?? record.handle ?? "Unknown"} (@${record.handle ?? "anon"}) \u2014 ${record.capturedAt}`;
      const body = record.text.split("\n").map((line) => `> ${line}`).join("\n");
      const media = record.media.length === 0 ? "" : `

${record.media.map((entry) => `- [${entry.kind}](${entry.url})`).join("\n")}`;
      const permalink = record.permalink ? `

${record.permalink}` : "";
      return `${header}

${body}${media}${permalink}`;
    });
    const md = `# Aviary export

Generated ${(/* @__PURE__ */ new Date()).toISOString()} \u2014 ${records.length} records.

${sections.join("\n\n---\n\n")}
`;
    return {
      filename: "tweets.md",
      contentType: "text/markdown",
      data: TEXT_ENCODER.encode(md)
    };
  }
  function escapeHtml(value) {
    return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  // src/features/export/query-discovery.ts
  var QUERY_REGISTRY_KEY = "aviary.queryIds.v1";
  var QUERY_REGEX = /\/i\/api\/graphql\/([A-Za-z0-9_-]{6,})\/([A-Za-z0-9_]{2,80})/g;
  async function discoverQueryIds(storage) {
    const fallback = { queries: {}, observedAt: null };
    const existing = await storage.get(QUERY_REGISTRY_KEY, fallback);
    const queries = { ...existing.queries };
    if (typeof document !== "undefined") {
      const scripts = Array.from(document.querySelectorAll("script[src]"));
      for (const script of scripts) {
        mergeFromString(queries, script.src);
      }
      const documentText = document.documentElement?.outerHTML ?? "";
      mergeFromString(queries, documentText);
    }
    const result = {
      queries,
      observedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    try {
      await storage.set(QUERY_REGISTRY_KEY, result);
    } catch {
    }
    return result;
  }
  function mergeFromString(target, source) {
    QUERY_REGEX.lastIndex = 0;
    let match;
    while ((match = QUERY_REGEX.exec(source)) !== null) {
      const [, id, operation] = match;
      if (id && operation) {
        target[operation] = id;
      }
    }
  }

  // src/features/export/export-feature.ts
  var checkpointStore;
  var queryRegistry;
  var activeJobId;
  var exportFeature = {
    id: "export.core",
    title: "Export core",
    category: "export",
    defaultEnabled: true,
    async init(ctx) {
      checkpointStore = new CheckpointStore(ctx.storage);
      const retention = await checkpointStore.load();
      if (retention.removedJobs > 0 || retention.removedRecords > 0) {
        ctx.diagnostics.info("Checkpoint retention sweep", { ...retention });
      }
      if (ctx.settings.export.autoDiscoverQueryIds) {
        try {
          queryRegistry = await discoverQueryIds(ctx.storage);
          ctx.diagnostics.info("Query IDs discovered", {
            count: Object.keys(queryRegistry.queries).length
          });
        } catch (error) {
          ctx.diagnostics.warn("Query ID discovery failed", errorDetails(error));
        }
      }
    },
    async apply(ctx, root, addedNodes) {
      if (!ctx.settings.export.enabled || !checkpointStore || !activeJobId) {
        return;
      }
      const records = collectExportRecords(root, ctx.route.surface);
      if (records.length === 0) {
        return;
      }
      await checkpointStore.append(activeJobId, records);
      if (addedNodes) {
        ctx.diagnostics.info("Export captured nodes", { count: records.length });
      }
    },
    destroy(ctx) {
      checkpointStore = void 0;
      queryRegistry = void 0;
      activeJobId = void 0;
      ctx.diagnostics.info("Export core destroyed");
    },
    getStatus() {
      if (!checkpointStore) {
        return { ok: true, message: "Export idle" };
      }
      const jobs = checkpointStore.list();
      return {
        ok: true,
        message: `${jobs.length} export jobs tracked`,
        details: { queries: queryRegistry?.queries ? Object.keys(queryRegistry.queries).length : 0 }
      };
    }
  };
  function getCheckpointStore() {
    return checkpointStore;
  }
  function getDiscoveredQueries() {
    return queryRegistry;
  }
  async function runExportOfVisibleTweets(ctx) {
    if (!checkpointStore) {
      checkpointStore = new CheckpointStore(ctx.storage);
      await checkpointStore.load();
    }
    const jobId = `job-${Date.now()}`;
    const formats = selectSupportedFormats(ctx.settings.export.formats);
    await checkpointStore.start(jobId, ctx.route.surface, formats, ctx.settings.export.preserveRawPayloads);
    void ctx.auditLog.record("export.start", { jobId, formats, surface: ctx.route.surface });
    activeJobId = jobId;
    const initialRecords = collectExportRecords(document, ctx.route.surface);
    await checkpointStore.append(jobId, initialRecords);
    activeJobId = void 0;
    const records = checkpointStore.records(jobId);
    const artifacts = records.length === 0 ? [] : buildExportZipChunks(
      records,
      formats,
      ctx.settings.media.lastSaveFolder,
      ctx.settings.media.zipChunkSize
    );
    await checkpointStore.finish(jobId);
    ctx.diagnostics.info("Export completed", { records: records.length, formats });
    void ctx.auditLog.record("export.complete", { jobId, records: records.length, formats });
    if (ctx.settings.integrations.semanticSearch.autoIndex) {
      void autoIndexExport(ctx, records);
    }
    return {
      jobId,
      records: records.length,
      artifacts,
      filename: artifacts[0]?.filename ?? zipFilename(ctx.settings.media.lastSaveFolder)
    };
  }
  function buildExportZip(records, formats, folder) {
    const entries = [];
    const safeFolder = sanitizeFolder(folder);
    for (const format of formats) {
      const artifact = formatExport(format, records);
      entries.push({
        filename: safeFolder ? `${safeFolder}/${artifact.filename}` : artifact.filename,
        data: artifact.data
      });
    }
    return buildStoreZip(entries);
  }
  function buildExportZipChunks(records, formats, folder, chunkSize) {
    if (records.length === 0) {
      return [];
    }
    const size = Math.max(1, Math.trunc(chunkSize) || records.length);
    const base = zipFilename(folder);
    if (records.length <= size) {
      return [{ data: buildExportZip(records, formats, folder), filename: base }];
    }
    const total = Math.ceil(records.length / size);
    const artifacts = [];
    for (let index = 0; index < total; index += 1) {
      const slice = records.slice(index * size, (index + 1) * size);
      artifacts.push({
        data: buildExportZip(slice, formats, folder),
        filename: base.replace(/\.zip$/, `-part${index + 1}of${total}.zip`)
      });
    }
    return artifacts;
  }
  function selectSupportedFormats(input) {
    const allowed = ["json", "csv", "html", "markdown", "xlsx"];
    const result = [];
    for (const candidate of input) {
      if (allowed.includes(candidate) && !result.includes(candidate)) {
        result.push(candidate);
      }
    }
    return result.length > 0 ? result : ["json"];
  }
  function sanitizeFolder(folder) {
    const cleaned = folder.replace(/[<>:"|?*\u0000-\u001f]/g, "").replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
    return cleaned.slice(0, 80);
  }
  function zipFilename(folder) {
    const safe = sanitizeFolder(folder);
    const base = safe.length > 0 ? safe.replace(/\//g, "_") : "aviary-export";
    return `${base}-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.zip`;
  }
  function errorDetails(error) {
    if (error instanceof Error) {
      return { name: error.name, message: error.message };
    }
    return { message: String(error) };
  }
  async function autoIndexExport(ctx, records) {
    try {
      const index = new SemanticIndex(ctx.storage);
      await index.load();
      const result = await index.embedAndIndex(ctx.settings.integrations.semanticSearch, records);
      ctx.diagnostics.info("Auto-embedding finished", result);
      void ctx.auditLog.record("export.complete", {
        kind: "auto-semantic-index",
        added: result.added,
        skipped: result.skipped,
        errors: result.errors
      });
    } catch (error) {
      ctx.diagnostics.warn("Auto-embedding failed", errorDetails(error));
    }
  }

  // src/features/export/external-targets.ts
  var ENCODER2 = new TextEncoder();
  function renderForExternalTarget(target, records) {
    switch (target) {
      case "clipboard-markdown":
        return { id: target, payload: toPlainMarkdown(records) };
      case "obsidian":
        return { id: target, artifact: toObsidianArtifact(records) };
      case "notion":
        return { id: target, artifact: toNotionArtifact(records) };
      case "raw-json":
        return { id: target, artifact: toJsonArtifact(records) };
      default:
        return { id: "clipboard-markdown", payload: toPlainMarkdown(records) };
    }
  }
  function toPlainMarkdown(records) {
    const lines = records.map((record) => {
      const handle = record.handle ? `@${record.handle}` : "(unknown)";
      const permalink = record.permalink ? ` \u2014 [link](${record.permalink})` : "";
      const body = record.text.split("\n").map((line) => `> ${line}`).join("\n");
      return `### ${record.displayName ?? handle} (${handle})${permalink}

${body}`;
    });
    return `# Aviary clipboard export

${lines.join("\n\n---\n\n")}
`;
  }
  function toObsidianArtifact(records) {
    const sections = records.map((record) => {
      const safeId = record.tweetId ?? "no-id";
      const handle = record.handle ?? "anon";
      const tags = ["#aviary", `#x/${handle}`];
      const frontmatter = [
        "---",
        `tweet_id: ${safeId}`,
        `handle: ${handle}`,
        `display_name: ${record.displayName ?? ""}`,
        `captured_at: ${record.capturedAt}`,
        `surface: ${record.surface}`,
        `permalink: ${record.permalink ?? ""}`,
        `tags: [${tags.join(", ")}]`,
        "---"
      ].join("\n");
      const mediaList = record.media.length === 0 ? "" : `

${record.media.map((media) => `- [${media.kind}](${media.url})`).join("\n")}`;
      return `${frontmatter}

# ${record.displayName ?? handle}

${record.text}${mediaList}`;
    });
    const document2 = sections.join("\n\n---\n\n");
    return {
      filename: "aviary-obsidian.md",
      contentType: "text/markdown",
      data: ENCODER2.encode(document2)
    };
  }
  function toNotionArtifact(records) {
    const lines = ["# Aviary export"];
    for (const record of records) {
      const handle = record.handle ?? "anon";
      lines.push("");
      lines.push(`## ${record.displayName ?? handle} \xB7 @${handle}`);
      lines.push("");
      lines.push(`*Captured:* ${record.capturedAt}  `);
      if (record.permalink) lines.push(`*Permalink:* ${record.permalink}  `);
      lines.push("");
      lines.push(record.text);
      if (record.media.length > 0) {
        lines.push("");
        lines.push("**Media**");
        for (const media of record.media) {
          lines.push(`- ${media.kind}: ${media.url}`);
        }
      }
    }
    return {
      filename: "aviary-notion.md",
      contentType: "text/markdown",
      data: ENCODER2.encode(`${lines.join("\n")}
`)
    };
  }
  function toJsonArtifact(records) {
    const json = JSON.stringify(
      { generator: "Aviary", generatedAt: (/* @__PURE__ */ new Date()).toISOString(), records },
      null,
      2
    );
    return {
      filename: "aviary-records.json",
      contentType: "application/json",
      data: ENCODER2.encode(json)
    };
  }

  // src/features/filtering/hidden-posts.ts
  var HIDDEN_POSTS_KEY = "aviary.hiddenPosts.v1";
  var TEXT_SNIPPET_LENGTH = 80;
  var UNDO_STACK_LIMIT = 20;
  var CONTROL_CHARS = /\p{Cc}/gu;
  function derivePostKey(identity) {
    const tweetId = normalizeTweetId(identity.tweetId);
    if (tweetId) {
      return `id:${tweetId}`;
    }
    const handle = normalizeHandle(identity.handle);
    const text = collapseWhitespace(identity.text);
    if (!handle || text.length === 0) {
      return null;
    }
    return `sig:${handle}:${hashText(text)}`;
  }
  function hashText(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index += 1) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return `${hash.toString(36)}${value.length.toString(36)}`;
  }
  function handleFromHref(href) {
    if (typeof href !== "string") {
      return null;
    }
    const withoutOrigin = href.replace(
      /^https?:\/\/(?:www\.|mobile\.|pro\.)?(?:x|twitter)\.com/i,
      ""
    );
    const match = /^\/([A-Za-z0-9_]{1,15})(?:[/?#]|$)/.exec(withoutOrigin);
    return match?.[1] ? normalizeHandle(match[1]) : null;
  }
  function normalizeHiddenPosts(input, maxEntries) {
    const record = isRecord2(input) ? input : {};
    const rawEntries = Array.isArray(record.entries) ? record.entries : [];
    const byKey = /* @__PURE__ */ new Map();
    for (const raw of rawEntries) {
      const entry = normalizeEntry(raw);
      if (!entry) {
        continue;
      }
      const previous = byKey.get(entry.key);
      if (!previous || previous.hiddenAt <= entry.hiddenAt) {
        byKey.set(entry.key, entry);
      }
    }
    const entries = [...byKey.values()].sort(
      (left, right) => left.hiddenAt < right.hiddenAt ? -1 : left.hiddenAt > right.hiddenAt ? 1 : 0
    );
    const limit = Number.isFinite(maxEntries) ? Math.max(1, Math.trunc(maxEntries)) : 5e3;
    const trimmed = entries.length > limit ? entries.slice(entries.length - limit) : entries;
    return {
      entries: trimmed,
      updatedAt: typeof record.updatedAt === "string" ? record.updatedAt : null
    };
  }
  var HiddenPostStore = class {
    #storage;
    #onPersistError;
    #entries = /* @__PURE__ */ new Map();
    #undoStack = [];
    #updatedAt = null;
    #version = 0;
    #loaded = false;
    constructor(storage, onPersistError) {
      this.#storage = storage;
      this.#onPersistError = onPersistError;
    }
    async load(maxEntries) {
      const stored = await this.#storage.get(HIDDEN_POSTS_KEY, null);
      const snapshot = normalizeHiddenPosts(stored, maxEntries);
      this.#entries = new Map(snapshot.entries.map((entry) => [entry.key, entry]));
      this.#updatedAt = snapshot.updatedAt;
      this.#undoStack = [];
      this.#loaded = true;
      this.#version += 1;
    }
    get loaded() {
      return this.#loaded;
    }
    /** Bumped on every mutation so DOM passes know a re-evaluation is required. */
    version() {
      return this.#version;
    }
    has(key) {
      return this.#entries.has(key);
    }
    size() {
      return this.#entries.size;
    }
    updatedAt() {
      return this.#updatedAt;
    }
    /** Newest first — the Control Center and undo affordances read the head. */
    list() {
      return [...this.#entries.values()].sort(
        (left, right) => left.hiddenAt < right.hiddenAt ? 1 : left.hiddenAt > right.hiddenAt ? -1 : 0
      );
    }
    undoDepth() {
      return this.#undoStack.length;
    }
    async hide(identity, maxEntries) {
      const key = identity.key ?? derivePostKey(identity);
      if (!key || this.#entries.has(key)) {
        return null;
      }
      const entry = {
        key,
        hiddenAt: (/* @__PURE__ */ new Date()).toISOString(),
        handle: normalizeHandle(identity.handle),
        tweetId: normalizeTweetId(identity.tweetId),
        text: snippet(identity.text)
      };
      this.#entries.set(key, entry);
      this.#undoStack.push(key);
      if (this.#undoStack.length > UNDO_STACK_LIMIT) {
        this.#undoStack.shift();
      }
      this.#evict(maxEntries);
      this.#version += 1;
      await this.#persist();
      return entry;
    }
    async unhide(key) {
      const entry = this.#entries.get(key);
      if (!entry) {
        return null;
      }
      this.#entries.delete(key);
      this.#undoStack = this.#undoStack.filter((candidate) => candidate !== key);
      this.#version += 1;
      await this.#persist();
      return entry;
    }
    /** Pops the most recent hide from this session; falls back to the newest stored entry. */
    async undoLast() {
      while (this.#undoStack.length > 0) {
        const key = this.#undoStack.pop();
        if (key && this.#entries.has(key)) {
          return await this.unhide(key);
        }
      }
      const newest = this.list()[0];
      return newest ? await this.unhide(newest.key) : null;
    }
    async clear() {
      const removed = this.#entries.size;
      this.#entries.clear();
      this.#undoStack = [];
      this.#version += 1;
      await this.#persist();
      return removed;
    }
    #evict(maxEntries) {
      const limit = Math.max(1, Math.trunc(maxEntries));
      if (this.#entries.size <= limit) {
        return;
      }
      const ordered = [...this.#entries.values()].sort(
        (left, right) => left.hiddenAt < right.hiddenAt ? -1 : left.hiddenAt > right.hiddenAt ? 1 : 0
      );
      for (const entry of ordered.slice(0, this.#entries.size - limit)) {
        this.#entries.delete(entry.key);
      }
    }
    async #persist() {
      this.#updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      const snapshot = {
        entries: [...this.#entries.values()],
        updatedAt: this.#updatedAt
      };
      try {
        await this.#storage.set(HIDDEN_POSTS_KEY, snapshot);
      } catch (error) {
        this.#onPersistError?.(error);
      }
    }
  };
  function normalizeEntry(input) {
    if (!isRecord2(input)) {
      return null;
    }
    const key = typeof input.key === "string" ? input.key.trim() : "";
    if (!/^(id:\d{1,25}|sig:[a-z0-9_]{1,15}:[a-z0-9]{1,20})$/.test(key)) {
      return null;
    }
    const hiddenAt = typeof input.hiddenAt === "string" && !Number.isNaN(Date.parse(input.hiddenAt)) ? input.hiddenAt : (/* @__PURE__ */ new Date(0)).toISOString();
    return {
      key,
      hiddenAt,
      handle: typeof input.handle === "string" ? normalizeHandle(input.handle) : null,
      tweetId: typeof input.tweetId === "string" ? normalizeTweetId(input.tweetId) : null,
      text: typeof input.text === "string" ? snippet(input.text) : ""
    };
  }
  function snippet(value) {
    return collapseWhitespace(value).slice(0, TEXT_SNIPPET_LENGTH);
  }
  function collapseWhitespace(value) {
    return value.replace(CONTROL_CHARS, " ").replace(/\s+/g, " ").trim();
  }
  function normalizeHandle(value) {
    if (typeof value !== "string") {
      return null;
    }
    const cleaned = value.replace(/^@/, "").trim().toLowerCase();
    return /^[a-z0-9_]{1,15}$/.test(cleaned) ? cleaned : null;
  }
  function normalizeTweetId(value) {
    if (typeof value !== "string") {
      return null;
    }
    const cleaned = value.trim();
    return /^\d{1,25}$/.test(cleaned) ? cleaned : null;
  }
  function isRecord2(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // src/features/filtering/hidden-posts-feature.ts
  var STYLE_ID2 = "av-hidden-posts";
  var TOAST_HOST_ID = "av-hidden-toast";
  var ARTICLE_SELECTOR = 'article[data-testid="tweet"]';
  var CELL_SELECTOR = '[data-testid="cellInnerDiv"]';
  var BUTTON_ATTR = "data-av-hide-button";
  var HIDDEN_ATTR = "data-av-hidden";
  var KEY_ATTR = "data-av-post-key";
  var STATE_ATTR = "data-av-hide-state";
  var TOAST_TIMEOUT_MS = 8e3;
  var store;
  var lastAppliedVersion = -1;
  var toastTimer;
  var reflowHandle;
  var hiddenPostsFeature = {
    id: "filtering.hiddenPosts",
    title: "Hide posts",
    category: "filtering",
    defaultEnabled: true,
    async init(ctx) {
      ensureStyle();
      store = new HiddenPostStore(ctx.storage, (error) => {
        ctx.diagnostics.error("Hidden posts failed to save", errorDetails2(error));
      });
      try {
        await store.load(ctx.settings.hidden.maxEntries);
      } catch (error) {
        ctx.diagnostics.error("Hidden posts failed to load", errorDetails2(error));
      }
      applyRootClass(ctx);
      scan(document, ctx);
      ctx.diagnostics.info("Hidden posts initialized", { hidden: store.size() });
    },
    apply(ctx, root, addedNodes) {
      ensureStyle();
      applyRootClass(ctx);
      if (!store) {
        return;
      }
      if (store.version() !== lastAppliedVersion) {
        lastAppliedVersion = store.version();
        scan(document, ctx);
        return;
      }
      if (!addedNodes || addedNodes.length === 0) {
        scan(root, ctx);
        return;
      }
      for (const node of addedNodes) {
        scan(node, ctx);
      }
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID2)?.remove();
      document.getElementById(TOAST_HOST_ID)?.remove();
      document.documentElement.classList.remove("av-hide-posts-enabled");
      for (const button2 of Array.from(document.querySelectorAll(`[${BUTTON_ATTR}]`))) {
        button2.remove();
      }
      for (const node of Array.from(
        document.querySelectorAll(`[${HIDDEN_ATTR}], [${KEY_ATTR}], [${STATE_ATTR}]`)
      )) {
        node.removeAttribute(HIDDEN_ATTR);
        node.removeAttribute(KEY_ATTR);
        node.removeAttribute(STATE_ATTR);
      }
      if (toastTimer !== void 0) {
        clearTimeout(toastTimer);
        toastTimer = void 0;
      }
      store = void 0;
      lastAppliedVersion = -1;
      ctx.diagnostics.info("Hidden posts destroyed");
    },
    getStatus() {
      return {
        ok: true,
        message: store ? `${store.size()} posts hidden` : "Hidden posts idle"
      };
    }
  };
  function getHiddenPostStore() {
    return store;
  }
  async function undoLastHide(ctx) {
    if (!store) {
      return null;
    }
    const entry = await store.undoLast();
    if (entry) {
      ctx.requestApply();
      void ctx.auditLog.record("post.unhide", { key: entry.key });
    }
    return entry;
  }
  async function clearHiddenPosts(ctx) {
    if (!store) {
      return 0;
    }
    const removed = await store.clear();
    ctx.requestApply();
    void ctx.auditLog.record("post.hide.cleared", { removed });
    return removed;
  }
  function applyRootClass(ctx) {
    document.documentElement.classList.toggle(
      "av-hide-posts-enabled",
      ctx.settings.hidden.enabled
    );
  }
  function surfaceMatches(ctx) {
    const surfaces = ctx.settings.hidden.surfaces;
    return surfaces.includes(ctx.route.surface);
  }
  function scan(root, ctx) {
    if (!store || !ctx.settings.hidden.enabled || !surfaceMatches(ctx)) {
      return;
    }
    for (const article of collectArticles(root)) {
      processArticle(article, ctx);
    }
  }
  function collectArticles(root) {
    const found = [];
    if (root instanceof Element && root.matches(ARTICLE_SELECTOR)) {
      found.push(root);
    }
    if ("querySelectorAll" in root) {
      for (const article of Array.from(root.querySelectorAll(ARTICLE_SELECTOR))) {
        found.push(article);
      }
    }
    return found;
  }
  function processArticle(article, ctx) {
    if (!store) {
      return;
    }
    const stateStamp = String(store.version());
    if (article.getAttribute(STATE_ATTR) === stateStamp) {
      return;
    }
    const key = resolvePostKey(article);
    article.setAttribute(STATE_ATTR, stateStamp);
    if (!key) {
      return;
    }
    if (store.has(key)) {
      collapse(article);
      return;
    }
    reveal(article);
    if (ctx.settings.hidden.buttons) {
      ensureButton(article, key, ctx);
    }
  }
  function resolvePostKey(article) {
    const cached = article.getAttribute(KEY_ATTR);
    if (cached) {
      return cached;
    }
    const key = derivePostKey(readIdentity(article));
    if (key) {
      article.setAttribute(KEY_ATTR, key);
    }
    return key;
  }
  function readIdentity(article) {
    return {
      tweetId: readTweetId2(article),
      handle: readHandle2(article),
      text: readText2(article)
    };
  }
  function readTweetId2(article) {
    for (const link of Array.from(article.querySelectorAll('a[href*="/status/"]'))) {
      const match = /\/status\/(\d{1,25})/.exec(link.getAttribute("href") ?? "");
      if (match?.[1]) {
        return match[1];
      }
    }
    return null;
  }
  function readHandle2(article) {
    const userName = article.querySelector('[data-testid="User-Name"]');
    for (const link of Array.from(userName?.querySelectorAll("a[href]") ?? [])) {
      const handle = handleFromHref(link.getAttribute("href"));
      if (handle) {
        return handle;
      }
    }
    return null;
  }
  function readText2(article) {
    const nodes = article.querySelectorAll('[data-testid="tweetText"]');
    if (nodes.length > 0) {
      return Array.from(nodes).map((node) => node.textContent ?? "").join(" ");
    }
    return article.textContent ?? "";
  }
  function collapseTarget(article) {
    return article.closest(CELL_SELECTOR) ?? article;
  }
  function collapse(article) {
    const target = collapseTarget(article);
    target.setAttribute(HIDDEN_ATTR, "1");
    article.querySelector(`[${BUTTON_ATTR}]`)?.remove();
    nudgeReflow();
  }
  function reveal(article) {
    const target = collapseTarget(article);
    if (target.hasAttribute(HIDDEN_ATTR)) {
      target.removeAttribute(HIDDEN_ATTR);
      nudgeReflow();
    }
  }
  function nudgeReflow() {
    if (reflowHandle !== void 0 || typeof requestAnimationFrame !== "function") {
      return;
    }
    reflowHandle = requestAnimationFrame(() => {
      reflowHandle = void 0;
      globalThis.dispatchEvent(new Event("resize"));
    });
  }
  function ensureButton(article, key, ctx) {
    if (article.querySelector(`[${BUTTON_ATTR}]`)) {
      return;
    }
    const button2 = document.createElement("button");
    button2.type = "button";
    button2.className = "av-hide-button";
    button2.setAttribute(BUTTON_ATTR, "1");
    button2.textContent = "Hide";
    button2.title = "Hide this post \u2014 Aviary keeps it hidden on future visits";
    button2.setAttribute("aria-label", "Hide this post");
    button2.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void hidePost(article, key, button2, ctx);
    });
    const caret = article.querySelector('[data-testid="caret"]');
    if (caret?.parentElement) {
      caret.parentElement.insertBefore(button2, caret);
      return;
    }
    const userName = article.querySelector('[data-testid="User-Name"]');
    if (userName) {
      userName.append(button2);
      return;
    }
    article.prepend(button2);
  }
  async function hidePost(article, key, button2, ctx) {
    if (!store) {
      return;
    }
    button2.disabled = true;
    const identity = readIdentity(article);
    try {
      const entry = await store.hide({ ...identity, key }, ctx.settings.hidden.maxEntries);
      lastAppliedVersion = store.version();
      collapse(article);
      if (entry) {
        ctx.diagnostics.info("Post hidden", { key, handle: entry.handle });
        void ctx.auditLog.record("post.hide", { key });
        showToast(`Post hidden \u2014 ${store.size()} stored`, ctx);
      }
    } catch (error) {
      button2.disabled = false;
      ctx.diagnostics.error("Could not hide post", errorDetails2(error));
      showToast("Could not save the hidden post. Storage rejected the write.", ctx);
    }
  }
  function showToast(message, ctx) {
    const shadow = ensureToastHost();
    const toastHost = document.getElementById(TOAST_HOST_ID);
    if (toastHost) {
      toastHost.dataset.avMotion = reduceMotion(ctx) ? "reduce" : "full";
    }
    const card = shadow.querySelector(".av-toast");
    const text = shadow.querySelector(".av-toast-text");
    const undo = shadow.querySelector(".av-toast-undo");
    if (!(card instanceof HTMLElement) || !(text instanceof HTMLElement) || !(undo instanceof HTMLButtonElement)) {
      return;
    }
    text.textContent = message;
    undo.disabled = false;
    undo.onclick = () => {
      undo.disabled = true;
      void undoLastHide(ctx).then((entry) => {
        text.textContent = entry ? "Post restored." : "Nothing left to restore.";
        scheduleToastDismiss(card, 2500);
      }).catch((error) => {
        ctx.diagnostics.error("Could not restore post", errorDetails2(error));
        text.textContent = "Could not restore that post.";
        scheduleToastDismiss(card, 4e3);
      });
    };
    card.classList.add("is-open");
    scheduleToastDismiss(card, TOAST_TIMEOUT_MS);
  }
  function reduceMotion(ctx) {
    if (ctx.settings.accessibility.reduceMotion === "always") return true;
    if (ctx.settings.accessibility.reduceMotion === "never") return false;
    return globalThis.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  }
  function scheduleToastDismiss(card, delay2) {
    if (toastTimer !== void 0) {
      clearTimeout(toastTimer);
    }
    toastTimer = setTimeout(() => {
      card.classList.remove("is-open");
      toastTimer = void 0;
    }, delay2);
  }
  function ensureToastHost() {
    const existing = document.getElementById(TOAST_HOST_ID);
    if (existing?.shadowRoot) {
      return existing.shadowRoot;
    }
    const host = document.createElement("div");
    host.id = TOAST_HOST_ID;
    host.dataset.avOwned = "true";
    document.documentElement.append(host);
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = TOAST_CSS;
    const card = document.createElement("div");
    card.className = "av-toast";
    card.setAttribute("role", "status");
    card.setAttribute("aria-live", "polite");
    const text = document.createElement("span");
    text.className = "av-toast-text";
    const undo = document.createElement("button");
    undo.type = "button";
    undo.className = "av-toast-undo";
    undo.textContent = "Undo";
    card.append(text, undo);
    shadow.append(style, card);
    return shadow;
  }
  function ensureStyle() {
    if (document.getElementById(STYLE_ID2)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID2;
    style.textContent = HIDDEN_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  function errorDetails2(error) {
    if (error instanceof Error) {
      return { name: error.name, message: error.message };
    }
    return { message: String(error) };
  }
  var HIDDEN_CSS = `
html.av-hide-posts-enabled [${HIDDEN_ATTR}="1"] {
  display: none !important;
}

.av-hide-button {
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  margin-right: 4px;
  padding: 2px 8px;
  border: 1px solid color-mix(in srgb, var(--av-muted, rgb(132, 139, 145)) 55%, transparent);
  border-radius: 6px;
  background: transparent;
  color: var(--av-muted, rgb(132, 139, 145));
  cursor: pointer;
  font: 700 11px/1.1 TwitterChirp, Inter, ui-sans-serif, system-ui, sans-serif;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  /* Resting state stays legible on its own: at 0.4 the label measured 1.56:1, which is
     invisible in practice and unreachable on touch, where there is no hover to reveal it. */
  opacity: 0.75;
  transition: opacity 120ms ease, color 120ms ease, border-color 120ms ease;
}

article[data-testid="tweet"]:hover .av-hide-button,
article[data-testid="tweet"]:focus-within .av-hide-button,
.av-hide-button:focus-visible {
  opacity: 1;
}

/* No hover to reveal on touch, so the control is always at full strength. */
@media (hover: none) {
  .av-hide-button {
    opacity: 1;
  }
}

.av-hide-button:focus-visible {
  outline: 2px solid var(--av-accent, rgb(29, 155, 240));
  outline-offset: 2px;
}

.av-hide-button:hover {
  border-color: color-mix(in srgb, rgb(244, 33, 46) 70%, transparent);
  color: rgb(244, 33, 46);
}

.av-hide-button[disabled] {
  cursor: default;
  opacity: 0.3;
}
`;
  var TOAST_CSS = `
.av-toast {
  position: fixed;
  right: 16px;
  bottom: 76px;
  z-index: 2147483000;
  display: flex;
  align-items: center;
  gap: 12px;
  max-width: 320px;
  padding: 10px 12px;
  border: 1px solid var(--av-border, rgb(47, 51, 54));
  border-radius: 10px;
  background: color-mix(in srgb, var(--av-surface-raised, rgb(22, 24, 28)) 97%, black);
  color: var(--av-text, rgb(239, 243, 244));
  font: 500 13px/1.35 TwitterChirp, Inter, ui-sans-serif, system-ui, sans-serif;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45);
  opacity: 0;
  pointer-events: none;
  transform: translateY(8px);
  transition: opacity 140ms ease, transform 140ms ease;
}

.av-toast.is-open {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.av-toast-text {
  flex: 1 1 auto;
}

.av-toast-undo {
  flex: 0 0 auto;
  min-height: 32px;
  padding: 4px 12px;
  border: 1px solid var(--av-accent, rgb(29, 155, 240));
  border-radius: 6px;
  background: transparent;
  color: var(--av-accent, rgb(29, 155, 240));
  cursor: pointer;
  font: 700 12px/1.1 inherit;
}

.av-toast-undo:focus-visible {
  outline: 2px solid var(--av-accent, rgb(29, 155, 240));
  outline-offset: 2px;
}

.av-toast-undo[disabled] {
  border-color: var(--av-border, rgb(47, 51, 54));
  color: var(--av-muted, rgb(132, 139, 145));
  cursor: default;
}

@media (pointer: coarse) {
  .av-toast-undo {
    min-height: 44px;
    padding: 8px 16px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .av-toast {
    transition: none;
    transform: none;
  }
}

:host([data-av-motion="reduce"]) .av-toast {
  transition: none;
  transform: none;
}
`;

  // src/features/export/warc.ts
  var ENCODER3 = new TextEncoder();
  function buildWarcArchive(records) {
    const blocks = [];
    blocks.push(formatRecord({
      url: "metadata://aviary",
      mime: "application/json",
      body: JSON.stringify({
        generator: "Aviary",
        generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        count: records.length
      }),
      recordType: "metadata"
    }));
    for (const record of records) {
      const summary = JSON.stringify(record, null, 2);
      blocks.push(formatRecord({
        url: record.permalink ?? `tweet://${record.tweetId ?? "unknown"}`,
        mime: "application/json",
        body: summary,
        recordType: "resource"
      }));
      for (const media of record.media) {
        blocks.push(formatRecord({
          url: media.url,
          mime: media.type ?? "application/octet-stream",
          body: `Aviary captured the resource URL for ${media.kind} ${media.url} without re-downloading the body. Use the Aviary media downloader to fetch the bytes if needed.`,
          recordType: "metadata"
        }));
      }
    }
    const totalSize = blocks.reduce((acc, block) => acc + block.length, 0);
    const out = new Uint8Array(totalSize);
    let cursor = 0;
    for (const block of blocks) {
      out.set(block, cursor);
      cursor += block.length;
    }
    return {
      filename: "tweets.warc",
      contentType: "application/warc",
      data: out
    };
  }
  function sanitizeHeaderValue(value) {
    let out = "";
    for (const ch of value) {
      const code = ch.codePointAt(0) ?? 0;
      out += code < 32 || code === 127 ? " " : ch;
    }
    return out.split(" ").filter((part) => part.length > 0).join(" ");
  }
  function formatRecord(input) {
    const recordType = input.recordType ?? "resource";
    const recordedAt = (input.recordedAt ?? /* @__PURE__ */ new Date()).toISOString().replace(/\.[0-9]{3}Z$/, "Z");
    const id = `<urn:uuid:${randomUuid()}>`;
    const bodyBytes = typeof input.body === "string" ? ENCODER3.encode(input.body) : input.body;
    const url = sanitizeHeaderValue(input.url);
    const mime = sanitizeHeaderValue(input.mime);
    const headerLines = [
      "WARC/1.1",
      `WARC-Type: ${recordType}`,
      // A record with no usable target still has to carry the field, or readers reject it.
      `WARC-Target-URI: ${url.length > 0 ? url : "urn:aviary:unknown"}`,
      `WARC-Date: ${recordedAt}`,
      `WARC-Record-ID: ${id}`,
      `Content-Type: ${mime.length > 0 ? mime : "application/octet-stream"}`,
      `Content-Length: ${bodyBytes.length}`
    ];
    const headerBytes = ENCODER3.encode(`${headerLines.join("\r\n")}\r
\r
`);
    const trailer = ENCODER3.encode("\r\n\r\n");
    const block = new Uint8Array(headerBytes.length + bodyBytes.length + trailer.length);
    block.set(headerBytes, 0);
    block.set(bodyBytes, headerBytes.length);
    block.set(trailer, headerBytes.length + bodyBytes.length);
    return block;
  }
  function randomUuid() {
    if (typeof globalThis.crypto?.randomUUID === "function") {
      return globalThis.crypto.randomUUID();
    }
    const random = (length) => Array.from({ length }, () => Math.floor(Math.random() * 16).toString(16)).join("");
    return `${random(8)}-${random(4)}-4${random(3)}-a${random(3)}-${random(12)}`;
  }

  // src/features/integrations/aria2.ts
  var ARIA2_HISTORY_KEY = "aviary.aria2.history.v1";
  var ARIA2_HISTORY_LIMIT = 1e3;
  async function addUriToAria2(config, request) {
    assertOutboundAllowed("The Aria2 handoff");
    if (!config.endpoint) {
      return { ok: false, error: "Aria2 endpoint not configured" };
    }
    const token = config.secret ? `token:${config.secret}` : void 0;
    const params = token ? [token] : [];
    params.push([request.url]);
    params.push({ out: request.filename });
    const body = JSON.stringify({
      jsonrpc: "2.0",
      id: `aviary-${Date.now()}`,
      method: "aria2.addUri",
      params
    });
    try {
      const response = await fetch(`${config.endpoint}/jsonrpc`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body
      });
      if (!response.ok) {
        return { ok: false, error: `Aria2 HTTP ${response.status}` };
      }
      const payload = await response.json();
      if (payload?.error) {
        return { ok: false, error: payload.error.message ?? "Aria2 error" };
      }
      const result = { ok: true };
      if (typeof payload?.result === "string") result.gid = payload.result;
      return result;
    } catch (error) {
      return { ok: false, error: String(error?.message ?? error) };
    }
  }
  function shouldHandoffToAria2(integration, estimatedBytes) {
    if (!integration.enabled || !integration.endpoint) return false;
    if (estimatedBytes === null) return true;
    return estimatedBytes >= integration.minBytes;
  }
  var Aria2History = class {
    #storage;
    #limit;
    #entries = [];
    #loaded = false;
    constructor(storage, limit = ARIA2_HISTORY_LIMIT) {
      this.#storage = storage;
      this.#limit = Math.max(50, Math.trunc(limit));
    }
    async load() {
      if (this.#loaded) return;
      const fallback = { entries: [] };
      const raw = await this.#storage.get(ARIA2_HISTORY_KEY, fallback);
      const entries = Array.isArray(raw?.entries) ? raw.entries : [];
      this.#entries = entries.filter(isHistoryEntry).slice(-this.#limit);
      this.#loaded = true;
    }
    hasUrl(url) {
      return this.#entries.some((entry) => entry.url === url);
    }
    snapshot() {
      return { entries: this.#entries.map((entry) => ({ ...entry })) };
    }
    async rememberQueued(entry) {
      await this.load();
      if (this.hasUrl(entry.url)) return;
      this.#entries.push({
        ...entry,
        status: "queued",
        queuedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      while (this.#entries.length > this.#limit) {
        this.#entries.shift();
      }
      await this.#persist();
    }
    async reconcile(config) {
      await this.load();
      let completed = 0;
      let removed = 0;
      const retained = [];
      for (const entry of this.#entries) {
        if (entry.status !== "queued") {
          retained.push(entry);
          continue;
        }
        const status = await tellAria2Status(config, entry.gid);
        if (status === "complete") {
          retained.push({ ...entry, status: "complete", completedAt: (/* @__PURE__ */ new Date()).toISOString() });
          completed += 1;
        } else if (status === "error" || status === "removed") {
          removed += 1;
        } else {
          retained.push(entry);
        }
      }
      this.#entries = retained;
      if (completed > 0 || removed > 0) {
        await this.#persist();
      }
      return { completed, removed };
    }
    async clear() {
      this.#entries = [];
      this.#loaded = true;
      await this.#persist();
    }
    async #persist() {
      try {
        await this.#storage.set(ARIA2_HISTORY_KEY, this.snapshot());
      } catch {
      }
    }
  };
  async function tellActiveAria2(config) {
    assertOutboundAllowed("The Aria2 sweep");
    const payload = await callAria2(config, "aria2.tellActive", []);
    if (!Array.isArray(payload)) return [];
    return payload.map((row) => ({
      gid: typeof row.gid === "string" ? row.gid : "",
      status: typeof row.status === "string" ? row.status : "unknown",
      totalLength: Number(row.totalLength ?? 0),
      completedLength: Number(row.completedLength ?? 0),
      files: Array.isArray(row.files) ? row.files.map((file) => typeof file === "object" && file !== null ? file : {}).map((file) => ({ path: typeof file.path === "string" ? file.path : "" })) : []
    }));
  }
  async function removeAria2Download(config, gid) {
    assertOutboundAllowed("The Aria2 cancel");
    if (!gid) return { ok: false, error: "Missing GID" };
    const payload = await callAria2(config, "aria2.remove", [gid]);
    if (typeof payload === "string") {
      return { ok: true, gid: payload };
    }
    return { ok: false, error: "Aria2 did not return a GID" };
  }
  async function tellAria2Status(config, gid) {
    assertOutboundAllowed("The Aria2 status check");
    if (!gid) return null;
    if (!config.endpoint) return null;
    const token = config.secret ? `token:${config.secret}` : void 0;
    const params = token ? [token, gid] : [gid];
    try {
      const response = await fetch(`${config.endpoint}/jsonrpc`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: `aviary-${Date.now()}`,
          method: "aria2.tellStatus",
          params
        })
      });
      if (!response.ok) return null;
      const payload = await response.json();
      if (payload.error) return "removed";
      return typeof payload.result?.status === "string" ? payload.result.status : null;
    } catch {
      return null;
    }
  }
  async function callAria2(config, method, args) {
    if (!config.endpoint) return null;
    const token = config.secret ? `token:${config.secret}` : void 0;
    const params = token ? [token, ...args] : args;
    const body = JSON.stringify({
      jsonrpc: "2.0",
      id: `aviary-${Date.now()}`,
      method,
      params
    });
    try {
      const response = await fetch(`${config.endpoint}/jsonrpc`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body
      });
      if (!response.ok) return null;
      const json = await response.json();
      return json?.result ?? null;
    } catch {
      return null;
    }
  }
  function isHistoryEntry(value) {
    if (typeof value !== "object" || value === null) return false;
    const entry = value;
    return typeof entry.gid === "string" && typeof entry.url === "string" && typeof entry.filename === "string" && (entry.status === "queued" || entry.status === "complete") && typeof entry.queuedAt === "string" && (entry.completedAt === void 0 || typeof entry.completedAt === "string");
  }

  // src/features/integrations/crosspost.ts
  function splitForThread(text) {
    const blocks = text.split(/\r?\n\s*\r?\n/).map((block) => block.trim()).filter((block) => block.length > 0);
    return blocks.length === 0 ? [text.trim()].filter((block) => block.length > 0) : blocks;
  }
  async function crosspost(integrations, request) {
    assertOutboundAllowed("The crosspost");
    if (request.text.trim().length === 0) {
      return { ok: false, target: request.target, error: "Empty post body" };
    }
    const segments = request.asThread ? splitForThread(request.text) : [request.text];
    if (segments.length === 0) {
      return { ok: false, target: request.target, error: "Empty post body" };
    }
    if (request.target === "bluesky") {
      return postToBluesky(integrations.bluesky, segments, request.attachment);
    }
    return postToMastodon(integrations.mastodon, segments, request.attachment);
  }
  async function postToBluesky(config, segments, attachment) {
    if (!config.enabled) return { ok: false, target: "bluesky", error: "Bluesky integration disabled" };
    if (!config.service || !config.handle || !config.appPassword) {
      return { ok: false, target: "bluesky", error: "Bluesky credentials missing" };
    }
    try {
      const session = await callBluesky(config.service, "com.atproto.server.createSession", {
        identifier: config.handle,
        password: config.appPassword
      });
      if (!session || typeof session.accessJwt !== "string" || typeof session.did !== "string") {
        return { ok: false, target: "bluesky", error: "Bluesky session response was malformed" };
      }
      const uploadedBlob = attachment ? await uploadBlueskyImage(config.service, session.accessJwt, attachment) : null;
      let rootRef = null;
      let parentRef = null;
      let firstUri = null;
      for (const segment of segments) {
        const record = {
          text: segment.slice(0, 300),
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          $type: "app.bsky.feed.post"
        };
        if (rootRef && parentRef) {
          record.reply = {
            root: rootRef,
            parent: parentRef
          };
        }
        if (uploadedBlob && !rootRef) {
          record.embed = {
            $type: "app.bsky.embed.images",
            images: [{ alt: "", image: uploadedBlob }]
          };
        }
        const response = await callBluesky(
          config.service,
          "com.atproto.repo.createRecord",
          {
            repo: session.did,
            collection: "app.bsky.feed.post",
            record
          },
          session.accessJwt
        );
        const uri = typeof response?.uri === "string" ? response.uri : null;
        const cid = typeof response?.cid === "string" ? response.cid : null;
        if (!uri || !cid) {
          return { ok: false, target: "bluesky", error: "Bluesky post response was malformed" };
        }
        if (!rootRef) {
          rootRef = { uri, cid };
          firstUri = uri;
        }
        parentRef = { uri, cid };
      }
      const result = {
        ok: true,
        target: "bluesky",
        posts: segments.length
      };
      if (firstUri) result.url = deriveBlueskyUrl(firstUri, config.handle);
      return result;
    } catch (error) {
      return { ok: false, target: "bluesky", error: String(error?.message ?? error) };
    }
  }
  async function postToMastodon(config, segments, attachment) {
    if (!config.enabled) return { ok: false, target: "mastodon", error: "Mastodon integration disabled" };
    if (!config.instance || !config.token) {
      return { ok: false, target: "mastodon", error: "Mastodon credentials missing" };
    }
    try {
      const mediaId = attachment ? await uploadMastodonMedia(config.instance, config.token, attachment) : null;
      let inReplyTo = null;
      let firstUrl = null;
      for (const segment of segments) {
        const body = {
          status: segment,
          visibility: config.visibility
        };
        if (inReplyTo) body.in_reply_to_id = inReplyTo;
        if (mediaId && !inReplyTo) body.media_ids = [mediaId];
        const response = await fetch(`${config.instance}/api/v1/statuses`, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            authorization: `Bearer ${config.token}`
          },
          body: JSON.stringify(body)
        });
        if (!response.ok) {
          return { ok: false, target: "mastodon", error: `Mastodon HTTP ${response.status}` };
        }
        const payload = await response.json();
        if (typeof payload?.id !== "string") {
          return { ok: false, target: "mastodon", error: "Mastodon response missing status id" };
        }
        inReplyTo = payload.id;
        if (typeof payload?.url === "string" && firstUrl === null) {
          firstUrl = payload.url;
        }
      }
      const result = { ok: true, target: "mastodon", posts: segments.length };
      if (firstUrl) result.url = firstUrl;
      return result;
    } catch (error) {
      return { ok: false, target: "mastodon", error: String(error?.message ?? error) };
    }
  }
  async function uploadBlueskyImage(service, accessJwt, attachment) {
    const media = await fetchAttachment(attachment);
    if (!media.contentType.startsWith("image/")) {
      throw new Error("Bluesky crosspost attachments must be images");
    }
    const response = await fetch(`${service}/xrpc/com.atproto.repo.uploadBlob`, {
      method: "POST",
      headers: {
        authorization: `Bearer ${accessJwt}`,
        "content-type": media.contentType
      },
      body: media.blob
    });
    if (!response.ok) {
      throw new Error(`Bluesky media upload HTTP ${response.status}`);
    }
    const payload = await response.json();
    if (!isRecord3(payload.blob)) {
      throw new Error("Bluesky media response was malformed");
    }
    return payload.blob;
  }
  async function uploadMastodonMedia(instance, token, attachment) {
    const media = await fetchAttachment(attachment);
    const form = new FormData();
    form.append("file", media.blob, safeFilename(attachment.filename));
    const response = await fetch(`${instance}/api/v1/media`, {
      method: "POST",
      headers: { authorization: `Bearer ${token}` },
      body: form
    });
    if (!response.ok) {
      throw new Error(`Mastodon media upload HTTP ${response.status}`);
    }
    const payload = await response.json();
    if (typeof payload.id !== "string" || payload.id.length === 0) {
      throw new Error("Mastodon media response missing id");
    }
    return payload.id;
  }
  async function fetchAttachment(attachment) {
    const response = await fetch(attachment.url);
    if (!response.ok) {
      throw new Error(`Media attachment HTTP ${response.status}`);
    }
    const contentType = normalizeContentType(response.headers.get("content-type")) ?? inferContentType(attachment);
    const bytes = await response.arrayBuffer();
    if (bytes.byteLength === 0) {
      throw new Error("Media attachment was empty");
    }
    return { blob: new Blob([bytes], { type: contentType }), contentType };
  }
  function normalizeContentType(value) {
    const type = value?.split(";", 1)[0]?.trim().toLowerCase();
    return type && /^[a-z0-9.+-]+\/[a-z0-9.+-]+$/.test(type) ? type : null;
  }
  function inferContentType(attachment) {
    const filename = attachment.filename.toLowerCase();
    if (filename.endsWith(".png")) return "image/png";
    if (filename.endsWith(".gif")) return "image/gif";
    if (filename.endsWith(".webp")) return "image/webp";
    if (filename.endsWith(".mp4")) return "video/mp4";
    if (filename.endsWith(".webm")) return "video/webm";
    return "image/jpeg";
  }
  function safeFilename(value) {
    const cleaned = value.replace(/[\\/\u0000-\u001f]/g, "_").trim();
    return cleaned.slice(0, 160) || "aviary-media";
  }
  function isRecord3(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  async function callBluesky(service, nsid, input, bearer) {
    const headers = { "content-type": "application/json" };
    if (bearer) headers.authorization = `Bearer ${bearer}`;
    const response = await fetch(`${service}/xrpc/${nsid}`, {
      method: "POST",
      headers,
      body: JSON.stringify(input)
    });
    if (!response.ok) {
      throw new Error(`Bluesky ${nsid} HTTP ${response.status}`);
    }
    return await response.json();
  }
  function deriveBlueskyUrl(uri, handle) {
    const match = /^at:\/\/[^/]+\/app\.bsky\.feed\.post\/(.+)$/.exec(uri);
    const rkey = match?.[1];
    return rkey ? `https://bsky.app/profile/${handle}/post/${rkey}` : `https://bsky.app/profile/${handle}`;
  }
  function readComposerText() {
    const composer = document.querySelector('[data-testid="tweetTextarea_0"]');
    return composer?.textContent?.trim() ?? "";
  }

  // src/features/core/integration-errors.ts
  var ERROR_ACTIONS = /* @__PURE__ */ new Set([
    "media.download.failed",
    "export.start",
    "export.complete"
  ]);
  function recentIntegrationErrors(entries, limit = 10) {
    const errors = [];
    for (let i = entries.length - 1; i >= 0; i--) {
      const entry = entries[i];
      if (!entry) continue;
      if (!ERROR_ACTIONS.has(entry.action) && entry.action !== "diagnostics.copy") continue;
      const detail = entry.detail ?? {};
      const failed = detail.error || detail.ok === false || entry.action === "media.download.failed";
      if (!failed) continue;
      errors.push({
        at: entry.at,
        kind: pickKind(entry.action, detail),
        message: String(detail.error ?? detail.message ?? entry.action),
        details: detail
      });
      if (errors.length >= limit) break;
    }
    return errors;
  }
  function pickKind(action, detail) {
    if (typeof detail.target === "string") return `crosspost:${detail.target}`;
    if (typeof detail.kind === "string") return String(detail.kind);
    if (action === "media.download.failed") return "media";
    return action;
  }

  // src/features/export/zip-reader.ts
  var LOCAL_HEADER = 67324752;
  var EOCD_SIGNATURE = 101010256;
  var ZIP64_LOCATOR = 117853008;
  var TEXT_DECODER = new TextDecoder();
  var UnsupportedZipMethodError = class extends Error {
    constructor(method, filename) {
      super(`Unsupported ZIP compression method ${method} for "${filename}"`);
      this.name = "UnsupportedZipMethodError";
    }
  };
  function readStoreZip(data) {
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    const eocd = locateEOCD(view, data.length);
    if (eocd === -1) {
      return [];
    }
    const entryCount = view.getUint16(eocd + 10, true);
    const centralOffset = view.getUint32(eocd + 16, true);
    const results = [];
    let cursor = centralOffset;
    for (let i = 0; i < entryCount; i++) {
      if (view.getUint32(cursor, true) !== 33639248) {
        break;
      }
      const method = view.getUint16(cursor + 10, true);
      const compressedSize = view.getUint32(cursor + 20, true);
      const uncompressedSize = view.getUint32(cursor + 24, true);
      const nameLength = view.getUint16(cursor + 28, true);
      const extraLength = view.getUint16(cursor + 30, true);
      const commentLength = view.getUint16(cursor + 32, true);
      const localOffset = view.getUint32(cursor + 42, true);
      const filename = TEXT_DECODER.decode(data.subarray(cursor + 46, cursor + 46 + nameLength));
      cursor += 46 + nameLength + extraLength + commentLength;
      if (filename.endsWith("/")) {
        continue;
      }
      if (method !== 0) {
        throw new UnsupportedZipMethodError(method, filename);
      }
      if (view.getUint32(localOffset, true) !== LOCAL_HEADER) {
        continue;
      }
      const localNameLength = view.getUint16(localOffset + 26, true);
      const localExtraLength = view.getUint16(localOffset + 28, true);
      const fileStart = localOffset + 30 + localNameLength + localExtraLength;
      const fileEnd = fileStart + compressedSize;
      const fileData = data.subarray(fileStart, fileEnd);
      const declaredCrc = view.getUint32(cursor - (extraLength + commentLength + nameLength + 46) + 16, true);
      const actualCrc = crc32(fileData);
      const expectedSize = uncompressedSize;
      results.push({
        filename,
        data: new Uint8Array(fileData),
        crcOk: declaredCrc === actualCrc && fileData.length === expectedSize
      });
    }
    return results;
  }
  function locateEOCD(view, length) {
    for (let i = length - 22; i >= Math.max(0, length - 65535 - 22); i--) {
      if (view.getUint32(i, true) === EOCD_SIGNATURE) {
        return i;
      }
      if (view.getUint32(i, true) === ZIP64_LOCATOR) {
        continue;
      }
    }
    return -1;
  }

  // src/features/library/archive-import.ts
  var TEXT_DECODER2 = new TextDecoder();
  function importOfficialArchive(buffer, surface = "archive") {
    const warnings = [];
    const errors = [];
    const filesParsed = [];
    const records = [];
    let entries;
    try {
      entries = readStoreZip(buffer);
    } catch (error) {
      errors.push(error.message);
      return { records, warnings, errors, filesParsed };
    }
    if (entries.length === 0) {
      errors.push("Archive contained no readable entries (compression methods other than STORE are not supported).");
      return { records, warnings, errors, filesParsed };
    }
    for (const entry of entries) {
      const lower = entry.filename.toLowerCase();
      if (!isInterestingFile(lower)) {
        continue;
      }
      if (!entry.crcOk) {
        warnings.push(`${entry.filename}: CRC32 mismatch \u2014 proceeding best effort.`);
      }
      const text = safeDecode(entry.data, errors, entry.filename);
      if (!text) continue;
      filesParsed.push(entry.filename);
      const payload = stripPrefix(text);
      let parsed;
      try {
        parsed = JSON.parse(payload);
      } catch (error) {
        warnings.push(`${entry.filename}: JSON parse failed (${error.message})`);
        continue;
      }
      if (lower.includes("tweets.js") || lower.includes("tweets-part") || lower.endsWith("/tweet.js")) {
        records.push(...mapTweets(parsed, surface));
      } else if (lower.includes("like.js")) {
        records.push(...mapLikes(parsed, surface));
      }
    }
    return { records, warnings, errors, filesParsed };
  }
  function isInterestingFile(name) {
    return name.endsWith("tweets.js") || name.endsWith("tweet.js") || name.includes("tweets-part") || name.endsWith("like.js");
  }
  function safeDecode(data, errors, filename) {
    try {
      return TEXT_DECODER2.decode(data);
    } catch (error) {
      errors.push(`${filename}: decode failed (${error.message})`);
      return null;
    }
  }
  function stripPrefix(text) {
    const match = /^[^=]*=\s*/.exec(text);
    return match ? text.slice(match[0].length) : text;
  }
  function mapTweets(parsed, surface) {
    if (!Array.isArray(parsed)) return [];
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const out = [];
    for (const entry of parsed) {
      const tweet = isRecord4(entry) && isRecord4(entry.tweet) ? entry.tweet : entry;
      if (!isRecord4(tweet)) continue;
      const id = stringField(tweet, "id_str", "id");
      const text = stringField(tweet, "full_text", "text") ?? "";
      const createdAt = stringField(tweet, "created_at") ?? now;
      const record = {
        tweetId: id,
        handle: stringFromEntities(tweet) ?? null,
        displayName: null,
        text,
        capturedAt: createdAt,
        surface,
        media: [],
        permalink: id ? `https://x.com/i/web/status/${id}` : null
      };
      out.push(record);
    }
    return out;
  }
  function mapLikes(parsed, surface) {
    if (!Array.isArray(parsed)) return [];
    const out = [];
    for (const entry of parsed) {
      const like = isRecord4(entry) && isRecord4(entry.like) ? entry.like : entry;
      if (!isRecord4(like)) continue;
      const id = stringField(like, "tweetId", "id");
      const text = stringField(like, "fullText", "text") ?? "";
      const record = {
        tweetId: id,
        handle: null,
        displayName: null,
        text,
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        surface: `${surface}.likes`,
        media: [],
        permalink: id ? `https://x.com/i/web/status/${id}` : null
      };
      out.push(record);
    }
    return out;
  }
  function stringField(record, ...keys) {
    for (const key of keys) {
      const value = record[key];
      if (typeof value === "string" && value.length > 0) {
        return value;
      }
    }
    return null;
  }
  function stringFromEntities(tweet) {
    const entities = tweet.entities;
    if (!isRecord4(entities)) return null;
    const userMentions = entities.user_mentions;
    if (!Array.isArray(userMentions) || userMentions.length === 0) return null;
    const first = userMentions[0];
    if (!isRecord4(first)) return null;
    return stringField(first, "screen_name");
  }
  function isRecord4(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // src/features/library/cleanup-preview.ts
  function previewCleanup(records, options = {}) {
    const whitelist = new Set((options.whitelistHandles ?? []).map((h) => h.toLowerCase()));
    const protectedIds = new Set(options.protectedTweetIds ?? []);
    const byBucket = {
      tweets: 0,
      retweets: 0,
      replies: 0,
      likes: 0,
      bookmarks: 0
    };
    let protectedCount = 0;
    const candidates = [];
    for (const record of records) {
      const bucket = classify(record, options.bucketHint);
      if (!bucket) continue;
      const handle = record.handle?.toLowerCase() ?? null;
      const isProtected = record.tweetId !== null && protectedIds.has(record.tweetId) || handle !== null && whitelist.has(handle);
      if (isProtected) {
        protectedCount += 1;
      }
      byBucket[bucket] += 1;
      candidates.push({
        bucket,
        tweetId: record.tweetId,
        handle: record.handle,
        text: record.text,
        permalink: record.permalink,
        reason: explain(bucket, record),
        protected: isProtected
      });
    }
    return {
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      candidates,
      byBucket,
      protectedCount
    };
  }
  function classify(record, hint) {
    if (hint) return hint;
    if (record.surface.includes("likes")) return "likes";
    if (record.surface.includes("bookmarks")) return "bookmarks";
    if (record.text.startsWith("RT @") || record.text.startsWith("Reposted ")) return "retweets";
    if (record.text.startsWith("@")) return "replies";
    return "tweets";
  }
  function explain(bucket, record) {
    switch (bucket) {
      case "retweets":
        return "Reposted content \u2014 author retains the original";
      case "replies":
        return "Reply to another account";
      case "likes":
        return "Imported from Likes archive";
      case "bookmarks":
        return "Imported from Bookmarks archive";
      case "tweets":
      default:
        return record.tweetId ? `Original post ${record.tweetId}` : "Original post";
    }
  }

  // src/features/library/cleanup-queue.ts
  var CLEANUP_QUEUE_KEY = "aviary.cleanupQueue.v1";
  var CLEANUP_QUEUE_LIMIT = 5e3;
  var EMPTY3 = { items: [], destructiveExecuted: false };
  var CleanupQueue = class {
    #storage;
    #limit;
    #state = EMPTY3;
    #loaded = false;
    constructor(storage, limit = CLEANUP_QUEUE_LIMIT) {
      this.#storage = storage;
      this.#limit = Math.max(50, limit);
    }
    async load() {
      if (this.#loaded) return;
      const stored = await this.#storage.get(CLEANUP_QUEUE_KEY, EMPTY3);
      this.#state = {
        items: Array.isArray(stored?.items) ? stored.items.filter(isQueueItem).slice(-this.#limit) : [],
        destructiveExecuted: stored?.destructiveExecuted === true
      };
      this.#loaded = true;
    }
    async enqueue(candidates) {
      await this.load();
      let added = 0;
      for (const candidate of candidates) {
        if (candidate.protected) continue;
        this.#state.items.push({
          ...candidate,
          id: `item-${Date.now()}-${this.#state.items.length}-${added}`,
          enqueuedAt: (/* @__PURE__ */ new Date()).toISOString(),
          status: "queued"
        });
        added += 1;
      }
      while (this.#state.items.length > this.#limit) {
        this.#state.items.shift();
      }
      await this.#persist();
      return added;
    }
    list(status) {
      if (!status) {
        return [...this.#state.items];
      }
      return this.#state.items.filter((item) => item.status === status);
    }
    size() {
      return this.#state.items.length;
    }
    async setStatus(id, status, note) {
      await this.load();
      const item = this.#state.items.find((entry) => entry.id === id);
      if (!item) return;
      item.status = status;
      item.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (note) item.reviewerNote = note;
      await this.#persist();
    }
    async clear() {
      this.#state = { items: [], destructiveExecuted: this.#state.destructiveExecuted };
      this.#loaded = true;
      await this.#persist();
    }
    /**
     * Aviary does not delete account data in v1.0.0. This flag exists to record
     * the deliberate refusal so future versions can flip it behind an explicit
     * destructive-action toggle. The current implementation always reports false.
     */
    destructiveAllowed() {
      return false;
    }
    async #persist() {
      try {
        await this.#storage.set(CLEANUP_QUEUE_KEY, this.#state);
      } catch {
      }
    }
  };
  function isQueueItem(value) {
    if (typeof value !== "object" || value === null) return false;
    const candidate = value;
    return typeof candidate.id === "string" && typeof candidate.enqueuedAt === "string" && typeof candidate.status === "string" && typeof candidate.bucket === "string";
  }

  // src/features/media/template.ts
  var FORBIDDEN = /[<>:"/\\|?*\u0000-\u001f]/g;
  var COLLAPSING_WHITESPACE = /\s+/g;
  function renderFilename(template, fields) {
    const datePart = formatDate(fields.date);
    const safeHandle = sanitizeSegment(fields.handle ?? "unknown");
    const safeText = sanitizeSegment(fields.text).slice(0, 60);
    const tweetId = sanitizeSegment(fields.tweetId ?? "0");
    const mediaId = sanitizeSegment(fields.mediaId ?? tweetId);
    const indexLabel = String(fields.index + 1).padStart(2, "0");
    const totalLabel = String(Math.max(fields.total, 1)).padStart(2, "0");
    const substitutions = {
      handle: safeHandle,
      tweetId,
      mediaId,
      index: indexLabel,
      total: totalLabel,
      date: datePart,
      text: safeText,
      ext: fields.ext.toLowerCase()
    };
    let name = template.replace(/\{(\w+)\}/g, (match, key) => {
      const value = substitutions[key];
      return value === void 0 ? match : value;
    }).replace(/[\\/]+/g, "/").trim();
    if (name.length === 0) {
      name = `${safeHandle}_${tweetId}_${indexLabel}`;
    }
    if (!name.toLowerCase().endsWith(`.${fields.ext.toLowerCase()}`)) {
      name = `${name}.${fields.ext.toLowerCase()}`;
    }
    return name;
  }
  function sanitizeSegment(value) {
    return value.replace(FORBIDDEN, "").replace(COLLAPSING_WHITESPACE, " ").trim();
  }
  function formatDate(date) {
    const y = date.getUTCFullYear();
    const m = String(date.getUTCMonth() + 1).padStart(2, "0");
    const d = String(date.getUTCDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  // src/features/media/downloader.ts
  var DOWNLOAD_PERMISSION_CODE = "downloads-permission-missing";
  var DownloadPermissionError = class extends Error {
    code = DOWNLOAD_PERMISSION_CODE;
    constructor(message = "Aviary needs the browser download permission to save this file.") {
      super(message);
      this.name = "DownloadPermissionError";
    }
  };
  function createDownloader(options = {}) {
    return async (request) => {
      if (options.integrations) {
        const aria = options.integrations.aria2;
        if (options.aria2History?.hasUrl(request.url)) {
          return { ok: true, via: "aria2", deduplicated: true };
        }
        if (shouldHandoffToAria2(aria, request.estimatedBytes ?? null)) {
          const result = await addUriToAria2(
            { endpoint: aria.endpoint, secret: aria.secret },
            { url: request.url, filename: request.filename }
          );
          if (result.ok) {
            if (result.gid && options.aria2History) {
              await options.aria2History.rememberQueued({
                gid: result.gid,
                url: request.url,
                filename: request.filename
              });
            }
            return { ok: true, via: "aria2", ...result.gid ? { gid: result.gid } : {} };
          }
        }
      }
      const gmResult = await tryGmDownload(request);
      if (gmResult) {
        return { ok: true, via: "gm" };
      }
      const extResult = await tryExtensionDownload(request);
      if (extResult.status === "ok") {
        return { ok: true, via: "extension" };
      }
      if (extResult.status === "needs-permission") {
        throw new DownloadPermissionError();
      }
      if (extResult.status === "failed") {
        throw new Error(extResult.error);
      }
      triggerAnchor(request);
      return isCrossOrigin(request.url) ? { ok: true, via: "anchor", degraded: true } : { ok: true, via: "anchor" };
    };
  }
  function isCrossOrigin(url) {
    if (/^(blob|data):/i.test(url)) {
      return false;
    }
    const base = typeof location === "undefined" ? void 0 : location.href;
    try {
      const parsed = new URL(url, base);
      return base === void 0 ? true : parsed.origin !== new URL(base).origin;
    } catch {
      return false;
    }
  }
  async function tryGmDownload(request) {
    const globals = globalThis;
    if (typeof globals.GM_download !== "function") {
      return false;
    }
    return await new Promise((resolve) => {
      try {
        globals.GM_download?.({
          url: request.url,
          name: request.filename,
          onload: () => resolve(true),
          onerror: () => resolve(false),
          ontimeout: () => resolve(false)
        });
      } catch {
        resolve(false);
      }
    });
  }
  async function tryExtensionDownload(request) {
    const runtime = globalThis.chrome?.runtime;
    if (!runtime?.sendMessage) {
      return { status: "unavailable" };
    }
    try {
      const response = await runtime.sendMessage({
        type: "AVIARY_DOWNLOAD",
        url: request.url,
        filename: request.filename
      });
      if (response?.ok === true) {
        return { status: "ok" };
      }
      if (response?.code === DOWNLOAD_PERMISSION_CODE) {
        return { status: "needs-permission" };
      }
      if (response === void 0) {
        return { status: "unavailable" };
      }
      return { status: "failed", error: response.error ?? "download failed" };
    } catch {
      return { status: "unavailable" };
    }
  }
  async function requestDownloadPermissionSurface() {
    const runtime = globalThis.chrome?.runtime;
    if (!runtime?.sendMessage) {
      return false;
    }
    try {
      const response = await runtime.sendMessage({ type: "AVIARY_OPEN_OPTIONS" });
      return response?.ok === true;
    } catch {
      return false;
    }
  }
  function triggerAnchor(request) {
    if (typeof document === "undefined") {
      return;
    }
    const anchor = document.createElement("a");
    anchor.href = request.url;
    anchor.download = request.filename;
    anchor.rel = "noopener noreferrer";
    anchor.target = "_blank";
    anchor.style.display = "none";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
  }

  // src/features/media/history.ts
  var MEDIA_HISTORY_KEY = "aviary.media.history.v1";
  var MEDIA_HISTORY_LIMIT = 1500;
  var MediaHistory = class {
    #storage;
    #limit;
    #onPersistError;
    #entries = [];
    #index = /* @__PURE__ */ new Set();
    #loaded = false;
    #loading;
    constructor(storage, limit = MEDIA_HISTORY_LIMIT, onPersistError) {
      this.#storage = storage;
      this.#limit = Math.max(50, limit);
      this.#onPersistError = onPersistError;
    }
    async load() {
      if (this.#loaded) {
        return;
      }
      if (!this.#loading) {
        this.#loading = this.#hydrate();
      }
      await this.#loading;
    }
    has(key) {
      return this.#index.has(key);
    }
    async record(key) {
      await this.load();
      if (this.#index.has(key)) {
        return false;
      }
      this.#index.add(key);
      this.#entries.push({ key, at: (/* @__PURE__ */ new Date()).toISOString() });
      while (this.#entries.length > this.#limit) {
        const removed = this.#entries.shift();
        if (removed) {
          this.#index.delete(removed.key);
        }
      }
      await this.#persist();
      return true;
    }
    async clear() {
      this.#entries = [];
      this.#index.clear();
      this.#loaded = true;
      await this.#persist();
    }
    size() {
      return this.#entries.length;
    }
    snapshot() {
      return { entries: [...this.#entries] };
    }
    async #hydrate() {
      const fallback = { entries: [] };
      const stored = await this.#storage.get(MEDIA_HISTORY_KEY, fallback);
      const entries = Array.isArray(stored?.entries) ? stored.entries : [];
      this.#entries = entries.filter(
        (entry) => typeof entry?.key === "string" && typeof entry?.at === "string"
      ).slice(-this.#limit);
      this.#index = new Set(this.#entries.map((entry) => entry.key));
      this.#loaded = true;
    }
    async #persist() {
      try {
        await this.#storage.set(MEDIA_HISTORY_KEY, {
          entries: this.#entries
        });
      } catch (error) {
        this.#onPersistError?.(error);
      }
    }
  };

  // src/features/media/last-download.ts
  var LAST_DOWNLOAD_KEY = "aviary.media.last-download.v1";
  async function rememberLastDownload(storage, input) {
    if (!isHttpUrl(input.url) || input.filename.trim().length === 0) return;
    try {
      await storage.set(LAST_DOWNLOAD_KEY, {
        ...input,
        filename: input.filename.slice(0, 240),
        downloadedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch {
    }
  }
  async function getLastDownload(storage) {
    const stored = await storage.get(LAST_DOWNLOAD_KEY, null);
    return isLastDownload(stored) ? stored : null;
  }
  function isLastDownload(value) {
    if (typeof value !== "object" || value === null) return false;
    const candidate = value;
    return typeof candidate.url === "string" && isHttpUrl(candidate.url) && typeof candidate.filename === "string" && candidate.filename.length > 0 && (candidate.kind === "photo" || candidate.kind === "video" || candidate.kind === "thumbnail") && typeof candidate.downloadedAt === "string";
  }
  function isHttpUrl(value) {
    try {
      const parsed = new URL(value);
      return parsed.protocol === "http:" || parsed.protocol === "https:";
    } catch {
      return false;
    }
  }

  // src/features/media/queue.ts
  var RECENT_LIMIT = 40;
  var DownloadQueue = class {
    #jobs = [];
    #listeners = /* @__PURE__ */ new Set();
    #seq = 0;
    enqueue(job) {
      const entry = {
        id: `job-${++this.#seq}`,
        status: "queued",
        ...job
      };
      this.#jobs.push(entry);
      this.#trim();
      this.#notify();
      return entry;
    }
    mark(jobId, status, error) {
      const job = this.#jobs.find((entry) => entry.id === jobId);
      if (!job) {
        return;
      }
      if (status === "running" && !job.startedAt) {
        job.startedAt = (/* @__PURE__ */ new Date()).toISOString();
      }
      if (status === "completed" || status === "failed" || status === "duplicate") {
        job.finishedAt = (/* @__PURE__ */ new Date()).toISOString();
      }
      job.status = status;
      if (error) {
        job.error = error;
      } else if (status !== "failed") {
        delete job.error;
      }
      this.#notify();
    }
    snapshot() {
      const counts = {
        queued: 0,
        running: 0,
        completed: 0,
        failed: 0,
        duplicate: 0
      };
      for (const job of this.#jobs) {
        counts[job.status] += 1;
      }
      return {
        total: this.#jobs.length,
        queued: counts.queued,
        running: counts.running,
        completed: counts.completed,
        failed: counts.failed,
        duplicate: counts.duplicate,
        recent: this.#jobs.slice(-RECENT_LIMIT)
      };
    }
    subscribe(listener) {
      this.#listeners.add(listener);
      listener(this.snapshot());
      return () => {
        this.#listeners.delete(listener);
      };
    }
    clear() {
      this.#jobs.length = 0;
      this.#notify();
    }
    #trim() {
      while (this.#jobs.length > 200) {
        this.#jobs.shift();
      }
    }
    #notify() {
      const snapshot = this.snapshot();
      for (const listener of this.#listeners) {
        try {
          listener(snapshot);
        } catch {
        }
      }
    }
  };

  // src/features/media/media-buttons.ts
  var STYLE_ID3 = "av-media-buttons";
  var BUTTON_ATTR2 = "data-av-media-button";
  var PROCESSED_ATTR = "data-av-media-processed";
  var downloader;
  var history;
  var aria2History;
  var queue;
  var permissionSurfaceOpened = false;
  var mediaButtonsFeature = {
    id: "media.buttons",
    title: "One-click media",
    category: "media",
    defaultEnabled: true,
    async init(ctx) {
      ensureMediaStyle();
      aria2History = new Aria2History(ctx.storage);
      await aria2History.load();
      if (ctx.settings.integrations.aria2.endpoint) {
        await aria2History.reconcile({
          endpoint: ctx.settings.integrations.aria2.endpoint,
          secret: ctx.settings.integrations.aria2.secret
        });
      }
      downloader = createDownloader({ integrations: ctx.settings.integrations, aria2History });
      queue = new DownloadQueue();
      history = new MediaHistory(ctx.storage, void 0, (error) => {
        ctx.diagnostics.error("Media history failed to save", errorDetails3(error));
      });
      try {
        await history.load();
      } catch (error) {
        ctx.diagnostics.warn("Media history failed to load", errorDetails3(error));
      }
      applyToggleClass(ctx);
      scanArticles(document, ctx);
      ctx.diagnostics.info("Media buttons initialized", { history: history.size() });
    },
    apply(ctx, root, addedNodes) {
      ensureMediaStyle();
      applyToggleClass(ctx);
      if (!ctx.settings.media.buttons) {
        return;
      }
      if (!addedNodes || addedNodes.length === 0) {
        scanArticles(root, ctx);
        return;
      }
      for (const node of addedNodes) {
        scanArticles(node, ctx);
      }
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID3)?.remove();
      document.documentElement.classList.remove("av-media-buttons-enabled");
      for (const article of Array.from(
        document.querySelectorAll(`[${PROCESSED_ATTR}]`)
      )) {
        article.removeAttribute(PROCESSED_ATTR);
      }
      for (const button2 of Array.from(document.querySelectorAll(`[${BUTTON_ATTR2}]`))) {
        button2.remove();
      }
      downloader = void 0;
      history = void 0;
      aria2History = void 0;
      queue?.clear();
      queue = void 0;
      ctx.diagnostics.info("Media buttons destroyed");
    },
    getStatus() {
      if (!queue) {
        return { ok: true, message: "Media buttons idle" };
      }
      const snapshot = queue.snapshot();
      return {
        ok: snapshot.failed === 0,
        message: `Downloads: ${snapshot.completed} ok / ${snapshot.duplicate} dup / ${snapshot.failed} fail`,
        details: { ...snapshot }
      };
    }
  };
  function getMediaQueue() {
    return queue;
  }
  function getMediaHistory() {
    return history;
  }
  function applyToggleClass(ctx) {
    document.documentElement.classList.toggle(
      "av-media-buttons-enabled",
      ctx.settings.media.buttons
    );
  }
  function scanArticles(root, ctx) {
    if (!ctx.settings.media.buttons) {
      return;
    }
    const articles = collectArticles2(root);
    for (const article of articles) {
      if (article.getAttribute(PROCESSED_ATTR) === "1") {
        continue;
      }
      const tweet = extractTweet(article, {
        preferOriginalImages: ctx.settings.media.preferOriginalImages
      });
      if (tweet.media.length === 0) {
        continue;
      }
      decorateArticle(tweet, ctx);
      article.setAttribute(PROCESSED_ATTR, "1");
    }
  }
  function collectArticles2(root) {
    const found = [];
    if (root instanceof Element && root.matches('article[data-testid="tweet"]')) {
      found.push(root);
    }
    if ("querySelectorAll" in root) {
      for (const article of Array.from(
        root.querySelectorAll('article[data-testid="tweet"]')
      )) {
        found.push(article);
      }
    }
    return found;
  }
  function decorateArticle(tweet, ctx) {
    tweet.media.forEach((media, index) => {
      const container = resolveContainer(media);
      if (!container || hasOwnButton(container, media.kind)) {
        return;
      }
      const button2 = buildButton(media, index, tweet, ctx);
      container.append(button2);
    });
  }
  function resolveContainer(media) {
    if (media.kind === "video" && media.video) {
      return media.video.container;
    }
    return media.source.closest('[data-testid="tweetPhoto"]') ?? media.source.parentElement;
  }
  function hasOwnButton(container, kind) {
    return container.querySelector(`[${BUTTON_ATTR2}="${kind}"]`) !== null;
  }
  function buildButton(media, index, tweet, ctx) {
    const button2 = document.createElement("button");
    button2.type = "button";
    button2.className = "av-media-button";
    button2.setAttribute(BUTTON_ATTR2, media.kind);
    button2.dataset.kind = media.kind;
    button2.setAttribute("aria-label", buttonAriaLabel(media));
    button2.textContent = buttonLabel(media);
    button2.addEventListener("click", (event) => {
      event.stopPropagation();
      event.preventDefault();
      void handleDownload(media, index, tweet, ctx, button2);
    });
    return button2;
  }
  function buttonLabel(media) {
    if (media.kind === "thumbnail") {
      return "Thumb";
    }
    if (media.kind === "video") {
      return media.video?.isGif ? "GIF" : "Video";
    }
    return "Save";
  }
  function buttonAriaLabel(media) {
    if (media.kind === "thumbnail") {
      return "Download thumbnail";
    }
    if (media.kind === "video") {
      return media.video?.isGif ? "Download GIF" : "Download video";
    }
    return "Download image";
  }
  async function handleDownload(media, index, tweet, ctx, button2) {
    if (!downloader || !queue || !history) {
      return;
    }
    const target = resolveTarget(media);
    if (!target) {
      button2.textContent = "Unavailable";
      button2.disabled = true;
      button2.classList.add("is-error");
      ctx.diagnostics.warn("Media target unavailable", { kind: media.kind });
      return;
    }
    const filename = renderFilename(ctx.settings.media.filenameTemplate, {
      handle: tweet.handle,
      tweetId: tweet.tweetId,
      index,
      total: tweet.media.length,
      date: /* @__PURE__ */ new Date(),
      ext: target.ext,
      text: tweet.text,
      mediaId: target.mediaId
    });
    const dedupeKey = `${tweet.tweetId ?? "0"}:${target.mediaId ?? target.url}:${index}:${media.kind}`;
    if (ctx.settings.media.downloadHistory && history.has(dedupeKey)) {
      const job2 = queue.enqueue({ url: target.url, filename });
      queue.mark(job2.id, "duplicate");
      button2.textContent = "Saved";
      button2.classList.add("is-duplicate");
      ctx.diagnostics.info("Media skipped \u2014 already in history", { dedupeKey });
      void ctx.auditLog.record("media.download.duplicate", { dedupeKey });
      return;
    }
    const job = queue.enqueue({ url: target.url, filename });
    queue.mark(job.id, "running");
    button2.classList.add("is-active");
    button2.disabled = true;
    try {
      const result = await downloader({ url: target.url, filename });
      if (result.deduplicated) {
        queue.mark(job.id, "duplicate");
        button2.textContent = "Queued";
        button2.classList.remove("is-active");
        button2.classList.add("is-duplicate");
        ctx.diagnostics.info("Media skipped \u2014 already queued in Aria2 history", { url: target.url });
        void ctx.auditLog.record("media.download.duplicate", {
          dedupeKey,
          source: "aria2-history"
        });
        return;
      }
      queue.mark(job.id, "completed");
      await rememberLastDownload(ctx.storage, {
        url: target.url,
        filename,
        kind: media.kind
      });
      if (ctx.settings.media.downloadHistory) {
        await history.record(dedupeKey);
      }
      button2.textContent = result.degraded ? "Opened" : successLabel(media);
      button2.classList.remove("is-active");
      button2.classList.add("is-success");
      if (result.degraded) {
        button2.title = "Your browser opened this file instead of saving it \u2014 grant Aviary the download permission for a real save.";
      }
      ctx.diagnostics.info("Media saved", { filename, kind: media.kind, degraded: result.degraded === true });
      void ctx.auditLog.record("media.download", { filename, kind: media.kind, via: result.via });
    } catch (error) {
      const needsPermission = error instanceof DownloadPermissionError;
      queue.mark(job.id, "failed", String(error?.message ?? error));
      button2.textContent = needsPermission ? "Allow" : "Retry";
      button2.classList.remove("is-active");
      button2.classList.add("is-error");
      button2.disabled = false;
      if (needsPermission) {
        button2.title = "Aviary needs the browser download permission. Opening its options page.";
        if (!permissionSurfaceOpened) {
          permissionSurfaceOpened = true;
          void requestDownloadPermissionSurface();
        }
      }
      ctx.diagnostics.error("Media download failed", errorDetails3(error));
      void ctx.auditLog.record("media.download.failed", {
        filename,
        kind: media.kind,
        ...needsPermission ? { reason: "downloads-permission-missing" } : {}
      });
    }
  }
  function resolveTarget(media) {
    if (media.kind === "video" && media.video?.preferred) {
      const url = media.video.preferred.url;
      return { url, mediaId: mediaIdFromVideo(url), ext: extensionForVideo(media.video.preferred.type, url) };
    }
    if (media.image) {
      return { url: media.image.url, mediaId: media.image.mediaId, ext: media.image.format };
    }
    return null;
  }
  function mediaIdFromVideo(url) {
    const match = /\/([A-Za-z0-9_-]{6,})\.(mp4|m4s|m3u8|webm|mov)(?:[?#]|$)/i.exec(url);
    return match?.[1] ?? null;
  }
  function extensionForVideo(mime, url) {
    if (/mp4/i.test(mime) || /\.mp4(?:[?#]|$)/i.test(url)) return "mp4";
    if (/webm/i.test(mime) || /\.webm(?:[?#]|$)/i.test(url)) return "webm";
    if (/m3u8/i.test(mime) || /\.m3u8(?:[?#]|$)/i.test(url)) return "m3u8";
    if (/mov/i.test(mime) || /\.mov(?:[?#]|$)/i.test(url)) return "mov";
    return "mp4";
  }
  function successLabel(media) {
    if (media.kind === "thumbnail") return "Got it";
    if (media.kind === "video") return media.video?.isGif ? "GIF saved" : "Saved";
    return "Saved";
  }
  function errorDetails3(error) {
    if (error instanceof Error) {
      return { name: error.name, message: error.message };
    }
    return { message: String(error) };
  }
  function ensureMediaStyle() {
    if (document.getElementById(STYLE_ID3)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID3;
    style.textContent = MEDIA_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var MEDIA_CSS = `
html:not(.av-media-buttons-enabled) [${BUTTON_ATTR2}] {
  display: none !important;
}

[${BUTTON_ATTR2}] {
  position: absolute;
  top: 8px;
  right: 8px;
  z-index: 2;
  min-height: 28px;
  padding: 4px 10px;
  border: 1px solid color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 60%, transparent);
  border-radius: 6px;
  background: color-mix(in srgb, rgb(0, 0, 0) 60%, transparent);
  color: var(--av-text, rgb(239, 243, 244));
  cursor: pointer;
  font: 700 11px/1.1 TwitterChirp, Inter, ui-sans-serif, system-ui, sans-serif;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  opacity: 0;
  transition: opacity 120ms ease, border-color 120ms ease;
}

[data-testid="tweetPhoto"] {
  position: relative;
}

[data-testid="tweetPhoto"]:hover [${BUTTON_ATTR2}],
[data-testid="tweetPhoto"]:focus-within [${BUTTON_ATTR2}],
[${BUTTON_ATTR2}]:focus-visible,
[${BUTTON_ATTR2}].is-active,
[${BUTTON_ATTR2}].is-success,
[${BUTTON_ATTR2}].is-error,
[${BUTTON_ATTR2}].is-duplicate {
  opacity: 1;
}

[${BUTTON_ATTR2}].is-success {
  border-color: rgb(120, 200, 130);
  color: rgb(206, 240, 210);
}

[${BUTTON_ATTR2}].is-duplicate {
  border-color: var(--av-muted, rgb(113, 118, 123));
  color: var(--av-muted, rgb(113, 118, 123));
}

[${BUTTON_ATTR2}].is-error {
  border-color: rgb(220, 110, 110);
  color: rgb(248, 200, 200);
}

[${BUTTON_ATTR2}][data-kind="thumbnail"] {
  top: 8px;
  right: 76px;
}
`;

  // src/features/media/batch-downloader.ts
  async function runMediaBatch(ctx, options = {}) {
    const queue2 = getMediaQueue();
    const history2 = getMediaHistory();
    const downloader2 = createDownloader({ integrations: ctx.settings.integrations });
    const concurrency = Math.max(1, Math.min(ctx.settings.jobs.concurrentDownloads, 6));
    const max = Math.max(1, options.maxItems ?? 200);
    const filterKind = options.filterKind ?? "all";
    const tweets = collectArticles3(document, options.surface, {
      preferOriginalImages: ctx.settings.media.preferOriginalImages
    });
    const tasks = [];
    for (const tweet of tweets) {
      tweet.media.forEach((media, index) => {
        if (filterKind !== "all" && media.kind !== filterKind) return;
        const target = resolveTarget2(media);
        if (!target) return;
        tasks.push({ media, tweet, index, target });
      });
      if (tasks.length >= max) {
        break;
      }
    }
    return runTasks(ctx, downloader2, queue2, history2, tasks.slice(0, max), concurrency);
  }
  async function runTasks(ctx, downloader2, queue2, history2, tasks, concurrency = 3) {
    const progress = {
      total: tasks.length,
      enqueued: 0,
      downloaded: 0,
      duplicate: 0,
      failed: 0
    };
    const jobIds = [];
    let cursor = 0;
    let needsDownloadPermission = false;
    const workers = [];
    const next = async () => {
      while (true) {
        if (needsDownloadPermission) return;
        const index = cursor++;
        if (index >= tasks.length) return;
        const task = tasks[index];
        const dedupeKey = `${task.tweet.tweetId ?? "0"}:${task.target.mediaId ?? task.target.url}:${task.index}:${task.media.kind}`;
        const filename = renderFilename(ctx.settings.media.filenameTemplate, {
          handle: task.tweet.handle,
          tweetId: task.tweet.tweetId,
          index: task.index,
          total: task.tweet.media.length,
          date: /* @__PURE__ */ new Date(),
          ext: task.target.ext,
          text: task.tweet.text,
          mediaId: task.target.mediaId
        });
        if (ctx.settings.media.downloadHistory && history2?.has(dedupeKey)) {
          progress.duplicate += 1;
          if (queue2) {
            const job2 = queue2.enqueue({ url: task.target.url, filename });
            queue2.mark(job2.id, "duplicate");
            jobIds.push(job2.id);
          }
          continue;
        }
        await ctx.limiter.waitForToken();
        const job = queue2?.enqueue({ url: task.target.url, filename });
        if (job) {
          jobIds.push(job.id);
          queue2?.mark(job.id, "running");
        }
        progress.enqueued += 1;
        try {
          const result = await downloader2({ url: task.target.url, filename });
          if (job) queue2?.mark(job.id, "completed");
          if (ctx.settings.media.downloadHistory && history2) {
            await history2.record(dedupeKey);
          }
          progress.downloaded += 1;
          void ctx.auditLog.record("media.download", { filename, kind: task.media.kind, via: result.via, batch: true });
        } catch (error) {
          if (job) queue2?.mark(job.id, "failed", String(error?.message ?? error));
          progress.failed += 1;
          if (error instanceof DownloadPermissionError) {
            needsDownloadPermission = true;
            void requestDownloadPermissionSurface();
          }
          ctx.diagnostics.error("Batch media download failed", {
            filename,
            kind: task.media.kind,
            error: String(error?.message ?? error)
          });
          void ctx.auditLog.record("media.download.failed", { filename, kind: task.media.kind, batch: true });
        }
      }
    };
    for (let i = 0; i < concurrency; i++) {
      workers.push(next());
    }
    await Promise.all(workers);
    return {
      ...progress,
      jobIds,
      cancelled: false,
      ...needsDownloadPermission ? { needsDownloadPermission: true } : {}
    };
  }
  function collectArticles3(root, surface = "active", extractOptions = {}) {
    const articles = root instanceof Element && root.matches('article[data-testid="tweet"]') ? [root] : Array.from(root.querySelectorAll('article[data-testid="tweet"]'));
    const seen = /* @__PURE__ */ new Set();
    const tweets = [];
    for (const article of articles) {
      const tweet = extractTweet(article, extractOptions);
      const key = `${tweet.tweetId ?? "noid"}:${tweet.handle ?? "noh"}`;
      if (seen.has(key) || tweet.media.length === 0) continue;
      seen.add(key);
      tweets.push(tweet);
    }
    return tweets.map((tweet) => ({ ...tweet, surface }));
  }
  function resolveTarget2(media) {
    if (media.kind === "video" && media.video?.preferred) {
      const url = media.video.preferred.url;
      return { url, mediaId: mediaIdFromVideo2(url), ext: extensionForVideo2(media.video.preferred.type, url) };
    }
    if (media.image) {
      return { url: media.image.url, mediaId: media.image.mediaId, ext: media.image.format };
    }
    return null;
  }
  function mediaIdFromVideo2(url) {
    const match = /\/([A-Za-z0-9_-]{6,})\.(mp4|m4s|m3u8|webm|mov)(?:[?#]|$)/i.exec(url);
    return match?.[1] ?? null;
  }
  function extensionForVideo2(mime, url) {
    if (/mp4/i.test(mime) || /\.mp4(?:[?#]|$)/i.test(url)) return "mp4";
    if (/webm/i.test(mime) || /\.webm(?:[?#]|$)/i.test(url)) return "webm";
    if (/m3u8/i.test(mime) || /\.m3u8(?:[?#]|$)/i.test(url)) return "m3u8";
    if (/mov/i.test(mime) || /\.mov(?:[?#]|$)/i.test(url)) return "mov";
    return "mp4";
  }

  // src/features/library/local-search.ts
  var LocalSearchIndex = class {
    #postings = /* @__PURE__ */ new Map();
    #records = [];
    rebuild(records) {
      this.#postings.clear();
      this.#records.length = 0;
      for (const record of records) {
        this.add(record);
      }
    }
    add(record) {
      const id = this.#records.push(record) - 1;
      for (const token of tokensFor(record)) {
        let posting = this.#postings.get(token);
        if (!posting) {
          posting = /* @__PURE__ */ new Set();
          this.#postings.set(token, posting);
        }
        posting.add(id);
      }
    }
    size() {
      return this.#records.length;
    }
    termCount() {
      return this.#postings.size;
    }
    search(query, options = {}) {
      const tokens = tokenize(query);
      if (tokens.length === 0) return [];
      const limit = options.limit ?? 50;
      const docScores = /* @__PURE__ */ new Map();
      for (const term of tokens) {
        const posting = this.#postings.get(term);
        if (!posting) continue;
        for (const id of posting) {
          const existing = docScores.get(id);
          if (existing) {
            existing.score += 1;
            existing.matched.add(term);
          } else {
            docScores.set(id, { score: 1, matched: /* @__PURE__ */ new Set([term]) });
          }
        }
      }
      const sorted = [...docScores.entries()].map(([id, { score, matched }]) => {
        const record = this.#records[id];
        if (!record) {
          return null;
        }
        return {
          record,
          score: score + matched.size,
          matchedTerms: [...matched].sort()
        };
      }).filter((hit) => hit !== null).sort((a, b) => b.score - a.score).slice(0, limit);
      return sorted;
    }
  };
  function tokensFor(record) {
    const haystack = [
      record.text,
      record.handle ?? "",
      record.displayName ?? "",
      record.surface,
      ...record.media.map((media) => media.url)
    ].join(" ");
    return new Set(tokenize(haystack));
  }
  function tokenize(value) {
    return value.toLowerCase().split(/[^a-z0-9_@]+/i).map((token) => token.replace(/^@/, "")).filter((token) => token.length >= 2 && token.length <= 40);
  }

  // src/features/library/reports.ts
  function buildMarkdownReport(input) {
    const at = input.generatedAt ?? (/* @__PURE__ */ new Date()).toISOString();
    const lines = [];
    lines.push(`# Aviary report`);
    lines.push("");
    lines.push(`Generated ${at}${input.version ? ` for v${input.version}` : ""}.`);
    lines.push("");
    lines.push(`## Audit log (${input.audit.length} entries)`);
    if (input.audit.length === 0) {
      lines.push("- No entries yet.");
    } else {
      for (const entry of input.audit.slice(-50)) {
        const detail = entry.detail ? ` \u2014 ${JSON.stringify(entry.detail)}` : "";
        lines.push(`- ${entry.at} \xB7 ${entry.action}${detail}`);
      }
    }
    lines.push("");
    if (input.snapshots) {
      const { latest, diff } = input.snapshots;
      lines.push(`## Snapshot \u2014 ${latest.kind} for @${latest.handle}`);
      lines.push("");
      lines.push(`- Captured: ${latest.capturedAt}`);
      lines.push(`- Source: ${latest.source}`);
      lines.push(`- Total: ${latest.accounts.length}`);
      if (diff) {
        lines.push("");
        lines.push(`### Diff vs ${diff.earlierAt}`);
        lines.push(`- Added (${diff.added.length}): ${diff.added.slice(0, 30).join(", ") || "\u2014"}${diff.added.length > 30 ? ", \u2026" : ""}`);
        lines.push(`- Removed (${diff.removed.length}): ${diff.removed.slice(0, 30).join(", ") || "\u2014"}${diff.removed.length > 30 ? ", \u2026" : ""}`);
        lines.push(`- Unchanged: ${diff.unchanged}`);
      }
      lines.push("");
    }
    if (input.cleanup) {
      const cleanup = input.cleanup;
      lines.push(`## Cleanup preview (no destructive action)`);
      lines.push("");
      lines.push(`- Generated: ${cleanup.generatedAt}`);
      lines.push(`- Total candidates: ${cleanup.candidates.length}`);
      lines.push(`- Protected: ${cleanup.protectedCount}`);
      for (const [bucket, count] of Object.entries(cleanup.byBucket)) {
        lines.push(`  - ${bucket}: ${count}`);
      }
      if (cleanup.candidates.length > 0) {
        lines.push("");
        lines.push("### Sample (first 20)");
        for (const candidate of cleanup.candidates.slice(0, 20)) {
          const guard = candidate.protected ? " [protected]" : "";
          const handle = candidate.handle ? `@${candidate.handle}` : "(unknown)";
          const preview = candidate.text.slice(0, 80).replace(/\s+/g, " ");
          lines.push(`- ${candidate.bucket}${guard} \xB7 ${handle} \xB7 ${candidate.tweetId ?? "\u2014"} \xB7 "${preview}"`);
        }
      }
      lines.push("");
    }
    lines.push("## Reminder");
    lines.push("");
    lines.push("Aviary never deletes anything for you in this release. The cleanup preview is read-only; destructive actions stay disabled per the v1.0 trust contract.");
    lines.push("");
    return `${lines.join("\n")}
`;
  }

  // src/features/library/snapshots.ts
  var SNAPSHOTS_KEY = "aviary.snapshots.v1";
  var SNAPSHOT_LIMIT = 24;
  var EMPTY4 = { entries: [] };
  var SnapshotStore = class {
    #storage;
    #limit;
    #state = EMPTY4;
    #loaded = false;
    constructor(storage, limit = SNAPSHOT_LIMIT) {
      this.#storage = storage;
      this.#limit = Math.max(4, limit);
    }
    async load() {
      if (this.#loaded) return;
      const stored = await this.#storage.get(SNAPSHOTS_KEY, EMPTY4);
      const entries = Array.isArray(stored?.entries) ? stored.entries : [];
      this.#state = { entries: entries.filter(isSnapshotEntry).slice(-this.#limit) };
      this.#loaded = true;
    }
    async record(entry) {
      await this.load();
      const stored = {
        ...entry,
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        accounts: Array.from(new Set(entry.accounts.map(normalizeHandle2).filter((value) => value !== null))).sort()
      };
      this.#state.entries.push(stored);
      while (this.#state.entries.length > this.#limit) {
        this.#state.entries.shift();
      }
      await this.#persist();
      return stored;
    }
    list(kind, handle) {
      const scoped = this.#state.entries.filter((entry) => {
        if (kind && entry.kind !== kind) return false;
        if (handle && entry.handle !== handle.toLowerCase()) return false;
        return true;
      });
      return [...scoped];
    }
    diffLatest(kind, handle) {
      const scoped = this.list(kind, handle);
      if (scoped.length < 2) return null;
      const earlier = scoped[scoped.length - 2];
      const later = scoped[scoped.length - 1];
      return diffSnapshots(earlier, later);
    }
    async clear() {
      this.#state = { entries: [] };
      this.#loaded = true;
      await this.#persist();
    }
    size() {
      return this.#state.entries.length;
    }
    async #persist() {
      try {
        await this.#storage.set(SNAPSHOTS_KEY, this.#state);
      } catch {
      }
    }
  };
  function diffSnapshots(earlier, later) {
    const earlierSet = new Set(earlier.accounts);
    const laterSet = new Set(later.accounts);
    const added = [];
    const removed = [];
    let unchanged = 0;
    for (const handle of laterSet) {
      if (earlierSet.has(handle)) {
        unchanged += 1;
      } else {
        added.push(handle);
      }
    }
    for (const handle of earlierSet) {
      if (!laterSet.has(handle)) {
        removed.push(handle);
      }
    }
    added.sort();
    removed.sort();
    return {
      earlierAt: earlier.capturedAt,
      laterAt: later.capturedAt,
      added,
      removed,
      unchanged
    };
  }
  function collectAccountsFromDom(root) {
    const cells = root.querySelectorAll('[data-testid="UserCell"]');
    const handles = /* @__PURE__ */ new Set();
    for (const cell of Array.from(cells)) {
      const link = cell.querySelector('a[href^="/"]');
      const href = link?.getAttribute("href") ?? "";
      const match = /^\/([A-Za-z0-9_]{1,15})(?:[/?#]|$)/.exec(href);
      const candidate = match?.[1];
      if (candidate) {
        const normalized = normalizeHandle2(candidate);
        if (normalized) handles.add(normalized);
      }
    }
    return Array.from(handles).sort();
  }
  function isSnapshotEntry(value) {
    if (typeof value !== "object" || value === null) return false;
    const candidate = value;
    return (candidate.kind === "followers" || candidate.kind === "following") && typeof candidate.handle === "string" && typeof candidate.capturedAt === "string" && Array.isArray(candidate.accounts) && candidate.accounts.every((entry) => typeof entry === "string");
  }
  function normalizeHandle2(value) {
    const cleaned = value.replace(/^@/, "").trim().toLowerCase();
    return /^[a-z0-9_]{1,15}$/.test(cleaned) ? cleaned : null;
  }

  // src/features/library/snapshots-feature.ts
  var store2;
  var snapshotsFeature = {
    id: "library.snapshots",
    title: "Follower / following snapshots",
    category: "core",
    defaultEnabled: true,
    async init(ctx) {
      store2 = new SnapshotStore(ctx.storage);
      await store2.load();
      ctx.diagnostics.info("Snapshots initialized", { entries: store2.size() });
    },
    destroy(ctx) {
      store2 = void 0;
      ctx.diagnostics.info("Snapshots destroyed");
    },
    getStatus() {
      return {
        ok: true,
        message: store2 ? `${store2.size()} snapshots stored` : "Snapshots idle"
      };
    }
  };
  function getSnapshotStore() {
    return store2;
  }
  async function captureSnapshotFromDom(ctx, kind, profileHandle) {
    if (!store2) return null;
    const accounts = collectAccountsFromDom(document);
    if (accounts.length === 0) {
      ctx.diagnostics.warn("Snapshot skipped \u2014 no UserCell rows in DOM");
      return null;
    }
    const entry = await store2.record({
      kind,
      handle: profileHandle.toLowerCase(),
      source: "dom",
      accounts
    });
    ctx.diagnostics.info("Snapshot captured", {
      kind,
      handle: profileHandle,
      count: accounts.length
    });
    return { entry, totalAccounts: accounts.length };
  }

  // src/features/library/user-notes.ts
  var USER_NOTES_KEY = "aviary.userNotes.v1";
  var STYLE_ID4 = "av-user-notes";
  var BADGE_ATTR = "data-av-note-badge";
  var ARTICLE_ATTR = "data-av-note-processed";
  var cache;
  var activeStorage;
  var userNotesFeature = {
    id: "library.userNotes",
    title: "Account notes",
    category: "core",
    defaultEnabled: true,
    async init(ctx) {
      activeStorage = ctx.storage;
      ensureStyle2();
      cache = await load(ctx.storage);
      decorate(ctx, document);
      ctx.diagnostics.info("User notes initialized", { count: Object.keys(cache.notes).length });
    },
    apply(ctx, root, addedNodes) {
      ensureStyle2();
      if (!cache) {
        return;
      }
      if (!addedNodes || addedNodes.length === 0) {
        decorate(ctx, root);
        return;
      }
      for (const node of addedNodes) {
        decorate(ctx, node);
      }
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID4)?.remove();
      for (const article of Array.from(document.querySelectorAll(`[${ARTICLE_ATTR}]`))) {
        article.removeAttribute(ARTICLE_ATTR);
      }
      for (const badge of Array.from(document.querySelectorAll(`[${BADGE_ATTR}]`))) {
        badge.remove();
      }
      cache = void 0;
      activeStorage = void 0;
      ctx.diagnostics.info("User notes destroyed");
    },
    getStatus() {
      return {
        ok: true,
        message: cache ? `${Object.keys(cache.notes).length} notes` : "Notes idle"
      };
    }
  };
  function getUserNotes() {
    return { ...cache?.notes ?? {} };
  }
  async function setUserNote(handle, note) {
    const normalized = normalizeHandle3(handle);
    if (!normalized || !activeStorage) {
      return;
    }
    if (!cache) {
      cache = await load(activeStorage);
    }
    if (note.trim().length === 0) {
      delete cache.notes[normalized];
    } else {
      cache.notes[normalized] = note.trim().slice(0, 280);
    }
    cache.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await activeStorage.set(USER_NOTES_KEY, cache);
    } catch {
    }
  }
  async function clearUserNotes() {
    if (!activeStorage) return;
    cache = { notes: {}, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    try {
      await activeStorage.set(USER_NOTES_KEY, cache);
    } catch {
    }
  }
  async function load(storage) {
    const fallback = { notes: {}, updatedAt: null };
    const stored = await storage.get(USER_NOTES_KEY, fallback);
    const notes = stored?.notes ?? {};
    const sanitized = {};
    for (const [handle, note] of Object.entries(notes)) {
      const normalized = normalizeHandle3(handle);
      if (normalized && typeof note === "string" && note.trim().length > 0) {
        sanitized[normalized] = note.slice(0, 280);
      }
    }
    return { notes: sanitized, updatedAt: stored?.updatedAt ?? null };
  }
  function decorate(_ctx, root) {
    if (!cache) return;
    const articles = root instanceof Element && root.matches('article[data-testid="tweet"]') ? [root] : Array.from(root.querySelectorAll('article[data-testid="tweet"]'));
    for (const article of articles) {
      if (article.getAttribute(ARTICLE_ATTR) === "1") {
        continue;
      }
      const handle = readHandle3(article);
      if (!handle) continue;
      const note = cache.notes[handle];
      if (!note) {
        article.setAttribute(ARTICLE_ATTR, "1");
        continue;
      }
      const userName = article.querySelector('[data-testid="User-Name"]');
      if (!userName || userName.querySelector(`[${BADGE_ATTR}]`)) {
        article.setAttribute(ARTICLE_ATTR, "1");
        continue;
      }
      const badge = document.createElement("span");
      badge.setAttribute(BADGE_ATTR, "1");
      badge.className = "av-note-badge";
      badge.textContent = "Note";
      badge.title = note;
      badge.setAttribute("role", "note");
      badge.setAttribute("aria-label", `Note for @${handle}: ${note}`);
      userName.append(badge);
      article.setAttribute(ARTICLE_ATTR, "1");
    }
  }
  function readHandle3(article) {
    const userName = article.querySelector('[data-testid="User-Name"]');
    const links = userName?.querySelectorAll('a[href^="/"]') ?? [];
    for (const link of Array.from(links)) {
      const href = link.getAttribute("href") ?? "";
      const match = /^\/([A-Za-z0-9_]{1,15})(?:[/?#]|$)/.exec(href);
      const candidate = match?.[1];
      if (candidate) {
        return normalizeHandle3(candidate);
      }
    }
    return null;
  }
  function normalizeHandle3(value) {
    const cleaned = value.replace(/^@/, "").trim().toLowerCase();
    return /^[a-z0-9_]{1,15}$/.test(cleaned) ? cleaned : null;
  }
  function ensureStyle2() {
    if (document.getElementById(STYLE_ID4)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID4;
    style.textContent = NOTE_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var NOTE_CSS = `
.av-note-badge {
  display: inline-flex;
  align-items: center;
  margin-left: 6px;
  padding: 1px 6px;
  border: 1px solid color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 70%, transparent);
  border-radius: 6px;
  background: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 18%, transparent);
  color: var(--av-text, rgb(239, 243, 244));
  font: 700 10px/1.2 inherit;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}
`;

  // src/features/core/settings-migration.ts
  var SETTINGS_EXPORT_VERSION = 1;
  var REDACTED_SECRET = "__aviary_redacted__";
  var SECRET_PATHS = [
    ["aria2", "secret"],
    ["bluesky", "appPassword"],
    ["mastodon", "token"],
    ["ai", "apiKey"],
    ["semanticSearch", "apiKey"]
  ];
  function readSecret(settings, group, key) {
    const record = settings.integrations[group];
    const value = record?.[key];
    return typeof value === "string" ? value : "";
  }
  function writeSecret(settings, group, key, value) {
    const record = settings.integrations[group];
    if (record) {
      record[key] = value;
    }
  }
  function buildSettingsExport(settings, options = {}) {
    const copy = cloneSettings(settings);
    const includeSecrets = options.includeSecrets === true;
    if (!includeSecrets) {
      for (const [group, key] of SECRET_PATHS) {
        if (readSecret(copy, group, key).length > 0) {
          writeSecret(copy, group, key, REDACTED_SECRET);
        }
      }
    }
    return {
      generator: "Aviary",
      version: SETTINGS_EXPORT_VERSION,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      secretsRedacted: !includeSecrets,
      settings: copy
    };
  }
  function parseSettingsImport(payload, current) {
    const errors = [];
    const warnings = [];
    let parsed;
    try {
      parsed = JSON.parse(payload);
    } catch (error) {
      errors.push(`Invalid JSON: ${error.message}`);
      return { applied: false, errors, warnings, settings: normalizeSettings({}) };
    }
    if (!isRecord5(parsed)) {
      errors.push("Top-level value must be an object.");
      return { applied: false, errors, warnings, settings: normalizeSettings({}) };
    }
    const generator = parsed.generator;
    if (generator !== "Aviary") {
      warnings.push(`Unknown generator '${String(generator ?? "unset")}'. Continuing best-effort.`);
    }
    const version = parsed.version;
    if (typeof version === "number" && version > SETTINGS_EXPORT_VERSION) {
      warnings.push(
        `Import version ${version} is newer than supported ${SETTINGS_EXPORT_VERSION}; unknown fields are dropped.`
      );
    }
    const rawSettings = isRecord5(parsed.settings) ? parsed.settings : parsed;
    const normalized = normalizeSettings(rawSettings);
    let restored = 0;
    for (const [group, key] of SECRET_PATHS) {
      if (readSecret(normalized, group, key) === REDACTED_SECRET) {
        writeSecret(normalized, group, key, current ? readSecret(current, group, key) : "");
        restored += 1;
      }
    }
    if (restored > 0) {
      warnings.push(
        `${restored} credential${restored === 1 ? " was" : "s were"} redacted in this file; the ${restored === 1 ? "value" : "values"} already saved here ${restored === 1 ? "was" : "were"} kept.`
      );
    }
    return { applied: true, errors, warnings, settings: normalized };
  }
  function isRecord5(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // src/features/core/control-center.ts
  var controlCenter;
  var searchIndex = new LocalSearchIndex();
  var cleanupQueue;
  var semanticIndex;
  var retentionPolicy;
  var controlCenterFeature = {
    id: "core.controlCenter",
    title: "Control Center",
    category: "core",
    defaultEnabled: true,
    async init(ctx) {
      if (!cleanupQueue) {
        cleanupQueue = new CleanupQueue(ctx.storage);
        await cleanupQueue.load();
      }
      if (!semanticIndex) {
        semanticIndex = new SemanticIndex(ctx.storage);
        await semanticIndex.load();
      }
      retentionPolicy = await loadRetentionPolicy(ctx.storage);
      controlCenter = mountControlCenter({
        settings: ctx.settings,
        diagnostics: () => ctx.diagnostics.snapshot(),
        async onChange() {
          await ctx.saveSettings();
          ctx.requestApply();
        },
        onError(message, error) {
          ctx.diagnostics.error(message, errorDetails4(error));
        },
        getMediaStatus() {
          const queue2 = getMediaQueue();
          const history2 = getMediaHistory();
          const snapshot = queue2?.snapshot();
          return {
            historySize: history2?.size() ?? 0,
            completed: snapshot?.completed ?? 0,
            failed: snapshot?.failed ?? 0,
            duplicate: snapshot?.duplicate ?? 0,
            running: snapshot?.running ?? 0
          };
        },
        async clearMediaHistory() {
          await getMediaHistory()?.clear();
        },
        getExportStatus() {
          const store3 = getCheckpointStore();
          const queries = getDiscoveredQueries();
          return {
            jobCount: store3?.list().length ?? 0,
            knownQueries: queries ? Object.keys(queries.queries).length : 0
          };
        },
        async runExport() {
          const result = await runExportOfVisibleTweets(ctx);
          for (const artifact of result.artifacts) {
            downloadBlob(artifact.data, artifact.filename);
          }
          return {
            records: result.records,
            filename: result.filename,
            files: result.artifacts.length
          };
        },
        async copyDiagnostics() {
          const payload = buildDiagnosticsPayload(ctx);
          await writeClipboard(payload);
          void ctx.auditLog.record("diagnostics.copy");
        },
        async exportSettings() {
          const envelope = buildSettingsExport(ctx.settings);
          const text = JSON.stringify(envelope, null, 2);
          const bytes = new TextEncoder().encode(text);
          downloadBlob(bytes, settingsFilename(), "application/json");
          void ctx.auditLog.record("settings.export");
        },
        async importSettings(payload) {
          const report = parseSettingsImport(payload, ctx.settings);
          if (report.applied) {
            Object.assign(ctx.settings, report.settings);
            await ctx.storage.set(SETTINGS_KEY, normalizeSettings(ctx.settings));
            ctx.requestApply();
            void ctx.auditLog.record("settings.import", {
              warnings: report.warnings.length,
              errors: report.errors.length
            });
          }
          return report;
        },
        getAuditSize() {
          return ctx.auditLog.size();
        },
        async clearAuditLog() {
          await ctx.auditLog.clear();
        },
        getRetentionPolicy() {
          return retentionPolicy ?? DEFAULT_RETENTION_POLICY;
        },
        async saveRetentionPolicy(next) {
          const normalized = await saveRetentionPolicy(ctx.storage, normalizeRetentionPolicy(next));
          retentionPolicy = normalized;
          const sweep = await getCheckpointStore()?.sweep(normalized);
          if (sweep && (sweep.removedJobs > 0 || sweep.removedRecords > 0)) {
            void ctx.auditLog.record("export.complete", {
              kind: "checkpoint-retention",
              removedJobs: sweep.removedJobs,
              removedRecords: sweep.removedRecords
            });
          }
          ctx.requestApply();
        },
        getHiddenPostsStatus() {
          const hiddenStore = getHiddenPostStore();
          const entries = hiddenStore?.list() ?? [];
          return {
            total: entries.length,
            updatedAt: hiddenStore?.updatedAt() ?? null,
            recent: entries.slice(0, 8).map((entry) => ({
              key: entry.key,
              handle: entry.handle,
              text: entry.text,
              hiddenAt: entry.hiddenAt
            }))
          };
        },
        async undoLastHide() {
          const entry = await undoLastHide(ctx);
          return { restored: entry !== null, handle: entry?.handle ?? null };
        },
        async unhidePost(key) {
          const entry = await getHiddenPostStore()?.unhide(key);
          if (entry) {
            ctx.requestApply();
            void ctx.auditLog.record("post.unhide", { key });
          }
          return entry !== null && entry !== void 0;
        },
        async clearHiddenPosts() {
          return await clearHiddenPosts(ctx);
        },
        getUserNotes() {
          return getUserNotes();
        },
        async setUserNote(handle, note) {
          await setUserNote(handle, note);
          ctx.requestApply();
        },
        async clearUserNotes() {
          await clearUserNotes();
          ctx.requestApply();
        },
        async captureSnapshot(kind) {
          const handle = inferProfileHandle(ctx.route.path) ?? "self";
          const result = await captureSnapshotFromDom(ctx, kind, handle);
          if (!result) return null;
          return { count: result.totalAccounts, handle: result.entry.handle };
        },
        getSnapshotStatus() {
          const store3 = getSnapshotStore();
          const entries = store3?.list() ?? [];
          const latest = entries[entries.length - 1];
          return {
            total: entries.length,
            latestAt: latest?.capturedAt ?? null,
            latestKind: latest?.kind ?? null,
            latestCount: latest?.accounts.length ?? 0
          };
        },
        diffLatestSnapshot(kind, handle) {
          const diff = getSnapshotStore()?.diffLatest(kind, handle);
          if (!diff) return null;
          return {
            added: diff.added.length,
            removed: diff.removed.length,
            unchanged: diff.unchanged
          };
        },
        async clearSnapshots() {
          await getSnapshotStore()?.clear();
        },
        async importArchive(file) {
          const buffer = new Uint8Array(await file.arrayBuffer());
          const result = importOfficialArchive(buffer, "archive");
          if (result.records.length > 0) {
            const store3 = getCheckpointStore();
            if (store3) {
              const jobId = `archive-${Date.now()}`;
              await store3.start(jobId, "archive", ["json"], false);
              await store3.append(jobId, result.records);
              await store3.finish(jobId);
            }
            rebuildSearchIndex();
            void ctx.auditLog.record("settings.import", {
              archive: file.name,
              records: result.records.length,
              warnings: result.warnings.length
            });
          }
          return {
            records: result.records.length,
            warnings: result.warnings.length,
            errors: result.errors.length
          };
        },
        searchArchive(query) {
          if (query.length === 0) return [];
          const storedRecordCount = countStoredRecords(getCheckpointStore());
          if (searchIndex.size() !== storedRecordCount) {
            rebuildSearchIndex();
          }
          return searchIndex.search(query, { limit: 20 }).map(formatHit);
        },
        listPresets() {
          return listPresets().map((preset) => ({
            id: preset.id,
            label: preset.label,
            description: preset.description
          }));
        },
        async applyPreset(id) {
          const preset = getPreset(id);
          if (!preset) return { applied: false, changes: [] };
          const changes = describePresetDelta(ctx.settings, preset);
          const next = applyPreset(ctx.settings, preset);
          replaceSettings(ctx.settings, next);
          await ctx.storage.set(SETTINGS_KEY, normalizeSettings(ctx.settings));
          ctx.requestApply();
          void ctx.auditLog.record("settings.import", { preset: preset.id, changes: changes.length });
          return { applied: changes.length > 0, changes };
        },
        listLocales() {
          return supportedLocales().map((entry) => ({
            code: entry.code,
            label: entry.label,
            direction: entry.direction
          }));
        },
        async setLocale(code) {
          ctx.settings.i18n.locale = code;
          await ctx.storage.set(SETTINGS_KEY, normalizeSettings(ctx.settings));
          ctx.requestApply();
        },
        getCleanupQueueSize() {
          const items = cleanupQueue?.list() ?? [];
          return {
            total: items.length,
            queued: items.filter((item) => item.status === "queued").length,
            approved: items.filter((item) => item.status === "approved").length,
            skipped: items.filter((item) => item.status === "skipped").length
          };
        },
        async enqueueCleanupReview() {
          rebuildSearchIndex();
          const store3 = getCheckpointStore();
          const records = collectAllRecords(store3);
          const preview = previewCleanup(records, {
            whitelistHandles: ctx.settings.filter.whitelist
          });
          const candidates = preview.candidates;
          const protectedCount = candidates.filter((candidate) => candidate.protected).length;
          const added = await cleanupQueue?.enqueue(candidates) ?? 0;
          void ctx.auditLog.record("settings.export", {
            cleanupEnqueued: added,
            protected: protectedCount
          });
          return { added, protected: protectedCount };
        },
        async clearCleanupQueue() {
          await cleanupQueue?.clear();
        },
        async crosspost(target, options) {
          const text = readComposerText();
          if (!text) {
            return { ok: false, error: "Composer is empty" };
          }
          const request = {
            text,
            target,
            asThread: options.asThread
          };
          if (ctx.settings.integrations.crosspost.attachLastDownload) {
            const lastDownload = await getLastDownload(ctx.storage);
            if (lastDownload) {
              request.attachment = {
                url: lastDownload.url,
                filename: lastDownload.filename,
                kind: lastDownload.kind
              };
            }
          }
          const result = await crosspost(ctx.settings.integrations, request);
          void ctx.auditLog.record(result.ok ? "export.complete" : "export.start", {
            kind: "crosspost",
            target,
            ok: result.ok,
            asThread: options.asThread,
            posts: result.posts ?? 0,
            error: result.error ?? null
          });
          return {
            ok: result.ok,
            ...result.url ? { url: result.url } : {},
            ...result.error ? { error: result.error } : {},
            ...result.posts !== void 0 ? { posts: result.posts } : {}
          };
        },
        async listAria2Active() {
          const active = await tellActiveAria2({
            endpoint: ctx.settings.integrations.aria2.endpoint,
            secret: ctx.settings.integrations.aria2.secret
          });
          return active.map((job) => ({
            gid: job.gid,
            status: job.status,
            totalLength: job.totalLength,
            completedLength: job.completedLength,
            path: job.files[0]?.path ?? ""
          }));
        },
        async cancelAria2(gid) {
          const result = await removeAria2Download(
            {
              endpoint: ctx.settings.integrations.aria2.endpoint,
              secret: ctx.settings.integrations.aria2.secret
            },
            gid
          );
          if (result.ok) {
            void ctx.auditLog.record("export.complete", { kind: "aria2-cancel", gid });
            return { ok: true };
          }
          return { ok: false, ...result.error ? { error: result.error } : {} };
        },
        recentIntegrationErrors() {
          return recentIntegrationErrors(ctx.auditLog.snapshot().entries);
        },
        async rebuildSemanticIndex() {
          if (!semanticIndex) {
            semanticIndex = new SemanticIndex(ctx.storage);
            await semanticIndex.load();
          }
          rebuildSearchIndex();
          const store3 = getCheckpointStore();
          const records = collectAllRecords(store3);
          const result = await semanticIndex.embedAndIndex(
            ctx.settings.integrations.semanticSearch,
            records
          );
          void ctx.auditLog.record("export.complete", {
            kind: "semantic-index",
            added: result.added,
            skipped: result.skipped,
            errors: result.errors
          });
          return { ...result, total: semanticIndex.size() };
        },
        async semanticSearchQuery(query) {
          if (!semanticIndex) return [];
          const hits = await semanticIndex.search(
            ctx.settings.integrations.semanticSearch,
            query,
            12
          );
          return hits.map((hit) => ({
            tweetId: hit.entry.tweetId,
            handle: hit.entry.handle,
            text: hit.entry.text,
            score: hit.score
          }));
        },
        async clearSemanticIndex() {
          await semanticIndex?.clear();
        },
        async pingAria2() {
          const result = await addUriToAria2(
            {
              endpoint: ctx.settings.integrations.aria2.endpoint,
              secret: ctx.settings.integrations.aria2.secret
            },
            { url: "https://example.invalid/aviary-ping", filename: "ping.txt" }
          );
          if (result.ok) return { ok: true };
          if (result.error && /HTTP/.test(result.error)) {
            return { ok: false, error: result.error };
          }
          if (result.error && /Aria2 endpoint/.test(result.error)) {
            return { ok: false, error: result.error };
          }
          return { ok: true };
        },
        getIntegrationStatus() {
          const integrations = ctx.settings.integrations;
          return {
            aria2: { enabled: integrations.aria2.enabled, configured: integrations.aria2.endpoint.length > 0 },
            bluesky: {
              enabled: integrations.bluesky.enabled,
              configured: integrations.bluesky.handle.length > 0 && integrations.bluesky.appPassword.length > 0
            },
            mastodon: {
              enabled: integrations.mastodon.enabled,
              configured: integrations.mastodon.instance.length > 0 && integrations.mastodon.token.length > 0
            },
            ai: {
              enabled: integrations.ai.enabled,
              configured: integrations.ai.apiKey.length > 0 && integrations.ai.model.length > 0
            },
            semanticSearch: {
              enabled: integrations.semanticSearch.enabled,
              configured: integrations.semanticSearch.endpoint.length > 0 && integrations.semanticSearch.apiKey.length > 0 && integrations.semanticSearch.model.length > 0,
              indexed: semanticIndex?.size() ?? 0
            }
          };
        },
        async runMediaBatch() {
          const result = await runMediaBatch(ctx, { maxItems: 100, surface: ctx.route.surface });
          void ctx.auditLog.record("media.download", {
            batch: true,
            total: result.total,
            downloaded: result.downloaded,
            duplicate: result.duplicate,
            failed: result.failed
          });
          return {
            total: result.total,
            downloaded: result.downloaded,
            duplicate: result.duplicate,
            failed: result.failed
          };
        },
        async downloadWarc() {
          rebuildSearchIndex();
          const store3 = getCheckpointStore();
          const records = collectAllRecords(store3);
          const artifact = buildWarcArchive(records);
          downloadBlob(artifact.data, artifact.filename, artifact.contentType);
          void ctx.auditLog.record("export.complete", { format: "warc", records: records.length });
          return { records: records.length };
        },
        async exportToTarget(target) {
          rebuildSearchIndex();
          const store3 = getCheckpointStore();
          const records = collectAllRecords(store3);
          const rendered = renderForExternalTarget(target, records);
          if (rendered.payload !== void 0) {
            await writeClipboard(rendered.payload);
            void ctx.auditLog.record("diagnostics.copy", { kind: "external", target });
            return { target, records: records.length, copied: true };
          }
          if (rendered.artifact) {
            downloadBlob(rendered.artifact.data, rendered.artifact.filename, rendered.artifact.contentType);
            void ctx.auditLog.record("export.complete", { format: target, records: records.length });
            return { target, records: records.length };
          }
          return { target, records: records.length };
        },
        async downloadReport() {
          rebuildSearchIndex();
          const store3 = getCheckpointStore();
          const records = collectAllRecords(store3);
          const cleanup = previewCleanup(records, {
            whitelistHandles: ctx.settings.filter.whitelist
          });
          const snapshotStore = getSnapshotStore();
          const latest = snapshotStore?.list().at(-1);
          const diff = latest ? snapshotStore?.diffLatest(latest.kind, latest.handle) ?? void 0 : void 0;
          const reportInput = {
            audit: ctx.auditLog.snapshot().entries,
            cleanup
          };
          if (latest) {
            reportInput.snapshots = diff ? { latest, diff } : { latest };
          }
          if (ctx.settings.i18n.locale !== "en") {
            reportInput.version = ctx.settings.i18n.locale;
          }
          const markdown = buildMarkdownReport(reportInput);
          const bytes = new TextEncoder().encode(markdown);
          downloadBlob(bytes, reportFilename(), "text/markdown");
        }
      });
      ctx.diagnostics.info("Control Center mounted");
    },
    apply() {
      controlCenter?.refresh();
    },
    destroy(ctx) {
      controlCenter?.destroy();
      controlCenter = void 0;
      cleanupQueue = void 0;
      semanticIndex = void 0;
      retentionPolicy = void 0;
      ctx.diagnostics.info("Control Center destroyed");
    }
  };
  function errorDetails4(error) {
    if (error instanceof Error) {
      return {
        name: error.name,
        message: error.message
      };
    }
    return {
      message: String(error)
    };
  }
  function replaceSettings(target, next) {
    for (const key of Object.keys(next)) {
      target[key] = next[key];
    }
  }
  function settingsFilename() {
    return `aviary-settings-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.json`;
  }
  function reportFilename() {
    return `aviary-report-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.md`;
  }
  function inferProfileHandle(path) {
    const match = /^\/([A-Za-z0-9_]{1,15})(?:\/(?:followers|following|verified_followers))?/.exec(path);
    return match?.[1]?.toLowerCase() ?? null;
  }
  function countStoredRecords(store3) {
    if (!store3) return 0;
    let total = 0;
    for (const job of store3.list()) {
      total += store3.records(job.jobId).length;
    }
    return total;
  }
  function rebuildSearchIndex() {
    const store3 = getCheckpointStore();
    searchIndex.rebuild(collectAllRecords(store3));
  }
  function collectAllRecords(store3) {
    if (!store3) return [];
    const all = [];
    for (const job of store3.list()) {
      all.push(...store3.records(job.jobId));
    }
    return all;
  }
  function formatHit(hit) {
    return {
      handle: hit.record.handle,
      tweetId: hit.record.tweetId,
      text: hit.record.text,
      score: hit.score
    };
  }
  function downloadBlob(data, filename, contentType = "application/zip") {
    if (typeof document === "undefined") {
      return;
    }
    const blob = new Blob([new Uint8Array(data)], { type: contentType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.rel = "noopener noreferrer";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4e3);
  }
  function buildDiagnosticsPayload(ctx) {
    const events = ctx.diagnostics.snapshot();
    const payload = {
      generator: "Aviary",
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      surface: ctx.route.surface,
      href: ctx.route.href,
      locale: ctx.settings.i18n.locale,
      userAgent: globalThis.navigator?.userAgent ?? "unknown",
      events
    };
    return JSON.stringify(payload, null, 2);
  }
  async function writeClipboard(payload) {
    const clipboard = globalThis.navigator?.clipboard;
    if (clipboard?.writeText) {
      await clipboard.writeText(payload);
      return;
    }
    throw new Error("Clipboard API unavailable in this context");
  }

  // src/platform/selectors.ts
  var SURFACE_SELECTORS = [
    {
      surface: "App root",
      stable: "#react-root",
      fallback: "body > div:first-child",
      churnRisk: "Medium",
      note: "Readiness anchor only; do not use as the scan scope after boot."
    },
    {
      surface: "Primary column",
      stable: '[data-testid="primaryColumn"]',
      fallback: ".r-150rngu.r-16y2uox",
      churnRisk: "Medium",
      note: "Main observer scope for timeline pages."
    },
    {
      surface: "Sidebar",
      stable: '[data-testid="sidebarColumn"]',
      fallback: ".r-1ifxtd0.r-1udh08x",
      churnRisk: "High",
      note: "Optional because the sidebar collapses by viewport."
    },
    {
      surface: "Tweet",
      stable: 'article[data-testid="tweet"]',
      fallback: "article .css-175oi2r",
      churnRisk: "High",
      note: "Process added articles only and mark processed nodes."
    },
    {
      surface: "Tweet text",
      stable: '[data-testid="tweetText"]',
      fallback: "article div[lang] span",
      churnRisk: "Medium",
      note: "Text extraction source with article textContent fallback."
    },
    {
      surface: "Composer",
      stable: '[data-testid="tweetTextarea_0"]',
      fallback: 'div[role="textbox"][aria-label]',
      churnRisk: "High",
      note: "Draft.js-aware insertion required for later composer features."
    },
    {
      surface: "Media photo",
      stable: '[data-testid="tweetPhoto"] img[src*="pbs.twimg.com/media"]',
      fallback: 'img[src*="format="]',
      churnRisk: "Medium",
      note: "Normalize image URLs to original quality before download."
    },
    {
      surface: "Video",
      stable: '[data-testid="videoPlayer"], [data-testid="videoComponent"]',
      fallback: 'video[src], div[aria-label*="Video"]',
      churnRisk: "High",
      note: "Network capture is required for complete video variants."
    },
    {
      surface: "Navigation",
      stable: '[data-testid^="AppTabBar_"], [data-testid="SideNav_NewTweet_Button"]',
      fallback: 'nav[aria-label] a[role="link"]',
      churnRisk: "High",
      note: "Support full, compact, and mobile navigation."
    },
    {
      surface: "Grok",
      stable: '[data-testid="GrokDrawer"], [data-testid="grokImgGen"]',
      fallback: 'div[id*="grok" i]',
      churnRisk: "High",
      note: "Grok controls change frequently; isolate all tweaks."
    }
  ];
  function getSelectorHealth(root = document) {
    return SURFACE_SELECTORS.map((entry) => {
      const stableCount = countMatches(root, entry.stable);
      const fallbackCount = countMatches(root, entry.fallback);
      return {
        surface: entry.surface,
        stable: entry.stable,
        fallback: entry.fallback,
        stableCount,
        fallbackCount,
        churnRisk: entry.churnRisk,
        healthy: stableCount > 0 || fallbackCount > 0
      };
    });
  }
  function countMatches(root, selector) {
    try {
      const self = root instanceof Element && root.matches(selector) ? 1 : 0;
      return self + root.querySelectorAll(selector).length;
    } catch {
      return 0;
    }
  }

  // src/features/core/selector-health.ts
  var CRITICAL_SURFACES = /* @__PURE__ */ new Set(["App root", "Primary column"]);
  var MIN_LOG_INTERVAL_MS = 5e3;
  var lastLogAt = 0;
  var lastSignature = "";
  var selectorHealthFeature = {
    id: "core.selectorHealth",
    title: "Selector health diagnostics",
    category: "core",
    defaultEnabled: true,
    init(ctx) {
      if (!ctx.settings.diagnostics.selectorHealth) {
        return;
      }
      ctx.diagnostics.info("Selector health initialized", {
        route: ctx.route.surface,
        healthy: getSelectorHealth().filter((item) => item.healthy).length
      });
    },
    apply(ctx, root) {
      if (!ctx.settings.diagnostics.selectorHealth) {
        return;
      }
      const health = getSelectorHealth(root);
      const missingCritical = health.filter((item) => !item.healthy && CRITICAL_SURFACES.has(item.surface));
      if (missingCritical.length === 0) {
        return;
      }
      const signature = `${ctx.route.surface}:${missingCritical.map((item) => item.surface).join(",")}`;
      const now = Date.now();
      if (signature !== lastSignature || now - lastLogAt >= MIN_LOG_INTERVAL_MS) {
        lastSignature = signature;
        lastLogAt = now;
        ctx.diagnostics.warn("Critical selector health degraded", {
          route: ctx.route.surface,
          missing: missingCritical.map((item) => item.surface)
        });
      }
    },
    destroy(ctx) {
      lastLogAt = 0;
      lastSignature = "";
      ctx.diagnostics.info("Selector health destroyed");
    },
    getStatus() {
      const health = getSelectorHealth();
      const healthyCount = health.filter((item) => item.healthy).length;
      return {
        ok: healthyCount > 0,
        message: `${healthyCount}/${health.length} selector surfaces detected`,
        details: { health }
      };
    }
  };

  // src/features/filtering/predicates.ts
  function compileFilters(input) {
    const keywords = input.keywords.map((value) => value.trim().toLowerCase()).filter((value) => value.length > 0);
    const patterns = [];
    for (const source of input.regex) {
      const compiled2 = tryCompileRegex(source);
      if (compiled2) {
        patterns.push(compiled2);
      }
    }
    const whitelist = /* @__PURE__ */ new Set();
    for (const handle of input.whitelist) {
      const normalized = normalizeHandle4(handle);
      if (normalized) {
        whitelist.add(normalized);
      }
    }
    return {
      keywords,
      patterns,
      whitelist,
      premium: input.premium,
      media: {
        photo: Boolean(input.media.photo),
        video: Boolean(input.media.video),
        gif: Boolean(input.media.gif)
      },
      generation: input.generation
    };
  }
  function decide(signal, filters) {
    if (signal.handle && filters.whitelist.has(signal.handle)) {
      return "show";
    }
    const text = signal.text.toLowerCase();
    for (const keyword of filters.keywords) {
      if (text.includes(keyword)) {
        return "hide";
      }
    }
    for (const pattern of filters.patterns) {
      pattern.lastIndex = 0;
      if (pattern.test(signal.text)) {
        return "hide";
      }
    }
    for (const key of ["photo", "video", "gif"]) {
      if (filters.media[key] && signal.media[key]) {
        return "hide";
      }
    }
    if (filters.premium !== "off" && signal.premium) {
      return filters.premium;
    }
    return "show";
  }
  function extractTweetSignal(article) {
    const textNodes = article.querySelectorAll('[data-testid="tweetText"]');
    const text = textNodes.length > 0 ? Array.from(textNodes).map((node) => node.textContent ?? "").join("\n") : article.textContent ?? "";
    const handle = readHandle4(article);
    const premium = article.querySelector('[data-testid="icon-verified"], [aria-label*="Verified" i]') !== null;
    const media = {
      photo: article.querySelector('[data-testid="tweetPhoto"] img[src*="pbs.twimg.com/media"]') !== null,
      video: article.querySelector('[data-testid="videoPlayer"], [data-testid="videoComponent"]') !== null,
      gif: article.querySelector('[data-testid="videoComponent"][aria-label*="GIF" i], [aria-label="Embedded video"][data-testid*="gif" i]') !== null
    };
    if (media.gif) {
      media.video = true;
    }
    return { text, handle, premium, media };
  }
  function readHandle4(article) {
    const userName = article.querySelector('[data-testid="User-Name"]');
    const links = userName?.querySelectorAll('a[href^="/"]') ?? [];
    for (const link of Array.from(links)) {
      const href = link.getAttribute("href") ?? "";
      const match = /^\/([A-Za-z0-9_]{1,15})(?:[/?#]|$)/.exec(href);
      const candidate = match?.[1];
      if (candidate) {
        return normalizeHandle4(candidate);
      }
    }
    return null;
  }
  function normalizeHandle4(value) {
    const cleaned = value.replace(/^@/, "").trim().toLowerCase();
    return /^[a-z0-9_]{1,15}$/.test(cleaned) ? cleaned : null;
  }
  function tryCompileRegex(source) {
    const trimmed = source.trim();
    if (trimmed.length === 0) {
      return null;
    }
    try {
      const match = /^\/(.+)\/([a-z]*)$/i.exec(trimmed);
      const body = match?.[1];
      const flags = match?.[2] ?? "";
      if (match && body) {
        return new RegExp(body, sanitizeFlags(flags));
      }
      return new RegExp(trimmed, "i");
    } catch {
      return null;
    }
  }
  function sanitizeFlags(input) {
    const allowed = /* @__PURE__ */ new Set(["i", "m", "s", "u"]);
    const flags = [];
    for (const flag of input.toLowerCase()) {
      if (allowed.has(flag) && !flags.includes(flag)) {
        flags.push(flag);
      }
    }
    if (!flags.includes("i")) {
      flags.push("i");
    }
    return flags.join("");
  }

  // src/features/filtering/filter-engine.ts
  var STYLE_ID5 = "av-filter-engine";
  var ARTICLE_SELECTOR2 = 'article[data-testid="tweet"]';
  var PROCESSED_ATTR2 = "data-av-filter-processed";
  var RESULT_ATTR = "data-av-filter-result";
  var generation = 0;
  var compiled;
  var filterEngineFeature = {
    id: "filtering.engine",
    title: "Filter engine",
    category: "filtering",
    defaultEnabled: true,
    init(ctx) {
      ensureFilterStyle();
      refreshCompiled(ctx);
      applyRootClasses(ctx);
      scanRoot(document, ctx);
      ctx.diagnostics.info("Filter engine initialized", filterSummary(ctx));
    },
    apply(ctx, root, addedNodes) {
      ensureFilterStyle();
      applyRootClasses(ctx);
      refreshCompiled(ctx);
      if (!ctx.settings.filter.enabled || !surfaceMatches2(ctx)) {
        return;
      }
      if (!addedNodes || addedNodes.length === 0) {
        scanRoot(root, ctx);
        return;
      }
      for (const node of addedNodes) {
        scanRoot(node, ctx);
      }
    },
    destroy(ctx) {
      compiled = void 0;
      generation = 0;
      document.getElementById(STYLE_ID5)?.remove();
      document.documentElement.classList.remove("av-filter-enabled");
      for (const article of Array.from(
        document.querySelectorAll(`[${PROCESSED_ATTR2}]`)
      )) {
        article.removeAttribute(PROCESSED_ATTR2);
        article.removeAttribute(RESULT_ATTR);
      }
      ctx.diagnostics.info("Filter engine destroyed");
    },
    getStatus() {
      return {
        ok: true,
        message: compiled ? `Filters: ${compiled.keywords.length} keyword, ${compiled.patterns.length} regex` : "Filters idle"
      };
    }
  };
  function applyRootClasses(ctx) {
    document.documentElement.classList.toggle("av-filter-enabled", ctx.settings.filter.enabled);
  }
  function surfaceMatches2(ctx) {
    const surfaces = ctx.settings.filter.surfaces;
    return surfaces.includes(ctx.route.surface);
  }
  function refreshCompiled(ctx) {
    generation += 1;
    compiled = compileFilters({
      keywords: ctx.settings.filter.keywordRules,
      regex: ctx.settings.filter.regexRules,
      whitelist: ctx.settings.filter.whitelist,
      premium: ctx.settings.filter.premiumRule,
      media: ctx.settings.filter.mediaTypes,
      generation
    });
  }
  function scanRoot(root, ctx) {
    if (!compiled || !ctx.settings.filter.enabled || !surfaceMatches2(ctx)) {
      return;
    }
    const articles = collectArticles4(root);
    for (const article of articles) {
      processArticle2(article, compiled);
    }
  }
  function collectArticles4(root) {
    const results = [];
    if (root instanceof Element && root.matches(ARTICLE_SELECTOR2)) {
      results.push(root);
    }
    if ("querySelectorAll" in root) {
      for (const article of Array.from(root.querySelectorAll(ARTICLE_SELECTOR2))) {
        results.push(article);
      }
    }
    return results;
  }
  function processArticle2(article, filters) {
    if (article.getAttribute(PROCESSED_ATTR2) === String(filters.generation)) {
      return;
    }
    const signal = extractTweetSignal(article);
    const decision = decide(signal, filters);
    article.setAttribute(PROCESSED_ATTR2, String(filters.generation));
    if (decision === "show") {
      article.removeAttribute(RESULT_ATTR);
    } else {
      article.setAttribute(RESULT_ATTR, decision);
    }
  }
  function filterSummary(ctx) {
    return {
      enabled: ctx.settings.filter.enabled,
      keywords: ctx.settings.filter.keywordRules.length,
      regex: ctx.settings.filter.regexRules.length,
      premium: ctx.settings.filter.premiumRule,
      media: Object.entries(ctx.settings.filter.mediaTypes).filter(([, value]) => value).map(([key]) => key),
      surfaces: ctx.settings.filter.surfaces
    };
  }
  function ensureFilterStyle() {
    if (document.getElementById(STYLE_ID5)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID5;
    style.textContent = FILTER_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var FILTER_CSS = `
html.av-filter-enabled article[data-testid="tweet"][${RESULT_ATTR}="hide"] {
  display: none !important;
}

html.av-filter-enabled article[data-testid="tweet"][${RESULT_ATTR}="dim"] {
  opacity: 0.36;
  filter: grayscale(0.5);
  transition: opacity 120ms ease, filter 120ms ease;
}

html.av-filter-enabled article[data-testid="tweet"][${RESULT_ATTR}="dim"]:hover,
html.av-filter-enabled article[data-testid="tweet"][${RESULT_ATTR}="dim"]:focus-within {
  opacity: 1;
  filter: none;
}
`;

  // src/features/layout/declutter.ts
  var STYLE_ID6 = "av-layout-declutter";
  var COMPOSER_SELECTOR = [
    '[data-testid^="tweetTextarea_"]',
    '[data-testid="toolBar"]',
    '[data-testid="tweetButtonInline"]',
    '[data-testid="tweetButton"]'
  ].join(", ");
  var writerListenersBound = false;
  var writerFrame = 0;
  var layoutDeclutterFeature = {
    id: "layout.declutter",
    title: "Layout declutter",
    category: "layout",
    defaultEnabled: true,
    init(ctx) {
      ensureLayoutStyle();
      applyLayoutClasses(ctx);
      ctx.diagnostics.info("Layout declutter initialized");
    },
    apply(ctx) {
      ensureLayoutStyle();
      applyLayoutClasses(ctx);
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID6)?.remove();
      unbindWriterListeners();
      document.documentElement.classList.remove(
        "av-hide-right-sidebar",
        "av-hide-trends",
        "av-hide-grok",
        "av-writer-mode",
        "av-writing"
      );
      for (const className of Array.from(document.documentElement.classList)) {
        if (className.startsWith("av-hide-nav-")) {
          document.documentElement.classList.remove(className);
        }
      }
      ctx.diagnostics.info("Layout declutter destroyed");
    }
  };
  function applyLayoutClasses(ctx) {
    const root = document.documentElement;
    root.classList.toggle("av-hide-right-sidebar", ctx.settings.layout.hideRightSidebar);
    root.classList.toggle("av-hide-trends", ctx.settings.layout.hideTrends);
    root.classList.toggle("av-hide-grok", ctx.settings.layout.hideGrok);
    root.classList.toggle("av-writer-mode", ctx.settings.layout.writerMode);
    if (ctx.settings.layout.writerMode) {
      bindWriterListeners();
      syncWritingClass();
    } else {
      unbindWriterListeners();
    }
    for (const className of Array.from(root.classList)) {
      if (className.startsWith("av-hide-nav-")) {
        root.classList.remove(className);
      }
    }
    for (const item of ctx.settings.layout.hideNavItems) {
      const safe = item.replace(/[^a-z0-9_-]/gi, "").toLowerCase();
      if (safe.length > 0) {
        root.classList.add(`av-hide-nav-${safe}`);
      }
    }
  }
  function isComposerNode(node) {
    if (!(node instanceof Element)) {
      return false;
    }
    return node.closest(COMPOSER_SELECTOR) !== null;
  }
  function syncWritingClass() {
    const writing = isComposerNode(document.activeElement);
    document.documentElement.classList.toggle("av-writing", writing);
  }
  function onFocusOut() {
    if (writerFrame !== 0) {
      return;
    }
    const schedule = globalThis.requestAnimationFrame ?? ((cb) => globalThis.setTimeout(() => cb(0), 16));
    writerFrame = schedule(() => {
      writerFrame = 0;
      syncWritingClass();
    });
  }
  function bindWriterListeners() {
    if (writerListenersBound) {
      return;
    }
    document.addEventListener("focusin", syncWritingClass, true);
    document.addEventListener("focusout", onFocusOut, true);
    writerListenersBound = true;
  }
  function unbindWriterListeners() {
    if (!writerListenersBound) {
      document.documentElement.classList.remove("av-writing");
      return;
    }
    document.removeEventListener("focusin", syncWritingClass, true);
    document.removeEventListener("focusout", onFocusOut, true);
    if (writerFrame !== 0) {
      globalThis.cancelAnimationFrame?.(writerFrame);
      writerFrame = 0;
    }
    writerListenersBound = false;
    document.documentElement.classList.remove("av-writing");
  }
  function ensureLayoutStyle() {
    if (document.getElementById(STYLE_ID6)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID6;
    style.textContent = LAYOUT_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var LAYOUT_CSS = `
html.av-hide-right-sidebar [data-testid="sidebarColumn"] {
  display: none !important;
}

html.av-hide-trends [data-testid="news_sidebar"],
html.av-hide-trends [data-testid="trend"] {
  display: none !important;
}

html.av-hide-grok [data-testid="GrokDrawer"],
html.av-hide-grok [data-testid="GrokDrawerHeader"],
html.av-hide-grok [data-testid="chat-drawer-root"],
html.av-hide-grok [data-testid="chat-drawer-main"],
html.av-hide-grok [data-testid="grokImgGen"] {
  display: none !important;
}

/* Writer mode: only active while focus is inside the composer, so the timeline is untouched
   the rest of the time. Nothing is display:none'd here \u2014 the surroundings recede and come
   straight back on blur, which keeps the effect reversible mid-scroll. */
html.av-writer-mode.av-writing [data-testid="sidebarColumn"],
html.av-writer-mode.av-writing [data-testid="news_sidebar"] {
  opacity: 0.12;
  pointer-events: none;
}

html.av-writer-mode.av-writing [data-testid="cellInnerDiv"] {
  opacity: 0.28;
}

html.av-writer-mode [data-testid="sidebarColumn"],
html.av-writer-mode [data-testid="news_sidebar"],
html.av-writer-mode [data-testid="cellInnerDiv"] {
  transition: opacity 160ms ease;
}

html.av-writer-mode.av-writing [data-testid="cellInnerDiv"]:hover {
  opacity: 1;
}

html.av-hide-nav-premium [data-testid="premium-signup-tab"],
html.av-hide-nav-home [data-testid="AppTabBar_Home_Link"],
html.av-hide-nav-explore [data-testid="AppTabBar_Explore_Link"],
html.av-hide-nav-notifications [data-testid="AppTabBar_Notifications_Link"],
html.av-hide-nav-messages [data-testid="AppTabBar_DirectMessage_Link"],
html.av-hide-nav-profile [data-testid="AppTabBar_Profile_Link"],
html.av-hide-nav-more [data-testid="AppTabBar_More_Menu"] {
  display: none !important;
}
`;

  // src/features/core/audit-log.ts
  var AUDIT_LOG_KEY = "aviary.audit.v1";
  var AUDIT_LOG_LIMIT = 500;
  var EMPTY5 = { entries: [] };
  var AuditLog = class {
    #storage;
    #limit;
    #onPersistError;
    #isEnabled;
    #entries = [];
    #loaded = false;
    #loading;
    constructor(storage, limit = AUDIT_LOG_LIMIT, onPersistError, isEnabled) {
      this.#storage = storage;
      this.#limit = Math.max(50, limit);
      this.#onPersistError = onPersistError;
      this.#isEnabled = isEnabled;
    }
    async load() {
      if (this.#loaded) return;
      if (!this.#loading) {
        this.#loading = this.#hydrate();
      }
      await this.#loading;
    }
    async record(action, detail) {
      if (this.#isEnabled && !this.#isEnabled()) {
        return;
      }
      await this.load();
      const entry = { at: (/* @__PURE__ */ new Date()).toISOString(), action };
      if (detail) entry.detail = detail;
      this.#entries.push(entry);
      while (this.#entries.length > this.#limit) {
        this.#entries.shift();
      }
      await this.#persist();
    }
    snapshot() {
      return { entries: [...this.#entries] };
    }
    async clear() {
      this.#entries = [];
      this.#loaded = true;
      await this.#persist();
    }
    size() {
      return this.#entries.length;
    }
    async #hydrate() {
      const stored = await this.#storage.get(AUDIT_LOG_KEY, EMPTY5);
      const entries = Array.isArray(stored?.entries) ? stored.entries : [];
      this.#entries = entries.filter(
        (entry) => typeof entry?.at === "string" && typeof entry?.action === "string"
      ).slice(-this.#limit);
      this.#loaded = true;
    }
    async #persist() {
      try {
        await this.#storage.set(AUDIT_LOG_KEY, { entries: this.#entries });
      } catch (error) {
        this.#onPersistError?.(error);
      }
    }
  };

  // src/features/integrations/ai-provider.ts
  async function runAiPrompt(config, request) {
    assertOutboundAllowed("The AI request");
    if (!config.enabled) return { ok: false, error: "AI provider integration disabled" };
    if (!config.apiKey) return { ok: false, error: "AI provider API key missing" };
    if (!config.model) return { ok: false, error: "AI provider model missing" };
    try {
      switch (config.provider) {
        case "anthropic":
          return await callAnthropic(config, request);
        case "openai":
        case "openai-compatible":
        default:
          return await callOpenAiCompatible(config, request);
      }
    } catch (error) {
      return { ok: false, error: String(error?.message ?? error) };
    }
  }
  async function callAnthropic(config, request) {
    const endpoint = config.endpoint || "https://api.anthropic.com/v1/messages";
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": config.apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: config.model,
        max_tokens: request.maxTokens ?? 1024,
        system: request.systemPrompt,
        messages: [{ role: "user", content: request.prompt }]
      })
    });
    if (!response.ok) {
      return { ok: false, error: `Anthropic HTTP ${response.status}` };
    }
    const payload = await response.json();
    if (payload?.error) return { ok: false, error: payload.error.message ?? "Anthropic error" };
    const text = payload?.content?.filter((block) => block?.type === "text").map((block) => block.text ?? "").join("\n");
    return { ok: true, text: text ?? "" };
  }
  async function callOpenAiCompatible(config, request) {
    const endpoint = config.endpoint || "https://api.openai.com/v1/chat/completions";
    const headers = {
      "content-type": "application/json",
      authorization: `Bearer ${config.apiKey}`
    };
    const response = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: config.model,
        max_tokens: request.maxTokens ?? 1024,
        messages: [
          ...request.systemPrompt ? [{ role: "system", content: request.systemPrompt }] : [],
          { role: "user", content: request.prompt }
        ]
      })
    });
    if (!response.ok) {
      return { ok: false, error: `Provider HTTP ${response.status}` };
    }
    const payload = await response.json();
    if (payload?.error) return { ok: false, error: payload.error.message ?? "Provider error" };
    const text = payload?.choices?.[0]?.message?.content ?? "";
    return { ok: true, text };
  }

  // src/features/ai/command-menu.ts
  var STYLE_ID7 = "av-ai-command-menu";
  var TRIGGER_ATTR = "data-av-ai-trigger";
  var PROCESSED_ATTR3 = "data-av-ai-processed";
  var AI_COMMANDS = [
    {
      id: "translate",
      label: "Translate",
      hint: "Translate the selected post to your active locale.",
      promptTemplate: (text) => `Translate the following X post. Keep the tone, hashtags, and @mentions intact.

${text}`
    },
    {
      id: "summarize",
      label: "Summarize",
      hint: "Summarize a thread or long post in 3 bullet points.",
      promptTemplate: (text) => `Summarize the following X post (or thread) in 3 short bullet points. Avoid speculation.

${text}`
    },
    {
      id: "explain",
      label: "Explain",
      hint: "Explain context, jargon, and references in the post.",
      promptTemplate: (text) => `Explain the context behind this X post: define jargon, expand acronyms, and note references that might be unfamiliar.

${text}`
    },
    {
      id: "factcheck",
      label: "Fact-check prompt",
      hint: "Generate a fact-check prompt for the post (no network call without your key).",
      promptTemplate: (text) => `Treat this X post as a claim. List the verifiable assertions, the kind of source that would confirm each one, and any obvious counterpoints. Do not invent sources.

${text}`
    }
  ];
  var aiCommandMenuFeature = {
    id: "ai.commandMenu",
    title: "AI command menu (local prompt builder)",
    category: "core",
    defaultEnabled: true,
    init(ctx) {
      ensureStyle3();
      decorate2(ctx, document);
      ctx.diagnostics.info("AI command menu ready");
    },
    apply(ctx, root, addedNodes) {
      ensureStyle3();
      if (!addedNodes || addedNodes.length === 0) {
        decorate2(ctx, root);
        return;
      }
      for (const node of addedNodes) {
        decorate2(ctx, node);
      }
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID7)?.remove();
      for (const article of Array.from(document.querySelectorAll(`[${PROCESSED_ATTR3}]`))) {
        article.removeAttribute(PROCESSED_ATTR3);
      }
      for (const trigger of Array.from(document.querySelectorAll(`[${TRIGGER_ATTR}]`))) {
        trigger.remove();
      }
      ctx.diagnostics.info("AI command menu destroyed");
    },
    getStatus() {
      return { ok: true, message: `${AI_COMMANDS.length} local AI prompts` };
    }
  };
  function decorate2(ctx, root) {
    const articles = root instanceof Element && root.matches('article[data-testid="tweet"]') ? [root] : Array.from(root.querySelectorAll('article[data-testid="tweet"]'));
    for (const article of articles) {
      if (article.getAttribute(PROCESSED_ATTR3) === "1") {
        continue;
      }
      const toolbar = article.querySelector('[role="group"][aria-label]');
      if (!toolbar) {
        article.setAttribute(PROCESSED_ATTR3, "1");
        continue;
      }
      if (toolbar.querySelector(`[${TRIGGER_ATTR}]`)) {
        article.setAttribute(PROCESSED_ATTR3, "1");
        continue;
      }
      const trigger = document.createElement("button");
      trigger.type = "button";
      trigger.className = "av-ai-trigger";
      trigger.setAttribute(TRIGGER_ATTR, "1");
      trigger.setAttribute("aria-label", "Open Aviary AI command menu");
      trigger.title = "Aviary AI commands (offline prompt builder)";
      trigger.textContent = "AI";
      trigger.addEventListener("click", (event) => {
        event.stopPropagation();
        event.preventDefault();
        openMenu(article, trigger, ctx);
      });
      toolbar.append(trigger);
      article.setAttribute(PROCESSED_ATTR3, "1");
    }
  }
  function openMenu(article, trigger, ctx) {
    for (const previous of Array.from(document.querySelectorAll(".av-ai-menu"))) {
      previous.remove();
    }
    const menu = document.createElement("div");
    menu.className = "av-ai-menu";
    menu.setAttribute("role", "menu");
    const text = (article.querySelector('[data-testid="tweetText"]')?.textContent ?? article.textContent ?? "").trim();
    const aiEnabled = ctx.settings.integrations.ai.enabled && ctx.settings.integrations.ai.apiKey.length > 0;
    for (const command of AI_COMMANDS) {
      const item = document.createElement("button");
      item.type = "button";
      item.className = "av-ai-option";
      item.setAttribute("role", "menuitem");
      item.title = command.hint;
      item.textContent = aiEnabled ? `${command.label} (Run with provider)` : command.label;
      item.addEventListener("click", async (event) => {
        event.stopPropagation();
        event.preventDefault();
        const prompt = command.promptTemplate(text);
        if (aiEnabled) {
          item.disabled = true;
          item.textContent = `${command.label} \u2014 running\u2026`;
          const result = await runAiPrompt(ctx.settings.integrations.ai, { prompt });
          if (result.ok && result.text) {
            try {
              await copyToClipboard(result.text);
              ctx.diagnostics.info("AI result copied", {
                command: command.id,
                length: result.text.length
              });
              void ctx.auditLog.record("diagnostics.copy", {
                kind: "ai-response",
                command: command.id,
                provider: ctx.settings.integrations.ai.provider
              });
            } catch (error) {
              ctx.diagnostics.warn("AI result clipboard failed", {
                error: String(error?.message ?? error)
              });
            }
          } else {
            ctx.diagnostics.warn("AI provider call failed", { error: result.error ?? "unknown" });
          }
        } else {
          try {
            await copyToClipboard(prompt);
            ctx.diagnostics.info("AI prompt copied", { command: command.id, length: prompt.length });
            void ctx.auditLog.record("diagnostics.copy", { kind: "ai", command: command.id });
          } catch (error) {
            ctx.diagnostics.warn("AI prompt clipboard failed", {
              error: String(error?.message ?? error)
            });
          }
        }
        menu.remove();
      });
      menu.append(item);
    }
    positionMenu(menu, trigger);
    document.body.append(menu);
    const dismiss = (event) => {
      if (!menu.contains(event.target) && event.target !== trigger) {
        menu.remove();
        document.removeEventListener("click", dismiss, true);
      }
    };
    setTimeout(() => document.addEventListener("click", dismiss, true), 0);
  }
  function positionMenu(menu, trigger) {
    const rect = trigger.getBoundingClientRect();
    menu.style.position = "fixed";
    menu.style.left = `${Math.max(12, rect.left)}px`;
    menu.style.top = `${Math.max(12, rect.bottom + 6)}px`;
    menu.style.maxWidth = "260px";
  }
  async function copyToClipboard(text) {
    const clipboard = globalThis.navigator?.clipboard;
    if (clipboard?.writeText) {
      await clipboard.writeText(text);
      return;
    }
    throw new Error("Clipboard API unavailable");
  }
  function ensureStyle3() {
    if (document.getElementById(STYLE_ID7)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID7;
    style.textContent = AI_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var AI_CSS = `
.av-ai-trigger {
  margin-inline-start: auto;
  padding: 2px 8px;
  border: 1px solid color-mix(in srgb, var(--av-muted, rgb(113, 118, 123)) 60%, transparent);
  border-radius: 6px;
  background: transparent;
  color: var(--av-muted, rgb(113, 118, 123));
  font: 700 10px/1.2 inherit;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  cursor: pointer;
  opacity: 0;
  transition: opacity 120ms ease, color 120ms ease, border-color 120ms ease;
}

article[data-testid="tweet"]:hover .av-ai-trigger,
article[data-testid="tweet"]:focus-within .av-ai-trigger,
.av-ai-trigger:focus-visible {
  opacity: 1;
  color: var(--av-text, rgb(239, 243, 244));
  border-color: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 60%, transparent);
}

.av-ai-menu {
  z-index: 2147482800;
  display: grid;
  gap: 4px;
  padding: 8px;
  border: 1px solid var(--av-border, rgb(47, 51, 54));
  border-radius: 10px;
  background: color-mix(in srgb, var(--av-surface, rgb(15, 20, 25)) 96%, black);
  box-shadow: 0 14px 36px rgba(0, 0, 0, 0.4);
}

.av-ai-option {
  padding: 6px 10px;
  border: 1px solid transparent;
  border-radius: 6px;
  background: transparent;
  color: var(--av-text, rgb(239, 243, 244));
  font: 600 12px/1.3 inherit;
  text-align: start;
  cursor: pointer;
}

.av-ai-option:hover,
.av-ai-option:focus-visible {
  border-color: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 60%, transparent);
  background: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 12%, transparent);
}
`;

  // src/features/composer/composer-snippets.ts
  var STYLE_ID8 = "av-composer-snippets";
  var TOOLBAR_ATTR = "data-av-composer-mounted";
  var PALETTE_ATTR = "data-av-snippet-palette";
  var composerSnippetsFeature = {
    id: "composer.snippets",
    title: "Composer snippets",
    category: "core",
    defaultEnabled: true,
    init(ctx) {
      ensureComposerStyle();
      decorate3(ctx, document);
      ctx.diagnostics.info("Composer snippets initialized");
    },
    apply(ctx, root, addedNodes) {
      ensureComposerStyle();
      if (!addedNodes || addedNodes.length === 0) {
        decorate3(ctx, root);
        return;
      }
      for (const node of addedNodes) {
        decorate3(ctx, node);
      }
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID8)?.remove();
      for (const toolbar of Array.from(document.querySelectorAll(`[${TOOLBAR_ATTR}]`))) {
        toolbar.removeAttribute(TOOLBAR_ATTR);
      }
      for (const palette of Array.from(document.querySelectorAll(`[${PALETTE_ATTR}]`))) {
        palette.remove();
      }
      ctx.diagnostics.info("Composer snippets destroyed");
    },
    getStatus() {
      return { ok: true, message: "Composer snippets ready" };
    }
  };
  function decorate3(ctx, root) {
    const toolbars = root instanceof Element && root.matches('[data-testid="toolBar"]') ? [root] : Array.from(root.querySelectorAll('[data-testid="toolBar"]'));
    for (const toolbar of toolbars) {
      if (toolbar.getAttribute(TOOLBAR_ATTR) === "1") {
        continue;
      }
      const button2 = document.createElement("button");
      button2.type = "button";
      button2.className = "av-snippet-trigger";
      button2.setAttribute(PALETTE_ATTR, "trigger");
      button2.textContent = "Snippets";
      button2.setAttribute("aria-label", "Open Aviary composer snippets");
      button2.addEventListener("click", (event) => {
        event.stopPropagation();
        event.preventDefault();
        openPalette(button2, ctx);
      });
      toolbar.append(button2);
      toolbar.setAttribute(TOOLBAR_ATTR, "1");
    }
  }
  function openPalette(trigger, ctx) {
    for (const previous of Array.from(document.querySelectorAll(`[${PALETTE_ATTR}="popover"]`))) {
      previous.remove();
    }
    const snippets = ctx.settings.composer.snippets;
    const popover = document.createElement("div");
    popover.setAttribute(PALETTE_ATTR, "popover");
    popover.className = "av-snippet-popover";
    popover.setAttribute("role", "menu");
    if (snippets.length === 0) {
      const empty = document.createElement("div");
      empty.className = "av-snippet-empty";
      empty.textContent = "No snippets yet. Add some in the Control Center \u2192 Library.";
      popover.append(empty);
    } else {
      for (const snippet2 of snippets) {
        const option = document.createElement("button");
        option.type = "button";
        option.className = "av-snippet-option";
        option.textContent = snippet2.length > 80 ? `${snippet2.slice(0, 77)}\u2026` : snippet2;
        option.setAttribute("role", "menuitem");
        option.title = snippet2;
        option.addEventListener("click", (event) => {
          event.stopPropagation();
          event.preventDefault();
          if (insertSnippet(snippet2)) {
            ctx.diagnostics.info("Snippet inserted", { length: snippet2.length });
            void ctx.auditLog.record("settings.import", { kind: "snippet", length: snippet2.length });
          } else {
            ctx.diagnostics.warn("Snippet insert failed \u2014 composer not focused");
          }
          popover.remove();
        });
        popover.append(option);
      }
    }
    positionPopover(popover, trigger);
    document.body.append(popover);
    const dismiss = (event) => {
      if (!popover.contains(event.target) && event.target !== trigger) {
        popover.remove();
        document.removeEventListener("click", dismiss, true);
      }
    };
    setTimeout(() => document.addEventListener("click", dismiss, true), 0);
  }
  function insertSnippet(snippet2) {
    const composer = document.querySelector('[data-testid="tweetTextarea_0"]');
    if (!composer) return false;
    composer.focus();
    const ok = document.execCommand("insertText", false, snippet2);
    if (!ok) {
      return false;
    }
    composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: snippet2 }));
    return true;
  }
  function positionPopover(popover, trigger) {
    const rect = trigger.getBoundingClientRect();
    popover.style.position = "fixed";
    popover.style.left = `${Math.max(12, rect.left)}px`;
    popover.style.bottom = `${Math.max(12, window.innerHeight - rect.top + 8)}px`;
    popover.style.maxWidth = "320px";
  }
  function ensureComposerStyle() {
    if (document.getElementById(STYLE_ID8)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID8;
    style.textContent = COMPOSER_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var COMPOSER_CSS = `
.av-snippet-trigger {
  margin-inline-start: 8px;
  padding: 4px 10px;
  border: 1px solid color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 60%, transparent);
  border-radius: 6px;
  background: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 14%, transparent);
  color: var(--av-text, rgb(239, 243, 244));
  font: 700 11px/1.2 inherit;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  cursor: pointer;
}

.av-snippet-popover {
  z-index: 2147482700;
  display: grid;
  gap: 4px;
  padding: 8px;
  border: 1px solid var(--av-border, rgb(47, 51, 54));
  border-radius: 10px;
  background: color-mix(in srgb, var(--av-surface, rgb(15, 20, 25)) 96%, black);
  box-shadow: 0 14px 36px rgba(0, 0, 0, 0.4);
}

.av-snippet-option {
  padding: 6px 8px;
  border: 1px solid transparent;
  border-radius: 6px;
  background: transparent;
  color: var(--av-text, rgb(239, 243, 244));
  font: 600 12px/1.3 inherit;
  text-align: start;
  cursor: pointer;
}

.av-snippet-option:hover,
.av-snippet-option:focus-visible {
  border-color: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 60%, transparent);
  background: color-mix(in srgb, var(--av-accent, rgb(29, 155, 240)) 12%, transparent);
}

.av-snippet-empty {
  padding: 6px 8px;
  color: var(--av-muted, rgb(113, 118, 123));
  font-size: 12px;
}
`;

  // src/features/core/i18n-feature.ts
  var STYLE_ID9 = "av-i18n";
  var i18nFeature = {
    id: "core.i18n",
    title: "Internationalization",
    category: "core",
    defaultEnabled: true,
    init(ctx) {
      ensureI18nStyle();
      applyLocaleClasses(ctx);
      ctx.diagnostics.info("i18n initialized", { locale: ctx.settings.i18n.locale });
    },
    apply(ctx) {
      ensureI18nStyle();
      applyLocaleClasses(ctx);
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID9)?.remove();
      const root = document.documentElement;
      root.classList.remove("av-rtl", "av-ltr");
      delete root.dataset.avLocale;
      ctx.diagnostics.info("i18n destroyed");
    }
  };
  function applyLocaleClasses(ctx) {
    const root = document.documentElement;
    const direction = localeDirection(ctx.settings.i18n.locale);
    root.dataset.avLocale = ctx.settings.i18n.locale;
    root.classList.toggle("av-rtl", direction === "rtl");
    root.classList.toggle("av-ltr", direction === "ltr");
  }
  function ensureI18nStyle() {
    if (document.getElementById(STYLE_ID9)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID9;
    style.textContent = I18N_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var I18N_CSS = `
html.av-rtl [data-testid="tweetText"] {
  text-align: start;
  unicode-bidi: plaintext;
}

html.av-rtl [data-testid="primaryColumn"] {
  direction: rtl;
}

html.av-ltr [data-testid="tweetText"][lang^="ar"],
html.av-ltr [data-testid="tweetText"][lang^="he"] {
  direction: rtl;
  text-align: start;
  unicode-bidi: plaintext;
}

[data-testid="tweetText"],
[data-testid="cellInnerDiv"] {
  overflow-wrap: anywhere;
  word-break: break-word;
}

@media (pointer: coarse) {
  html [data-testid="reply"],
  html [data-testid="retweet"],
  html [data-testid="like"],
  html [data-testid="bookmark"] {
    min-height: 44px;
    min-width: 44px;
  }
}
`;

  // src/features/core/mobile-touch.ts
  var STYLE_ID10 = "av-mobile-touch";
  var mobileTouchFeature = {
    id: "core.mobileTouch",
    title: "Mobile & touch ergonomics",
    category: "accessibility",
    defaultEnabled: true,
    init(ctx) {
      ensureMobileStyle();
      applyMobileClasses();
      ctx.diagnostics.info("Mobile/touch initialized");
    },
    apply() {
      ensureMobileStyle();
      applyMobileClasses();
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID10)?.remove();
      document.documentElement.classList.remove("av-mobile", "av-touch");
      ctx.diagnostics.info("Mobile/touch destroyed");
    }
  };
  function applyMobileClasses() {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
      return;
    }
    const root = document.documentElement;
    const touch = window.matchMedia("(pointer: coarse)").matches;
    const narrow = window.matchMedia("(max-width: 760px)").matches;
    root.classList.toggle("av-touch", touch);
    root.classList.toggle("av-mobile", narrow);
  }
  function ensureMobileStyle() {
    if (document.getElementById(STYLE_ID10)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID10;
    style.textContent = MOBILE_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var MOBILE_CSS = `
html.av-touch [${"data-av-hide-button"}] {
  min-height: 40px;
  padding: 6px 12px;
}

html.av-touch [${"data-av-media-button"}] {
  min-height: 40px;
  padding: 6px 12px;
  font-size: 12px;
}

html.av-mobile [data-testid="primaryColumn"] {
  padding-inline: 0;
}
`;

  // src/features/export/network-capture.ts
  var MAX_PAYLOAD_BYTES = 15e5;
  var MAX_PAYLOADS = 50;
  var installed = false;
  var activeContext;
  var recentPayloads = [];
  var originalFetch;
  var patchedFetch;
  var networkCaptureFeature = {
    id: "export.networkCapture",
    title: "Passive GraphQL capture",
    category: "export",
    defaultEnabled: true,
    init(ctx) {
      activeContext = ctx;
      if (ctx.settings.export.preserveRawPayloads) {
        installInterceptor(ctx);
      }
      ctx.diagnostics.info("Network capture feature ready", {
        enabled: ctx.settings.export.preserveRawPayloads,
        installed
      });
    },
    apply(ctx) {
      activeContext = ctx;
      if (ctx.settings.export.preserveRawPayloads && !installed) {
        installInterceptor(ctx);
      } else if (!ctx.settings.export.preserveRawPayloads && installed) {
        uninstallInterceptor(ctx);
      }
    },
    destroy(ctx) {
      if (installed) {
        uninstallInterceptor(ctx);
      }
      activeContext = void 0;
      ctx.diagnostics.info("Network capture destroyed");
    },
    getStatus() {
      return {
        ok: true,
        message: installed ? `Capturing GraphQL \u2014 ${recentPayloads.length} payload${recentPayloads.length === 1 ? "" : "s"} sampled` : "Capture inactive"
      };
    }
  };
  function installInterceptor(ctx) {
    if (installed || typeof globalThis.fetch !== "function") return;
    originalFetch = { fn: globalThis.fetch };
    const patched = async (input, init) => {
      const response = await originalFetch.fn(input, init);
      if (response.ok && shouldCapture(resolveUrl(input))) {
        void capturePayload(ctx, input, response.clone());
      }
      return response;
    };
    patchedFetch = patched;
    globalThis.fetch = patchedFetch;
    installed = true;
    ctx.diagnostics.info("Passive GraphQL interceptor installed");
  }
  function uninstallInterceptor(ctx) {
    if (!installed || !originalFetch) return;
    if (globalThis.fetch === patchedFetch) {
      globalThis.fetch = originalFetch.fn;
    } else {
      ctx.diagnostics.warn("fetch was re-patched downstream \u2014 leaving the current wrapper in place");
    }
    originalFetch = void 0;
    patchedFetch = void 0;
    installed = false;
    ctx.diagnostics.info("Passive GraphQL interceptor uninstalled");
  }
  async function capturePayload(ctx, input, response) {
    try {
      const url = resolveUrl(input);
      if (!shouldCapture(url)) return;
      if (!response.ok || !response.body) return;
      const blob = await response.blob();
      if (blob.size === 0 || blob.size > MAX_PAYLOAD_BYTES) return;
      const text = await blob.text();
      recordPayload(url, response.status, blob.size);
      await persistPayload(ctx, url, text);
    } catch (error) {
      ctx.diagnostics.warn("Network capture skipped", { error: String(error?.message ?? error) });
    }
  }
  function resolveUrl(input) {
    if (typeof input === "string") return input;
    if (input instanceof URL) return input.toString();
    return input.url;
  }
  function shouldCapture(url) {
    if (!/\/i\/api\/graphql\//.test(url)) return false;
    return true;
  }
  function recordPayload(url, status, bytes) {
    recentPayloads.push({ url, status, bytes, at: (/* @__PURE__ */ new Date()).toISOString() });
    while (recentPayloads.length > MAX_PAYLOADS) {
      recentPayloads.shift();
    }
  }
  async function persistPayload(ctx, url, body) {
    const store3 = getCheckpointStore();
    if (!store3) return;
    const operationName = /\/i\/api\/graphql\/[^/]+\/([A-Za-z0-9_]+)/.exec(url)?.[1] ?? "graphql";
    const jobId = `capture-${operationName}`;
    if (store3.list().every((entry) => entry.jobId !== jobId)) {
      await store3.start(jobId, "capture", ["json"], true);
    }
    await store3.append(jobId, [
      {
        tweetId: null,
        handle: null,
        displayName: null,
        text: scrubAuth(body).slice(0, MAX_PAYLOAD_BYTES),
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        surface: `graphql:${operationName}`,
        media: [],
        permalink: url
      }
    ]);
    void ctx.auditLog.record("export.start", { jobId, operation: operationName });
  }
  function scrubAuth(body) {
    return body.replace(/"(ct0|auth_token|guest_id|csrf_token)"\s*:\s*"[^"]*"/g, '"$1":"<scrubbed>"').replace(/Bearer\s+[A-Za-z0-9._-]{12,}/g, "Bearer <scrubbed>");
  }

  // src/features/library/clean-share-links.ts
  var PROCESSED_ATTR4 = "data-av-share-clean";
  var ORIGINAL_HREF = "avOriginalHref";
  var TRACKING_PARAMS = /* @__PURE__ */ new Set([
    "t",
    "s",
    "ref_src",
    "ref_url",
    "cxt",
    "twclid",
    "fbclid",
    "gclid",
    "dclid",
    "msclkid",
    "igshid",
    "mc_eid",
    "mc_cid",
    "vero_id",
    "_hsenc",
    "_hsmi"
  ]);
  var X_HOSTS = /(^|\.)((x|twitter)\.com|t\.co)$/i;
  var cleanShareLinksFeature = {
    id: "library.cleanShareLinks",
    title: "Clean share links",
    category: "core",
    defaultEnabled: true,
    init(ctx) {
      if (!ctx.settings.links.cleanShareButtons) {
        return;
      }
      scan2(document);
      ctx.diagnostics.info("Share link cleaning initialized");
    },
    apply(ctx, root, addedNodes) {
      if (!ctx.settings.links.cleanShareButtons) {
        return;
      }
      if (!addedNodes || addedNodes.length === 0) {
        scan2(root);
        return;
      }
      for (const node of addedNodes) {
        scan2(node);
      }
    },
    destroy(ctx) {
      for (const anchor of Array.from(
        document.querySelectorAll(`a[${PROCESSED_ATTR4}]`)
      )) {
        const original = anchor.dataset[ORIGINAL_HREF];
        if (original !== void 0) {
          anchor.setAttribute("href", original);
          delete anchor.dataset[ORIGINAL_HREF];
        }
        anchor.removeAttribute(PROCESSED_ATTR4);
      }
      ctx.diagnostics.info("Share link cleaning destroyed");
    }
  };
  function scan2(root) {
    const anchors = root instanceof HTMLAnchorElement ? [root] : Array.from(root.querySelectorAll("a[href]"));
    for (const anchor of anchors) {
      if (anchor.getAttribute(PROCESSED_ATTR4) === "1") {
        continue;
      }
      const href = anchor.getAttribute("href");
      if (!href) {
        continue;
      }
      const cleaned = cleanUrl(href);
      anchor.setAttribute(PROCESSED_ATTR4, "1");
      if (cleaned === null || cleaned === href) {
        continue;
      }
      if (anchor.dataset[ORIGINAL_HREF] === void 0) {
        anchor.dataset[ORIGINAL_HREF] = href;
      }
      anchor.setAttribute("href", cleaned);
    }
  }
  function cleanUrl(href) {
    const trimmed = href.trim();
    if (trimmed.length === 0 || /^(javascript|data|mailto|blob):/i.test(trimmed)) {
      return null;
    }
    let url;
    const relative = !/^[a-z][a-z0-9+.-]*:/i.test(trimmed) && !trimmed.startsWith("//");
    try {
      url = new URL(trimmed, "https://x.com");
    } catch {
      return null;
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      return null;
    }
    if (/(^|\.)t\.co$/i.test(url.hostname)) {
      return null;
    }
    const keys = [];
    url.searchParams.forEach((_value, key) => {
      keys.push(key);
    });
    let changed = false;
    for (const key of keys) {
      const lower = key.toLowerCase();
      const isCampaign = lower.startsWith("utm_") || TRACKING_PARAMS.has(lower);
      const scopedToX = lower === "t" || lower === "s";
      if (!isCampaign) {
        continue;
      }
      if (scopedToX && !X_HOSTS.test(url.hostname)) {
        continue;
      }
      url.searchParams.delete(key);
      changed = true;
    }
    if (!changed) {
      return null;
    }
    if (relative) {
      return `${url.pathname}${url.search}${url.hash}`;
    }
    return url.toString();
  }

  // src/features/library/link-unshorten.ts
  var STYLE_ID11 = "av-link-unshorten";
  var PROCESSED_ATTR5 = "data-av-link-clean";
  var linkUnshortenFeature = {
    id: "library.linkUnshorten",
    title: "Direct link unshortening",
    category: "core",
    defaultEnabled: true,
    init(ctx) {
      ensureStyle4();
      if (!ctx.settings.links.expandTco) {
        return;
      }
      scan3(document);
      ctx.diagnostics.info("Link unshortening initialized");
    },
    apply(ctx, root, addedNodes) {
      ensureStyle4();
      if (!ctx.settings.links.expandTco) {
        return;
      }
      if (!addedNodes || addedNodes.length === 0) {
        scan3(root);
        return;
      }
      for (const node of addedNodes) {
        scan3(node);
      }
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID11)?.remove();
      for (const link of Array.from(
        document.querySelectorAll(`a[${PROCESSED_ATTR5}]`)
      )) {
        link.removeAttribute(PROCESSED_ATTR5);
        link.classList.remove("av-link-clean");
        const original = link.dataset.avOriginalText;
        if (original !== void 0) {
          link.textContent = original;
          delete link.dataset.avOriginalText;
        }
        const originalTitle = link.dataset.avOriginalTitle;
        link.title = originalTitle ?? "";
        delete link.dataset.avOriginalTitle;
      }
      ctx.diagnostics.info("Link unshortening destroyed");
    }
  };
  function scan3(root) {
    const anchors = root instanceof HTMLAnchorElement ? [root] : Array.from(root.querySelectorAll("a"));
    for (const anchor of anchors) {
      if (anchor.getAttribute(PROCESSED_ATTR5) === "1") {
        continue;
      }
      const href = anchor.getAttribute("href") ?? "";
      if (!/(^|\.)t\.co\//.test(href) && !/^https?:\/\/t\.co\//.test(href)) {
        continue;
      }
      const target = resolveDestination(anchor);
      if (!target) {
        continue;
      }
      if (!anchor.dataset.avOriginalText) {
        anchor.dataset.avOriginalText = anchor.textContent ?? "";
      }
      if (anchor.dataset.avOriginalTitle === void 0) {
        anchor.dataset.avOriginalTitle = anchor.title;
      }
      anchor.classList.add("av-link-clean");
      anchor.title = target;
      anchor.setAttribute(PROCESSED_ATTR5, "1");
      if (anchor.textContent && /^https?:\/\/t\.co\//i.test(anchor.textContent.trim())) {
        anchor.textContent = target;
      }
    }
  }
  function resolveDestination(anchor) {
    const candidates = [
      anchor.getAttribute("aria-label") ?? "",
      anchor.getAttribute("data-expanded-url") ?? "",
      anchor.title,
      anchor.textContent ?? ""
    ];
    for (const candidate of candidates) {
      const match = /https?:\/\/[^\s]+/i.exec(candidate);
      if (match && !/^https?:\/\/t\.co\//i.test(match[0])) {
        return match[0];
      }
    }
    return null;
  }
  function ensureStyle4() {
    if (document.getElementById(STYLE_ID11)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID11;
    style.textContent = LINK_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var LINK_CSS = `
a.av-link-clean {
  text-decoration-style: dotted;
  text-decoration-thickness: 1px;
}
`;

  // src/features/media/media-presentation.ts
  var STYLE_ID12 = "av-media-presentation";
  var mediaPresentationFeature = {
    id: "media.presentation",
    title: "Media presentation",
    category: "media",
    defaultEnabled: true,
    init(ctx) {
      ensurePresentationStyle();
      applyPresentationClasses(ctx);
      ctx.diagnostics.info("Media presentation initialized", {
        sensitive: ctx.settings.media.sensitive,
        layout: ctx.settings.media.layout
      });
    },
    apply(ctx) {
      ensurePresentationStyle();
      applyPresentationClasses(ctx);
    },
    destroy(ctx) {
      document.getElementById(STYLE_ID12)?.remove();
      const root = document.documentElement;
      for (const className of [
        "av-sensitive-default",
        "av-sensitive-reveal",
        "av-sensitive-blur",
        "av-sensitive-hide",
        "av-media-layout-default",
        "av-media-layout-stacked",
        "av-media-layout-grid"
      ]) {
        root.classList.remove(className);
      }
      ctx.diagnostics.info("Media presentation destroyed");
    }
  };
  function applyPresentationClasses(ctx) {
    const root = document.documentElement;
    for (const className of [
      "av-sensitive-default",
      "av-sensitive-reveal",
      "av-sensitive-blur",
      "av-sensitive-hide"
    ]) {
      root.classList.remove(className);
    }
    root.classList.add(`av-sensitive-${ctx.settings.media.sensitive}`);
    for (const className of [
      "av-media-layout-default",
      "av-media-layout-stacked",
      "av-media-layout-grid"
    ]) {
      root.classList.remove(className);
    }
    root.classList.add(`av-media-layout-${ctx.settings.media.layout}`);
  }
  function ensurePresentationStyle() {
    if (document.getElementById(STYLE_ID12)) {
      return;
    }
    const style = document.createElement("style");
    style.id = STYLE_ID12;
    style.textContent = PRESENTATION_CSS;
    (document.head ?? document.documentElement).append(style);
  }
  var PRESENTATION_CSS = `
html.av-sensitive-reveal article[data-testid="tweet"] [data-testid="contentDisclosureButton"] {
  display: none !important;
}

html.av-sensitive-reveal article[data-testid="tweet"] [data-testid="tweetPhoto"] img,
html.av-sensitive-reveal article[data-testid="tweet"] [data-testid="videoPlayer"] video,
html.av-sensitive-reveal article[data-testid="tweet"] [data-testid="videoComponent"] video {
  filter: none !important;
}

html.av-sensitive-blur article[data-testid="tweet"] [data-testid="tweetPhoto"] img,
html.av-sensitive-blur article[data-testid="tweet"] [data-testid="videoPlayer"] video,
html.av-sensitive-blur article[data-testid="tweet"] [data-testid="videoComponent"] video {
  filter: blur(18px) saturate(0.85) !important;
  transition: filter 160ms ease;
}

html.av-sensitive-blur article[data-testid="tweet"] [data-testid="tweetPhoto"]:hover img,
html.av-sensitive-blur article[data-testid="tweet"] [data-testid="tweetPhoto"]:focus-within img {
  filter: none !important;
}

html.av-sensitive-hide article[data-testid="tweet"] [data-testid="tweetPhoto"],
html.av-sensitive-hide article[data-testid="tweet"] [data-testid="videoPlayer"],
html.av-sensitive-hide article[data-testid="tweet"] [data-testid="videoComponent"] {
  display: none !important;
}

html.av-media-layout-stacked article[data-testid="tweet"] [data-testid="tweetPhoto"] {
  display: block !important;
  width: 100% !important;
  max-width: 100% !important;
  margin: 8px 0 !important;
}

html.av-media-layout-stacked article[data-testid="tweet"] [data-testid="tweetPhoto"] img {
  width: 100% !important;
  height: auto !important;
  object-fit: contain !important;
  border-radius: 12px;
}

html.av-media-layout-grid article[data-testid="tweet"] [aria-label="Image"] {
  display: grid !important;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)) !important;
  gap: 6px !important;
}
`;

  // src/features/registry.ts
  var FeatureRegistry = class {
    #features = /* @__PURE__ */ new Map();
    #active = /* @__PURE__ */ new Set();
    register(feature) {
      if (this.#features.has(feature.id)) {
        throw new Error(`Feature already registered: ${feature.id}`);
      }
      this.#features.set(feature.id, feature);
    }
    async initAll(ctx) {
      for (const feature of this.#features.values()) {
        if (!feature.defaultEnabled) {
          continue;
        }
        try {
          await feature.init(ctx);
          this.#active.add(feature.id);
          ctx.diagnostics.info(`Feature initialized: ${feature.id}`);
        } catch (error) {
          ctx.diagnostics.error(`Feature failed to initialize: ${feature.id}`, errorDetails5(error));
        }
      }
    }
    async applyAll(ctx, root, addedNodes) {
      for (const id of this.#active) {
        const feature = this.#features.get(id);
        if (feature?.apply) {
          try {
            await feature.apply(ctx, root, addedNodes);
          } catch (error) {
            ctx.diagnostics.error(`Feature failed to apply: ${id}`, errorDetails5(error));
          }
        }
      }
    }
    async destroyAll(ctx) {
      for (const id of [...this.#active].reverse()) {
        const feature = this.#features.get(id);
        try {
          if (feature) {
            await feature.destroy(ctx);
          }
        } catch (error) {
          ctx.diagnostics.error(`Feature failed to destroy: ${id}`, errorDetails5(error));
        }
        this.#active.delete(id);
      }
    }
    statuses() {
      return [...this.#features.values()].map((feature) => {
        try {
          return feature.getStatus?.() ?? {
            ok: true,
            message: `${feature.id} registered`
          };
        } catch (error) {
          return {
            ok: false,
            message: `${feature.id} status failed`,
            details: errorDetails5(error)
          };
        }
      });
    }
  };
  function errorDetails5(error) {
    if (error instanceof Error) {
      return {
        name: error.name,
        message: error.message
      };
    }
    return {
      message: String(error)
    };
  }

  // src/platform/diagnostics.ts
  var Diagnostics = class {
    #events = [];
    info(message, details) {
      this.push("info", message, details);
    }
    warn(message, details) {
      this.push("warn", message, details);
    }
    error(message, details) {
      this.push("error", message, details);
    }
    snapshot() {
      return [...this.#events];
    }
    push(level, message, details) {
      const event = {
        level,
        message,
        at: (/* @__PURE__ */ new Date()).toISOString(),
        ...details ? { details } : {}
      };
      this.#events.push(event);
      if (this.#events.length > 200) {
        this.#events.shift();
      }
    }
  };

  // src/platform/observer.ts
  var FLUSH_DELAY_MS = 120;
  var MAX_BATCH_NODES = 400;
  function observeAddedElements(root, onAdded) {
    let pending = /* @__PURE__ */ new Set();
    let timer;
    let overflowed = false;
    let stopped = false;
    const flush = () => {
      timer = void 0;
      if (stopped) {
        return;
      }
      const batch = overflowed ? [] : [...pending].filter((node) => node.isConnected);
      const wasOverflowed = overflowed;
      pending = /* @__PURE__ */ new Set();
      overflowed = false;
      if (wasOverflowed) {
        onAdded([], root);
        return;
      }
      if (batch.length > 0) {
        onAdded(batch, root);
      }
    };
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of Array.from(mutation.addedNodes)) {
          if (!(node instanceof Element)) {
            continue;
          }
          if (pending.size >= MAX_BATCH_NODES) {
            overflowed = true;
            pending.clear();
            break;
          }
          pending.add(node);
        }
      }
      if (pending.size === 0 && !overflowed) {
        return;
      }
      if (timer === void 0) {
        timer = setTimeout(flush, FLUSH_DELAY_MS);
      }
    });
    observer.observe(root, {
      childList: true,
      subtree: true
    });
    return () => {
      stopped = true;
      observer.disconnect();
      if (timer !== void 0) {
        clearTimeout(timer);
        timer = void 0;
      }
      pending = /* @__PURE__ */ new Set();
    };
  }

  // src/platform/rate-limit.ts
  var TokenBucket = class {
    constructor(capacity, refillPerSecond) {
      this.capacity = capacity;
      this.refillPerSecond = refillPerSecond;
      this.#tokens = capacity;
      this.#lastRefill = Date.now();
    }
    #tokens;
    #lastRefill;
    tryRemove(tokens = 1) {
      this.refill();
      if (this.#tokens < tokens) {
        return false;
      }
      this.#tokens -= tokens;
      return true;
    }
    /**
     * Waits until `tokens` are available. Asking for more than the bucket can ever hold used to
     * spin forever, because refill() clamps at capacity and the condition could never become
     * true — a silent hang rather than a visible error.
     */
    async waitForToken(tokens = 1) {
      if (tokens > this.capacity) {
        throw new RangeError(
          `TokenBucket asked for ${tokens} tokens but capacity is ${this.capacity}; this would wait forever.`
        );
      }
      while (!this.tryRemove(tokens)) {
        await delay(250);
      }
    }
    snapshot() {
      this.refill();
      return {
        tokens: this.#tokens,
        capacity: this.capacity,
        refillPerSecond: this.refillPerSecond
      };
    }
    refill() {
      const now = Date.now();
      const elapsed = Math.max(0, now - this.#lastRefill) / 1e3;
      this.#tokens = Math.min(this.capacity, this.#tokens + elapsed * this.refillPerSecond);
      this.#lastRefill = now;
    }
  };
  function delay(ms) {
    return new Promise((resolve) => {
      globalThis.setTimeout(resolve, ms);
    });
  }

  // src/platform/route.ts
  function readRoute(location2 = globalThis.location) {
    const path = location2.pathname;
    return {
      href: location2.href,
      path,
      surface: detectSurface(path)
    };
  }
  function watchRoute(onRoute) {
    const history2 = globalThis.history;
    const originalPush = history2.pushState;
    const originalReplace = history2.replaceState;
    const callOriginalPush = originalPush.bind(history2);
    const callOriginalReplace = originalReplace.bind(history2);
    let lastHref = globalThis.location.href;
    const emitIfChanged = () => {
      if (globalThis.location.href === lastHref) {
        return;
      }
      lastHref = globalThis.location.href;
      onRoute(readRoute());
    };
    const patchedPush = (...args) => {
      callOriginalPush(...args);
      queueMicrotask(emitIfChanged);
    };
    const patchedReplace = (...args) => {
      callOriginalReplace(...args);
      queueMicrotask(emitIfChanged);
    };
    try {
      history2.pushState = patchedPush;
      history2.replaceState = patchedReplace;
    } catch {
    }
    globalThis.addEventListener("popstate", emitIfChanged);
    return () => {
      try {
        if (history2.pushState === patchedPush) {
          history2.pushState = originalPush;
        }
        if (history2.replaceState === patchedReplace) {
          history2.replaceState = originalReplace;
        }
      } catch {
      }
      globalThis.removeEventListener("popstate", emitIfChanged);
    };
  }
  function detectSurface(path) {
    if (path === "/home") return "home";
    if (/\/status\/\d+/.test(path)) return "status";
    if (path.startsWith("/notifications")) return "notifications";
    if (path.startsWith("/messages")) return "messages";
    if (path.startsWith("/settings")) return "settings";
    if (path.startsWith("/search")) return "search";
    if (path.startsWith("/i/grok")) return "grok";
    if (/^\/[^/]+$/.test(path)) return "profile";
    return "unknown";
  }

  // src/platform/storage.ts
  var onWriteError;
  function setStorageErrorSink(sink) {
    onWriteError = sink;
  }
  function createStorageGateway(namespace = "aviary") {
    const scoped = (key) => {
      if (namespace.length === 0 || key.startsWith(`${namespace}.`)) {
        return key;
      }
      return `${namespace}.${key}`;
    };
    const globals = globalThis;
    return {
      async get(key, fallback) {
        const storageKey = scoped(key);
        try {
          if (typeof globals.GM_getValue === "function") {
            return await globals.GM_getValue(storageKey, fallback);
          }
          if (globalThis.chrome?.storage?.local) {
            const result = await globalThis.chrome.storage.local.get(storageKey);
            return result[storageKey] === void 0 ? fallback : result[storageKey];
          }
          const raw = globalThis.localStorage?.getItem(storageKey);
          return raw === null || raw === void 0 ? fallback : JSON.parse(raw);
        } catch {
          return fallback;
        }
      },
      async set(key, value) {
        const storageKey = scoped(key);
        try {
          if (typeof globals.GM_setValue === "function") {
            await globals.GM_setValue(storageKey, value);
            return;
          }
          if (globalThis.chrome?.storage?.local) {
            await globalThis.chrome.storage.local.set({ [storageKey]: value });
            return;
          }
          if (globalThis.localStorage) {
            globalThis.localStorage.setItem(storageKey, JSON.stringify(value));
            return;
          }
          throw new Error(`No storage backend is available for ${storageKey}`);
        } catch (error) {
          onWriteError?.(storageKey, error);
          throw error;
        }
      },
      async remove(key) {
        const storageKey = scoped(key);
        if (typeof globals.GM_deleteValue === "function") {
          await globals.GM_deleteValue(storageKey);
          return;
        }
        if (globalThis.chrome?.storage?.local) {
          await globalThis.chrome.storage.local.remove(storageKey);
          return;
        }
        if (globalThis.localStorage) {
          globalThis.localStorage.removeItem(storageKey);
          return;
        }
        throw new Error(`No storage backend is available for ${storageKey}`);
      }
    };
  }

  // src/platform/trusted-types.ts
  function createTrustedHtmlPolicy(name = "aviary") {
    const factory = globalThis.window?.trustedTypes;
    if (!factory) {
      return {
        html(input) {
          return input;
        }
      };
    }
    let policy;
    try {
      policy = factory.createPolicy(name, {
        createHTML(input) {
          return input;
        }
      });
    } catch {
      policy = void 0;
    }
    return {
      html(input) {
        return policy ? policy.createHTML(input) : input;
      }
    };
  }

  // src/main.ts
  var activeApp;
  var bootingApp;
  function boot(options) {
    if (typeof document === "undefined") {
      return Promise.resolve(void 0);
    }
    if (activeApp) {
      return Promise.resolve(activeApp);
    }
    if (bootingApp) {
      return bootingApp;
    }
    bootingApp = bootInternal(options).finally(() => {
      bootingApp = void 0;
    });
    return bootingApp;
  }
  async function bootInternal(options) {
    document.documentElement.dataset.avTheme = DEFAULT_SETTINGS.appearance.theme;
    document.documentElement.dataset.avReady = "booting";
    const storage = createStorageGateway("aviary");
    const settings = normalizeSettings(await storage.get(SETTINGS_KEY, DEFAULT_SETTINGS));
    const diagnostics = new Diagnostics();
    setStorageErrorSink((key, error) => {
      diagnostics.error(`Storage write failed to save ${key}`, errorDetails6(error));
    });
    setLocalOnlyPolicy(() => settings.privacy.localOnly);
    const limiter = settings.jobs.rateLimitMode === "conservative" ? new TokenBucket(4, 1) : new TokenBucket(8, 4);
    const registry = new FeatureRegistry();
    const policy = createTrustedHtmlPolicy();
    const auditLog = new AuditLog(
      storage,
      void 0,
      (error) => {
        diagnostics.error("Audit log failed to save", errorDetails6(error));
      },
      () => settings.privacy.auditLog
    );
    await auditLog.load();
    registry.register(themeFeature);
    registry.register(i18nFeature);
    registry.register(selectorHealthFeature);
    registry.register(layoutDeclutterFeature);
    registry.register(filterEngineFeature);
    registry.register(hiddenPostsFeature);
    registry.register(mediaButtonsFeature);
    registry.register(mediaPresentationFeature);
    registry.register(exportFeature);
    registry.register(userNotesFeature);
    registry.register(linkUnshortenFeature);
    registry.register(cleanShareLinksFeature);
    registry.register(snapshotsFeature);
    registry.register(mobileTouchFeature);
    registry.register(composerSnippetsFeature);
    registry.register(networkCaptureFeature);
    registry.register(aiCommandMenuFeature);
    registry.register(controlCenterFeature);
    const context = {
      route: readRoute(),
      settings,
      storage,
      limiter,
      diagnostics,
      auditLog,
      async saveSettings() {
        await storage.set(SETTINGS_KEY, cloneSettings(settings));
        diagnostics.info("Settings saved", { key: SETTINGS_KEY });
      },
      requestApply() {
        void registry.applyAll(context, document);
      }
    };
    const stops = [];
    document.documentElement.dataset.avSource = options.source;
    policy.html("");
    try {
      await registry.initAll(context);
      await registry.applyAll(context, document);
      const observerRoot = document.body ?? document.documentElement;
      stops.push(
        observeAddedElements(observerRoot, (nodes, root) => {
          void registry.applyAll(context, root, nodes);
        })
      );
      stops.push(
        watchRoute((route) => {
          context.route = route;
          diagnostics.info("Route changed", { surface: route.surface, path: route.path });
          void registry.applyAll(context, document);
        })
      );
      document.documentElement.dataset.avReady = "true";
      diagnostics.info("Aviary booted", { source: options.source, surface: context.route.surface });
      activeApp = {
        context,
        registry,
        async destroy() {
          for (const stop of stops.reverse()) {
            stop();
          }
          await registry.destroyAll(context);
          delete document.documentElement.dataset.avReady;
          delete document.documentElement.dataset.avSource;
          activeApp = void 0;
        }
      };
      return activeApp;
    } catch (error) {
      diagnostics.error("Aviary boot failed", errorDetails6(error));
      document.documentElement.dataset.avReady = "error";
      for (const stop of stops.reverse()) {
        stop();
      }
      await registry.destroyAll(context);
      throw error;
    }
  }
  function errorDetails6(error) {
    if (error instanceof Error) {
      return {
        name: error.name,
        message: error.message
      };
    }
    return {
      message: String(error)
    };
  }

  // src/entrypoints/extension-content.ts
  void boot({ source: "extension" });
})();
