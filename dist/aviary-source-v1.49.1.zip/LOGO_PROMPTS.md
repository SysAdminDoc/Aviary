# Logo Prompt Pack

Project: Aviary

Description: Aviary is a local-first X/Twitter enhancer planned as a readable userscript first and a Manifest V3 extension second. Aviary is a local-first X enhancer shipped as a readable userscript and a Manifest V3 extension for Chrome and Firefox.

Review decision: Refreshing generated repo-root logo prompt file. No obvious logo/icon assets were found in the reviewed project tree.

Design direction: Premium browser extension branding using browser frame corners, tabs, content filters, cursor paths, and compact toolbar glyphs. Palette guidance: dark graphite, clean white, browser blue, and one vivid accent. Keep the mark high-contrast on both light and dark surfaces, built from clean SVG-friendly shapes with confident negative space.

Trademark guardrail: Do not use protected logos, mascots, proprietary UI marks, or exact brand-color lockups from Twitter. Use abstract cues for the workflow instead.

Use any one of the prompts below as a copy-ready image-generation request. Each prompt is written for a true transparent PNG, not a fake checkerboard or flattened background.

## Minimal Icon

```text
Project: Aviary. Description: Aviary is a local-first X/Twitter enhancer planned as a readable userscript first and a Manifest V3 extension second. Aviary is a local-first X enhancer shipped as a readable userscript and a Manifest V3 extension for Chrome and Firefox.
Create a premium minimal software icon for Aviary. Use browser frame corners, tabs, content filters, cursor paths, and compact toolbar glyphs as the visual language, reduced to a flat, memorable glyph that remains recognizable at 16px through 128px. Use crisp vector-like geometry, balanced negative space, high contrast, and the palette direction dark graphite, clean white, browser blue, and one vivid accent. Do not use protected logos, mascots, proprietary UI marks, or exact brand-color lockups from Twitter. Use abstract cues for the workflow instead. No text, letters, numbers, UI screenshots, product mockups, or app-window frames.
Background/output requirements: The final image must be a true transparent PNG in RGBA format with a real alpha channel. Everything outside the main icon/logo must be fully transparent, alpha = 0. Do not render a checkerboard pattern. Do not render a white, gray, black, colored, or textured background. Do not simulate transparency. Only the main icon/logo should contain visible pixels. If the generated image includes a checkerboard or any visible background, remove it with image processing and export a corrected transparent PNG artifact. Final output: 512x512 PNG, RGBA, true transparent background, alpha channel enabled, no checkerboard, no solid background, no watermark.
```

## App Icon

```text
Project: Aviary. Description: Aviary is a local-first X/Twitter enhancer planned as a readable userscript first and a Manifest V3 extension second. Aviary is a local-first X enhancer shipped as a readable userscript and a Manifest V3 extension for Chrome and Firefox.
Create a premium app icon mark for Aviary. The icon should feel like polished commercial software: dimensional but restrained, legible at launcher size, with a strong central silhouette based on browser frame corners, tabs, content filters, cursor paths, and compact toolbar glyphs. Use dark graphite, clean white, browser blue, and one vivid accent; avoid muddy gradients, clip-art effects, mascot art, and decorative clutter. Do not bake in a full-canvas square, circle, pill, oval, or platform mask; the transparent PNG should contain only the logo mark. Do not use protected logos, mascots, proprietary UI marks, or exact brand-color lockups from Twitter. Use abstract cues for the workflow instead. No text.
Background/output requirements: The final image must be a true transparent PNG in RGBA format with a real alpha channel. Everything outside the main icon/logo must be fully transparent, alpha = 0. Do not render a checkerboard pattern. Do not render a white, gray, black, colored, or textured background. Do not simulate transparency. Only the main icon/logo should contain visible pixels. If the generated image includes a checkerboard or any visible background, remove it with image processing and export a corrected transparent PNG artifact. Final output: 512x512 PNG, RGBA, true transparent background, alpha channel enabled, no checkerboard, no solid background, no watermark.
```

## Wordmark

```text
Project: Aviary. Description: Aviary is a local-first X/Twitter enhancer planned as a readable userscript first and a Manifest V3 extension second. Aviary is a local-first X enhancer shipped as a readable userscript and a Manifest V3 extension for Chrome and Firefox.
Create a premium transparent wordmark for the exact text "Aviary". Use custom typography that feels precise, modern, and product-grade, with one small integrated symbol inspired by browser frame corners, tabs, content filters, cursor paths, and compact toolbar glyphs. Keep letters readable at README-header size and app-about-screen size. Use dark graphite, clean white, browser blue, and one vivid accent. Do not use protected logos, mascots, proprietary UI marks, or exact brand-color lockups from Twitter. Use abstract cues for the workflow instead. Text is allowed only for this wordmark prompt.
Background/output requirements: The final image must be a true transparent PNG in RGBA format with a real alpha channel. Everything outside the main icon/logo must be fully transparent, alpha = 0. Do not render a checkerboard pattern. Do not render a white, gray, black, colored, or textured background. Do not simulate transparency. Only the main icon/logo should contain visible pixels. If the generated image includes a checkerboard or any visible background, remove it with image processing and export a corrected transparent PNG artifact. Final output: 512x512 PNG, RGBA, true transparent background, alpha channel enabled, no checkerboard, no solid background, no watermark.
```

## Emblem

```text
Project: Aviary. Description: Aviary is a local-first X/Twitter enhancer planned as a readable userscript first and a Manifest V3 extension second. Aviary is a local-first X enhancer shipped as a readable userscript and a Manifest V3 extension for Chrome and Firefox.
Create a premium emblem logo for Aviary suitable for README headers, splash screens, and installer/about dialogs. Build a compact badge-like composition from browser frame corners, tabs, content filters, cursor paths, and compact toolbar glyphs, but do not use a filled background plate, shield cliche, full-canvas container, pill, oval, or seal. The silhouette should be distinctive, balanced, and credible for professional software. Use dark graphite, clean white, browser blue, and one vivid accent. Do not use protected logos, mascots, proprietary UI marks, or exact brand-color lockups from Twitter. Use abstract cues for the workflow instead. No text.
Background/output requirements: The final image must be a true transparent PNG in RGBA format with a real alpha channel. Everything outside the main icon/logo must be fully transparent, alpha = 0. Do not render a checkerboard pattern. Do not render a white, gray, black, colored, or textured background. Do not simulate transparency. Only the main icon/logo should contain visible pixels. If the generated image includes a checkerboard or any visible background, remove it with image processing and export a corrected transparent PNG artifact. Final output: 512x512 PNG, RGBA, true transparent background, alpha channel enabled, no checkerboard, no solid background, no watermark.
```

## Abstract Mark

```text
Project: Aviary. Description: Aviary is a local-first X/Twitter enhancer planned as a readable userscript first and a Manifest V3 extension second. Aviary is a local-first X enhancer shipped as a readable userscript and a Manifest V3 extension for Chrome and Firefox.
Create an abstract premium software logo mark for Aviary. Express the product purpose through symbolic geometry rather than literal screenshots: browser frame corners, tabs, content filters, cursor paths, and compact toolbar glyphs. The result should look like a modern SaaS/app icon system asset, with strong negative space, clean edges, and a silhouette that survives monochrome conversion. Use dark graphite, clean white, browser blue, and one vivid accent. Do not use protected logos, mascots, proprietary UI marks, or exact brand-color lockups from Twitter. Use abstract cues for the workflow instead. No text.
Background/output requirements: The final image must be a true transparent PNG in RGBA format with a real alpha channel. Everything outside the main icon/logo must be fully transparent, alpha = 0. Do not render a checkerboard pattern. Do not render a white, gray, black, colored, or textured background. Do not simulate transparency. Only the main icon/logo should contain visible pixels. If the generated image includes a checkerboard or any visible background, remove it with image processing and export a corrected transparent PNG artifact. Final output: 512x512 PNG, RGBA, true transparent background, alpha channel enabled, no checkerboard, no solid background, no watermark.
```

## Verification

After generation, verify the PNG is real RGBA with alpha transparency:

```bash
magick identify -format '%[channels]' icon.png
```

Valid results include `rgba`, `srgba`, or `graya`. A flat `rgb` result means transparency was lost and the image must be regenerated or post-processed.
