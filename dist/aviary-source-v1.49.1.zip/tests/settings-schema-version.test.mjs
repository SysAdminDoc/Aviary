import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, test } from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";
import { build } from "esbuild";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

let mod;
let temp;

before(async () => {
  temp = await mkdtemp(path.join(tmpdir(), "aviary-settings-version-"));
  const outfile = path.join(temp, "settings.mjs");
  await build({
    entryPoints: [path.join(root, "src/platform/settings.ts")],
    outfile,
    bundle: true,
    format: "esm",
    platform: "neutral",
    target: "es2022",
    logLevel: "silent"
  });
  mod = await import(pathToFileURL(outfile).href);
});

after(async () => {
  await rm(temp, { recursive: true, force: true });
});

test("every persisted payload is stamped with the current schema version", () => {
  assert.equal(mod.DEFAULT_SETTINGS.schemaVersion, mod.SETTINGS_SCHEMA_VERSION);
  assert.equal(mod.normalizeSettings({}).schemaVersion, mod.SETTINGS_SCHEMA_VERSION);
  // A payload claiming some other version is still written back at this build's version.
  assert.equal(mod.normalizeSettings({ schemaVersion: 99 }).schemaVersion, mod.SETTINGS_SCHEMA_VERSION);
});

test("an unversioned payload upgrades without losing settings", () => {
  const legacy = { appearance: { theme: "noir" }, layout: { hideTrends: true } };
  const envelope = mod.readSettingsEnvelope(legacy);
  assert.equal(envelope.fromVersion, null, "a pre-versioning payload declares nothing");
  assert.equal(envelope.fromFuture, false);
  assert.equal(envelope.settings.schemaVersion, mod.SETTINGS_SCHEMA_VERSION);
  assert.equal(envelope.settings.appearance.theme, "noir", "existing choices must survive");
  assert.equal(envelope.settings.layout.hideTrends, true);
});

test("a payload from a newer Aviary is flagged rather than silently downgraded", () => {
  const future = mod.readSettingsEnvelope({
    schemaVersion: mod.SETTINGS_SCHEMA_VERSION + 5,
    appearance: { theme: "noir" },
    somethingThisBuildHasNeverHeardOf: { enabled: true }
  });
  assert.equal(future.fromFuture, true, "a newer payload must be recognised as newer");
  assert.equal(future.fromVersion, mod.SETTINGS_SCHEMA_VERSION + 5);
  assert.deepEqual(future.applied, [], "no migration step may run against an unknown future shape");
  // Runtime still needs usable values.
  assert.equal(future.settings.appearance.theme, "noir");
});

test("the ladder is well formed: every step reaches the current version", () => {
  // A gap would silently stop the loop and leave a payload half-migrated.
  const envelope = mod.readSettingsEnvelope({ schemaVersion: 1 });
  assert.equal(envelope.settings.schemaVersion, mod.SETTINGS_SCHEMA_VERSION);
  assert.equal(envelope.fromFuture, false);
});

test("garbage payloads normalize to defaults instead of throwing", () => {
  for (const input of [null, undefined, 7, "settings", [], { schemaVersion: "one" }]) {
    const envelope = mod.readSettingsEnvelope(input);
    assert.equal(envelope.settings.schemaVersion, mod.SETTINGS_SCHEMA_VERSION);
    assert.equal(envelope.settings.appearance.theme, mod.DEFAULT_SETTINGS.appearance.theme);
  }
});

test("bumping the schema version requires a matching migration step", async () => {
  // The ladder is only useful if it is filled in. If a future change bumps the constant without
  // adding the step that performs it, an upgrade would leave settings at the older shape.
  // Read as the ladder itself rather than as a regex over the file that declares it: a step
  // written on one line, or a second object also named SETTINGS_MIGRATIONS, satisfied the pattern
  // without being the ladder `readSettingsEnvelope` actually walks.
  const declared = mod.SETTINGS_SCHEMA_VERSION;
  const missing = [];
  for (let version = 1; version < declared; version++) {
    if (typeof mod.SETTINGS_MIGRATIONS[version] !== "function") missing.push(version);
  }
  assert.deepEqual(missing, [], `schema version ${declared} has no migration step for ${missing.join(", ")}`);

  // And nothing above the declared version: a step for a version the build never reaches can
  // never run, so it is a change somebody believes shipped and did not.
  const stranded = Object.keys(mod.SETTINGS_MIGRATIONS)
    .map(Number)
    .filter((version) => version >= declared);
  assert.deepEqual(stranded, [], "these migration steps are above the declared schema version");
});

test("the v1 budget migration carries an unlimited budget instead of inverting it", () => {
  const { readSettingsEnvelope, INTEGRATION_BUDGET_CEILINGS } = mod;

  // v1 documented 0 as "no bound". v2 reads 0 as zero and blocks, so a stored 0 has to be carried
  // to the ceiling -- normalizing it unchanged would silently turn "unlimited" into "blocked".
  const stored = {
    schemaVersion: 1,
    integrations: {
      ai: { maxRequestBytes: 0, dailyRequestBytes: 0 },
      semanticSearch: { maxRecordBytes: 0, dailyRecordBytes: 12345 }
    }
  };

  const envelope = readSettingsEnvelope(stored);
  assert.deepEqual(envelope.applied, [1]);
  assert.equal(envelope.fromVersion, 1);
  assert.equal(envelope.fromFuture, false);

  const ai = envelope.settings.integrations.ai;
  assert.equal(ai.maxRequestBytes, INTEGRATION_BUDGET_CEILINGS.ai.maxRequestBytes);
  assert.equal(ai.dailyRequestBytes, INTEGRATION_BUDGET_CEILINGS.ai.dailyRequestBytes);

  const semantic = envelope.settings.integrations.semanticSearch;
  assert.equal(semantic.maxRecordBytes, INTEGRATION_BUDGET_CEILINGS.semanticSearch.maxRecordBytes);
  // A budget the user actually chose is left exactly alone.
  assert.equal(semantic.dailyRecordBytes, 12345);
});

test("an unversioned payload still runs the ladder rather than being assumed current", () => {
  const { readSettingsEnvelope, INTEGRATION_BUDGET_CEILINGS } = mod;

  // Defaulting an absent version to the *current* version skipped every step the moment the ladder
  // gained one -- which is precisely when an old payload most needs migrating.
  const envelope = readSettingsEnvelope({
    integrations: { ai: { maxRequestBytes: 0, dailyRequestBytes: 0 } }
  });

  assert.deepEqual(envelope.applied, [1]);
  assert.equal(
    envelope.settings.integrations.ai.dailyRequestBytes,
    INTEGRATION_BUDGET_CEILINGS.ai.dailyRequestBytes
  );
});

/**
 * Downgrading must not delete what the newer build wrote.
 *
 * `fromFuture` was set and then consumed by exactly one line, a diagnostics warning. The save choke
 * point normalized unconditionally, so opening a profile in an older Aviary and toggling any single
 * setting wrote this build's narrower shape over the newer one: every key the newer schema had
 * added was gone, with no prompt, no backup, and a warning the user never sees.
 */
test("a payload from a newer Aviary survives a save by an older one", async () => {
  const { readSettingsEnvelope, mergeKnownSettings, SETTINGS_SCHEMA_VERSION } = await import(
    new URL("../src/platform/settings.ts", import.meta.url).href
  );

  const stored = {
    schemaVersion: SETTINGS_SCHEMA_VERSION + 97,
    somethingThisBuildHasNeverHeardOf: { keep: "me", nested: [1, 2, 3] },
    appearance: { theme: "noir", aFutureAppearanceKey: true },
    filter: { enabled: true }
  };

  const envelope = readSettingsEnvelope(structuredClone(stored));
  assert.equal(envelope.fromFuture, true);
  assert.equal(envelope.fromVersion, stored.schemaVersion);
  assert.ok(envelope.future, "the original payload must be kept so a save can merge onto it");

  // What the boot's save choke point now writes.
  const written = mergeKnownSettings(envelope.future, envelope.settings);

  assert.deepEqual(
    written.somethingThisBuildHasNeverHeardOf,
    stored.somethingThisBuildHasNeverHeardOf,
    "a group this build does not know must survive untouched"
  );
  assert.equal(
    written.schemaVersion,
    stored.schemaVersion,
    "the stored version belongs to the newer build and must not be restamped"
  );
  // A group this build owns is replaced wholesale, because it owns that shape.
  assert.equal(written.appearance.theme, "noir", "known values still round-trip");
  assert.equal(
    "aFutureAppearanceKey" in written.appearance,
    false,
    "a key inside a group this build owns is not preserved, and that is the documented trade"
  );

  // The ordinary path is unchanged: a current payload has nothing to merge onto.
  const current = readSettingsEnvelope({ schemaVersion: SETTINGS_SCHEMA_VERSION });
  assert.equal(current.fromFuture, false);
  assert.equal(current.future, undefined);
});
