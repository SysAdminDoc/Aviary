import assert from "node:assert/strict";
import { captureUrl } from "./helpers/synthetic-capture.mjs";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, test } from "node:test";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { chromium } from "playwright";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

let browser;
let page;
let currentPage;
let temp;
let bundle;

/** Settings shaped enough for applyTheme, which reads appearance + accessibility. */
const settings = (appearance) => ({
  appearance: {
    theme: "dim",
    denseMode: false,
    timelineWidth: "default",
    hideBorders: false,
    hideCounts: false,
    restoreChirp: false,
    ...appearance
  },
  accessibility: { reduceMotion: "never", highContrast: false }
});

before(async () => {
  temp = await mkdtemp(path.join(tmpdir(), "aviary-appearance-"));
  bundle = path.join(temp, "bundle.js");
  const entry = path.join(temp, "entry.ts");
  await writeFile(
    entry,
    `export { applyTheme, themeFeature } from ${JSON.stringify(
      path.resolve(root, "src/features/appearance/theme.ts").replace(/\\/g, "/")
    )};`,
    "utf8"
  );
  await build({
    entryPoints: [entry],
    outfile: bundle,
    bundle: true,
    format: "iife",
    globalName: "AviaryTheme",
    platform: "browser",
    target: "es2022",
    logLevel: "silent"
  });

  try {
    browser = await chromium.launch({ headless: true });
  } catch (error) {
    throw new Error(
      `chromium is required for this test -- run "npx playwright install chromium".\n${error}`
    );
  }
  page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  await page.route("**://pbs.twimg.com/**", (route) => route.abort());
  await page.route("**://abs.twimg.com/**", (route) => route.abort());
  await page.goto(await captureUrl("home"));
  await page.addScriptTag({ path: bundle });
  await page.evaluate(() => {
    const style = document.createElement("style");
    style.id = "av-theme-style";
    document.head.append(style);
  });

  // The same document with the column geometry the schema recorded from X's own stylesheets.
  //
  // This is a reduction, and it is worth being plain about: the lane used to attach the ~8,000
  // lines of stylesheet the capture carried, and it now attaches eleven rules built from thirteen
  // recorded numbers -- flex, max-width and column widths. What it still proves is that Aviary's
  // width tiers beat X's own flex declarations for the primary column, which is the claim the
  // feature makes. What it no longer proves is that nothing else in X's cascade interferes. That
  // trade bought the removal of a saved authenticated page; the numbers it rests on are recorded
  // in `_decoded/dom-schema.json` under `layout`, with the date they were measured.
  currentPage = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  await currentPage.goto(await captureUrl("home-layout"));
  await currentPage.addScriptTag({ path: bundle });
});

after(async () => {
  await currentPage?.close();
  await browser?.close();
  await rm(temp, { recursive: true, force: true });
});

/** Installs the feature's real stylesheet, then measures the captured primary column. */
async function measure(appearance) {
  // The settings object is plain JSON, so it is built here and handed over as an argument --
  // no function source crosses the boundary.
  return page.evaluate(
    (nextSettings) => {
      document.getElementById("av-theme-style")?.remove();
      AviaryTheme.themeFeature.init({
        settings: nextSettings,
        diagnostics: { info() {}, error() {} }
      });
      const column = document.querySelector('[data-testid="primaryColumn"]');
      const article = document.querySelector('article[data-testid="tweet"]');
      return {
        width: Math.round(column.getBoundingClientRect().width),
        font: article ? getComputedStyle(article).fontFamily : null,
        dataWidth: document.documentElement.dataset.avWidth,
        chirpClass: document.documentElement.classList.contains("av-chirp")
      };
    },
    settings(appearance)
  );
}

async function measureCurrent(appearance) {
  return currentPage.evaluate(
    (nextSettings) => {
      document.getElementById("av-theme-foundation")?.remove();
      AviaryTheme.themeFeature.init({
        settings: nextSettings,
        diagnostics: { info() {}, error() {} }
      });
      const column = document.querySelector('[data-testid="primaryColumn"]');
      const available = column.closest('main[role="main"]') ?? column.parentElement;
      return {
        width: Math.round(column.getBoundingClientRect().width),
        parentWidth: Math.round(column.parentElement.getBoundingClientRect().width),
        availableWidth: Math.round(available.getBoundingClientRect().width),
        flexBasis: getComputedStyle(column).flexBasis,
        viewportWidth: window.innerWidth,
        scrollWidth: document.documentElement.scrollWidth
      };
    },
    settings(appearance)
  );
}

test("timelineWidth actually widens the captured primary column", async () => {
  const base = await measure({ timelineWidth: "default" });
  const comfortable = await measure({ timelineWidth: "comfortable" });
  const wide = await measure({ timelineWidth: "wide" });

  assert.equal(base.dataWidth, "default");
  // The setting round-tripped through normalizeSettings for two releases while nothing read it.
  // These are the numbers that prove it is wired to something now.
  assert.ok(
    comfortable.width > base.width,
    `comfortable (${comfortable.width}px) must exceed default (${base.width}px)`
  );
  assert.ok(
    wide.width > comfortable.width,
    `wide (${wide.width}px) must exceed comfortable (${comfortable.width}px)`
  );
  assert.equal(wide.width, 1400, "wide fills the captured desktop viewport");
});

test("timelineWidth controls the recorded X flex item when the sidebar is hidden", async () => {
  await currentPage.evaluate(() => {
    document.querySelector('[data-testid="sidebarColumn"]')?.remove();
  });

  const base = await measureCurrent({ timelineWidth: "default" });
  const comfortable = await measureCurrent({ timelineWidth: "comfortable" });
  const wide = await measureCurrent({ timelineWidth: "wide" });

  assert.ok(
    comfortable.width > base.width,
    `current X comfortable (${comfortable.width}px) must exceed default (${base.width}px)`
  );
  assert.ok(
    wide.width > comfortable.width,
    `current X wide (${wide.width}px) must exceed comfortable (${comfortable.width}px)`
  );
  assert.ok(wide.width >= 1040, `current X wide should use at least 1040px, saw ${wide.width}px`);
  assert.equal(
    wide.flexBasis,
    "1400px",
    `current X flex basis should resolve to the viewport width, saw ${wide.flexBasis}`
  );
});

test("wide fills all space beside navigation", async () => {
  await currentPage.setViewportSize({ width: 1920, height: 1080 });
  const wide = await measureCurrent({ timelineWidth: "wide" });
  await currentPage.setViewportSize({ width: 1400, height: 900 });

  assert.ok(
    wide.availableWidth > 1200,
    `the fixture must expose spare desktop canvas, saw ${wide.availableWidth}px`
  );
  assert.ok(
    Math.abs(wide.width - wide.availableWidth) <= 1,
    `wide left unused canvas beside the feed: ${wide.width}px of ${wide.availableWidth}px`
  );
  assert.equal(wide.scrollWidth, wide.viewportWidth, "full width introduced horizontal scrolling");
});

test("timelineWidth never overflows a viewport narrower than the tier", async () => {
  await page.setViewportSize({ width: 700, height: 900 });
  const narrow = await measure({ timelineWidth: "wide" });
  await page.setViewportSize({ width: 1400, height: 900 });

  assert.ok(
    narrow.width <= 700,
    `full width must clamp to the 700px viewport, measured ${narrow.width}px`
  );
});

test("restoreChirp applies the family name X actually registers", async () => {
  const off = await measure({ restoreChirp: false });
  const on = await measure({ restoreChirp: true });

  assert.equal(off.chirpClass, false);
  assert.equal(on.chirpClass, true);
  assert.match(on.font, /^TwitterChirp/, `expected the Chirp stack, saw ${on.font}`);
  assert.notEqual(on.font, off.font, "the rule must change the computed font, not just a class");
});

test("hideCounts removes the view number without removing its accessible analytics link", async () => {
  const result = await page.evaluate((nextSettings) => {
    const article = document.createElement("article");
    article.dataset.testid = "tweet";
    const analytics = document.createElement("a");
    analytics.href = "/fixture/status/1/analytics";
    analytics.setAttribute("aria-label", "4200 views. View post analytics");
    const count = document.createElement("span");
    count.dataset.testid = "app-text-transition-container";
    count.textContent = "4.2K";
    analytics.append(count);
    article.append(analytics);
    document.body.append(article);

    AviaryTheme.applyTheme(nextSettings);
    const measured = {
      count: getComputedStyle(count).display,
      link: getComputedStyle(analytics).display,
      label: analytics.getAttribute("aria-label")
    };
    article.remove();
    return measured;
  }, settings({ hideCounts: true }));

  assert.deepEqual(result, {
    count: "none",
    link: "inline",
    label: "4200 views. View post analytics"
  });
});

test("destroy clears both new hooks off the document element", async () => {
  const after = await page.evaluate(() => {
    AviaryTheme.themeFeature.destroy({ diagnostics: { info() {}, error() {} } });
    return {
      dataWidth: document.documentElement.dataset.avWidth ?? null,
      chirpClass: document.documentElement.classList.contains("av-chirp")
    };
  });

  assert.equal(after.dataWidth, null);
  assert.equal(after.chirpClass, false);
});
