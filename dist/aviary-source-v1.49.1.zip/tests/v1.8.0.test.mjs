import { importSourceModule } from "./helpers/source-import.mjs";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { test } from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";
import { build } from "esbuild";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("downloader throws instead of reporting success when downloads is not granted", async () => {
  const { createDownloader, DownloadPermissionError } = await importSourceModule(
    "src/features/media/downloader.ts"
  );

  const originalChrome = globalThis.chrome;
  globalThis.chrome = {
    runtime: {
      sendMessage: async () => ({
        ok: false,
        code: "downloads-permission-missing",
        error: "downloads permission not granted"
      })
    }
  };

  try {
    const downloader = createDownloader();
    await assert.rejects(
      () => downloader({ url: "https://pbs.twimg.com/media/x.jpg", filename: "x.jpg" }),
      (error) => error instanceof DownloadPermissionError && error.code === "downloads-permission-missing"
    );
  } finally {
    globalThis.chrome = originalChrome;
  }
});

test("downloader surfaces a background failure rather than silently navigating", async () => {
  const { createDownloader } = await importSourceModule("src/features/media/downloader.ts");
  const originalChrome = globalThis.chrome;
  globalThis.chrome = {
    runtime: { sendMessage: async () => ({ ok: false, error: "disk full" }) }
  };

  try {
    await assert.rejects(
      () => createDownloader()({ url: "https://pbs.twimg.com/media/x.jpg", filename: "x.jpg" }),
      /disk full/
    );
  } finally {
    globalThis.chrome = originalChrome;
  }
});

test("extension downloads receive the ordered original-image fallback candidates", async () => {
  const { createDownloader } = await importSourceModule("src/features/media/downloader.ts");
  const originalChrome = globalThis.chrome;
  const sent = [];
  globalThis.chrome = {
    runtime: {
      sendMessage: async (message) => {
        sent.push(message);
        return { ok: true };
      }
    }
  };

  try {
    const result = await createDownloader()({
      url: "https://pbs.twimg.com/media/x?format=jpg&name=orig",
      fallbackUrls: ["https://pbs.twimg.com/media/x?format=jpg&name=4096x4096"],
      filename: "x.jpg"
    });
    assert.deepEqual(result, { ok: true, via: "extension" });
    assert.deepEqual(sent, [
      {
        type: "AVIARY_DOWNLOAD",
        url: "https://pbs.twimg.com/media/x?format=jpg&name=orig",
        fallbackUrls: ["https://pbs.twimg.com/media/x?format=jpg&name=4096x4096"],
        filename: "x.jpg"
      }
    ]);
  } finally {
    globalThis.chrome = originalChrome;
  }
});

test("isCrossOrigin marks the anchor fallback degraded only when download is ignored", async () => {
  const { isCrossOrigin } = await importSourceModule("src/features/media/downloader.ts");
  assert.equal(isCrossOrigin("blob:https://x.com/abc"), false);
  assert.equal(isCrossOrigin("data:image/png;base64,AAAA"), false);
  // No `location` in node: treat unknown origin as cross-origin so callers never over-promise.
  assert.equal(isCrossOrigin("https://pbs.twimg.com/media/x.jpg"), true);
  assert.equal(isCrossOrigin("not a url"), false);
});

test("both manifests declare the options page that hosts the permission grant", async () => {
  for (const name of ["manifest.chrome.json", "manifest.firefox.json"]) {
    const manifest = JSON.parse(await readFile(path.join(root, "src/extension", name), "utf8"));
    assert.deepEqual(manifest.options_ui, { page: "options.html", open_in_tab: true }, name);
    assert.equal(manifest.incognito, "not_allowed", name);
    assert.ok(manifest.optional_permissions.includes("downloads"), name);
    assert.ok(manifest.permissions.includes("contextMenus"), name);
  }
});

test("native media context clicks request download access before messaging the selected X tab", async () => {
  const originalChrome = globalThis.chrome;
  const sent = [];
  const requests = [];
  const grants = [true, false];
  let clicked;
  let insideGesture = false;

  globalThis.chrome = {
    runtime: {
      onInstalled: { addListener() {} },
      onStartup: { addListener() {} },
      onMessage: { addListener() {} }
    },
    action: { onClicked: { addListener() {} } },
    contextMenus: {
      create() { return "aviary-download-media"; },
      removeAll(callback) { callback?.(); },
      onClicked: { addListener(listener) { clicked = listener; } }
    },
    permissions: {
      request(request) {
        assert.equal(insideGesture, true, "permission request escaped the context-menu gesture");
        requests.push(request);
        return Promise.resolve(grants.shift());
      }
    },
    tabs: {
      async sendMessage(tabId, message) {
        sent.push({ tabId, message });
        return { ok: true };
      }
    }
  };

  try {
    await importSourceModule("src/entrypoints/extension-background.ts", { fresh: true });
    assert.equal(typeof clicked, "function", "background did not register the context-menu action");

    insideGesture = true;
    clicked({ menuItemId: "aviary-download-media", pageUrl: "https://x.com/home" }, { id: 91 });
    insideGesture = false;
    await waitFor(() => sent.length === 1);

    insideGesture = true;
    clicked({ menuItemId: "aviary-download-media", pageUrl: "https://x.com/home" }, { id: 92 });
    insideGesture = false;
    await waitFor(() => sent.length === 2);

    assert.deepEqual(requests, [
      { permissions: ["downloads"] },
      { permissions: ["downloads"] }
    ]);
    assert.deepEqual(sent, [
      {
        tabId: 91,
        message: { type: "AVIARY_DOWNLOAD_CONTEXT_MEDIA", documentUrl: "https://x.com/home" }
      },
      {
        tabId: 92,
        message: {
          type: "AVIARY_CONTEXT_DOWNLOAD_PERMISSION_DENIED",
          documentUrl: "https://x.com/home"
        }
      }
    ]);
  } finally {
    globalThis.chrome = originalChrome;
  }
});

test("an interrupted original-image download resumes from the persisted quality fallback", async () => {
  const originalChrome = globalThis.chrome;
  const calls = [];
  const stored = {};
  let onMessage;
  let onDownloadChanged;
  let nextId = 40;
  globalThis.chrome = {
    runtime: {
      onInstalled: { addListener() {} },
      onStartup: { addListener() {} },
      onMessage: { addListener(listener) { onMessage = listener; } }
    },
    permissions: { async contains() { return true; } },
    storage: {
      local: {
        async get(key) { return { [key]: stored[key] }; },
        async set(items) { Object.assign(stored, structuredClone(items)); }
      }
    },
    downloads: {
      async download(options) {
        calls.push(options);
        return nextId++;
      },
      onChanged: { addListener(listener) { onDownloadChanged = listener; } }
    }
  };

  try {
    await importSourceModule("src/entrypoints/extension-background.ts", { fresh: true });
    const response = await new Promise((resolve) => {
      const keptOpen = onMessage(
        {
          type: "AVIARY_DOWNLOAD",
          url: "https://pbs.twimg.com/media/x?format=jpg&name=orig",
          fallbackUrls: ["https://pbs.twimg.com/media/x?format=jpg&name=4096x4096"],
          filename: "x.jpg"
        },
        {},
        resolve
      );
      assert.equal(keptOpen, true);
    });
    assert.deepEqual(response, { ok: true, id: 40, pending: true });
    assert.equal(typeof onDownloadChanged, "function");

    onDownloadChanged({ id: 40, state: { current: "interrupted" } });
    await waitFor(() => calls.length === 2);
    assert.deepEqual(calls.map((call) => call.url), [
      "https://pbs.twimg.com/media/x?format=jpg&name=orig",
      "https://pbs.twimg.com/media/x?format=jpg&name=orig"
    ]);
    onDownloadChanged({ id: 41, state: { current: "interrupted" } });
    await waitFor(() => calls.length === 3);
    onDownloadChanged({ id: 42, state: { current: "interrupted" } });
    await waitFor(() => calls.length === 4);
    assert.equal(calls[3].url, "https://pbs.twimg.com/media/x?format=jpg&name=4096x4096");
    // The retry is a new download id, and it inherits the id the content script was told about --
    // otherwise the tab waiting on 40 would never hear how the transfer it started ended.
    assert.equal(stored["aviary.downloadTracking.v2"][43].reportId, 40);
    assert.equal(stored["aviary.downloadTracking.v2"][43].url, "https://pbs.twimg.com/media/x?format=jpg&name=4096x4096");
  } finally {
    globalThis.chrome = originalChrome;
  }
});

test("presets can promise the two settings that now have implementations", async () => {
  const { PRESETS } = await importSourceModule("src/features/core/presets.ts");
  const byId = Object.fromEntries(PRESETS.map((preset) => [preset.id, preset]));
  assert.equal(byId["quiet-reader"].overrides.appearance.hideBorders, true);
  assert.equal(byId.minimal.overrides.appearance.hideBorders, true);
  assert.equal(byId.minimal.overrides.layout.hideForYouTab, true);
  assert.equal(byId.creator.overrides.layout.writerMode, true);
});

test("the Control Center exposes both settings", async () => {
  const source = (
    await Promise.all([
      "src/ui/control-center.ts",
      "src/ui/control-center/sections/reading.ts"
    ].map((file) => readFile(path.join(root, file), "utf8")))
  ).join("\n");
  assert.match(source, /ctx\.options\.settings\.appearance\.hideBorders = checked/);
  assert.match(source, /ctx\.options\.settings\.layout\.writerMode = checked/);
  assert.match(source, /ctx\.options\.settings\.layout\.hideForYouTab = checked/);
});

async function waitFor(predicate, timeoutMs = 1_000) {
  const deadline = Date.now() + timeoutMs;
  while (!predicate() && Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
  assert.equal(predicate(), true, "timed out waiting for asynchronous background work");
}

test("a failed write reports to the persistence sink instead of vanishing", async () => {
  const { MediaHistory } = await importSourceModule("src/features/media/history.ts");

  const full = {
    async get(_key, fallback) {
      return fallback;
    },
    async set() {
      throw new DOMException("exceeded the quota", "QuotaExceededError");
    }
  };

  const reported = [];
  const history = new MediaHistory(full, undefined, (error) => reported.push(error));
  await history.load();

  // The write fails, but the call must still resolve — persistence is best-effort by design.
  await history.record("https://pbs.twimg.com/media/a.jpg");

  assert.equal(reported.length, 1, "a full backend must not fail silently");
  assert.match(String(reported[0]), /quota/i);
});

test("waitForToken refuses an impossible request instead of hanging forever", async () => {
  const { TokenBucket } = await importSourceModule("src/platform/rate-limit.ts");

  const bucket = new TokenBucket(4, 1);
  // refill() clamps at capacity, so this condition could never come true — it used to spin.
  await assert.rejects(() => bucket.waitForToken(5), RangeError);

  assert.equal(bucket.tryRemove(4), true, "a full bucket should satisfy a capacity-sized draw");
  assert.equal(bucket.tryRemove(1), false, "an empty bucket should refuse");
});

test("media.zipChunkSize splits a long export into several archives", async () => {
  const { buildExportZipChunks } = await importSourceModule("src/features/export/export-feature.ts");

  const records = Array.from({ length: 250 }, (_, i) => ({
    tweetId: String(i),
    handle: "someone",
    text: `post ${i}`,
    capturedAt: "2026-08-06T00:00:00Z"
  }));

  const one = await buildExportZipChunks(records, ["json"], "", 1000);
  assert.equal(one.length, 1, "a run that fits must stay a single archive");
  assert.doesNotMatch(one[0].filename, /part/, "an unsplit run keeps the plain name");

  const many = await buildExportZipChunks(records, ["json"], "", 100);
  assert.equal(many.length, 3, "250 records at 100 per ZIP is three archives");
  assert.match(many[0].filename, /-part1of3\.zip$/);
  assert.match(many[2].filename, /-part3of3\.zip$/);
  assert.equal(new Set(many.map((a) => a.filename)).size, 3, "chunk names must be unique");

  // Every record has to land in exactly one archive -- a chunker that drops the tail is worse
  // than no chunking at all, and a plain length check would not catch it. Read the archives
  // properly rather than scanning raw bytes: entries are DEFLATE now, so a substring search over
  // the container would find nothing and quietly pass once the assertion was relaxed.
  const { readZip } = await importSourceModule("src/features/export/zip-reader.ts");
  const decoder = new TextDecoder();
  const seen = new Set();
  for (const artifact of many) {
    assert.ok(artifact.data.byteLength > 0);
    for (const entry of await readZip(artifact.data)) {
      const text = decoder.decode(entry.data);
      for (let i = 0; i < 250; i += 1) {
        if (text.includes(`"post ${i}"`)) seen.add(i);
      }
    }
  }
  assert.equal(seen.size, 250, "every record must survive compression into some chunk");

  assert.equal((await buildExportZipChunks([], ["json"], "", 100)).length, 0, "no records, no archive");
});

test("cleanShareButtons strips tracking parameters without breaking links", async () => {
  const { cleanUrl } = await importSourceModule("src/features/library/clean-share-links.ts");

  // X's own share sheet appends t= and s=.
  assert.equal(
    cleanUrl("https://x.com/someone/status/123?t=AbC&s=20"),
    "https://x.com/someone/status/123"
  );
  // Campaign parameters go everywhere; unrelated query values must survive.
  assert.equal(
    cleanUrl("https://example.com/a?utm_source=x&id=7&fbclid=zz"),
    "https://example.com/a?id=7"
  );
  // A relative SPA route stays relative — returning an absolute URL would change navigation.
  assert.equal(cleanUrl("/someone/status/123?t=AbC"), "/someone/status/123");

  // `t` and `s` are ordinary parameter names off X; stripping them elsewhere breaks real links.
  assert.equal(cleanUrl("https://example.com/search?s=shoes&t=1"), null);

  // Nothing to do, or unsafe to touch.
  assert.equal(cleanUrl("https://example.com/plain"), null);
  assert.equal(cleanUrl("https://t.co/abc123"), null, "t.co paths are the identifier");
  assert.equal(cleanUrl("javascript:alert(1)"), null);
  assert.equal(cleanUrl("mailto:a@b.c"), null);
  assert.equal(cleanUrl(""), null);
  assert.equal(cleanUrl("not a url at all"), null);
});

test("every setting a preset promises now has an implementation behind it", async () => {
  const { PRESETS } = await importSourceModule("src/features/core/presets.ts");

  // A preset that flips a setting nothing reads silently lies about what applying it does.
  // These are the keys the presets touch that were schema-only when v1.8.0 opened.
  const promised = PRESETS.flatMap((preset) => Object.keys(preset.overrides.links ?? {}));
  assert.ok(promised.includes("cleanShareButtons"), "presets no longer exercise this key");

  // That the key drives a registered, reversible feature is proven by driving it:
  // tests/feature-lifecycle.test.mjs applies and destroys it against a fixture, and
  // tests/boot-registration.test.mjs asks the booted registry whether it is there.
});

test("local-only mode blocks every integration entry point", async () => {
  const policy = await importSourceModule("src/features/integrations/network-policy.ts");
  const {
    assertOutboundAllowed,
    setLocalOnlyPolicy,
    resetLocalOnlyPolicy,
    LocalOnlyError,
    NetworkPolicyNotInstalledError
  } = policy;

  // This used to assert that an uninstalled policy allows the request. It was the contract, and it
  // was the wrong one: the install point in main.ts sits after storage, profile, diagnostics, usage
  // and the settings load, so anything reaching an integration before that line went out with the
  // user's Local-only mode switched on. Nothing goes out until a policy is installed, and the
  // refusal names the installation rather than the setting -- a boot-order fault reported as
  // "Local-only mode blocked this" sends the reader to a switch that is not the problem.
  resetLocalOnlyPolicy();
  assert.throws(() => assertOutboundAllowed("A request"), NetworkPolicyNotInstalledError);
  assert.throws(() => assertOutboundAllowed("A request"), /has not been installed/);
  assert.doesNotThrow(() => {
    try {
      assertOutboundAllowed("A request");
    } catch (error) {
      assert.ok(!(error instanceof LocalOnlyError), "a boot fault must not be reported as the setting");
    }
  });

  setLocalOnlyPolicy(() => false);
  assert.doesNotThrow(() => assertOutboundAllowed("A request"));

  setLocalOnlyPolicy(() => true);
  assert.throws(() => assertOutboundAllowed("A request"), LocalOnlyError);
  // The message has to name the switch, or a blocked call reads as a broken integration.
  assert.throws(() => assertOutboundAllowed("A request"), /Local-only mode/i);

  // Read fresh each call, so toggling the setting applies without a reload.
  let on = true;
  setLocalOnlyPolicy(() => on);
  assert.throws(() => assertOutboundAllowed("A request"), LocalOnlyError);
  on = false;
  assert.doesNotThrow(() => assertOutboundAllowed("A request"));
  setLocalOnlyPolicy(() => false);

  // Which modules honour the policy is settled by calling them -- see the guard test below, which
  // rejects a real call into every integration client. That main.ts wires the policy to the live
  // setting is settled by tests/boot-registration.test.mjs, from the booted app's own settings.
});

test("upgrading with a configured integration does not silently break it", async () => {
  const { normalizeSettings, DEFAULT_SETTINGS } = await importSourceModule("src/platform/settings.ts");

  // A fresh install keeps the local-only default, because integrations ship disabled.
  assert.equal(normalizeSettings({}).privacy.localOnly, true);
  assert.equal(DEFAULT_SETTINGS.privacy.localOnly, true);

  // Someone who configured Aria2 in v1.3-v1.7 was already opting into those requests.
  const upgraded = normalizeSettings({
    privacy: { localOnly: true },
    integrations: { aria2: { enabled: true, endpoint: "http://localhost:6800" } }
  });
  assert.equal(upgraded.privacy.localOnly, false, "an enabled integration must clear local-only");

  // A disabled integration is not consent.
  const untouched = normalizeSettings({
    privacy: { localOnly: true },
    integrations: { aria2: { enabled: false, endpoint: "http://localhost:6800" } }
  });
  assert.equal(untouched.privacy.localOnly, true);
});

test("the local-only guard fires before any integration touches the network", async () => {
  // Bundled as one entry on purpose: the policy is module-scope state, so this also proves
  // main.ts and the integration clients share one instance in a real build. Bundling each
  // module separately would give each its own copy and quietly pass while shipping broken.
  const temp = await mkdtemp(path.join(tmpdir(), "aviary-localonly-"));
  try {
    const entry = path.join(temp, "entry.ts");
    const p = (rel) => path.resolve(root, rel).split(path.sep).join("/");
    await writeFile(
      entry,
      `export { setLocalOnlyPolicy, resetLocalOnlyPolicy, LocalOnlyError } from "${p("src/features/integrations/network-policy.ts")}";
export { addUriToAria2, tellActiveAria2 } from "${p("src/features/integrations/aria2.ts")}";
export { crosspost } from "${p("src/features/integrations/crosspost.ts")}";
export { SemanticIndex } from "${p("src/features/integrations/semantic-search.ts")}";
export { runAiPrompt } from "${p("src/features/integrations/ai-provider.ts")}";`
    );
    const outfile = path.join(temp, "bundle.mjs");
    await build({
      entryPoints: [entry],
      outfile,
      bundle: true,
      format: "esm",
      platform: "neutral",
      logLevel: "silent"
    });
    const mod = await import(pathToFileURL(outfile).href);

    // Any fetch at all means the guard did not stop the call early enough.
    const originalFetch = globalThis.fetch;
    globalThis.fetch = () => {
      throw new Error("network was reached while local-only mode was on");
    };
    try {
      mod.setLocalOnlyPolicy(() => true);
      await assert.rejects(
        () => mod.addUriToAria2({ enabled: true, endpoint: "http://localhost:6800", secret: "" }, { url: "https://x/y.mp4" }),
        mod.LocalOnlyError
      );
      await assert.rejects(
        () => mod.tellActiveAria2({ enabled: true, endpoint: "http://localhost:6800", secret: "" }),
        mod.LocalOnlyError
      );
      await assert.rejects(
        () => mod.runAiPrompt({ enabled: true, apiKey: "k", provider: "anthropic", endpoint: "", model: "m" }, { prompt: "hi" }),
        mod.LocalOnlyError
      );
      await assert.rejects(
        () => mod.crosspost(
          { bluesky: { enabled: true, service: "https://bsky.social", identifier: "a", appPassword: "b" } },
          { target: "bluesky", text: "hello" }
        ),
        mod.LocalOnlyError
      );

      // The one integration that reaches the network from inside a class rather than a free
      // function, and the one the per-file grep it replaces would have missed if the call moved.
      const index = new mod.SemanticIndex({
        async get() {
          return { entries: [{ id: "1", text: "hello", vector: [1, 0], tweetId: "1", handle: "a", embeddedAt: "2026-08-18T00:00:00.000Z" }] };
        },
        async set() {},
        async remove() {}
      });
      await assert.rejects(
        () => index.search(
          { enabled: true, endpoint: "https://api.example.com/v1/embeddings", apiKey: "k", model: "m" },
          "hello"
        ),
        mod.LocalOnlyError
      );
    } finally {
      mod.resetLocalOnlyPolicy();
      globalThis.fetch = originalFetch;
    }
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});

test("zip entry names are flagged UTF-8 so non-ASCII paths survive extraction", async () => {
  const { buildStoreZip } = await importSourceModule("src/features/export/zip-store.ts");

  const name = "Recherché-アーカイブ/aviary-export.json";
  const zip = buildStoreZip([
    { filename: name, data: new TextEncoder().encode('{"ok":true}'), date: new Date("2026-08-06T12:00:00Z") }
  ]);
  const view = new DataView(zip.buffer, zip.byteOffset, zip.byteLength);

  // Bit 11 says "these name bytes are UTF-8". Without it a conforming extractor must read them
  // as CP437, and Recherché-アーカイブ arrives as Recherch├⌐-πéóπâ╝πé½πéñπâû.
  assert.equal(view.getUint16(6, true) & 0x0800, 0x0800, "local header is not flagged UTF-8");

  let centralAt = -1;
  for (let i = 0; i < zip.length - 4; i += 1) {
    if (view.getUint32(i, true) === 0x02014b50) {
      centralAt = i;
      break;
    }
  }
  assert.ok(centralAt > -1, "no central directory header found");
  assert.equal(view.getUint16(centralAt + 8, true) & 0x0800, 0x0800, "central header is not flagged UTF-8");

  // The stored bytes must be the UTF-8 encoding, and the length field must count bytes not chars.
  const expected = new TextEncoder().encode(name);
  assert.equal(view.getUint16(26, true), expected.length);
  assert.deepEqual(zip.slice(30, 30 + expected.length), expected);
});

test("the zip writer refuses to emit a silently-truncated archive", async () => {
  const { buildStoreZip } = await importSourceModule("src/features/export/zip-store.ts");

  // setUint16/setUint32 truncate without complaint, so these ceilings have to be checked.
  const tooMany = Array.from({ length: 0x10000 }, (_, i) => ({
    filename: `f${i}.txt`,
    data: new Uint8Array(0)
  }));
  assert.throws(() => buildStoreZip(tooMany), RangeError);

  // A name longer than the uint16 field that records its length.
  assert.throws(
    () => buildStoreZip([{ filename: "x".repeat(0x10000), data: new Uint8Array(0) }]),
    RangeError
  );

  // The ordinary case still works and stays byte-identical in shape.
  const ok = buildStoreZip([{ filename: "a.txt", data: new TextEncoder().encode("hi") }]);
  assert.equal(new DataView(ok.buffer, ok.byteOffset).getUint32(0, true), 0x04034b50);
});

test("a CRLF in a scraped value cannot inject WARC headers or split a record", async () => {
  const { formatRecord, buildWarcArchive } = await importSourceModule("src/features/export/warc.ts");

  const hostile = "https://x.com/a/status/456\r\nWARC-Type: warcinfo\r\nX-Injected: yes";
  const bytes = formatRecord({ url: hostile, mime: "application/json", body: "{}" });
  const text = new TextDecoder().decode(bytes);

  // One record means exactly one version line and one header block.
  assert.equal(text.split("WARC/1.1").length - 1, 1, "the value started a second record");

  // The hostile text survives *inside* the URI value, which is fine and inert. What must not
  // happen is it becoming its own header line, so assert on line starts rather than substrings.
  const headerLines = text.split("\r\n\r\n")[0].split("\r\n");
  assert.ok(
    !headerLines.some((line) => line.startsWith("X-Injected")),
    `an arbitrary header was injected: ${JSON.stringify(headerLines)}`
  );
  assert.equal(
    headerLines.filter((line) => line.startsWith("WARC-Type:")).length,
    1,
    "WARC-Type could be forged"
  );

  // The whole archive must still parse as the expected number of records.
  const archive = buildWarcArchive([
    { tweetId: "1", handle: "a", text: "t", permalink: hostile, media: [{ url: hostile, kind: "photo", type: "image/jpeg" }], audience: "public" }
  ]);
  const all = new TextDecoder().decode(archive.data);
  const recordStarts = all.match(/(?:^|\r\n\r\n)WARC\/1\.1\r\n/g) ?? [];
  assert.equal(recordStarts.length, 5, "expected warcinfo + metadata + two resources + media records");
});

test("WARC Content-Length counts bytes, not characters", async () => {
  const { formatRecord } = await importSourceModule("src/features/export/warc.ts");

  // 8 characters, but more than 8 bytes once encoded — a char count would truncate the body
  // and desynchronise every following record.
  const body = "アーカイブ-é";
  const expected = new TextEncoder().encode(body).length;
  assert.notEqual(expected, body.length, "pick a body where bytes and chars differ");

  const text = new TextDecoder().decode(formatRecord({ url: "urn:x", mime: "text/plain", body }));
  const declared = Number(/Content-Length: (\d+)/.exec(text)[1]);
  assert.equal(declared, expected);
});

test("a record with no target URI or mime still carries both fields", async () => {
  const { formatRecord } = await importSourceModule("src/features/export/warc.ts");
  const text = new TextDecoder().decode(formatRecord({ url: "", mime: "", body: "x" }));
  assert.match(text, /WARC-Target-URI: urn:aviary:unknown/);
  assert.match(text, /Content-Type: application\/octet-stream/);
});

test("a swallowed storage write still reports through the gateway sink", async () => {
  const { createStorageGateway, setStorageErrorSink } = await importSourceModule(
    "src/platform/storage.ts"
  );

  const original = globalThis.localStorage;
  globalThis.localStorage = {
    setItem() {
      throw new DOMException("exceeded the quota", "QuotaExceededError");
    },
    getItem: () => null,
    removeItem() {}
  };

  const seen = [];
  setStorageErrorSink((key, error) => seen.push({ key, error }));
  try {
    const storage = createStorageGateway("aviary");
    // The gateway must report *and* rethrow: callers that swallow keep working, but the
    // failure stops being invisible. Nine call sites wrap set() in an empty catch.
    await assert.rejects(() => storage.set("cleanupQueue.v1", { a: 1 }));
    assert.equal(seen.length, 1, "a failed write did not reach the sink");
    assert.match(seen[0].key, /cleanupQueue/);
    assert.match(String(seen[0].error), /quota/i);

    // The Trust row keys off this wording; keep them in step.
    assert.match(`Storage write failed to save ${seen[0].key}`, /failed to save/);
  } finally {
    setStorageErrorSink(undefined);
    globalThis.localStorage = original;
  }
});
