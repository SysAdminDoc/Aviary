import { importSourceModule } from "./source-import.mjs";

/**
 * Loads the background service worker against a stubbed `chrome`.
 *
 * `stored` is deliberately a caller-supplied object: passing the same one to two loads is how a
 * service-worker restart is reproduced -- the new worker has no memory of anything except what was
 * written to `storage.local`, which is the whole reason the download tracking is persisted.
 */
export async function loadBackground({
  stored = {},
  granted = true,
  downloadStates = {},
  nextId: initialNextId = 1,
  onCreateState
} = {}) {
  const downloads = [];
  const tabMessages = [];
  const pending = new Set();
  let onMessage;
  let onDownloadChanged;
  let nextId = initialNextId;

  globalThis.chrome = {
    runtime: {
      onInstalled: { addListener() {} },
      onStartup: { addListener() {} },
      onMessage: { addListener(listener) { onMessage = listener; } }
    },
    action: { onClicked: { addListener() {} } },
    contextMenus: {
      create() {},
      removeAll(callback) { callback?.(); },
      onClicked: { addListener() {} }
    },
    permissions: {
      async contains() { return granted; },
      async request() { return granted; }
    },
    tabs: {
      async sendMessage(tabId, message) {
        tabMessages.push({ tabId, message });
      }
    },
    downloads: {
      async download(options) {
        const id = nextId++;
        downloads.push(options);
        downloadStates[id] ??= { id, state: "in_progress" };
        if (onCreateState) {
          downloadStates[id] = { id, state: onCreateState };
          onDownloadChanged?.({ id, state: { current: onCreateState } });
        }
        return id;
      },
      async search(query) {
        const record = downloadStates[query?.id];
        return record ? [structuredClone(record)] : [];
      },
      onChanged: { addListener(listener) { onDownloadChanged = listener; } }
    },
    storage: {
      local: {
        async get(key) { return { [key]: stored[key] }; },
        async set(items) { Object.assign(stored, structuredClone(items)); }
      }
    }
  };

  await importSourceModule("src/entrypoints/extension-background.ts", { fresh: true });

  return {
    downloads,
    tabMessages,
    stored,
    onDownloadChanged: (delta) => {
      const before = tabMessages.length;
      if (typeof delta?.id === "number" && delta.state?.current) {
        downloadStates[delta.id] = {
          id: delta.id,
          state: delta.state.current,
          ...(delta.error?.current ? { error: delta.error.current } : {})
        };
      }
      onDownloadChanged(delta);
      pending.add(before);
    },
    send: (message, sender = {}) =>
      new Promise((resolve, reject) => {
        const timer = setTimeout(
          () => reject(new Error(`no response to ${JSON.stringify(message)}`)),
          2000
        );
        const async = onMessage(message, sender, (response) => {
          clearTimeout(timer);
          resolve(response);
        });
        if (async !== true) {
          clearTimeout(timer);
          resolve(undefined);
        }
      }),
    /** The worker's listeners are fire-and-forget; give their promise chains a turn to run. */
    settled: async () => {
      for (let i = 0; i < 12; i += 1) {
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    }
  };
}
