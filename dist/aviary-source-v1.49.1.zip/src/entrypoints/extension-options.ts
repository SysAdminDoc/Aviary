/**
 * Options page controller.
 *
 * A content-script click cannot request extension permissions directly. This page is the durable
 * management surface: it reports what is granted and lets the user grant or revoke each optional
 * permission. The native media context-menu click can request download access inline as a second
 * browser-owned gesture. No network calls. Diagnostics are read locally and copied only on click.
 */

import {
  BACKGROUND_DIAGNOSTICS_MESSAGE,
  parseBackgroundDiagnostics
} from "../extension/background-diagnostics.ts";
import { DIAGNOSTICS_KEY, parseStoredDiagnostics } from "../platform/diagnostics-store.ts";
import { createStorageGateway } from "../platform/storage.ts";
import { createDurableStorageGateway } from "../platform/durable-storage.ts";
import { ACTIVE_PROFILE_KEY, DEFAULT_PROFILE_ID, createProfileStorageGateway } from "../platform/profile.ts";
import { SETTINGS_KEY } from "../platform/settings.ts";
import { createExtensionDurableStorageBackend } from "../extension/durable-storage-api.ts";
import { localeDirection, supportedLocales } from "../platform/i18n-runtime.ts";

export const MEDIA_ORIGINS = ["https://pbs.twimg.com/*", "https://video.twimg.com/*"];

/**
 * Only the strings this page uses, injected at build time from the one catalog.
 *
 * The page is a separate document with no FeatureContext, so it cannot call `ft()`. Importing
 * PANEL_CATALOG would put roughly 240KB of translations into a page that otherwise ships a few
 * KB and is opened rarely, so tools/build.mjs reads the `data-i18n` keys out of options.html and
 * defines just those. One source of truth, and the page stays small.
 */
declare const __AVIARY_OPTIONS_I18N__: Record<string, Record<string, string>>;

const CATALOG: Record<string, Record<string, string>> =
  typeof __AVIARY_OPTIONS_I18N__ === "undefined" ? {} : __AVIARY_OPTIONS_I18N__;

let locale = "en";
const SUPPORTED_LOCALE_CODES = new Set<string>(supportedLocales().map((entry) => entry.code));

function translate(english: string): string {
  return CATALOG[locale]?.[english] ?? english;
}

/**
 * Reads the locale the Control Center saved, through the storage stack that actually wrote it.
 *
 * This used to read `chrome.storage.local` for a bare `aviary.settings.v1`. Nothing has ever
 * written that key: settings go through the profile gateway as `aviary.profile.<id>.settings.v1`,
 * and any `aviary.*.vN` key is routed to the durable IndexedDB backend. The lookup therefore missed
 * every time and this page fell back to English no matter what the user had chosen — in a build
 * that ships a nine-locale catalog and tests it for drift.
 */
async function readLocale(): Promise<string> {
  try {
    const scoped = await activeProfileStorage();
    const settings = await scoped.get<{ i18n?: { locale?: unknown } } | null>(SETTINGS_KEY, null);
    const code = settings?.i18n?.locale;
    return typeof code === "string" && SUPPORTED_LOCALE_CODES.has(code) ? code : "en";
  } catch {
    return "en";
  }
}

async function activeProfileStorage() {
  const backend = createExtensionDurableStorageBackend();
  if (!backend) throw new Error("Extension durable storage is unavailable");
  const durable = createDurableStorageGateway(
    createStorageGateway("aviary", { mode: "extension" }),
    { backend }
  );
  const activeId = await durable.get<string | null>(ACTIVE_PROFILE_KEY, null);
  return createProfileStorageGateway(durable, activeId ?? DEFAULT_PROFILE_ID);
}

async function readPersistedDiagnostics(): Promise<ReturnType<typeof parseStoredDiagnostics>> {
  try {
    const scoped = await activeProfileStorage();
    return parseStoredDiagnostics(await scoped.get<unknown>(DIAGNOSTICS_KEY, undefined));
  } catch {
    return [];
  }
}

async function readWorkerDiagnostics(): Promise<ReturnType<typeof parseBackgroundDiagnostics>> {
  try {
    const response = await globalThis.chrome?.runtime?.sendMessage?.({
      type: BACKGROUND_DIAGNOSTICS_MESSAGE,
      operation: "read"
    });
    if (!response || typeof response !== "object") return [];
    return parseBackgroundDiagnostics({
      version: 1,
      events: (response as { events?: unknown }).events
    });
  } catch {
    return [];
  }
}

async function buildDiagnosticsReport(): Promise<string> {
  const [page, background] = await Promise.all([readPersistedDiagnostics(), readWorkerDiagnostics()]);
  return JSON.stringify(
    {
      generator: "Aviary",
      generatedAt: new Date().toISOString(),
      version: globalThis.chrome?.runtime?.getManifest?.()?.version ?? "unknown",
      surface: "extension-options",
      events: page,
      background
    },
    null,
    2
  );
}

function applyTranslations(): void {
  for (const node of Array.from(document.querySelectorAll<HTMLElement>("[data-i18n]"))) {
    const english = node.dataset.i18n;
    if (english) {
      node.textContent = translate(english);
    }
  }
  document.documentElement.lang = locale;
  document.documentElement.dir = localeDirection(locale);
}

interface PermissionRequest {
  permissions?: string[];
  origins?: string[];
}

interface CardWiring {
  request: PermissionRequest;
  stateId: string;
  grantId: string;
  revokeId: string;
  grantedLabel: string;
  missingLabel: string;
  /** Card-specific, because host access and download access do different things. */
  grantedMessage: string;
}

const CARDS: CardWiring[] = [
  {
    request: { permissions: ["downloads"] },
    stateId: "downloads-state",
    grantId: "downloads-grant",
    revokeId: "downloads-revoke",
    grantedLabel: "granted",
    missingLabel: "not granted",
    grantedMessage: "Granted. Media saves through the browser now."
  },
  {
    request: { origins: MEDIA_ORIGINS },
    stateId: "media-state",
    grantId: "media-grant",
    revokeId: "media-revoke",
    grantedLabel: "granted",
    missingLabel: "not granted",
    grantedMessage: "Granted. Aviary can read full-size media directly for exports now."
  }
];

start();

function start(): void {
  if (typeof document === "undefined") {
    return;
  }
  showVersion();
  wireOpenX();
  wireDiagnostics();
  for (const card of CARDS) {
    wireCard(card);
  }
  // After wiring, so the state labels a card writes are re-rendered in the chosen locale.
  void readLocale().then((code) => {
    locale = code;
    applyTranslations();
    for (const card of CARDS) {
      void refresh(card);
    }
  });
}

function wireDiagnostics(): void {
  document.getElementById("diagnostics-copy")?.addEventListener("click", () => {
    void copyDiagnostics();
  });
}

async function copyDiagnostics(): Promise<void> {
  const button = document.getElementById("diagnostics-copy") as HTMLButtonElement | null;
  const status = document.getElementById("diagnostics-status");
  if (button) button.disabled = true;
  try {
    const clipboard = globalThis.navigator?.clipboard;
    if (!clipboard?.writeText) throw new Error("Clipboard API unavailable");
    await clipboard.writeText(await buildDiagnosticsReport());
    if (status) {
      status.textContent = translate("Diagnostics copied to clipboard.");
      status.dataset.tone = "success";
    }
  } catch {
    if (status) {
      status.textContent = translate("Could not copy diagnostics.");
      status.dataset.tone = "error";
    }
  } finally {
    if (button) button.disabled = false;
  }
}

function wireOpenX(): void {
  document.getElementById("open-x")?.addEventListener("click", () => {
    const opened = globalThis.open("https://x.com/home", "_blank", "noopener");
    if (!opened) globalThis.location.assign("https://x.com/home");
  });
}

function showVersion(): void {
  const target = document.getElementById("version");
  const version = globalThis.chrome?.runtime?.getManifest?.()?.version;
  if (target && version) {
    target.textContent = `v${version}`;
  }
}

function wireCard(card: CardWiring): void {
  const grant = document.getElementById(card.grantId);
  const revoke = document.getElementById(card.revokeId);

  grant?.addEventListener("click", () => {
    void run(card, "request");
  });
  revoke?.addEventListener("click", () => {
    void run(card, "remove");
  });

  void refresh(card);
}

async function run(card: CardWiring, action: "request" | "remove"): Promise<void> {
  const permissions = globalThis.chrome?.permissions;
  if (!permissions) {
    setStatus(translate("This browser did not expose the permissions API."), "error");
    return;
  }
  setBusy(card, true);
  try {
    const changed =
      action === "request"
        ? await permissions.request(card.request)
        : await permissions.remove(card.request);
    const granted = await refresh(card);
    if (action === "request") {
      setStatus(
        granted ? translate(card.grantedMessage) : translate("Request dismissed. Nothing changed."),
        granted ? "success" : "info"
      );
    } else {
      setStatus(
        changed && !granted ? translate("Revoked.") : translate("Nothing to revoke."),
        changed && !granted ? "success" : "info"
      );
    }
  } catch (error) {
    setStatus(error instanceof Error ? error.message : String(error), "error");
  } finally {
    setBusy(card, false);
    await refresh(card);
  }
}

function setBusy(card: CardWiring, busy: boolean): void {
  const state = document.getElementById(card.stateId);
  const grant = document.getElementById(card.grantId) as HTMLButtonElement | null;
  const revoke = document.getElementById(card.revokeId) as HTMLButtonElement | null;
  state?.setAttribute("aria-busy", String(busy));
  if (busy && state) state.textContent = translate("checking…");
  if (grant) grant.disabled = busy || grant.disabled;
  if (revoke) revoke.disabled = busy || revoke.disabled;
}

async function refresh(card: CardWiring): Promise<boolean> {
  const state = document.getElementById(card.stateId);
  const grant = document.getElementById(card.grantId) as HTMLButtonElement | null;
  const revoke = document.getElementById(card.revokeId) as HTMLButtonElement | null;
  const permissions = globalThis.chrome?.permissions;

  let granted = false;
  if (permissions?.contains) {
    try {
      granted = await permissions.contains(card.request);
    } catch {
      granted = false;
    }
  }

  if (state) {
    state.textContent = translate(granted ? card.grantedLabel : card.missingLabel);
    state.setAttribute("data-granted", String(granted));
    state.setAttribute("aria-busy", "false");
  }
  if (grant) grant.disabled = granted;
  if (revoke) revoke.disabled = !granted;
  updatePermissionHealth();
  return granted;
}

function updatePermissionHealth(): void {
  const target = document.getElementById("granted-count");
  if (!target) return;
  const grantedCount = document.querySelectorAll<HTMLElement>('.state[data-granted="true"]').length;
  target.textContent = String(grantedCount);
  const downloadsReady = document.getElementById("downloads-state")?.dataset.granted === "true";
  const message = document.getElementById("health-message");
  if (message) {
    message.textContent = translate(
      downloadsReady ? "Granted. Media saves through the browser now." : "Grant download access"
    );
  }
}

function setStatus(message: string, tone: "info" | "success" | "error" = "info"): void {
  const status = document.getElementById("status");
  if (status) {
    status.textContent = message;
    status.dataset.tone = tone;
  }
}
