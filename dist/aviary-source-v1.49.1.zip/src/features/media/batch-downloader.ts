import { renderFilename } from "./template.ts";
import {
  extractTweet,
  mediaIdentity,
  type ExtractedTweet,
  type ExtractedMedia,
  type ExtractTweetOptions
} from "./extract.ts";
import { sharedDownloadWatcher } from "./download-watch.ts";
import {
  createDownloader,
  DownloadPermissionError,
  fingerprintMediaDownload,
  queryExtensionDownload,
  requestDownloadPermissionSurface,
  type Downloader,
  type DownloaderResult
} from "./downloader.ts";
import { mediaIdentityHash, type MediaFingerprint } from "../export/assets.ts";
import { getCapturedMediaMetadata, getMediaHistory, getMediaQueue } from "./media-buttons.ts";
import { isSaveableVariantUrl } from "./video-extract.ts";
import type { DownloadJob } from "./queue.ts";
import type { FeatureContext } from "../registry.ts";
import type { ExportMedia, ExportRecord } from "../export/types.ts";
import { normalizeImageUrl } from "./urls.ts";
import {
  mediaSidecarRequest,
  saveMediaSidecar,
  type MediaSidecarRequest
} from "./sidecar.ts";
import {
  normalizeDownloadQuality,
  type DownloadQualityReceipt
} from "../../extension/download-state.ts";

export interface BatchOptions {
  surface?: string;
  maxItems?: number;
  filterKind?: "photo" | "video" | "thumbnail" | "audio" | "subtitle" | "all";
}

export interface BatchProgress {
  total: number;
  enqueued: number;
  downloaded: number;
  started: number;
  opened: number;
  duplicate: number;
  failed: number;
}

export interface BatchResult extends BatchProgress {
  jobIds: string[];
  cancelled: boolean;
  /** Set when the batch stopped early because the browser download permission is missing. */
  needsDownloadPermission?: boolean;
}

export interface MediaBatchStatus extends BatchProgress {
  id: string;
  status: "running" | "paused" | "cancelling";
}

export interface BatchActionResult {
  ok: boolean;
  error?: string;
}

type ResolvedTarget = {
  url: string;
  fallbackUrls?: string[];
  quality: DownloadQualityReceipt;
  fallbackQualities?: DownloadQualityReceipt[];
  mediaId: string | null;
  ext: string;
};

interface ActiveBatch {
  id: string;
  status: "running" | "paused" | "cancelling";
  cancelled: boolean;
  waiters: Set<() => void>;
  progress: BatchProgress;
}

interface MediaBatchTask {
  kind: "photo" | "video" | "thumbnail" | "audio" | "subtitle";
  index: number;
  total: number;
  target: ResolvedTarget;
  identity: { handle: string | null; tweetId: string | null; text: string };
  permalink: string | null;
  refreshTarget?: () => ResolvedTarget | null;
}

interface PreparedMediaBatchTask extends MediaBatchTask {
  filename: string;
  job: DownloadJob | undefined;
  sidecar: MediaSidecarRequest | undefined;
}

const MEDIA_BATCH_LIMIT = 5_000;

let activeBatch: ActiveBatch | undefined;
let batchSequence = 0;

export function getMediaBatchStatus(): MediaBatchStatus | undefined {
  if (!activeBatch) {
    return undefined;
  }
  const { id, status } = activeBatch;
  const { total, enqueued, downloaded, started, opened, duplicate, failed } = activeBatch.progress;
  return { id, status, total, enqueued, downloaded, started, opened, duplicate, failed };
}

export function pauseMediaBatch(): BatchActionResult {
  if (!activeBatch) {
    return { ok: false, error: "No media batch is running" };
  }
  if (activeBatch.status === "running") {
    activeBatch.status = "paused";
  }
  return { ok: true };
}

export function resumeMediaBatch(): BatchActionResult {
  if (!activeBatch) {
    return { ok: false, error: "No media batch is running" };
  }
  if (activeBatch.status === "paused") {
    activeBatch.status = "running";
    wakeBatch(activeBatch);
  }
  return { ok: true };
}

export function cancelMediaBatch(): BatchActionResult {
  if (!activeBatch) {
    return { ok: false, error: "No media batch is running" };
  }
  activeBatch.status = "cancelling";
  activeBatch.cancelled = true;
  wakeBatch(activeBatch);
  return { ok: true };
}

export async function runMediaBatch(
  ctx: FeatureContext,
  options: BatchOptions = {}
): Promise<BatchResult> {
  const queue = getMediaQueue();
  const history = getMediaHistory();
  const downloader: Downloader = createDownloader({
    integrations: ctx.settings.integrations,
    onWarn: (message, details) => ctx.diagnostics.warn(message, details)
  });
  const concurrency = Math.max(1, Math.min(ctx.settings.jobs.concurrentDownloads, 6));
  const max = Math.max(1, Math.min(MEDIA_BATCH_LIMIT, options.maxItems ?? 200));
  const filterKind = options.filterKind ?? "all";

  const tweets = collectArticles(document, options.surface, {
    preferOriginalImages: ctx.settings.media.preferOriginalImages,
    mediaMetadata: getCapturedMediaMetadata
  });
  const tasks: MediaBatchTask[] = [];

  for (const tweet of tweets) {
    tweet.media.forEach((media, index) => {
      if (filterKind !== "all" && media.kind !== filterKind) return;
      const target = resolveTarget(media);
      if (!target) return;
      const identity = mediaIdentity(tweet, media);
      tasks.push({
        kind: media.kind,
        index,
        total: tweet.media.length,
        target,
        identity,
        permalink: postPermalink(identity),
        refreshTarget: () => {
          const refreshed = extractTweet(tweet.article, {
            preferOriginalImages: ctx.settings.media.preferOriginalImages,
            mediaMetadata: getCapturedMediaMetadata
          }).media[index];
          return refreshed ? resolveTarget(refreshed) : null;
        }
      });
    });
    // Stop collecting once the cap is reached; the single exit below keeps the configured
    // concurrency applied on every path.
    if (tasks.length >= max) {
      break;
    }
  }

  return runTasks(ctx, downloader, queue, history, tasks.slice(0, max), concurrency);
}

export function countCapturedMedia(
  records: readonly ExportRecord[],
  preferOriginalImages: boolean,
  filterKind: NonNullable<BatchOptions["filterKind"]> = "all"
): number {
  return capturedMediaTasks(records, preferOriginalImages, filterKind, null).length;
}

/** One row of the review list a person sees before any of this reaches the durable queue. */
export interface MediaBatchPreviewItem {
  /** Stable across a re-preview of the same library, so a selection survives a filter change. */
  id: string;
  kind: ExportMedia["kind"];
  handle: string | null;
  tweetId: string | null;
  /** The name this item would be saved as, already made unique within the batch. */
  filename: string;
  qualityLabel: string;
  width: number | null;
  height: number | null;
  /** False when nothing downloadable could be resolved; `reason` says what. */
  available: boolean;
  reason?: string;
}

export interface MediaBatchPreview {
  items: MediaBatchPreviewItem[];
  /** Items that cannot be downloaded, kept out of the count but shown with their reason. */
  unavailable: MediaBatchPreviewItem[];
  /** Kinds present in this result, so the filter offers only what is actually there. */
  kinds: Array<ExportMedia["kind"]>;
  /** True when the library holds more than one batch can take. */
  overLimit: boolean;
  limit: number;
}

/**
 * What a batch would do, worked out from stored records alone.
 *
 * The action used to queue the whole local result set the moment it was clicked, which on a
 * library of any size is a decision nobody got to make. Nothing here touches the network, the
 * queue, or the history: it reads what is already stored and reports it, and the caller decides
 * what, if anything, to run.
 */
export function previewCapturedMediaBatch(
  ctx: FeatureContext,
  records: readonly ExportRecord[],
  options: Pick<BatchOptions, "filterKind"> = {}
): MediaBatchPreview {
  const kinds = new Set<ExportMedia["kind"]>();
  for (const record of records) {
    for (const media of record.media) kinds.add(media.kind);
  }

  const available: MediaBatchPreviewItem[] = [];
  const unavailable: MediaBatchPreviewItem[] = [];
  const usedFilenames = new Map<string, number>();
  const seen = new Set<string>();
  const filterKind = options.filterKind ?? "all";

  for (const record of records) {
    record.media.forEach((media, index) => {
      if (filterKind !== "all" && media.kind !== filterKind) return;
      const target = resolveCapturedTarget(media, ctx.settings.media.preferOriginalImages);
      const attributed = media.attribution;
      const handle = attributed?.handle ?? record.handle;
      const text = attributed?.scope === "quote" ? record.quote?.text ?? record.text : record.text;
      const id = `${record.tweetId ?? "unknown"}:${index}:${media.kind}`;

      if (!target) {
        unavailable.push({
          id,
          kind: media.kind,
          handle,
          tweetId: record.tweetId,
          filename: "",
          qualityLabel: "",
          width: media.width ?? null,
          height: media.height ?? null,
          available: false,
          reason: unavailableReason(media)
        });
        return;
      }

      // The same identity twice is one file, and the batch already collapses it. Saying so here
      // stops the count promising more files than the run will produce.
      const key = `${media.kind}:${target.mediaId ?? target.url}`;
      if (seen.has(key)) return;
      seen.add(key);

      const base = renderFilename(ctx.settings.media.filenameTemplate, {
        handle,
        tweetId: record.tweetId,
        index,
        total: record.media.length,
        date: new Date(),
        ext: target.ext,
        text,
        mediaId: target.mediaId
      });
      available.push({
        id,
        kind: media.kind,
        handle,
        tweetId: record.tweetId,
        filename: uniqueFilename(base, usedFilenames),
        qualityLabel: target.quality.label,
        width: target.quality.width,
        height: target.quality.height,
        available: true
      });
    });
  }

  return {
    items: available,
    unavailable,
    kinds: [...kinds].sort(),
    overLimit: available.length > MEDIA_BATCH_LIMIT,
    limit: MEDIA_BATCH_LIMIT
  };
}

/**
 * Two captures of different posts can render the same name. The queue would then write one file
 * over the other, and the count would have promised two.
 */
function uniqueFilename(base: string, used: Map<string, number>): string {
  const seen = used.get(base) ?? 0;
  used.set(base, seen + 1);
  if (seen === 0) return base;
  const dot = base.lastIndexOf(".");
  return dot > 0 ? `${base.slice(0, dot)}-${seen + 1}${base.slice(dot)}` : `${base}-${seen + 1}`;
}

function unavailableReason(media: ExportMedia): string {
  const url = (media.url || media.sourceUrl || "").trim();
  if (!url) return "No stored address for this item.";
  if (/^blob:/i.test(url)) return "The player handle is only valid in the tab that made it.";
  if (/\.(?:m3u8|mpd|m4s)(?:[?#]|$)/i.test(url)) return "A streaming manifest, not a file.";
  return "Nothing downloadable was stored for this item.";
}

/** Downloads only media URLs already present in local capture records. */
export async function runCapturedMediaBatch(
  ctx: FeatureContext,
  records: readonly ExportRecord[],
  options: Pick<BatchOptions, "maxItems" | "filterKind"> & {
    /** When present, only these preview ids are queued. Everything else is left alone. */
    selectedIds?: readonly string[];
  } = {}
): Promise<BatchResult> {
  const queue = getMediaQueue();
  const history = getMediaHistory();
  const downloader = createDownloader({
    integrations: ctx.settings.integrations,
    onWarn: (message, details) => ctx.diagnostics.warn(message, details)
  });
  const tasks = capturedMediaTasks(
    records,
    ctx.settings.media.preferOriginalImages,
    options.filterKind ?? "all",
    options.selectedIds ? new Set(options.selectedIds) : null
  );
  const max = Math.max(1, Math.min(MEDIA_BATCH_LIMIT, options.maxItems ?? MEDIA_BATCH_LIMIT));
  if (tasks.length > MEDIA_BATCH_LIMIT && (options.maxItems === undefined || options.maxItems > MEDIA_BATCH_LIMIT)) {
    throw new Error(`This collection has more than ${MEDIA_BATCH_LIMIT.toLocaleString()} downloadable items. Narrow the Library search and try again.`);
  }
  const concurrency = Math.max(1, Math.min(ctx.settings.jobs.concurrentDownloads, 6));
  return runTasks(ctx, downloader, queue, history, tasks.slice(0, max), concurrency);
}

async function runTasks(
  ctx: FeatureContext,
  downloader: Downloader,
  queue: ReturnType<typeof getMediaQueue>,
  history: ReturnType<typeof getMediaHistory>,
  tasks: MediaBatchTask[],
  concurrency = 3
): Promise<BatchResult> {
  const progress: BatchProgress = {
    total: tasks.length,
    enqueued: 0,
    downloaded: 0,
    started: 0,
    opened: 0,
    duplicate: 0,
    failed: 0
  };
  const control = beginBatch(tasks.length, progress);
  let prepared: PreparedMediaBatchTask[] = [];
  let jobIds: string[] = [];
  let cursor = 0;
  let needsDownloadPermission = false;
  const workers: Promise<void>[] = [];

  try {
    prepared = tasks.map((task): PreparedMediaBatchTask => {
      const filename = renderFilename(ctx.settings.media.filenameTemplate, {
        handle: task.identity.handle,
        tweetId: task.identity.tweetId,
        index: task.index,
        total: task.total,
        date: new Date(),
        ext: task.target.ext,
        text: task.identity.text,
        mediaId: task.target.mediaId
      });
      const sidecar = mediaSidecarRequest(ctx.settings.media.sidecarFormat, {
        mediaFilename: filename,
        kind: task.kind,
        handle: task.identity.handle,
        tweetId: task.identity.tweetId,
        text: task.identity.text,
        permalink: task.permalink,
        queuedAt: new Date().toISOString()
      });
      const job = queue?.enqueue({
        url: task.target.url,
        ...(task.target.fallbackUrls ? { fallbackUrls: task.target.fallbackUrls } : {}),
        quality: task.target.quality,
        ...(task.target.fallbackQualities
          ? { fallbackQualities: task.target.fallbackQualities }
          : {}),
        filename,
        kind: task.kind,
        mediaId: task.target.mediaId,
        ...(sidecar ? { sidecar } : {})
      });
      return { ...task, filename, job, sidecar };
    });
    jobIds = prepared.flatMap((task) => task.job ? [task.job.id] : []);
    await queue?.checkpoint();
    const next = async (): Promise<void> => {
      while (true) {
        // A missing download permission fails every remaining task the same way — stop
        // instead of grinding through hundreds of identical failures.
        if (needsDownloadPermission) return;
        if (control.cancelled) return;
        await waitForBatch(control);
        if (needsDownloadPermission) return;
        if (control.cancelled) return;
        const index = cursor++;
        if (index >= prepared.length) return;
        const task = prepared[index]!;
        const { filename, job } = task;
        refreshTaskTarget(task, job, queue);

        let fingerprint: MediaFingerprint = {
          identityHash: mediaIdentityHash(
            task.kind,
            task.target.url,
            task.target.mediaId
          )
        };
        let historyMatch = ctx.settings.media.downloadHistory
          ? history?.findMatch(fingerprint, false) ?? null
          : null;
        let reservationToken: string | null = null;

        if (historyMatch && history) {
          const reservation = await history.reserve(fingerprint, false);
          historyMatch = reservation.match;
          reservationToken = reservation.token;
        }
        if (historyMatch && history) {
          await history.noteMatch(historyMatch);
          progress.duplicate += 1;
          if (job) queue?.mark(job.id, "duplicate");
          continue;
        }

        // `jobs.rateLimitMode` used to change nothing but the bucket's capacity, because no
        // feature ever drew from it. A batch is the one place the pacing matters: it is the
        // only path that fires hundreds of requests at X's media hosts back to back.
        await ctx.limiter.waitForToken();
        if (control.cancelled) {
          if (reservationToken && history) await history.release(reservationToken);
          return;
        }
        await waitForBatch(control);
        if (control.cancelled) {
          if (reservationToken && history) await history.release(reservationToken);
          return;
        }

        if (ctx.settings.media.downloadHistory && history && !reservationToken) {
          fingerprint = await fingerprintMediaDownload({
            kind: task.kind,
            url: task.target.url,
            ...(task.target.fallbackUrls
              ? { fallbackUrls: task.target.fallbackUrls }
              : {}),
            mediaId: task.target.mediaId,
            includePerceptual: ctx.settings.media.perceptualDedup
          });
          const reservation = await history.reserve(
            fingerprint,
            ctx.settings.media.perceptualDedup
          );
          historyMatch = reservation.match;
          reservationToken = reservation.token;
          if (historyMatch) {
            await history.noteMatch(historyMatch);
            progress.duplicate += 1;
            if (job) queue?.mark(job.id, "duplicate");
            void ctx.auditLog.record("media.download.duplicate", {
              matchKind: historyMatch,
              batch: true
            });
            continue;
          }
        }
        if (control.cancelled) {
          if (reservationToken && history) await history.release(reservationToken);
          return;
        }

        // A player can receive richer metadata while this task waits for pacing. Refresh only after
        // that wait, while the queue job is still queued, so the durable target and the fingerprint
        // agree with the best direct file observed before the handoff starts.
        if (refreshTaskTarget(task, job, queue)) {
          fingerprint = { identityHash: mediaIdentityHash(task.kind, task.target.url, task.target.mediaId) };
          historyMatch = null;
          reservationToken = null;
        }

        if (job) {
          queue?.mark(job.id, "running");
        }
        progress.enqueued += 1;

        try {
          const result: DownloaderResult = await downloader({
            url: task.target.url,
            ...(task.target.fallbackUrls
              ? { fallbackUrls: task.target.fallbackUrls }
              : {}),
            quality: task.target.quality,
            ...(task.target.fallbackQualities ? { fallbackQualities: task.target.fallbackQualities } : {}),
            filename
          });
          if (result.deduplicated) {
            if (reservationToken && history) {
              await history.release(reservationToken);
              reservationToken = null;
            }
            if (job) queue?.mark(job.id, "duplicate");
            progress.duplicate += 1;
            void ctx.auditLog.record("media.download.duplicate", {
              source: "aria2-history",
              batch: true
            });
            continue;
          }
          if (result.degraded) {
            if (reservationToken && history) {
              await history.release(reservationToken);
              reservationToken = null;
            }
            if (job) {
              queue?.mark(job.id, "opened", "the browser opened this URL; a saved file was not confirmed");
            }
            progress.opened += 1;
            void ctx.auditLog.record("media.download.opened", {
              filename,
              kind: task.kind,
              via: result.via,
              batch: true
            });
            continue;
          }
          if (result.pending && result.downloadId !== undefined) {
            // The batch can return after the handoff, but the terminal listener remains active.
            // Only that listener is allowed to count, audit, or write metadata for a saved file.
            const jobId = job?.id;
            const activeReservation = reservationToken;
            reservationToken = null;
            if (jobId) queue?.trackDownload(jobId, result.downloadId);
            void sharedDownloadWatcher()
              .terminal(result.downloadId)
              .then(async (terminal) => {
                if (terminal === "complete") {
                  const quality = sharedDownloadWatcher().receipt(result.downloadId!) ?? task.target.quality;
                  if (jobId) queue?.mark(jobId, "completed");
                  if (jobId) queue?.setQuality(jobId, quality);
                  if (ctx.settings.media.downloadHistory && history) {
                    if (activeReservation) await history.commit(activeReservation, fingerprint, quality);
                    else await history.record(fingerprint, quality);
                  }
                  saveSidecarOrWarn(ctx, task.sidecar, filename);
                  void ctx.auditLog.record("media.download", {
                    filename,
                    kind: task.kind,
                    via: result.via,
                    batch: true
                  });
                  return;
                }
                if (terminal === "interrupted") {
                  if (activeReservation && history) await history.release(activeReservation);
                  if (jobId) queue?.mark(jobId, "failed", "the browser interrupted this transfer");
                  ctx.diagnostics.warn("Batch media transfer was interrupted", {
                    filename,
                    kind: task.kind
                  });
                  void ctx.auditLog.record("media.download.failed", {
                    filename,
                    kind: task.kind,
                    batch: true
                  });
                }
              })
              .catch(async (error) => {
                if (activeReservation && history) await history.release(activeReservation);
                if (jobId) queue?.mark(jobId, "failed", "the browser result could not be confirmed");
                ctx.diagnostics.warn("Could not confirm batch media transfer", {
                  filename,
                  error: String((error as Error)?.message ?? error)
                });
              });
            progress.started += 1;
            continue;
          } else {
            const quality = result.quality ?? task.target.quality;
            if (job) queue?.mark(job.id, "completed");
            if (job) queue?.setQuality(job.id, quality);
            if (ctx.settings.media.downloadHistory && history) {
              if (reservationToken) {
                await history.commit(reservationToken, fingerprint, quality);
                reservationToken = null;
              } else {
                await history.record(fingerprint, quality);
              }
            }
            saveSidecarOrWarn(ctx, task.sidecar, filename);
          }
          progress.downloaded += 1;
          void ctx.auditLog.record("media.download", { filename, kind: task.kind, via: result.via, batch: true });
        } catch (error) {
          if (reservationToken && history) {
            await history.release(reservationToken);
            reservationToken = null;
          }
          if (job) queue?.mark(job.id, "failed", String((error as Error)?.message ?? error));
          progress.failed += 1;
          if (error instanceof DownloadPermissionError) {
            needsDownloadPermission = true;
            void requestDownloadPermissionSurface();
          }
          ctx.diagnostics.error("Batch media download failed", {
            filename,
            kind: task.kind,
            error: String((error as Error)?.message ?? error)
          });
          void ctx.auditLog.record("media.download.failed", { filename, kind: task.kind, batch: true });
        }
      }
    };

    for (let i = 0; i < concurrency; i++) {
      workers.push(next());
    }
    await Promise.all(workers);
    await queue?.flush();

    return {
      ...progress,
      jobIds,
      cancelled: control.cancelled,
      ...(needsDownloadPermission ? { needsDownloadPermission: true } : {})
    };
  } finally {
    finishBatch(control);
  }
}

function sameTarget(left: ResolvedTarget, right: ResolvedTarget): boolean {
  return (
    left.url === right.url &&
    left.mediaId === right.mediaId &&
    JSON.stringify(left.fallbackUrls ?? []) === JSON.stringify(right.fallbackUrls ?? []) &&
    JSON.stringify(left.quality) === JSON.stringify(right.quality) &&
    JSON.stringify(left.fallbackQualities ?? []) === JSON.stringify(right.fallbackQualities ?? [])
  );
}

function refreshTaskTarget(
  task: PreparedMediaBatchTask,
  job: DownloadJob | undefined,
  queue: ReturnType<typeof getMediaQueue>
): boolean {
  const refreshedTarget = task.refreshTarget?.();
  if (!refreshedTarget || sameTarget(task.target, refreshedTarget)) return false;
  task.target = refreshedTarget;
  if (job) {
    queue?.updateTarget(job.id, {
      url: refreshedTarget.url,
      ...(refreshedTarget.fallbackUrls ? { fallbackUrls: refreshedTarget.fallbackUrls } : {}),
      ...(refreshedTarget.fallbackQualities
        ? { fallbackQualities: refreshedTarget.fallbackQualities }
        : {}),
      quality: refreshedTarget.quality,
      mediaId: refreshedTarget.mediaId
    });
  }
  return true;
}

/** Replays jobs left in the durable queue after a restart, only after an explicit user action. */
export async function resumePendingMediaJobs(ctx: FeatureContext): Promise<BatchResult> {
  const queue = getMediaQueue();
  const pending = queue?.pending() ?? [];
  return runPersistedJobs(ctx, queue, pending);
}

/** Marks failed/cancelled queue entries retryable, then runs them through the normal downloader. */
export async function retryFailedMediaJobs(ctx: FeatureContext): Promise<BatchResult> {
  const queue = getMediaQueue();
  const pending = queue?.retryFailed() ?? [];
  return runPersistedJobs(ctx, queue, pending);
}

async function runPersistedJobs(
  ctx: FeatureContext,
  queue: ReturnType<typeof getMediaQueue>,
  jobs: DownloadJob[]
): Promise<BatchResult> {
  const progress: BatchProgress = {
    total: jobs.length,
    enqueued: 0,
    downloaded: 0,
    started: 0,
    opened: 0,
    duplicate: 0,
    failed: 0
  };
  const jobIds = jobs.map((job) => job.id);
  if (!queue || jobs.length === 0) {
    return { ...progress, jobIds, cancelled: false };
  }
  const control = beginBatch(jobs.length, progress);
  const downloader = createDownloader({
    integrations: ctx.settings.integrations,
    onWarn: (message, details) => ctx.diagnostics.warn(message, details)
  });
  const history = getMediaHistory();
  let needsDownloadPermission = false;

  try {
    for (const job of jobs) {
      if (control.cancelled || needsDownloadPermission) break;
      await waitForBatch(control);
      if (control.cancelled) break;

      // A queue entry can retain the browser id that was handed off before this tab or its
      // service worker restarted. Ask the background about that id before creating another file.
      if (job.downloadId !== undefined) {
        const retained = await queryExtensionDownload(job.downloadId);
        if (!retained) {
          // A retained id is an extension handoff. If the background cannot answer, do not guess
          // that the file is gone and create a duplicate. Leave it paused for a later retry.
          queue.mark(job.id, "paused", "The browser download could not be verified; try resume again.");
          progress.failed += 1;
          ctx.diagnostics.warn("Could not reconcile retained media transfer", {
            filename: job.filename,
            downloadId: job.downloadId
          });
          continue;
        }
        if (retained?.state === "in_progress") {
          queue.resume(job.id);
          queue.mark(job.id, "running");
          progress.started += 1;
          watchRetainedDownload(ctx, queue, history, job, job.downloadId);
          continue;
        }
        if (retained?.state === "complete") {
          queue.mark(job.id, "completed");
          const quality = retained.quality ?? job.quality ?? unknownQualityReceipt();
          queue.setQuality(job.id, quality);
          const fingerprint = retainedFingerprint(job);
          if (ctx.settings.media.downloadHistory && history && fingerprint) {
            await history.record(fingerprint, quality);
          }
          saveSidecarOrWarn(ctx, job.sidecar, job.filename);
          progress.downloaded += 1;
          void ctx.auditLog.record("media.download", {
            filename: job.filename,
            batch: true,
            resumed: true,
            reconciled: true
          });
          continue;
        }
        if (retained?.state === "interrupted" || retained?.state === "missing") {
          // The old browser record is no longer a transfer we can wait on. Let the normal path
          // retry the member once, with its original quality-ordered candidates.
          queue.forgetDownload(job.id);
        }
      }
      queue.resume(job.id);
      let fingerprint: MediaFingerprint | undefined;
      let reservationToken: string | null = null;
      try {
        await ctx.limiter.waitForToken();
        if (control.cancelled) break;

        if (ctx.settings.media.downloadHistory && history && job.kind) {
          fingerprint = {
            identityHash: mediaIdentityHash(job.kind, job.url, job.mediaId ?? null)
          };
          let historyMatch = history.findMatch(fingerprint, false);
          if (!historyMatch) {
            fingerprint = await fingerprintMediaDownload({
              kind: job.kind,
              url: job.url,
              ...(job.fallbackUrls ? { fallbackUrls: job.fallbackUrls } : {}),
              mediaId: job.mediaId ?? null,
              includePerceptual: ctx.settings.media.perceptualDedup
            });
          }
          const reservation = await history.reserve(
            fingerprint,
            ctx.settings.media.perceptualDedup
          );
          historyMatch = reservation.match;
          reservationToken = reservation.token;
          if (historyMatch) {
            await history.noteMatch(historyMatch);
            queue.mark(job.id, "duplicate");
            progress.duplicate += 1;
            void ctx.auditLog.record("media.download.duplicate", {
              matchKind: historyMatch,
              batch: true,
              resumed: true
            });
            continue;
          }
        }

        queue.mark(job.id, "running");
        progress.enqueued += 1;
        const result = await downloader({
          url: job.url,
          ...(job.fallbackUrls ? { fallbackUrls: job.fallbackUrls } : {}),
          ...(job.quality ? { quality: job.quality } : {}),
          ...(job.fallbackQualities ? { fallbackQualities: job.fallbackQualities } : {}),
          filename: job.filename
        });
        if (result.deduplicated) {
          if (reservationToken && history) {
            await history.release(reservationToken);
            reservationToken = null;
          }
          queue.mark(job.id, "duplicate");
          progress.duplicate += 1;
          void ctx.auditLog.record("media.download.duplicate", {
            filename: job.filename,
            batch: true,
            resumed: true,
            via: result.via
          });
          continue;
        }
        if (result.degraded) {
          if (reservationToken && history) {
            await history.release(reservationToken);
            reservationToken = null;
          }
          queue.mark(job.id, "opened", "the browser opened this URL; a saved file was not confirmed");
          progress.opened += 1;
          void ctx.auditLog.record("media.download.opened", {
            filename: job.filename,
            batch: true,
            resumed: true,
            via: result.via
          });
          continue;
        }
        if (result.pending && result.downloadId !== undefined) {
          // Resumed jobs settle the same way a fresh batch does: the queue entry stays running
          // until the browser reports the transfer's terminal state, so a resumed job that fails
          // is retryable rather than marked completed.
          const jobId = job.id;
          const activeReservation = reservationToken;
          const activeFingerprint = fingerprint;
          reservationToken = null;
          queue.trackDownload(jobId, result.downloadId);
          void sharedDownloadWatcher()
            .terminal(result.downloadId)
            .then(async (terminal) => {
              if (terminal === "complete") {
                const quality = sharedDownloadWatcher().receipt(result.downloadId!) ?? job.quality ?? unknownQualityReceipt();
                queue.mark(jobId, "completed");
                queue.setQuality(jobId, quality);
                if (ctx.settings.media.downloadHistory && history && activeFingerprint) {
                  if (activeReservation) {
                    await history.commit(activeReservation, activeFingerprint, quality);
                  } else {
                    await history.record(activeFingerprint, quality);
                  }
                }
                saveSidecarOrWarn(ctx, job.sidecar, job.filename);
                void ctx.auditLog.record("media.download", {
                  filename: job.filename,
                  batch: true,
                  resumed: true,
                  via: result.via
                });
              } else if (terminal === "interrupted") {
                if (activeReservation && history) await history.release(activeReservation);
                queue.mark(jobId, "failed", "the browser interrupted this transfer");
                void ctx.auditLog.record("media.download.failed", {
                  filename: job.filename,
                  batch: true,
                  resumed: true
                });
              }
            })
            .catch(async (error) => {
              if (activeReservation && history) await history.release(activeReservation);
              queue.mark(jobId, "failed", "the browser result could not be confirmed");
              ctx.diagnostics.warn("Could not confirm resumed media transfer", {
                filename: job.filename,
                error: String((error as Error)?.message ?? error)
              });
            });
          progress.started += 1;
          continue;
        } else {
          const quality = result.quality ?? job.quality ?? unknownQualityReceipt();
          queue.mark(job.id, "completed");
          queue.setQuality(job.id, quality);
          if (ctx.settings.media.downloadHistory && history && fingerprint) {
            if (reservationToken) {
              await history.commit(reservationToken, fingerprint, quality);
              reservationToken = null;
            } else {
              await history.record(fingerprint, quality);
            }
          }
          saveSidecarOrWarn(ctx, job.sidecar, job.filename);
        }
        progress.downloaded += 1;
        void ctx.auditLog.record("media.download", {
          filename: job.filename,
          batch: true,
          resumed: true,
          via: result.via
        });
      } catch (error) {
        if (reservationToken && history) {
          await history.release(reservationToken);
          reservationToken = null;
        }
        queue.mark(job.id, "failed", String((error as Error)?.message ?? error));
        progress.failed += 1;
        if (error instanceof DownloadPermissionError) {
          needsDownloadPermission = true;
          void requestDownloadPermissionSurface();
        }
        ctx.diagnostics.error("Resumed media download failed", {
          filename: job.filename,
          error: String((error as Error)?.message ?? error)
        });
        void ctx.auditLog.record("media.download.failed", { filename: job.filename, batch: true, resumed: true });
      }
    }
    await queue.flush();
    return {
      ...progress,
      jobIds,
      cancelled: control.cancelled,
      ...(needsDownloadPermission ? { needsDownloadPermission: true } : {})
    };
  } finally {
    finishBatch(control);
  }
}

function retainedFingerprint(job: DownloadJob): MediaFingerprint | undefined {
  return job.kind
    ? { identityHash: mediaIdentityHash(job.kind, job.url, job.mediaId ?? null) }
    : undefined;
}

function watchRetainedDownload(
  ctx: FeatureContext,
  queue: ReturnType<typeof getMediaQueue>,
  history: ReturnType<typeof getMediaHistory>,
  job: DownloadJob,
  downloadId: number
): void {
  const fingerprint = retainedFingerprint(job);
  void sharedDownloadWatcher()
    .terminal(downloadId)
    .then(async (terminal) => {
      if (terminal === "complete") {
        const quality = sharedDownloadWatcher().receipt(downloadId) ?? job.quality ?? unknownQualityReceipt();
        queue?.mark(job.id, "completed");
        queue?.setQuality(job.id, quality);
        if (ctx.settings.media.downloadHistory && history && fingerprint) {
          await history.record(fingerprint, quality);
        }
        saveSidecarOrWarn(ctx, job.sidecar, job.filename);
        void ctx.auditLog.record("media.download", {
          filename: job.filename,
          batch: true,
          resumed: true,
          reconciled: true
        });
      } else if (terminal === "interrupted") {
        queue?.mark(job.id, "failed", "the browser interrupted this transfer");
        void ctx.auditLog.record("media.download.failed", {
          filename: job.filename,
          batch: true,
          resumed: true,
          reconciled: true
        });
      }
    })
    .catch((error) => {
      queue?.mark(job.id, "failed", "the browser result could not be confirmed");
      ctx.diagnostics.warn("Could not confirm retained media transfer", {
        filename: job.filename,
        error: String((error as Error)?.message ?? error)
      });
    });
}

function saveSidecarOrWarn(
  ctx: FeatureContext,
  request: MediaSidecarRequest | undefined,
  mediaFilename: string
): void {
  if (!request || saveMediaSidecar(request)) return;
  ctx.diagnostics.warn("Media sidecar could not be saved", { mediaFilename });
}

function beginBatch(total: number, progress: BatchProgress): ActiveBatch {
  if (activeBatch) {
    throw new Error("A media batch is already running");
  }
  const control: ActiveBatch = {
    id: `media-${Date.now()}-${++batchSequence}`,
    status: "running",
    cancelled: false,
    waiters: new Set(),
    progress
  };
  activeBatch = control;
  return control;
}

async function waitForBatch(control: ActiveBatch): Promise<void> {
  while (control.status === "paused" && !control.cancelled) {
    await new Promise<void>((resolve) => {
      control.waiters.add(resolve);
    });
  }
}

function wakeBatch(control: ActiveBatch): void {
  for (const resolve of control.waiters) {
    resolve();
  }
  control.waiters.clear();
}

function finishBatch(control: ActiveBatch): void {
  wakeBatch(control);
  if (activeBatch === control) {
    activeBatch = undefined;
  }
}

function capturedMediaTasks(
  records: readonly ExportRecord[],
  preferOriginalImages: boolean,
  filterKind: NonNullable<BatchOptions["filterKind"]>,
  selectedIds: ReadonlySet<string> | null
): MediaBatchTask[] {
  const tasks: MediaBatchTask[] = [];
  const seen = new Set<string>();
  for (const record of records) {
    record.media.forEach((media, index) => {
      if (filterKind !== "all" && media.kind !== filterKind) return;
      // The same id the preview showed. Nothing the person did not tick reaches the queue.
      if (selectedIds && !selectedIds.has(`${record.tweetId ?? "unknown"}:${index}:${media.kind}`)) {
        return;
      }
      const target = resolveCapturedTarget(media, preferOriginalImages);
      if (!target) return;
      const key = `${media.kind}:${target.mediaId ?? target.url}`;
      if (seen.has(key)) return;
      seen.add(key);
      const attributed = media.attribution;
      const handle = attributed?.handle ?? record.handle;
      const text = attributed?.scope === "quote" ? record.quote?.text ?? record.text : record.text;
      tasks.push({
        kind: media.kind,
        index,
        total: record.media.length,
        target,
        identity: { handle, tweetId: record.tweetId, text },
        permalink: record.permalink
      });
    });
  }
  return tasks;
}

function resolveCapturedTarget(
  media: ExportMedia,
  preferOriginalImages: boolean
): ResolvedTarget | null {
  const url = (media.url || media.sourceUrl || "").trim();
  if (media.kind === "photo" || media.kind === "thumbnail") {
    const image = normalizeImageUrl(url, { preferOriginal: preferOriginalImages });
    return image
      ? {
          url: image.url,
          fallbackUrls: image.fallbackUrls,
          quality: imageQuality(image.url, "original"),
          ...(image.fallbackUrls.length > 0
            ? { fallbackQualities: image.fallbackUrls.map((fallback) => imageQuality(fallback, "fallback")) }
            : {}),
          mediaId: image.mediaId,
          ext: image.format
        }
      : null;
  }
  const type = media.type ?? "video/mp4";
  if (!isSaveableVariantUrl(url, type)) return null;
  return {
    url,
    quality: normalizeDownloadQuality({ label: "quality-unknown", mime: type }),
    mediaId: mediaIdFromVideo(url),
    ext:
      media.kind === "audio"
        ? extensionForAudio(type, url)
        : media.kind === "subtitle"
          ? extensionForSubtitle(type, url)
          : extensionForVideo(type, url)
  };
}

function postPermalink(identity: MediaBatchTask["identity"]): string | null {
  if (!identity.tweetId) return null;
  return `https://x.com/${identity.handle ?? "i"}/status/${identity.tweetId}`;
}

function collectArticles(
  root: ParentNode,
  surface = "active",
  extractOptions: Pick<ExtractTweetOptions, "preferOriginalImages" | "mediaMetadata"> = {}
): ExtractedTweet[] {
  const articles =
    root instanceof Element && root.matches('article[data-testid="tweet"]')
      ? [root]
      : Array.from(root.querySelectorAll<Element>('article[data-testid="tweet"]'));
  const seen = new Set<string>();
  const tweets: ExtractedTweet[] = [];
  for (const article of articles) {
    const tweet = extractTweet(article, extractOptions);
    const key = `${tweet.tweetId ?? "noid"}:${tweet.handle ?? "noh"}`;
    if (seen.has(key) || tweet.media.length === 0) continue;
    seen.add(key);
    tweets.push(tweet);
  }
  return tweets.map((tweet) => ({ ...tweet, surface }));
}

export function resolveTarget(media: ExtractedMedia): ResolvedTarget | null {
  if (media.kind === "video" && media.video?.preferred) {
    const url = media.video.preferred.url;
    // A MediaSource blob cannot be handed to any downloader; skipping it keeps the batch
    // counters honest instead of recording saves that never happened.
    if (!isSaveableVariantUrl(url, media.video.preferred.type)) {
      return null;
    }
    const variant = media.video.preferred;
    return {
      url,
      quality: normalizeDownloadQuality({
        label: "best-direct",
        width: variant.width,
        height: variant.height,
        bitrate: variant.bitrate,
        mime: variant.type,
        codec: variant.codec ?? null,
        codecSource: variant.codecSource ?? null,
        playbackProven: variant.playbackObserved === true
      }),
      mediaId: mediaIdFromVideo(url),
      ext: extensionForVideo(variant.type, url)
    };
  }
  if (media.kind === "audio" && media.audio?.preferred) {
    const variant = media.audio.preferred;
    if (!isSaveableVariantUrl(variant.url, variant.type)) return null;
    return {
      url: variant.url,
      quality: normalizeDownloadQuality({
        label: "best-direct",
        width: variant.width,
        height: variant.height,
        bitrate: variant.bitrate,
        mime: variant.type,
        codec: variant.codec ?? null,
        codecSource: variant.codecSource ?? null,
        playbackProven: variant.playbackObserved === true
      }),
      mediaId: mediaIdFromVideo(variant.url),
      ext: extensionForAudio(variant.type, variant.url)
    };
  }
  if (media.kind === "subtitle" && media.subtitle?.track) {
    const track = media.subtitle.track;
    if (!isSaveableVariantUrl(track.url, track.type)) return null;
    return {
      url: track.url,
      quality: normalizeDownloadQuality({ label: "quality-unknown", mime: track.type }),
      mediaId: mediaIdFromVideo(track.url),
      ext: extensionForSubtitle(track.type, track.url)
    };
  }
  if (media.image) {
    const fallbackQualities = media.image.fallbackUrls.map((url) => imageQuality(url, "fallback"));
    return {
      url: media.image.url,
      fallbackUrls: media.image.fallbackUrls,
      quality: imageQuality(media.image.url, "original"),
      ...(fallbackQualities.length > 0 ? { fallbackQualities } : {}),
      mediaId: media.image.mediaId,
      ext: media.image.format
    };
  }
  return null;
}

function imageQuality(url: string, label: "original" | "fallback"): DownloadQualityReceipt {
  const size = /(?:^|[?&])name=(\d{2,5})x(\d{2,5})(?:&|$)/i.exec(url);
  const format = /(?:^|[?&])format=([a-z0-9]+)/i.exec(url)?.[1]?.toLowerCase() ?? "jpg";
  return normalizeDownloadQuality({
    label,
    width: size ? Number(size[1]) : null,
    height: size ? Number(size[2]) : null,
    mime: format === "png" ? "image/png" : format === "webp" ? "image/webp" : "image/jpeg"
  });
}

function mediaIdFromVideo(url: string): string | null {
  const match = /\/([A-Za-z0-9_-]{6,})\.(mp4|m4s|m3u8|webm|mov|m4a|mp3|ogg|opus|wav|vtt|srt|ttml|dfxp)(?:[?#]|$)/i.exec(url);
  return match?.[1] ?? null;
}

function extensionForVideo(mime: string, url: string): string {
  if (/mp4/i.test(mime) || /\.mp4(?:[?#]|$)/i.test(url)) return "mp4";
  if (/webm/i.test(mime) || /\.webm(?:[?#]|$)/i.test(url)) return "webm";
  if (/m3u8/i.test(mime) || /\.m3u8(?:[?#]|$)/i.test(url)) return "m3u8";
  if (/mov/i.test(mime) || /\.mov(?:[?#]|$)/i.test(url)) return "mov";
  return "mp4";
}

function extensionForAudio(mime: string, url: string): string {
  if (/mpeg|mp3/i.test(mime) || /\.mp3(?:[?#]|$)/i.test(url)) return "mp3";
  if (/ogg|opus/i.test(mime) || /\.(?:ogg|opus)(?:[?#]|$)/i.test(url)) return "ogg";
  if (/wav/i.test(mime) || /\.wav(?:[?#]|$)/i.test(url)) return "wav";
  return "m4a";
}

function extensionForSubtitle(mime: string, url: string): string {
  if (/srt/i.test(mime) || /\.srt(?:[?#]|$)/i.test(url)) return "srt";
  if (/ttml|dfxp/i.test(mime) || /\.(?:ttml|dfxp)(?:[?#]|$)/i.test(url)) return "ttml";
  return "vtt";
}

function unknownQualityReceipt(): DownloadQualityReceipt {
  return normalizeDownloadQuality(undefined);
}
