import type { StorageGateway } from "../../platform/storage.ts";
import { mutateStored, replaceStored } from "../../platform/storage-lock.ts";
import {
  hexadecimalHammingDistance,
  mediaIdentityHash,
  PERCEPTUAL_MATCH_DISTANCE,
  sha256Hex,
  type MediaFingerprint,
  type MediaFingerprintKind
} from "../export/assets.ts";
import {
  isDownloadQualityReceipt,
  normalizeDownloadQuality,
  unknownDownloadQuality,
  type DownloadQualityReceipt
} from "../../extension/download-state.ts";

export const MEDIA_HISTORY_KEY = "aviary.media.history.v1";
export const MEDIA_HISTORY_LIMIT = 1500;
export const MEDIA_HISTORY_RESERVATION_TTL_MS = 10 * 60 * 1000;
const MEDIA_HISTORY_RESERVATION_LIMIT = 128;
export const MEDIA_HISTORY_SCHEMA_VERSION = 5;

export interface MediaHistoryEntry {
  identityHash: string;
  exactHash?: string;
  perceptualHash?: string;
  /** Quality evidence only. Source URLs are deliberately never retained here. */
  quality: DownloadQualityReceipt;
  at: string;
}

export interface MediaHistoryReservation extends MediaFingerprint {
  token: string;
  at: string;
  expiresAt: number;
}

export type MediaMatchKind = "identity" | "exact" | "perceptual";

export interface MediaHistoryMatchSummary {
  identity: number;
  exact: number;
  perceptual: number;
}

export interface MediaHistoryLastMatch {
  kind: MediaMatchKind;
  at: string;
}

export interface MediaHistorySnapshot {
  schemaVersion: typeof MEDIA_HISTORY_SCHEMA_VERSION;
  entries: MediaHistoryEntry[];
  reservations: MediaHistoryReservation[];
  matches: MediaHistoryMatchSummary;
  lastMatch: MediaHistoryLastMatch | null;
}

export interface MediaHistoryReservationResult {
  match: MediaMatchKind | null;
  token: string | null;
}

export interface MediaHistoryExportOptions {
  from?: string | null;
  to?: string | null;
}

export interface MediaHistoryExportArtifact {
  filename: string;
  contentType: string;
  data: Uint8Array;
}

export type MediaQualityReceipt = DownloadQualityReceipt;

/** Builds bounded JSON and CSV history files without retaining or exporting source media URLs. */
export function buildMediaHistoryExportArtifacts(
  snapshot: Pick<MediaHistorySnapshot, "entries" | "matches" | "lastMatch">,
  options: MediaHistoryExportOptions = {}
): MediaHistoryExportArtifact[] {
  const range = normalizeHistoryRange(options);
  const entries = snapshot.entries
    .filter((entry) => {
      const at = Date.parse(entry.at);
      return Number.isFinite(at) && at >= range.fromMs && at <= range.toMs;
    })
    .sort((left, right) => left.at.localeCompare(right.at));
  const rangeLabel = `${range.fromLabel ?? "all"}-to-${range.toLabel ?? "all"}`;
  const payload = {
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    range: { from: range.fromLabel, to: range.toLabel },
    count: entries.length,
    matches: { ...snapshot.matches },
    lastMatch: snapshot.lastMatch ? { ...snapshot.lastMatch } : null,
    entries: entries.map((entry) => ({
      ...entry,
      quality: entry.quality ?? unknownDownloadQuality()
    }))
  };
  const csv = [
    "identity_hash,exact_hash,perceptual_hash,quality,width,height,bitrate,mime,codec,codec_source,playback_proven,downloaded_at",
    ...entries.map((entry) => {
      const quality = entry.quality ?? unknownDownloadQuality();
      return [
        entry.identityHash,
        entry.exactHash ?? "",
        entry.perceptualHash ?? "",
        quality.label,
        quality.width === null ? "" : String(quality.width),
        quality.height === null ? "" : String(quality.height),
        quality.bitrate === null ? "" : String(quality.bitrate),
        quality.mime ?? "",
        quality.codec ?? "",
        quality.codecSource ?? "",
        quality.playbackProven ? "yes" : "no",
        entry.at
      ].map(csvCell).join(",");
    })
  ].join("\n") + "\n";
  return [
    {
      filename: `aviary-media-history-${rangeLabel}.json`,
      contentType: "application/json",
      data: new TextEncoder().encode(`${JSON.stringify(payload, null, 2)}\n`)
    },
    {
      filename: `aviary-media-history-${rangeLabel}.csv`,
      contentType: "text/csv",
      data: new TextEncoder().encode(csv)
    }
  ];
}

/**
 * Called when a write to the storage backend fails. Persistence here is best-effort by design,
 * but swallowing the error entirely turns a full quota into "changes silently stop sticking",
 * which is indistinguishable from a bug. Reporting it lets the caller surface the state.
 */
export type PersistErrorSink = (error: unknown) => void;

export class MediaHistory {
  readonly #storage: StorageGateway;
  readonly #limit: number;
  readonly #onPersistError: PersistErrorSink | undefined;
  #entries: MediaHistoryEntry[] = [];
  #reservations: MediaHistoryReservation[] = [];
  #matches: MediaHistoryMatchSummary = emptyMatches();
  #lastMatch: MediaHistoryLastMatch | null = null;
  #loaded = false;
  #loading: Promise<void> | undefined;

  constructor(
    storage: StorageGateway,
    limit = MEDIA_HISTORY_LIMIT,
    onPersistError?: PersistErrorSink
  ) {
    this.#storage = storage;
    this.#limit = Math.max(50, limit);
    this.#onPersistError = onPersistError;
  }

  async load(): Promise<void> {
    if (this.#loaded) {
      return;
    }
    if (!this.#loading) {
      this.#loading = this.#hydrate();
    }
    await this.#loading;
  }

  has(key: string): boolean {
    return this.findMatch({ identityHash: legacyIdentityHash(key) }, false) !== null;
  }

  findMatch(fingerprint: MediaFingerprint, allowPerceptual = false): MediaMatchKind | null {
    const candidate = normalizeFingerprint(fingerprint);
    return findFingerprintMatch(
      this.#entries,
      activeReservations(this.#reservations),
      candidate,
      allowPerceptual
    );
  }

  /** Completed history only. In-flight claims must not paint a media item as already saved. */
  wasDownloaded(fingerprint: MediaFingerprint, allowPerceptual = false): boolean {
    const candidate = normalizeFingerprint(fingerprint);
    return findFingerprintMatch(this.#entries, [], candidate, allowPerceptual) !== null;
  }

  async record(
    fingerprintOrLegacyKey: MediaFingerprint | string,
    quality?: MediaQualityReceipt
  ): Promise<boolean> {
    await this.load();
    const fingerprint =
      typeof fingerprintOrLegacyKey === "string"
        ? { identityHash: legacyIdentityHash(fingerprintOrLegacyKey) }
        : normalizeFingerprint(fingerprintOrLegacyKey);
    const entry: MediaHistoryEntry = {
      ...fingerprint,
      quality: normalizeDownloadQuality(quality),
      at: new Date().toISOString()
    };
    return (await this.#persist({ added: [entry] })) > 0;
  }

  /** Returns the bounded quality receipt for a previously downloaded identity. */
  findQuality(
    fingerprint: MediaFingerprint,
    allowPerceptual = false
  ): MediaQualityReceipt | null {
    const candidate = normalizeFingerprint(fingerprint);
    const entry = findEntry(this.#entries, candidate, allowPerceptual);
    return entry ? { ...entry.quality } : null;
  }

  /** Atomically claims a fingerprint so two tabs cannot start the same transfer. */
  async reserve(
    fingerprint: MediaFingerprint,
    allowPerceptual = false
  ): Promise<MediaHistoryReservationResult> {
    await this.load();
    const candidate = normalizeFingerprint(fingerprint);
    const now = Date.now();
    const reservation: MediaHistoryReservation = {
      ...candidate,
      token: reservationToken(candidate, now),
      at: new Date(now).toISOString(),
      expiresAt: now + MEDIA_HISTORY_RESERVATION_TTL_MS
    };
    let result: MediaHistoryReservationResult = { match: null, token: reservation.token };
    try {
      const merged = await mutateStored<MediaHistorySnapshot | LegacyMediaHistorySnapshot>(
        this.#storage,
        MEDIA_HISTORY_KEY,
        emptySnapshot(),
        (stored) => {
          const entries = readEntries(stored);
          const reservations = readReservations(stored, now);
          const match = findFingerprintMatch(entries, reservations, candidate, allowPerceptual);
          if (match) {
            result = { match, token: null };
          } else {
            reservations.push(reservation);
          }
          return snapshotFrom(stored, entries, reservations, this.#limit);
        }
      );
      this.#adopt(merged);
      return result;
    } catch (error) {
      this.#onPersistError?.(error);
      const match = this.findMatch(candidate, allowPerceptual);
      if (match) return { match, token: null };
      this.#reservations.push(reservation);
      this.#reservations = activeReservations(this.#reservations).slice(-MEDIA_HISTORY_RESERVATION_LIMIT);
      return result;
    }
  }

  /** Turns a successful in-flight claim into durable completed history. */
  async commit(
    token: string,
    fingerprint: MediaFingerprint,
    quality?: MediaQualityReceipt
  ): Promise<boolean> {
    await this.load();
    if (!validToken(token)) return false;
    const candidate = normalizeFingerprint(fingerprint);
    const entry: MediaHistoryEntry = {
      ...candidate,
      quality: normalizeDownloadQuality(quality),
      at: new Date().toISOString()
    };
    let added = false;
    try {
      const merged = await mutateStored<MediaHistorySnapshot | LegacyMediaHistorySnapshot>(
        this.#storage,
        MEDIA_HISTORY_KEY,
        emptySnapshot(),
        (stored) => {
          const entries = readEntries(stored);
          const reservations = readReservations(stored).filter((item) => item.token !== token);
          const existing = findEntry(entries, candidate, false);
          if (existing) {
            const before = JSON.stringify(existing.quality);
            mergeEntry(entries, entry);
            added = JSON.stringify(existing.quality) !== before;
          } else {
            mergeEntry(entries, entry);
            added = true;
          }
          return snapshotFrom(stored, entries, reservations, this.#limit);
        }
      );
      this.#adopt(merged);
      return added;
    } catch (error) {
      this.#onPersistError?.(error);
      this.#reservations = this.#reservations.filter((item) => item.token !== token);
      const existing = findEntry(this.#entries, candidate, false);
      if (existing) {
        const before = JSON.stringify(existing.quality);
        mergeEntry(this.#entries, entry);
        return JSON.stringify(existing.quality) !== before;
      }
      mergeEntry(this.#entries, entry);
      return true;
    }
  }

  /** Releases a failed transfer claim so a retry can start immediately. */
  async release(token: string): Promise<void> {
    await this.load();
    if (!validToken(token)) return;
    try {
      const merged = await mutateStored<MediaHistorySnapshot | LegacyMediaHistorySnapshot>(
        this.#storage,
        MEDIA_HISTORY_KEY,
        emptySnapshot(),
        (stored) => snapshotFrom(
          stored,
          readEntries(stored),
          readReservations(stored).filter((item) => item.token !== token),
          this.#limit
        )
      );
      this.#adopt(merged);
    } catch (error) {
      this.#onPersistError?.(error);
      this.#reservations = this.#reservations.filter((item) => item.token !== token);
    }
  }

  async noteMatch(kind: MediaMatchKind): Promise<void> {
    await this.load();
    const match = { kind, at: new Date().toISOString() } satisfies MediaHistoryLastMatch;
    await this.#persist({ matched: match });
  }

  async clear(): Promise<void> {
    this.#entries = [];
    this.#reservations = [];
    this.#matches = emptyMatches();
    this.#lastMatch = null;
    this.#loaded = true;
    // "Clear download history" means clear it, including whatever a second tab recorded.
    try {
      await replaceStored<MediaHistorySnapshot>(this.#storage, MEDIA_HISTORY_KEY, emptySnapshot());
    } catch (error) {
      this.#onPersistError?.(error);
    }
  }

  size(): number {
    return this.#entries.length;
  }

  snapshot(): MediaHistorySnapshot {
    return {
      schemaVersion: MEDIA_HISTORY_SCHEMA_VERSION,
      entries: this.#entries.map((entry) => ({ ...entry })),
      reservations: activeReservations(this.#reservations).map((entry) => ({ ...entry })),
      matches: { ...this.#matches },
      lastMatch: this.#lastMatch ? { ...this.#lastMatch } : null
    };
  }

  async #hydrate(): Promise<void> {
    const stored = await this.#storage.get<MediaHistorySnapshot | LegacyMediaHistorySnapshot>(
      MEDIA_HISTORY_KEY,
      emptySnapshot()
    );
    this.#entries = readEntries(stored).slice(-this.#limit);
    this.#reservations = readReservations(stored);
    this.#matches = readMatches(stored);
    this.#lastMatch = readLastMatch(stored);
    this.#loaded = true;
    if (!isCurrentSnapshot(stored)) {
      await this.#persist({});
    }
  }

  /**
   * Folds this tab's entries into what is stored, under a cross-tab lock.
   *
   * Overwriting cost real work: two tabs saving media each wrote their own list, so the loser's
   * dedup keys disappeared and the same files were offered again as new. `added` is what this call
   * recorded -- never the whole local list -- then the same cap the in-memory list applies.
   */
  async #persist(delta: {
    added?: MediaHistoryEntry[];
    matched?: MediaHistoryLastMatch;
  }): Promise<number> {
    let added = 0;
    try {
      const merged = await mutateStored<MediaHistorySnapshot | LegacyMediaHistorySnapshot>(
        this.#storage,
        MEDIA_HISTORY_KEY,
        emptySnapshot(),
        (stored) => {
          const entries = readEntries(stored);
          const reservations = readReservations(stored);
          // Only this call's entry. Folding the whole local list in would undo a
          // "Clear download history" performed in another tab.
          for (const entry of delta.added ?? []) {
            const existing = findEntry(entries, entry, false);
            if (existing) {
              const before = JSON.stringify(existing.quality);
              mergeEntry(entries, entry);
              if (JSON.stringify(existing.quality) !== before) added += 1;
              continue;
            }
            mergeEntry(entries, entry);
            added += 1;
          }
          const ordered = entries.sort((left, right) =>
            left.at < right.at ? -1 : left.at > right.at ? 1 : 0
          );
          const matches = readMatches(stored);
          if (delta.matched) {
            matches[delta.matched.kind] += 1;
          }
          const storedLastMatch = readLastMatch(stored);
          const lastMatch =
            delta.matched && (!storedLastMatch || storedLastMatch.at <= delta.matched.at)
              ? delta.matched
              : storedLastMatch;
          return {
            schemaVersion: MEDIA_HISTORY_SCHEMA_VERSION,
            entries: ordered.slice(-this.#limit),
            reservations: reservations.slice(-MEDIA_HISTORY_RESERVATION_LIMIT),
            matches,
            lastMatch
          };
        }
      );
      this.#adopt(merged);
    } catch (error) {
      // Best-effort, but not silent: a full backend must be visible somewhere.
      this.#onPersistError?.(error);
    }
    return added;
  }

  #adopt(snapshot: MediaHistorySnapshot | LegacyMediaHistorySnapshot): void {
    this.#entries = readEntries(snapshot).slice(-this.#limit);
    this.#reservations = readReservations(snapshot);
    this.#matches = readMatches(snapshot);
    this.#lastMatch = readLastMatch(snapshot);
  }
}

/** The stored shape is user-writable through a backup import, so every read validates it. */
function readEntries(
  stored: MediaHistorySnapshot | LegacyMediaHistorySnapshot | undefined
): MediaHistoryEntry[] {
  const entries = Array.isArray(stored?.entries) ? stored.entries : [];
  const normalized: MediaHistoryEntry[] = [];
  for (const candidate of entries) {
    if (!candidate || typeof candidate !== "object" || typeof candidate.at !== "string") continue;
    if ("identityHash" in candidate && validHash(candidate.identityHash)) {
      const exactHash = validHash(candidate.exactHash) ? candidate.exactHash.toLowerCase() : undefined;
      const perceptualHash = validHash(candidate.perceptualHash)
        ? candidate.perceptualHash.toLowerCase()
        : undefined;
      mergeEntry(normalized, {
        identityHash: candidate.identityHash.toLowerCase(),
        ...(exactHash ? { exactHash } : {}),
        ...(perceptualHash ? { perceptualHash } : {}),
        quality: normalizeDownloadQuality("quality" in candidate ? candidate.quality : undefined),
        at: candidate.at
      });
      continue;
    }
    if ("key" in candidate && typeof candidate.key === "string") {
      mergeEntry(normalized, {
        identityHash: legacyIdentityHash(candidate.key),
        quality: normalizeDownloadQuality(undefined),
        at: candidate.at
      });
    }
  }
  return normalized;
}

interface LegacyMediaHistoryEntry {
  key: string;
  at: string;
}

interface LegacyMediaHistorySnapshot {
  entries: Array<MediaHistoryEntry | LegacyMediaHistoryEntry>;
  reservations?: unknown;
  matches?: Partial<MediaHistoryMatchSummary>;
  lastMatch?: MediaHistoryLastMatch | null;
  schemaVersion?: number;
}

function emptySnapshot(): MediaHistorySnapshot {
  return {
    schemaVersion: MEDIA_HISTORY_SCHEMA_VERSION,
    entries: [],
    reservations: [],
    matches: emptyMatches(),
    lastMatch: null
  };
}

function normalizeHistoryRange(options: MediaHistoryExportOptions): {
  fromMs: number;
  toMs: number;
  fromLabel: string | null;
  toLabel: string | null;
} {
  const from = normalizeDateInput(options.from, false);
  const to = normalizeDateInput(options.to, true);
  if (from && to && from.ms > to.ms) {
    throw new RangeError("The history start date must be on or before the end date.");
  }
  return {
    fromMs: from?.ms ?? Number.NEGATIVE_INFINITY,
    toMs: to?.ms ?? Number.POSITIVE_INFINITY,
    fromLabel: from?.label ?? null,
    toLabel: to?.label ?? null
  };
}

function normalizeDateInput(value: string | null | undefined, endOfDay: boolean): { ms: number; label: string } | null {
  if (value === null || value === undefined || value.trim() === "") return null;
  const trimmed = value.trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
  if (!match) throw new RangeError("History dates must use YYYY-MM-DD.");
  const date = new Date(`${trimmed}T${endOfDay ? "23:59:59.999" : "00:00:00.000"}Z`);
  if (!Number.isFinite(date.getTime())) throw new RangeError("History date is invalid.");
  if (
    date.getUTCFullYear() !== Number(match[1]) ||
    date.getUTCMonth() + 1 !== Number(match[2]) ||
    date.getUTCDate() !== Number(match[3])
  ) {
    throw new RangeError("History date is invalid.");
  }
  return { ms: date.getTime(), label: trimmed.replaceAll("-", "") };
}

function csvCell(value: string): string {
  const safe = value.replaceAll("\"", "\"\"");
  return /[",\n\r]/.test(safe) ? `"${safe}"` : safe;
}

function readReservations(
  stored: MediaHistorySnapshot | LegacyMediaHistorySnapshot | undefined,
  now = Date.now()
): MediaHistoryReservation[] {
  const candidates = Array.isArray(stored?.reservations) ? stored.reservations : [];
  const reservations: MediaHistoryReservation[] = [];
  for (const candidate of candidates) {
    if (!candidate || typeof candidate !== "object") continue;
    const value = candidate as Partial<MediaHistoryReservation>;
    if (
      !validToken(value.token) ||
      !validHash(value.identityHash) ||
      typeof value.at !== "string" ||
      typeof value.expiresAt !== "number" ||
      !Number.isFinite(value.expiresAt) ||
      value.expiresAt <= now
    ) {
      continue;
    }
    reservations.push({
      token: value.token,
      identityHash: value.identityHash.toLowerCase(),
      ...(validHash(value.exactHash) ? { exactHash: value.exactHash.toLowerCase() } : {}),
      ...(validHash(value.perceptualHash)
        ? { perceptualHash: value.perceptualHash.toLowerCase() }
        : {}),
      at: value.at,
      expiresAt: Math.trunc(value.expiresAt)
    });
  }
  return reservations.slice(-MEDIA_HISTORY_RESERVATION_LIMIT);
}

function activeReservations(
  reservations: readonly MediaHistoryReservation[],
  now = Date.now()
): MediaHistoryReservation[] {
  return reservations.filter((entry) => entry.expiresAt > now);
}

function snapshotFrom(
  stored: MediaHistorySnapshot | LegacyMediaHistorySnapshot,
  entries: MediaHistoryEntry[],
  reservations: MediaHistoryReservation[],
  limit: number
): MediaHistorySnapshot {
  return {
    schemaVersion: MEDIA_HISTORY_SCHEMA_VERSION,
    entries: entries
      .sort((left, right) => left.at < right.at ? -1 : left.at > right.at ? 1 : 0)
      .slice(-limit),
    reservations: activeReservations(reservations).slice(-MEDIA_HISTORY_RESERVATION_LIMIT),
    matches: readMatches(stored),
    lastMatch: readLastMatch(stored)
  };
}

function emptyMatches(): MediaHistoryMatchSummary {
  return { identity: 0, exact: 0, perceptual: 0 };
}

function readMatches(
  stored: MediaHistorySnapshot | LegacyMediaHistorySnapshot | undefined
): MediaHistoryMatchSummary {
  const candidate = stored?.matches;
  return {
    identity: validCount(candidate?.identity),
    exact: validCount(candidate?.exact),
    perceptual: validCount(candidate?.perceptual)
  };
}

function readLastMatch(
  stored: MediaHistorySnapshot | LegacyMediaHistorySnapshot | undefined
): MediaHistoryLastMatch | null {
  const candidate = stored?.lastMatch;
  return candidate && isMatchKind(candidate.kind) && typeof candidate.at === "string"
    ? { kind: candidate.kind, at: candidate.at }
    : null;
}

function mergeEntry(entries: MediaHistoryEntry[], incoming: MediaHistoryEntry): void {
  const existing = entries.find((entry) =>
    entry.identityHash === incoming.identityHash ||
    Boolean(entry.exactHash && incoming.exactHash && entry.exactHash === incoming.exactHash)
  );
  if (!existing) {
    entries.push({ ...incoming });
    return;
  }
  if (!existing.exactHash && incoming.exactHash) existing.exactHash = incoming.exactHash;
  if (!existing.perceptualHash && incoming.perceptualHash) {
    existing.perceptualHash = incoming.perceptualHash;
  }
  existing.quality = mergeQuality(existing.quality, incoming.quality);
  if (existing.at < incoming.at) existing.at = incoming.at;
}

function normalizeFingerprint(fingerprint: MediaFingerprint): MediaFingerprint {
  const identityHash = validHash(fingerprint.identityHash)
    ? fingerprint.identityHash.toLowerCase()
    : sha256Hex(new TextEncoder().encode(String(fingerprint.identityHash)));
  const exactHash = validHash(fingerprint.exactHash) ? fingerprint.exactHash.toLowerCase() : undefined;
  const perceptualHash = validHash(fingerprint.perceptualHash)
    ? fingerprint.perceptualHash.toLowerCase()
    : undefined;
  return {
    identityHash,
    ...(exactHash ? { exactHash } : {}),
    ...(perceptualHash ? { perceptualHash } : {})
  };
}

function legacyIdentityHash(key: string): string {
  const parts = key.split(":");
  const kind = parts.at(-1);
  const index = parts.at(-2);
  if (isMediaKind(kind) && /^\d+$/.test(index ?? "") && parts.length >= 4) {
    const source = parts.slice(1, -2).join(":");
    return mediaIdentityHash(kind, source, /^https?:\/\//i.test(source) ? null : source);
  }
  return sha256Hex(new TextEncoder().encode(`aviary-media-legacy:${key}`));
}

function isCurrentSnapshot(stored: MediaHistorySnapshot | LegacyMediaHistorySnapshot): boolean {
  const now = Date.now();
  return stored.schemaVersion === MEDIA_HISTORY_SCHEMA_VERSION &&
    Array.isArray(stored.entries) &&
    Array.isArray(stored.reservations) &&
    stored.entries.every((entry) =>
      typeof entry === "object" && entry !== null &&
      "identityHash" in entry && validHash(entry.identityHash) && !("key" in entry)
      && "quality" in entry && isDownloadQualityReceipt(entry.quality)
    ) &&
    stored.reservations.every((entry) => isActiveStoredReservation(entry, now));
}

function findEntry(
  entries: readonly MediaHistoryEntry[],
  fingerprint: MediaFingerprint,
  allowPerceptual: boolean
): MediaHistoryEntry | null {
  const exact = fingerprint.exactHash && entries.find((entry) => entry.exactHash === fingerprint.exactHash);
  if (exact) return exact;
  const identity = entries.find((entry) => entry.identityHash === fingerprint.identityHash);
  if (identity) return identity;
  if (allowPerceptual && fingerprint.perceptualHash) {
    return entries.find((entry) =>
      entry.perceptualHash &&
      hexadecimalHammingDistance(entry.perceptualHash, fingerprint.perceptualHash!) <=
        PERCEPTUAL_MATCH_DISTANCE
    ) ?? null;
  }
  return null;
}

/**
 * How much of a claim each label makes about the file on disk.
 *
 * `adaptive-remux` sits above a direct rendition because it carries the streams the adaptive
 * manifest offered, and below `original` because it is not the file X served -- it is a container
 * this machine wrote. Nothing here re-encodes, so the ordering is about provenance, not loss.
 */
function qualityRank(value: DownloadQualityReceipt): number {
  return value.label === "original" ? 5 : value.label === "adaptive-remux" ? 4 :
    value.label === "best-direct" ? 3 : value.label === "fallback" ? 2 : 1;
}

function mergeQuality(
  existing: DownloadQualityReceipt,
  incoming: DownloadQualityReceipt
): DownloadQualityReceipt {
  const existingRank = qualityRank(existing);
  const incomingRank = qualityRank(incoming);
  if (incomingRank > existingRank) return { ...incoming };
  if (incomingRank < existingRank) return { ...existing };
  return {
    ...existing,
    width: incoming.width ?? existing.width,
    height: incoming.height ?? existing.height,
    bitrate: incoming.bitrate ?? existing.bitrate,
    mime: incoming.mime ?? existing.mime,
    // Codec evidence only ever arrives with its source, so the pair moves together or not at all.
    ...(incoming.codec !== null
      ? { codec: incoming.codec, codecSource: incoming.codecSource }
      : {}),
    // Playback is one-way: a later observation that did not play does not unprove an earlier one.
    playbackProven: existing.playbackProven || incoming.playbackProven
  };
}

function isActiveStoredReservation(value: unknown, now: number): boolean {
  if (!value || typeof value !== "object") return false;
  const entry = value as Partial<MediaHistoryReservation>;
  return validToken(entry.token) &&
    validHash(entry.identityHash) &&
    (entry.exactHash === undefined || validHash(entry.exactHash)) &&
    (entry.perceptualHash === undefined || validHash(entry.perceptualHash)) &&
    typeof entry.at === "string" &&
    typeof entry.expiresAt === "number" &&
    Number.isFinite(entry.expiresAt) &&
    entry.expiresAt > now;
}

function findFingerprintMatch(
  entries: readonly MediaFingerprint[],
  reservations: readonly MediaFingerprint[],
  fingerprint: MediaFingerprint,
  allowPerceptual: boolean
): MediaMatchKind | null {
  const candidates = [...entries, ...reservations];
  if (fingerprint.exactHash && candidates.some((entry) => entry.exactHash === fingerprint.exactHash)) {
    return "exact";
  }
  if (candidates.some((entry) => entry.identityHash === fingerprint.identityHash)) {
    return "identity";
  }
  if (allowPerceptual && fingerprint.perceptualHash) {
    for (const entry of candidates) {
      if (
        entry.perceptualHash &&
        hexadecimalHammingDistance(entry.perceptualHash, fingerprint.perceptualHash) <=
          PERCEPTUAL_MATCH_DISTANCE
      ) {
        return "perceptual";
      }
    }
  }
  return null;
}

let reservationSequence = 0;

function reservationToken(fingerprint: MediaFingerprint, now: number): string {
  reservationSequence += 1;
  return sha256Hex(new TextEncoder().encode(
    `${fingerprint.exactHash ?? fingerprint.identityHash}:${now}:${reservationSequence}:${Math.random()}`
  ));
}

function validToken(value: unknown): value is string {
  return typeof value === "string" && /^[0-9a-f]{64}$/i.test(value);
}

function validHash(value: unknown): value is string {
  return typeof value === "string" && /^[0-9a-f]{64}$/i.test(value);
}

function validCount(value: unknown): number {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 ? Math.trunc(value) : 0;
}

function isMatchKind(value: unknown): value is MediaMatchKind {
  return value === "identity" || value === "exact" || value === "perceptual";
}

function isMediaKind(value: unknown): value is MediaFingerprintKind {
  return value === "photo" || value === "video" || value === "thumbnail" || value === "audio" || value === "subtitle";
}
