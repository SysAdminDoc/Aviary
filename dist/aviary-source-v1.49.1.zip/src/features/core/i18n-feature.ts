import { localeDirection } from "../../platform/i18n.ts";
import type { FeatureContext, FeatureModule } from "../registry.ts";

const STYLE_ID = "av-i18n";

export const i18nFeature: FeatureModule = {
  id: "core.i18n",
  title: "Internationalization",
  category: "core",

  init(ctx) {
    ensureI18nStyle();
    applyLocaleClasses(ctx);
    ctx.diagnostics.info("i18n initialized", { locale: ctx.settings.i18n.locale });
  },

  apply(ctx) {
    ensureI18nStyle();
    applyLocaleClasses(ctx);
  },

  destroy(ctx) {
    document.getElementById(STYLE_ID)?.remove();
    const root = document.documentElement;
    root.classList.remove("av-rtl", "av-ltr");
    delete root.dataset.avLocale;
    document.getElementById("av-control-center")?.removeAttribute("dir");
    ctx.diagnostics.info("i18n destroyed");
  }
};

function applyLocaleClasses(ctx: FeatureContext): void {
  const root = document.documentElement;
  const direction = localeDirection(ctx.settings.i18n.locale);
  root.dataset.avLocale = ctx.settings.i18n.locale;
  root.classList.toggle("av-rtl", direction === "rtl");
  root.classList.toggle("av-ltr", direction === "ltr");
  document.getElementById("av-control-center")?.setAttribute("dir", direction);
}

function ensureI18nStyle(): void {
  if (document.getElementById(STYLE_ID)) {
    return;
  }
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = I18N_CSS;
  (document.head ?? document.documentElement).append(style);
}

const I18N_CSS = `
html.av-rtl [data-testid="tweetText"] {
  text-align: start;
  unicode-bidi: plaintext;
}

html.av-rtl [data-testid="primaryColumn"] {
  direction: rtl;
}

html.av-ltr [data-testid="tweetText"][lang^="ar"],
html.av-ltr [data-testid="tweetText"][lang^="he"] {
  direction: rtl;
  text-align: start;
  unicode-bidi: plaintext;
}

@media (pointer: coarse) {
  html.av-touch [data-testid="reply"],
  html.av-touch [data-testid="retweet"],
  html.av-touch [data-testid="like"],
  html.av-touch [data-testid="bookmark"] {
    min-height: 44px;
    min-width: 44px;
  }
}
`;
