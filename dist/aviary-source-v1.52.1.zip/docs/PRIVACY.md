# Aviary Privacy Manifest

Updated: 2026-09-21, release 1.52.1.

## Defaults and network boundaries

Aviary is local-first. The default build sends no telemetry, loads no remote code, exports no
cookies or authentication headers, and makes no provider request. Default-on ad protection answers
X's exact `/i/api/1.1/promoted_content/log.json` event locally when the userscript manager exposes
the page world, and blocks it with
a host-scoped session request rule for the enabled X tab in the extension before a network connection; it does
not block HomeTimeline, media, login, or unrelated analytics traffic. Native sponsored records are
delivered inside the same first-party timeline response as ordinary posts, so Aviary suppresses
their rendering but cannot truthfully claim those bytes were absent. Optional page-world capture
only observes bounded first-party GraphQL responses across X's `fetch` and `XMLHttpRequest`
transports after you enable the relevant capture setting.

Violentmonkey's content mode doesn't expose that page-world observer. Structural ad removal still
runs, but promoted logging refusal, broader analytics refusal and direct video-variant discovery
are unavailable in that mode. The extension uses its declared MAIN-world script instead. Trust
reports the manager limitation; it must not be read as a claim that those requests were blocked.

Passive capture does not start a timeline, profile, search, or GraphQL request. It watches a request
X already made, keeps bounded response metadata, and never reads request cookies or authorization
headers. Clicking X's own controls can still make X request data, because that is ordinary site
behavior. Aviary cannot promise that an account is risk-free or that any use complies with X's
rules; it only limits the requests Aviary itself starts.

These are the only Aviary-triggered network paths:

| Feature | When it leaves the browser | Destination and data |
|---|---|---|
| Media Save / Thumb / captured Library batch | After you click a media button or the Library download action | The selected X image, video, audio, or caption URL, or URLs already stored in local capture records. A browser/userscript downloader handles each file. Optional text or JSON sidecars are built locally after a completed save. |
| Export media-byte capture | Only when **Capture media bytes in export** is enabled and you click export | The selected X media URLs; successful response bytes, length, and checksum are placed in that local package, while failures remain local retryable metadata. |
| Aria2 handoff | When enabled, configured, and the media meets the threshold | Your configured JSON-RPC endpoint; the media URL, filename, and optional RPC secret are sent. |
| Local yt-dlp handoff | Only after you enable it and click **Send to yt-dlp** for an observed adaptive manifest | Your configured loopback helper; only the observed `video.twimg.com` manifest URL, filename, and fixed format policy are sent. X post URLs, cookies, and bearer tokens are excluded. |
| Bluesky / Mastodon | After you click the corresponding crosspost action | Your configured service; composer text, thread metadata, and optionally the last downloaded media when attachment is enabled. |
| AI provider | When AI runs is enabled, you review the disclosure, and you send a provider-backed command | Your configured endpoint; the prompt built from the selected post and configured system text. The review shows fields, character/token estimate, retention notice, network status, and byte budget. |
| Semantic search | When you rebuild the index, explicitly add semantic ranking to a query, or enable auto-embedding | Your configured embeddings endpoint; the model and record text sent for each embedding request. The Control Center shows the destination, fields, retention notice, and byte budget before auto-indexing. |
| Bookmark mirror | Never; it reads only GraphQL responses already delivered to the page when **Preserve raw payloads** is enabled | No new destination. Matching bookmark timeline payloads are parsed locally and the tweet text, handle, permalink, operation name, and timestamp are stored in `aviary.library.bookmarks.v1`. |
| Captured thread reader | Never; it reads only records already stored in the local export checkpoints | No destination. Root, parent, author, and creation metadata are parsed from captured GraphQL bodies, and missing parents remain local gaps. |
| Analytics refusal | When beacon blocking is enabled | No new destination; matching analytics beacons are intercepted before they leave the page. |

Every integration is disabled by default and requires an explicit setting, endpoint/credential,
and (for actions) a user gesture. Local prompt building works without an AI key. The options page
grant/revoke controls are local extension UI and do not send data.

Library text ranking, including exact-handle and quoted-phrase matching, never makes a request.
Local-only mode returns those text results before the semantic query path can contact a provider.
Downloading media from a Library search contacts only the stored X media URLs selected by that
local query. It does not request a timeline or GraphQL response.

The permissions the extension declares, read from the manifests themselves:

<!-- docs-facts:start -->

<!-- Generated by tools/docs-facts.mjs from the manifests and the panel's own metadata.
     Edit those, then run `npm run docs:facts`. -->

Required permissions: `contextMenus`, `declarativeNetRequestWithHostAccess`, `scripting`, `storage`, `unlimitedStorage`.

Optional permissions: `downloads`, plus optional host access to `https://pbs.twimg.com/*`, `https://video.twimg.com/*`.

Host access: `https://pro.x.com/*`, `https://twitter.com/*`, `https://x.com/*`.

Both browser manifests declare exactly this set. Removing the extension the ordinary way deletes everything it stored, including the library.

<!-- docs-facts:end -->

`declarativeNetRequestWithHostAccess` is bounded by the existing X/Twitter host list and owns only
the exact promoted logger session rules; shipped builds omit diagnostic feedback, broad
`webRequest`, and `<all_urls>` access. `contextMenus` adds the one Download entry to the right-click
menu on X media. `scripting` registers the content script. `unlimitedStorage` asks the browser not
to evict the local library, and is the permission half of that request; whether the browser honours
it is reported in Trust.

The optional grants are requested only from the options page and can be revoked there; the
userscript declares the equivalent `GM_download`/`@connect` surfaces in its metadata.

Aviary handles what it clips locally: the post text, media bytes and observed responses you ask it
to keep. That is different from transmitting anything, which happens only through an integration you
configure and turn on. Both extension manifests set `incognito` to `not_allowed`, so private windows cannot
run the content scripts or write Aviary records. A userscript has no standard private-window
signal; its private-mode persistence follows the manager and is reported as unknown.

## Data stored locally

Library storage measurements count only collections in the active profile. Browser-reported
origin usage is shown separately and can include other profiles and database overhead. Measurement
doesn't transmit records or change them. An unavailable measurement is reported, not shown as zero.

The logical keys below are stored in the active profile unless noted. The extension owns one IndexedDB database,
`aviary.durable.v1`, in its background origin. Content scripts and options use a typed extension
message API and cannot open that active database from X. On upgrade, the content script reads only
the old X-origin database, sends each value with a SHA-256 receipt, checks the background readback,
then deletes the old database. A failed or interrupted copy leaves the source intact for retry.
If an old tab blocks deletion, Aviary seals that database, continues booting, and recopies any late
writes before a later deletion. The userscript uses `GM_getValue`, `GM_setValue`, `GM_deleteValue`,
and `GM_listValues` only, never X storage, and refuses a measured value above 16 MiB explicitly.
Profile-scoped copies may be prefixed with
`aviary.profile.<profileId>.`; Trust reports the active backend, schema, migration, usage, quota,
and whether the browser has agreed to keep the library. When you explicitly adopt data from an
older unprofiled install, Aviary stores only per-key SHA-256 receipts in the unscoped migration
journal. Receipts contain the source hash, destination profile, phase, and bounded error text, not
the copied values. Adoption serializes source claims across profiles and rechecks both values while
the per-key lock is held; a concurrent change remains available as a reported conflict.

Browser storage is best effort unless something asks otherwise, which means a browser short on disk
space can clear a local library without warning. The extension declares `unlimitedStorage` and asks
once per session for eviction exemption, then reports the answer the browser actually gives rather
than a cached one. For the userscript, durability belongs to the userscript manager: Aviary stores
through `GM_setValue` and can neither request nor measure the manager's own retention, so Trust
reports that state as unknown and the per-value ceiling above is the only limit Aviary enforces
itself. Keep a library backup either way. During an extension storage outage, the latest pending value or removal for each key stays
in one locked `chrome.storage.local` journal. Recovery stages that operation in the background and
commits the value or removal with marker cleanup in one IndexedDB transaction. The journal is
cleared only after every receipt matches, so interruption leaves a retry path instead of stale data.
Lock registers live in extension or manager storage, so x.com, twitter.com, and pro.x.com share one
restore and journal authority. Extension pages ask the background for one known per-lock roster key
instead of enumerating unrelated `chrome.storage.local` values; userscript managers keep the same
bounded roster under one manager key.

| Key | Data | Purpose and user control |
|---|---|---|
| `aviary.profiles.v1` / `aviary.profile.active.v1` | Profile registry and active-profile id | Keep explicit settings/library boundaries. Profiles are created and switched in Trust. |
| `aviary.profile.migration.v1` | Per-store source and destination hashes, destination profile, phase, and bounded error text | Make explicit legacy-profile adoption retry-safe. It is install metadata, never profile data or a backup collection. |
| `aviary.settings.v1` | Preferences, scoped custom CSS rules, portable filter rules, and any integration credentials you enter | Configure Aviary. Custom CSS stays local to the named surface. Plain-text rule exports contain only the rules you wrote. **Export settings** is a settings envelope, not a full-library backup. |
| `aviary.integration.usage.v1` | Profile-scoped AI/embedding request, record, and UTF-8 byte counters for the local 31-day history | Enforce configurable per-request/daily budgets and show usage; **Clear AI and embedding usage** removes counters. No API keys or raw prompts are stored here. |
| `aviary.hiddenPosts.v1` | Hidden status ids or handle/text signatures | Hide posts across visits; **Clear hidden posts** removes them. |
| `aviary.seenPosts.v1` | Post ids and the time each first scrolled past, no text, handle, or URL | Fade a post the second time you pass it; capped at 4,000 entries and 30 days; **Forget seen posts** removes them. |
| `aviary.readingMarkers.v1` | One last-read X post id and local update time per feed surface | Show a local new-post separator, advance it after an upward viewport exit or explicit action, and include it in library backups. No post text or unread badge. |
| `aviary.timeline-position.v1:*` | Current route, scroll offset, save time, and up to six visible post ids, handles, and viewport offsets | Restore the same visible post after browser Back. This opt-in data uses tab session storage, expires after 30 minutes, closes with the tab, and is not included in settings or library backups. |
| `aviary.catchUp.v1` | Bounded copies of rendered post text, account, permalink, media references, filter reason, and basic counts | Power the local Catch-up digest; capped at 4,000 rows and 30 days; **Forget seen posts** removes them. |
| `aviary.adObservations.v1` | Which ad markers were present on a route, as counts, no post content | Notice when X changes its ad markup; bounded to 64 entries and 30 days. |
| `aviary.diagnostics.v1` | Stable authored message id, severity, ISO time, and detail-key names only | Let a failure from an earlier page load still be reportable; bounded to 50 entries and 7 days; clearable from Trust. Legacy message and reason values are removed on migration. |
| `aviary.background.diagnostics.v1` | Bounded background operation code, severity, and ISO time only | Keep worker failures reportable after suspension or restart; bounded to 64 entries and never includes URLs, filenames, provider text, or exception strings. |
| `aviary.firstRun.v1` | A single flag recording that the first-run notice was dismissed | Stop showing the notice again on this profile. |
| `aviary.media.history.v1` | Bounded media dedup records, non-identifying quality receipts, and short-lived hashed in-flight claims | Avoid duplicate downloads across tabs; failed claims expire or are removed, and **Clear download history** removes all of them. A receipt keeps only its quality label, known dimensions, bitrate, MIME, and timestamp. The date-range JSON and CSV export contains hashes and receipts, never source media URLs. |
| `aviary.media.queue.v1` | Queued, paused, failed, opened, and completed media jobs. A job can include X media URLs, fallback URLs, a filename, media kind/id, a browser download id, a bounded quality receipt, and an opted-in sidecar request with bounded post text, account, post id, permalink, and queue time. | Resume/retry media work and create the sidecar only after a confirmed save; completed history is separately clearable. |
| `aviary.waczSigning.v1` | An opt-in local ECDSA-P384-SHA256 identity, including its private key, public key, fingerprint, and creation time | Create an Aviary-only WACZ proof and export the keypair explicitly. It is never included in routine library backups. |
| `aviary.media.last-download.v1` | Metadata for the last successful download | Make an explicitly enabled crosspost-media attachment possible. |
| `aviary.audit.v1` | Capped local action log | Review activity; **Clear audit log** removes it. |
| `aviary.export.checkpoints.v1` | Export jobs, captured records, and checkpoints | Resume capture/export and local search; retention limits can remove old jobs. |
| `aviary.retention.maxJobs`, `aviary.retention.maxRecordsPerJob`, `aviary.retention.maxAgeDays` | Export retention limits | Bound checkpoint storage; zero disables the corresponding limit. |
| `aviary.queryIds.v1` | GraphQL operation ids discovered in loaded X scripts | Keep export parsing resilient as X changes. |
| `aviary.aria2.history.v1` | Queued/completed Aria2 gids and media metadata | Avoid requeueing the same media URL. |
| `aviary.snapshots.v1` | Captured follower/following snapshots | Compare snapshots over time; **Clear all snapshots** removes them. |
| `aviary.library.bookmarks.v1` | Local bookmarks, tags, folders, reminders, notes, captured source and operation metadata | Search/edit the local library; mirrored records contain only posts X sent while you scrolled past them; individual bookmarks or **Clear local bookmarks** remove them. |
| `aviary.library.underTheHood.v1` | Normalized monthly summaries from JSON reports the user downloaded from X, including reporting periods, aggregate label names, counts, and explanations | Read X's own summary locally, compare stored months, include it in library backups, or export the normalized copy. Aviary never adds ranking weights or infers a production score. |
| `aviary.userNotes.v1` | Private account notes | Decorate matching posts; **Clear all account notes** removes them. |
| `aviary.cleanupQueue.v1` | Review candidates from local Library cleanup previews | Review-only queue; **Clear cleanup queue** removes it. This store never triggers an X action. |
| `aviary.accountCleanup.v1` | Signed-in handle, selected categories, pass state, counts, pacing, recovery and fresh-pass state, the current Like rate-window timestamp and count, and bounded status ids or active failure keys while a pass can resume | Resume Account Cleanup across X routes, verify each category from the top, and wait for X's next Like-removal window without losing progress. Post text is never stored. Status ids, failure keys, verification state, and rate-window data are removed when the pass completes or is stopped; **Clear cleanup record** removes the remaining summary. |
| `aviary.semanticIndex.v1` | Embedding vectors and record metadata | Local semantic search; **Clear semantic index** removes it. |
| `aviary.archive.imports.v1` | Official X archive import jobs and checkpoints | Pause/resume/retry imports and preserve progress. |
| `aviary.archive.library.v1` | Imported archive collections, including typed account/media/list data | Keep archive data separate from public-post search. |

The extension background uses `aviary.downloadTracking.v2` as short-lived runtime state. It
contains only the browser download id, requested filename, and remaining X media candidate URLs
for an active media download. The entry is removed when the download completes, when an
interruption advances to the next candidate, or when no candidate remains. A bounded
`aviary.downloadTerminal.v1` receipt keeps only the original report id, terminal state, optional
error, quality receipt, and timestamp for a fallback that finishes under a different browser id. Neither key is
included in profiles or library backups.

Selector health and other transient DOM diagnostics are in memory unless an action is explicitly
written to the audit log. Persisted page diagnostics contain only stable message ids, severity,
ISO time, and detail-key names. The background ring contains only operation codes, severity, and
time. **Copy diagnostics** in the Control Center or Options page merges those redacted records and
never copies URLs, filenames, provider text, exception strings, or credentials. A selector-break
report is narrower still: it contains only build, route surface, missing selector names and feature
ids. The transient Mutation performance ring is never persisted. If you copy diagnostics, it carries
only bounded feature ids, pass types, invocation counts, and durations. It never carries selectors,
route URLs, post text, handles, or DOM values. Imported media
bytes are not retained after a completed archive import; resumable import state may retain the
local source while the job is unfinished.

The optional **Copy links** action writes the selected post's direct media URLs to the system
clipboard only after a click. Aviary does not persist that clipboard payload or send a request to
resolve more links.

Account Cleanup uses the ordinary controls X rendered for the current signed-in session. Starting
a destructive pass therefore causes the same X requests as manually removing a bookmark, undoing
a repost, removing a like or confirming a post deletion. Aviary does not read cookies or copy
request headers to do this. Its local audit entries keep the account handle, selected category
names, pacing, limits and final counts. They do not contain post text, URLs or status ids.

## Data not stored

Aviary does not store X `auth_token` or `ct0` cookies, bearer tokens, raw request headers, or your
X password. When **Preserve raw payloads** is enabled, captured GraphQL bodies are scrubbed for
`ct0`, `auth_token`, `guest_id`, `csrf_token`, and `Bearer …` values before persistence. This does
not make the remaining captured post data anonymous: treat it as account data.

## Credentials and exports

Aria2 secrets, the yt-dlp helper secret, Bluesky app passwords, Mastodon tokens, and AI/embedding keys are stored locally in
the active profile in the form the browser needs. They are sent only to the service you configured
when that integration runs. Use scoped, revocable credentials. **Export settings** replaces these
secrets with placeholders; importing the file keeps credentials already saved on the destination
browser instead of overwriting them.

AI and embedding usage history stores counters only: it does not retain provider URLs, API keys,
prompts, record text, or vectors. A request is reserved in the local ledger before provider work;
if the per-request or daily UTF-8 byte budget is exhausted, no provider request is made. Local-only
mode also blocks every provider call.

Aviary does not encrypt local storage. Use the browser profile's normal protections and full-disk
encryption. Anyone with access to that browser profile may be able to read the stored credentials
and local library.

WARC and WACZ preservation downloads contain the captured post text, original URLs, timestamps,
and any media bytes already present in the selected records. Treat them as account data. Aviary
builds both files locally in a dedicated worker, applies a 256 MiB estimate guard, and does not
upload them. An optional local ECDSA P-384 signing identity signs only the manifest digest; its
private key remains in this profile and is excluded from routine library backups. The replayweb.page
action only opens the viewer; you decide which archive to load there.

## Clearing and uninstalling

Export a full library backup before removing the extension if you want to keep its records.
Ordinary extension removal deletes its extension-owned storage and IndexedDB library. It doesn't
delete files you downloaded. Userscript retention follows the manager, so use its storage controls
to remove saved values. An interrupted migration from an older install may leave legacy X-origin
data; review that separately without clearing unrelated X data. The Control Center clear actions
remain available while installed. Optional `downloads` and media-host permissions can be revoked
from the extension's dedicated Options page.

Display and capture features are reversible: disabling them removes the DOM nodes, styles,
observers, timers and listeners they created. Aviary never auto-likes, auto-follows or posts.
Delete X activity is the exception for deletion. Pressing **Run** starts removing the selected
activity immediately. Deleting posts or replies cannot be undone by Aviary.
