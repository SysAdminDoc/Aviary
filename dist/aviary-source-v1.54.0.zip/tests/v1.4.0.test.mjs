import { importSourceModule } from "./helpers/source-import.mjs";
import { allowOutbound } from "./helpers/network-policy.mjs";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

// Nothing outbound is permitted until a policy is installed, so a spec that drives an integration
// says which posture it is driving under. This file's cases assume Local-only mode is off; the
// ones that assert the refusal install the opposite policy themselves.
await allowOutbound();

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("tellActiveAria2 parses RPC results and removeAria2Download issues aria2.remove", async () => {
  const { tellActiveAria2, removeAria2Download } = await importSourceModule(
    "src/features/integrations/aria2.ts"
  );

  const originalFetch = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, init) => {
    const body = JSON.parse(init.body);
    calls.push(body);
    if (body.method === "aria2.tellActive") {
      return new Response(
        JSON.stringify({
          result: [
            {
              gid: "abc",
              status: "active",
              totalLength: "100",
              completedLength: "40",
              files: [{ path: "/tmp/foo.mp4" }]
            }
          ]
        }),
        { status: 200, headers: { "content-type": "application/json" } }
      );
    }
    if (body.method === "aria2.remove") {
      return new Response(JSON.stringify({ result: "abc" }), {
        status: 200,
        headers: { "content-type": "application/json" }
      });
    }
    return new Response("{}", { status: 200 });
  };

  try {
    const active = await tellActiveAria2({ endpoint: "http://aria.local", secret: "" });
    assert.equal(active.length, 1);
    assert.equal(active[0].gid, "abc");
    assert.equal(active[0].totalLength, 100);
    assert.equal(active[0].completedLength, 40);
    assert.equal(active[0].files[0].path, "/tmp/foo.mp4");

    const cancel = await removeAria2Download({ endpoint: "http://aria.local", secret: "s3cret" }, "abc");
    assert.equal(cancel.ok, true);
    assert.equal(cancel.gid, "abc");
    // Last call should have prefixed with `token:s3cret`.
    const lastBody = calls[calls.length - 1];
    assert.equal(lastBody.params[0], "token:s3cret");
    assert.equal(lastBody.params[1], "abc");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("splitForThread chunks on blank lines and drops empty segments", async () => {
  const { splitForThread } = await importSourceModule(
    "src/features/integrations/crosspost.ts"
  );
  assert.deepEqual(splitForThread("first\n\nsecond\n\nthird"), ["first", "second", "third"]);
  assert.deepEqual(splitForThread("solo"), ["solo"]);
  assert.deepEqual(splitForThread(""), []);
  assert.deepEqual(splitForThread("a\n\n\nb"), ["a", "b"]);
});

test("crosspost asThread posts every segment for Bluesky with reply refs", async () => {
  const { crosspost } = await importSourceModule(
    "src/features/integrations/crosspost.ts"
  );
  const original = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, init) => {
    calls.push({ url, body: JSON.parse(init.body) });
    if (typeof url === "string" && url.includes("createSession")) {
      return new Response(JSON.stringify({ accessJwt: "jwt", did: "did:plc:1" }), {
        status: 200,
        headers: { "content-type": "application/json" }
      });
    }
    return new Response(
      JSON.stringify({ uri: `at://did:plc:1/app.bsky.feed.post/post${calls.length}`, cid: `cid${calls.length}` }),
      { status: 200, headers: { "content-type": "application/json" } }
    );
  };
  try {
    const integrations = {
      aria2: { enabled: false, endpoint: "", secret: "", minBytes: 1_000_000 },
      bluesky: {
        enabled: true,
        service: "https://bsky.social",
        handle: "you.bsky.social",
        appPassword: "abc"
      },
      mastodon: { enabled: false, instance: "", token: "", visibility: "public" },
      ai: { enabled: false, provider: "anthropic", endpoint: "", apiKey: "", model: "" },
      semanticSearch: { enabled: false, endpoint: "", apiKey: "", model: "", autoIndex: false }
    };
    const result = await crosspost(integrations, {
      text: "one\n\ntwo\n\nthree",
      target: "bluesky",
      asThread: true
    });
    assert.equal(result.ok, true);
    assert.equal(result.posts, 3);
    // 1 session + 3 createRecord calls.
    assert.equal(calls.length, 4);
    const replyPayload = calls[3].body.record.reply;
    assert.ok(replyPayload, "third post should carry reply ref");
    assert.equal(replyPayload.root.uri, "at://did:plc:1/app.bsky.feed.post/post2");
  } finally {
    globalThis.fetch = original;
  }
});

test("crosspost asThread chains in_reply_to_id for Mastodon", async () => {
  const { crosspost } = await importSourceModule(
    "src/features/integrations/crosspost.ts"
  );
  const original = globalThis.fetch;
  const calls = [];
  let nextId = 0;
  globalThis.fetch = async (url, init) => {
    calls.push({ url, body: JSON.parse(init.body) });
    nextId += 1;
    return new Response(
      JSON.stringify({ id: `s${nextId}`, url: `https://mastodon.social/@you/s${nextId}` }),
      { status: 200, headers: { "content-type": "application/json" } }
    );
  };
  try {
    const integrations = {
      aria2: { enabled: false, endpoint: "", secret: "", minBytes: 1_000_000 },
      bluesky: { enabled: false, service: "", handle: "", appPassword: "" },
      mastodon: {
        enabled: true,
        instance: "https://mastodon.social",
        token: "tok",
        visibility: "unlisted"
      },
      ai: { enabled: false, provider: "anthropic", endpoint: "", apiKey: "", model: "" },
      semanticSearch: { enabled: false, endpoint: "", apiKey: "", model: "", autoIndex: false }
    };
    const result = await crosspost(integrations, {
      text: "a\n\nb\n\nc",
      target: "mastodon",
      asThread: true
    });
    assert.equal(result.ok, true);
    assert.equal(result.posts, 3);
    assert.equal(calls.length, 3);
    assert.equal(calls[0].body.in_reply_to_id, undefined);
    assert.equal(calls[1].body.in_reply_to_id, "s1");
    assert.equal(calls[2].body.in_reply_to_id, "s2");
    assert.equal(result.url, "https://mastodon.social/@you/s1");
  } finally {
    globalThis.fetch = original;
  }
});

test("crosspost uploads the last image to Bluesky and embeds it on the first post", async () => {
  const { crosspost } = await importSourceModule("src/features/integrations/crosspost.ts");
  const original = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, init) => {
    calls.push({ url, init });
    if (typeof url === "string" && url.includes("source.jpg")) {
      return new Response(new Uint8Array([1, 2, 3]), {
        status: 200,
        headers: { "content-type": "image/jpeg" }
      });
    }
    if (typeof url === "string" && url.includes("uploadBlob")) {
      assert.equal(init.headers.authorization, "Bearer jwt");
      assert.ok(init.body instanceof Blob);
      return new Response(JSON.stringify({ blob: { $type: "blob", ref: { $link: "cid-image" }, mimeType: "image/jpeg", size: 3 } }), {
        status: 200,
        headers: { "content-type": "application/json" }
      });
    }
    if (typeof url === "string" && url.includes("createSession")) {
      return new Response(JSON.stringify({ accessJwt: "jwt", did: "did:plc:1" }), { status: 200 });
    }
    return new Response(JSON.stringify({ uri: "at://did:plc:1/app.bsky.feed.post/post1", cid: "cid1" }), { status: 200 });
  };

  try {
    const result = await crosspost(
      {
        aria2: { enabled: false, endpoint: "", secret: "", minBytes: 1_000_000 },
        bluesky: { enabled: true, service: "https://bsky.social", handle: "you.bsky.social", appPassword: "abc" },
        mastodon: { enabled: false, instance: "", token: "", visibility: "public" },
        ai: { enabled: false, provider: "anthropic", endpoint: "", apiKey: "", model: "" },
        semanticSearch: { enabled: false, endpoint: "", apiKey: "", model: "", autoIndex: false },
        crosspost: { attachLastDownload: true }
      },
      {
        text: "With an image",
        target: "bluesky",
        attachment: { url: "https://cdn.test/source.jpg", filename: "source.jpg", kind: "photo" }
      }
    );
    assert.equal(result.ok, true);
    const recordCall = calls.find((entry) => typeof entry.url === "string" && entry.url.includes("createRecord"));
    const record = JSON.parse(recordCall.init.body).record;
    assert.equal(record.embed.$type, "app.bsky.embed.images");
    assert.equal(record.embed.images[0].image.ref.$link, "cid-image");
  } finally {
    globalThis.fetch = original;
  }
});

test("crosspost uploads the last media to Mastodon and attaches it to the first status", async () => {
  const { crosspost } = await importSourceModule("src/features/integrations/crosspost.ts");
  const original = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, init) => {
    calls.push({ url, init });
    if (typeof url === "string" && url.includes("source.png")) {
      return new Response(new Uint8Array([4, 5]), {
        status: 200,
        headers: { "content-type": "image/png" }
      });
    }
    if (typeof url === "string" && url.endsWith("/api/v1/media")) {
      assert.equal(init.headers.authorization, "Bearer token");
      assert.ok(init.body instanceof FormData);
      assert.equal(init.body.get("file").name, "source.png");
      return new Response(JSON.stringify({ id: "media-1" }), { status: 200 });
    }
    const body = JSON.parse(init.body);
    assert.deepEqual(body.media_ids, ["media-1"]);
    return new Response(JSON.stringify({ id: "status-1", url: "https://mastodon.social/@you/1" }), { status: 200 });
  };

  try {
    const result = await crosspost(
      {
        aria2: { enabled: false, endpoint: "", secret: "", minBytes: 1_000_000 },
        bluesky: { enabled: false, service: "", handle: "", appPassword: "" },
        mastodon: { enabled: true, instance: "https://mastodon.social", token: "token", visibility: "public" },
        ai: { enabled: false, provider: "anthropic", endpoint: "", apiKey: "", model: "" },
        semanticSearch: { enabled: false, endpoint: "", apiKey: "", model: "", autoIndex: false },
        crosspost: { attachLastDownload: true }
      },
      {
        text: "With an image",
        target: "mastodon",
        attachment: { url: "https://cdn.test/source.png", filename: "source.png", kind: "photo" }
      }
    );
    assert.equal(result.ok, true);
    assert.equal(result.url, "https://mastodon.social/@you/1");
  } finally {
    globalThis.fetch = original;
  }
});

test("crosspost rejects an attachment over the bounded download limit", async () => {
  const { ATTACHMENT_LIMITS, crosspost } = await importSourceModule(
    "src/features/integrations/crosspost.ts"
  );
  const original = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url) => {
    calls.push(url);
    if (String(url).includes("createSession")) {
      return new Response(JSON.stringify({ accessJwt: "jwt", did: "did:plc:1" }), { status: 200 });
    }
    if (String(url).includes("source.jpg")) {
      return new Response(new Uint8Array([1]), {
        status: 200,
        headers: {
          "content-type": "image/jpeg",
          "content-length": String(ATTACHMENT_LIMITS.photo + 1)
        }
      });
    }
    throw new Error(`unexpected network call: ${String(url)}`);
  };

  try {
    const result = await crosspost(
      {
        aria2: { enabled: false, endpoint: "", secret: "", minBytes: 1_000_000 },
        bluesky: { enabled: true, service: "https://bsky.social", handle: "you.bsky.social", appPassword: "abc" },
        mastodon: { enabled: false, instance: "", token: "", visibility: "public" },
        ai: { enabled: false, provider: "anthropic", endpoint: "", apiKey: "", model: "" },
        semanticSearch: { enabled: false, endpoint: "", apiKey: "", model: "", autoIndex: false },
        crosspost: { attachLastDownload: true }
      },
      {
        text: "Too large",
        target: "bluesky",
        attachment: { url: "https://cdn.test/source.jpg", filename: "source.jpg", kind: "photo" }
      }
    );
    assert.equal(result.ok, false);
    assert.match(result.error, /limit/i);
    assert.equal(calls.length, 2, "session may authenticate, but the oversized media must not upload or post");
  } finally {
    globalThis.fetch = original;
  }
});

test("recentIntegrationErrors surfaces failed audit entries newest-first", async () => {
  const { recentIntegrationErrors } = await importSourceModule(
    "src/features/core/integration-errors.ts"
  );
  const entries = [
    { at: "2026-05-19T10:00:00Z", action: "media.download", detail: { ok: true } },
    {
      at: "2026-05-19T10:05:00Z",
      action: "media.download.failed",
      detail: { kind: "video", error: "HTTP 404" }
    },
    // Filed under their own action since v1.9.0. These used to be recorded as export.start /
    // export.complete, which made the user-facing log describe a failed crosspost as an export.
    {
      at: "2026-05-19T10:06:00Z",
      action: "crosspost",
      detail: { target: "bluesky", ok: false, error: "Bluesky HTTP 401" }
    },
    {
      at: "2026-05-19T10:07:00Z",
      action: "crosspost",
      detail: { target: "mastodon", ok: true }
    }
  ];
  const errors = recentIntegrationErrors(entries);
  assert.equal(errors.length, 2);
  // Most recent first.
  assert.equal(errors[0].at, "2026-05-19T10:06:00Z");
  assert.equal(errors[0].kind, "crosspost:bluesky");
  assert.match(errors[0].message, /HTTP 401/);
  assert.equal(errors[1].kind, "video");
  assert.match(errors[1].message, /HTTP 404/);
});

test("semanticSearch settings carry the new autoIndex flag", async () => {
  const { DEFAULT_SETTINGS, normalizeSettings } = await importSourceModule(
    "src/platform/settings.ts"
  );
  assert.equal(DEFAULT_SETTINGS.integrations.semanticSearch.autoIndex, false);
  const enabled = normalizeSettings({
    integrations: { semanticSearch: { autoIndex: true, endpoint: "https://example.com" } }
  });
  assert.equal(enabled.integrations.semanticSearch.autoIndex, true);
});

test("crosspost attachment preference defaults off and normalizes safely", async () => {
  const { DEFAULT_SETTINGS, normalizeSettings } = await importSourceModule(
    "src/platform/settings.ts"
  );
  assert.equal(DEFAULT_SETTINGS.integrations.crosspost.attachLastDownload, false);
  assert.equal(normalizeSettings({ integrations: { crosspost: { attachLastDownload: true } } }).integrations.crosspost.attachLastDownload, true);
  assert.equal(normalizeSettings({ integrations: { crosspost: { attachLastDownload: "yes" } } }).integrations.crosspost.attachLastDownload, false);
});

test("smoke spec scaffold ships with explicit setup instructions", async () => {
  const source = await readFile(
    path.join(root, "tests/smoke/aviary.smoke.mjs"),
    "utf8"
  );
  assert.match(source, /npm install --save-dev playwright/);
  assert.match(source, /launchPersistentContext/);
  assert.match(source, /Integrations/);
  assert.match(source, /current-x-home\.html/);
  assert.match(source, /headless: false/);
  assert.match(source, /page\.route/);
  assert.match(source, /data-av-media-button/);
  assert.match(source, /Selector health/);
  assert.match(source, /16 page-hook configurations/);
  assert.match(source, /home\?tab=following/);
  assert.match(source, /PageHookProbe/);
  assert.match(source, /selector-degraded/);
  assert.match(source, /resourceType\(\) === "document"/);
  const external = await readFile(
    path.join(root, "tests/smoke/externally-gated.smoke.mjs"),
    "utf8"
  );
  assert.match(external, /--headless=new/);
  assert.match(external, /chrome\.runtime\.sendMessage/);
  assert.match(external, /Import official X archive/);
  assert.match(external, /Rebuild semantic index/);
  assert.match(external, /Test Aria2 connection/);
  assert.match(external, /Crosspost composer/);
  assert.match(external, /provider\.server\.close/);
  assert.match(external, /rm\(tempProfile/);
  const [dnrChromium, dnrFirefox] = await Promise.all([
    readFile(path.join(root, "tests/smoke/dnr-chromium.smoke.mjs"), "utf8"),
    readFile(path.join(root, "tests/smoke/dnr-firefox.smoke.mjs"), "utf8")
  ]);
  for (const source of [dnrChromium, dnrFirefox]) {
    assert.match(source, /testMatchOutcome/);
    assert.match(source, /AVIARY_SYNC_AD_RULE/);
    assert.match(source, /HomeTimeline/);
    assert.match(source, /promoted_content\/log/);
  }
  assert.match(dnrChromium, /tab-scoped/);
  assert.match(dnrFirefox, /CONNECT x\.com:443/);
  // `error` logs nothing geckodriver said, so a failed launch has to be read at `info` or the
  // captured output the throw below carries is only Firefox's console noise.
  assert.match(dnrFirefox, /"--log",\s+"info"/);
  assert.match(dnrFirefox, /geckodriver could not start a Firefox session/);
  const incognito = await readFile(
    path.join(root, "tests/smoke/incognito-chromium.smoke.mjs"),
    "utf8"
  );
  assert.match(incognito, /not_allowed/);
  assert.match(incognito, /createBrowserContext/);
  assert.match(incognito, /Extensions\.loadUnpacked/);
  assert.match(incognito, /enableInIncognito/);
  assert.match(incognito, /indexedDB\.databases/);
  const helperLane = await readFile(
    path.join(root, "tests/smoke/ytdlp-helper-chromium.smoke.mjs"),
    "utf8"
  );
  // The lane is only evidence while its positive control stands: the page itself must be refused.
  assert.match(helperLane, /AVIARY_YTDLP_PROXY/);
  assert.match(helperLane, /assert\.match\(direct, \/\^refused\//);
  assert.match(helperLane, /runLane\(\{ granted: false \}\)/);
  assert.match(helperLane, /runLane\(\{ granted: true \}\)/);
  const pkg = JSON.parse(await readFile(path.join(root, "package.json"), "utf8"));
  assert.equal(
    pkg.scripts.smoke,
    "node tests/smoke/dnr-chromium.smoke.mjs && node tests/smoke/dnr-firefox.smoke.mjs && node tests/smoke/aviary.smoke.mjs && node tests/smoke/incognito-chromium.smoke.mjs && node tests/smoke/externally-gated.smoke.mjs && node tests/smoke/extension-lifecycle.smoke.mjs && node tests/smoke/ytdlp-helper-chromium.smoke.mjs && node tests/smoke/userscript-manager-lifecycle.smoke.mjs"
  );
});

test("anything running more than one visual lane at once runs them one at a time", async () => {
  // Each visual lane launches its own headless Chromium against a persistent profile, and
  // `node --test` runs files at `os.availableParallelism() - 1` unless told otherwise. Three
  // browsers competing made the Control Center take tens of seconds to mount, so the lanes failed
  // on a WebDriver-side timeout on a different viewport every run instead of on a pixel
  // difference -- and the parallel run was slower anyway, 265-278s against 239s serial.
  //
  // The rule is tied to the condition rather than to a fixed string: a runner that drives one lane
  // needs no flag, and one that drives several does. Dropping back to a single lane must not fail
  // this, and adding a fourth entry point that forgets the flag must.
  const pkg = JSON.parse(await readFile(path.join(root, "package.json"), "utf8"));
  const runners = [
    { name: "package.json test:visual", source: pkg.scripts["test:visual"] },
    {
      name: "tools/release-gate.mjs",
      source: await readFile(path.join(root, "tools/release-gate.mjs"), "utf8")
    },
    {
      name: "tools/update-settings-visuals.mjs",
      source: await readFile(path.join(root, "tools/update-settings-visuals.mjs"), "utf8")
    }
  ];

  let checked = 0;
  for (const runner of runners) {
    assert.ok(runner.source, `${runner.name} is missing`);
    const lanes = new Set(runner.source.match(/[\w-]+-visual-regression\.test\.mjs/g) ?? []);
    if (lanes.size < 2) continue;
    checked += 1;
    assert.match(
      runner.source,
      /--test-concurrency=1/,
      `${runner.name} drives ${lanes.size} visual lanes at once without serialising them`
    );
  }
  // Without this, deleting a lane from all three runners would leave nothing asserted and pass.
  assert.equal(checked, 3, `expected three multi-lane runners, checked ${checked}`);
});

test("Playwright smoke stays local and leaves no hosted build workflow", async () => {
  await assert.rejects(
    readFile(path.join(root, ".github/workflows/smoke.yml"), "utf8"),
    (error) => error?.code === "ENOENT"
  );
  const smoke = await readFile(path.join(root, "tests/smoke/aviary.smoke.mjs"), "utf8");
  assert.doesNotMatch(smoke, /MouseEvent|HTMLButtonElement/);
  assert.match(smoke, /rm\(userDataDir/);
});
