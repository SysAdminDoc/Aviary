import { cloneSettings, normalizeSettings, type AviarySettings } from "../../platform/settings.ts";

export type PresetId =
  | "quiet-reader"
  | "media-archivist"
  | "creator"
  | "researcher"
  | "classic"
  | "minimal";

export interface PresetDefinition {
  id: PresetId;
  label: string;
  description: string;
  highlights: PresetHighlight[];
  overrides: PresetOverrides;
}

export interface PresetHighlight {
  label: string;
  value: string;
}

export type PresetOverrides = Partial<{
  appearance: Partial<AviarySettings["appearance"]>;
  layout: Partial<AviarySettings["layout"]>;
  filter: Partial<AviarySettings["filter"]>;
  media: Partial<AviarySettings["media"]>;
  export: Partial<AviarySettings["export"]>;
  links: Partial<AviarySettings["links"]>;
  composer: Partial<AviarySettings["composer"]>;
  accessibility: Partial<AviarySettings["accessibility"]>;
  jobs: Partial<AviarySettings["jobs"]>;
  privacy: Partial<AviarySettings["privacy"]>;
  diagnostics: Partial<AviarySettings["diagnostics"]>;
  i18n: Partial<AviarySettings["i18n"]>;
}>;

export const PRESETS: PresetDefinition[] = [
  {
    id: "quiet-reader",
    label: "Quiet Reader",
    description: "Hide trends, row borders and engagement counts, dim premium posts, strip t.co, dense + dim theme.",
    highlights: [
      { label: "Hide right sidebar", value: "Enabled" },
      { label: "Suppress hover previews", value: "Enabled" },
      { label: "Hide engagement counts", value: "Enabled" },
      { label: "Theme", value: "Dim" }
    ],
    overrides: {
      appearance: { theme: "dim", denseMode: true, hideCounts: true, hideBorders: true },
      layout: {
        hideRightSidebar: true,
        hideTrends: true,
        hideGrok: true,
        autoExpandPostText: true,
        restoreTimelinePosition: true
      },
      filter: { enabled: true, premiumRule: "dim" },
      links: { expandTco: true, cleanShareButtons: true }
    }
  },
  {
    id: "media-archivist",
    label: "Media Archivist",
    description: "Original-quality downloads, deterministic filenames, dedup history, stacked media.",
    highlights: [
      { label: "Prefer original quality", value: "Enabled" },
      { label: "Media layout", value: "Stacked" },
      { label: "Show download buttons", value: "Enabled" }
    ],
    overrides: {
      appearance: { theme: "lightsOut" },
      media: {
        buttons: true,
        copyMediaLinks: true,
        preferOriginalImages: true,
        downloadHistory: true,
        layout: "stacked"
      },
      filter: { enabled: false }
    }
  },
  {
    id: "creator",
    label: "Creator",
    description: "Writer mode, composer snippets, share-button cleanup, sidebar and trends hidden.",
    highlights: [
      { label: "Writer mode", value: "Enabled" },
      { label: "Hide trends", value: "Enabled" },
      { label: "Media layout", value: "Strict grid" }
    ],
    overrides: {
      appearance: { theme: "midnight" },
      layout: { hideRightSidebar: true, hideTrends: true, hideGrok: true, writerMode: true },
      media: { layout: "grid" },
      links: { cleanShareButtons: true, expandTco: true }
    }
  },
  {
    id: "researcher",
    label: "Researcher",
    description: "Export capture on, JSON+CSV+HTML+MD formats, auto-discover query IDs, raw payloads.",
    highlights: [
      { label: "Capture visible posts", value: "Enabled" },
      { label: "Preserve raw payloads", value: "Enabled" },
      { label: "Export formats", value: "JSON, CSV, HTML, Markdown" }
    ],
    overrides: {
      filter: { enabled: false },
      export: {
        enabled: true,
        formats: ["json", "csv", "html", "markdown"],
        preserveRawPayloads: true,
        autoDiscoverQueryIds: true
      },
      media: { layout: "default" },
      links: { cleanShareButtons: true }
    }
  },
  {
    id: "classic",
    label: "Classic",
    description: "Restore dim, keep sidebar, hide Grok only, no premium filtering.",
    highlights: [
      { label: "Theme", value: "Dim" },
      { label: "Dense mode", value: "Disabled" },
      { label: "Hide Grok surfaces", value: "Enabled" }
    ],
    overrides: {
      appearance: { theme: "dim", denseMode: false },
      layout: {
        hideRightSidebar: false,
        hideTrends: false,
        hideGrok: true
      },
      filter: { enabled: false, premiumRule: "off" }
    }
  },
  {
    id: "minimal",
    label: "Minimal",
    description: "Maximum declutter: no counts, no borders, no trends, big text safe zones.",
    highlights: [
      { label: "Hide engagement counts", value: "Enabled" },
      { label: "Hide right sidebar", value: "Enabled" },
      { label: "Theme", value: "Noir" }
    ],
    overrides: {
      appearance: {
        theme: "noir",
        denseMode: false,
        timelineWidth: "wide",
        hideCounts: true,
        hideBorders: true
      },
      layout: {
        hideRightSidebar: true,
        hideTrends: true,
        hideFollowSuggestions: true,
        hideHomeComposer: true,
        hideGrok: true,
        suppressHoverPreviews: true,
        hideForYouTab: true,
        hideNavItems: ["follow", "grok", "history", "studio", "premium"]
      },
      filter: { enabled: true, premiumRule: "hide" },
      accessibility: { reduceMotion: "always" }
    }
  }
];

export function listPresets(): PresetDefinition[] {
  return PRESETS.map((preset) => ({
    ...preset,
    highlights: preset.highlights.map((highlight) => ({ ...highlight })),
    overrides: cloneOverrides(preset.overrides)
  }));
}

export function getPreset(id: PresetId): PresetDefinition | undefined {
  return listPresets().find((preset) => preset.id === id);
}

export function applyPreset(current: AviarySettings, preset: PresetDefinition): AviarySettings {
  const next = cloneSettings(current);
  for (const [section, overrides] of Object.entries(preset.overrides)) {
    if (!overrides) continue;
    const target = (next as unknown as Record<string, Record<string, unknown>>)[section];
    if (!target) continue;
    for (const [key, value] of Object.entries(overrides)) {
      target[key] = value;
    }
  }
  return normalizeSettings(next);
}

export function describePresetDelta(current: AviarySettings, preset: PresetDefinition): string[] {
  const result: string[] = [];
  const next = applyPreset(current, preset);
  for (const section of Object.keys(preset.overrides) as Array<keyof PresetOverrides>) {
    const currentSection = (current as unknown as Record<string, Record<string, unknown>>)[section] ?? {};
    const nextSection = (next as unknown as Record<string, Record<string, unknown>>)[section] ?? {};
    for (const key of Object.keys(preset.overrides[section] ?? {})) {
      const before = JSON.stringify(currentSection[key]);
      const after = JSON.stringify(nextSection[key]);
      if (before !== after) {
        result.push(`${section}.${key}: ${before} → ${after}`);
      }
    }
  }
  return result;
}

function cloneOverrides(overrides: PresetOverrides): PresetOverrides {
  return JSON.parse(JSON.stringify(overrides)) as PresetOverrides;
}
