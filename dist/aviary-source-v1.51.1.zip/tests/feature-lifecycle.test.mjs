import assert from "node:assert/strict";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { after, before, test } from "node:test";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { chromium } from "playwright";

/**
 * Three features whose contract is "apply changes the page, destroy puts it back", driven rather
 * than read.
 *
 * These were asserted as regexes over their own source — `/root\.classList\.toggle\("av-hide-
 * borders", settings\.appearance\.hideBorders\)/`, `/setAttribute\("href", original\)/`. A regex
 * over the line that performs an effect cannot tell whether the effect happened: it survives a
 * feature that toggles the class and then throws, or one that restores an href it never recorded.
 * Each test below applies the feature to a fixture, checks the page, destroys it, and checks the
 * page is back where it started.
 */

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const abs = (file) => path.resolve(root, file).replace(/\\/g, "/");

let browser;
let bundle;
let page;
let temp;

before(async () => {
  temp = await mkdtemp(path.join(tmpdir(), "aviary-lifecycle-"));
  const entry = path.join(temp, "entry.ts");
  await writeFile(
    entry,
    [
      `export { themeFeature, THEME_CSS } from ${JSON.stringify(abs("src/features/appearance/theme.ts"))};`,
      `export { layoutDeclutterFeature } from ${JSON.stringify(abs("src/features/layout/declutter.ts"))};`,
      `export { forceFollowingFeature } from ${JSON.stringify(abs("src/features/layout/force-following.ts"))};`,
      `export { cleanShareLinksFeature, cleanUrl } from ${JSON.stringify(abs("src/features/library/clean-share-links.ts"))};`,
      `export { linkUnshortenFeature } from ${JSON.stringify(abs("src/features/library/link-unshorten.ts"))};`,
      `export { PRESETS } from ${JSON.stringify(abs("src/features/core/presets.ts"))};`,
      `export { userNotesFeature } from ${JSON.stringify(abs("src/features/library/user-notes.ts"))};`,
      `export { mobileTouchFeature } from ${JSON.stringify(abs("src/features/core/mobile-touch.ts"))};`,
      `export { i18nFeature } from ${JSON.stringify(abs("src/features/core/i18n-feature.ts"))};`,
      `export { mediaPresentationFeature } from ${JSON.stringify(abs("src/features/media/media-presentation.ts"))};`,
      `export { DEFAULT_SETTINGS, cloneSettings } from ${JSON.stringify(abs("src/platform/settings.ts"))};`
    ].join("\n"),
    "utf8"
  );
  bundle = path.join(temp, "bundle.js");
  await build({
    entryPoints: [entry],
    outfile: bundle,
    bundle: true,
    format: "iife",
    globalName: "AviaryLifecycle",
    platform: "browser",
    target: "es2022",
    logLevel: "silent"
  });

  browser = await chromium.launch({ headless: true });
  page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.setContent("<!doctype html><meta charset=utf-8><body></body>");
  await page.addScriptTag({ path: bundle });
  await page.evaluate(() => {
    window.ctx = (mutate) => {
      const settings = AviaryLifecycle.cloneSettings(AviaryLifecycle.DEFAULT_SETTINGS);
      mutate?.(settings);
      return {
        settings,
        route: { surface: "home", path: "/home" },
        diagnostics: { info() {}, warn() {}, error() {} }
      };
    };
    window.reset = () => {
      document.documentElement.className = "";
      document.body.replaceChildren();
    };
  });
});

after(async () => {
  await browser?.close();
  await rm(temp, { recursive: true, force: true });
});

test("hideBorders adds a class the stylesheet targets, and destroy takes it away", async () => {
  const result = await page.evaluate(() => {
    window.reset();
    const html = document.documentElement;
    const off = window.ctx();
    const on = window.ctx((settings) => {
      settings.appearance.hideBorders = true;
    });

    AviaryLifecycle.themeFeature.init(off);
    const whenOff = html.classList.contains("av-hide-borders");

    AviaryLifecycle.themeFeature.apply(on);
    const whenOn = html.classList.contains("av-hide-borders");

    // Turning the setting back off must be enough; the user should not have to reload.
    AviaryLifecycle.themeFeature.apply(off);
    const afterOff = html.classList.contains("av-hide-borders");

    AviaryLifecycle.themeFeature.apply(on);
    AviaryLifecycle.themeFeature.destroy(on);
    return {
      whenOff,
      whenOn,
      afterOff,
      afterDestroy: html.classList.contains("av-hide-borders"),
      styleAfterDestroy: Boolean(document.getElementById("av-theme-foundation"))
    };
  });

  assert.equal(result.whenOff, false, "off by default, like every appearance control");
  assert.equal(result.whenOn, true);
  assert.equal(result.afterOff, false, "the class must follow the setting both ways");
  assert.equal(result.afterDestroy, false, "destroy must leave no trace on the page");
  assert.equal(result.styleAfterDestroy, false, "and must take its stylesheet with it");
});

test("the hide-borders rules select X's structure, never its generated class names", async () => {
  const css = await page.evaluate(() => AviaryLifecycle.THEME_CSS);

  // Structural selectors survive X shipping a new build; `.r-1kihuf0` does not.
  assert.match(css, /html\.av-hide-borders \[data-testid="cellInnerDiv"\]/);
  assert.match(css, /html\.av-hide-borders \[data-testid="primaryColumn"\]/);
  assert.ok(
    !/\.r-[a-z0-9]{5,}/.test(css),
    "the stylesheet must not depend on X's generated atomic class names"
  );
});

test("hide-borders actually flattens the timeline it targets", async () => {
  const borders = await page.evaluate(() => {
    window.reset();
    document.body.innerHTML = `
      <main data-testid="primaryColumn" style="border: 1px solid rgb(200, 0, 0)">
        <div data-testid="cellInnerDiv"><div style="border-bottom: 1px solid rgb(200, 0, 0)">post</div></div>
      </main>`;
    const cell = document.querySelector('[data-testid="cellInnerDiv"] > div');
    const column = document.querySelector('[data-testid="primaryColumn"]');
    const ctx = window.ctx((settings) => {
      settings.appearance.hideBorders = true;
    });

    AviaryLifecycle.themeFeature.init(window.ctx());
    const before = {
      cell: getComputedStyle(cell).borderBottomWidth,
      column: getComputedStyle(column).borderLeftWidth
    };
    AviaryLifecycle.themeFeature.apply(ctx);
    const after = {
      cell: getComputedStyle(cell).borderBottomWidth,
      column: getComputedStyle(column).borderLeftWidth
    };
    AviaryLifecycle.themeFeature.destroy(ctx);
    return { before, after };
  });

  assert.equal(borders.before.cell, "1px", "the fixture must start with the border this removes");
  assert.equal(borders.after.cell, "0px", "the timeline separator must actually go");
  assert.equal(borders.after.column, "0px", "and so must the column edge");
});

test("writer mode follows focus into and out of the composer, with no key handler", async () => {
  const result = await page.evaluate(async () => {
    window.reset();
    document.body.innerHTML = `
      <div data-testid="primaryColumn">
        <div data-testid="tweetTextarea_0RichTextInputContainer">
          <div contenteditable="true" data-testid="tweetTextarea_0" tabindex="0"></div>
        </div>
      </div>
      <aside data-testid="sidebarColumn">trends</aside>
      <button id="elsewhere">elsewhere</button>`;

    const html = document.documentElement;
    const composer = document.querySelector('[data-testid="tweetTextarea_0"]');
    const elsewhere = document.getElementById("elsewhere");
    const ctx = window.ctx((settings) => {
      settings.layout.writerMode = true;
    });

    // Any key event reaching the document would be a hotkey; Aviary registers none.
    let keyEvents = 0;
    for (const type of ["keydown", "keyup", "keypress"]) {
      document.addEventListener(type, () => keyEvents++, true);
    }

    AviaryLifecycle.layoutDeclutterFeature.init(ctx);
    const armed = { mode: html.classList.contains("av-writer-mode"), writing: html.classList.contains("av-writing") };

    composer.focus();
    // The surroundings recede over a 160ms transition rather than snapping, so sampling the
    // computed opacity any sooner reads the value mid-animation.
    await new Promise((resolve) => setTimeout(resolve, 260));
    const typing = {
      writing: html.classList.contains("av-writing"),
      sidebar: getComputedStyle(document.querySelector('[data-testid="sidebarColumn"]')).opacity
    };

    elsewhere.focus();
    // focusout fires before focus lands, so the feature re-reads on the next frame.
    await new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 10)));
    const away = html.classList.contains("av-writing");

    composer.focus();
    await new Promise((resolve) => setTimeout(resolve, 10));
    AviaryLifecycle.layoutDeclutterFeature.destroy(ctx);

    // If destroy left the listeners bound, this focus would put the class straight back.
    elsewhere.focus();
    composer.focus();
    await new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 10)));

    return {
      armed,
      typing,
      away,
      afterDestroy: {
        mode: html.classList.contains("av-writer-mode"),
        writing: html.classList.contains("av-writing")
      },
      keyEvents
    };
  });

  assert.equal(result.armed.mode, true, "the setting must arm writer mode");
  assert.equal(result.armed.writing, false, "arming it is not the same as writing");
  assert.equal(result.typing.writing, true, "focusing the composer must enter writing");
  assert.notEqual(result.typing.sidebar, "1", "and must actually dim what surrounds it");
  assert.equal(result.away, false, "leaving the composer must leave writing");
  assert.equal(result.afterDestroy.mode, false, "destroy must drop both classes");
  assert.equal(result.afterDestroy.writing, false);
  assert.equal(result.keyEvents, 0, "focus is the signal — Aviary registers no key handlers");
});

test("clean share links strips tracking parameters and puts the original href back", async () => {
  const result = await page.evaluate(() => {
    window.reset();
    document.body.innerHTML = `
      <a id="tracked" href="https://x.com/user/status/1?t=abc123&s=20">post</a>
      <a id="plain" href="https://x.com/user/status/2">plain</a>
      <a id="foreign" href="https://example.com/a?utm_source=x&keep=1">foreign</a>`;
    const read = () => ({
      tracked: document.getElementById("tracked").getAttribute("href"),
      plain: document.getElementById("plain").getAttribute("href"),
      foreign: document.getElementById("foreign").getAttribute("href")
    });

    const off = window.ctx((settings) => {
      settings.links.cleanShareButtons = false;
    });
    const on = window.ctx((settings) => {
      settings.links.cleanShareButtons = true;
    });

    AviaryLifecycle.cleanShareLinksFeature.init(off);
    const whenOff = read();

    AviaryLifecycle.cleanShareLinksFeature.apply(on, document);
    const whenOn = read();

    // Turning the setting off has to undo the rewrite, not merely stop doing more of it.
    AviaryLifecycle.cleanShareLinksFeature.apply(off, document);
    const afterOff = read();

    AviaryLifecycle.cleanShareLinksFeature.apply(on, document);
    AviaryLifecycle.cleanShareLinksFeature.destroy(on);
    return { whenOff, whenOn, afterOff, afterDestroy: read() };
  });

  assert.equal(result.whenOff.tracked, "https://x.com/user/status/1?t=abc123&s=20", "off means untouched");
  assert.equal(result.whenOn.tracked, "https://x.com/user/status/1", "t and s are X's share tracking");
  assert.equal(result.whenOn.plain, "https://x.com/user/status/2", "a clean link must be left alone");
  assert.equal(result.afterOff.tracked, "https://x.com/user/status/1?t=abc123&s=20", "turning it off restores");
  assert.equal(result.afterDestroy.tracked, "https://x.com/user/status/1?t=abc123&s=20", "destroy restores");
});

test("each declutter switch adds only its own class, and destroy removes them all", async () => {
  const result = await page.evaluate(() => {
    window.reset();
    document.body.innerHTML = `
      <main data-testid="primaryColumn"><div data-testid="cellInnerDiv">post</div></main>
      <aside data-testid="sidebarColumn">
        <div data-testid="trend">trend</div>
        <div data-testid="sidebarColumn-grok">grok</div>
      </aside>`;
    const html = document.documentElement;
    const avClasses = () => [...html.classList].filter((name) => name.startsWith("av-"));

    const cases = {
      hideRightSidebar: "av-hide-right-sidebar",
      hideTrends: "av-hide-trends",
      hideGrok: "av-hide-grok",
      hideFollowSuggestions: "av-hide-follow-suggestions"
    };

    const seen = {};
    for (const [setting, className] of Object.entries(cases)) {
      const ctx = window.ctx((settings) => {
        settings.layout[setting] = true;
      });
      AviaryLifecycle.layoutDeclutterFeature.init(ctx);
      seen[setting] = { classes: avClasses(), expected: className };
      AviaryLifecycle.layoutDeclutterFeature.destroy(ctx);
      seen[setting].afterDestroy = avClasses();
    }

    // A nav item name is user input; it becomes part of a class name, so it has to be sanitised.
    const navCtx = window.ctx((settings) => {
      settings.layout.hideNavItems = ["Messages", 'evil"><script>', "Explore"];
    });
    AviaryLifecycle.layoutDeclutterFeature.init(navCtx);
    const nav = avClasses().filter((name) => name.startsWith("av-hide-nav-"));
    AviaryLifecycle.layoutDeclutterFeature.destroy(navCtx);

    return { seen, nav, afterNavDestroy: avClasses() };
  });

  for (const [setting, entry] of Object.entries(result.seen)) {
    assert.deepEqual(
      entry.classes,
      [entry.expected],
      `${setting} added ${JSON.stringify(entry.classes)} instead of only ${entry.expected}`
    );
    assert.deepEqual(entry.afterDestroy, [], `${setting} left classes behind after destroy`);
  }

  assert.ok(
    result.nav.includes("av-hide-nav-messages") && result.nav.includes("av-hide-nav-explore"),
    `the two real nav items must be hidden: ${JSON.stringify(result.nav)}`
  );
  // The hostile entry is not rejected, it is stripped to the characters a class name may hold —
  // which is the point: nothing from the settings file can close the attribute or open a tag.
  assert.ok(
    !result.nav.some((name) => /[^a-z0-9-]/.test(name)),
    `a nav item name reached the class list unsanitised: ${JSON.stringify(result.nav)}`
  );
  assert.deepEqual(result.afterNavDestroy, [], "per-item nav classes must be removed too");
});

test("link unshortening restores the title and class it replaced", async () => {
  const result = await page.evaluate(async () => {
    window.reset();
    document.body.innerHTML = `
      <article data-testid="tweet">
        <div data-testid="tweetText">
          <a href="https://t.co/abcd1234" title="t.co/abcd1234"
             aria-label="https://example.com/article">https://t.co/abcd1234</a>
          <a href="https://example.org/plain" title="original title">plain</a>
        </div>
      </article>`;
    const read = () =>
      [...document.querySelectorAll("a")].map((anchor) => ({
        title: anchor.getAttribute("title"),
        clean: anchor.classList.contains("av-link-clean"),
        classes: anchor.className
      }));

    const before = read();
    const ctx = window.ctx((settings) => {
      settings.links.expandTco = true;
    });
    await AviaryLifecycle.linkUnshortenFeature.init(ctx);
    await AviaryLifecycle.linkUnshortenFeature.apply(ctx, document);
    const during = read();

    await AviaryLifecycle.linkUnshortenFeature.destroy(ctx);
    return { before, during, after: read() };
  });

  assert.ok(
    result.during.some((entry) => entry.clean),
    "the feature marked nothing — the fixture no longer matches what it looks for"
  );
  assert.ok(
    result.during.filter((entry) => entry.clean).every((entry) => entry.title === null),
    "an expanded link still opens a native title tooltip on hover"
  );
  // Reversibility is the whole contract: the class goes, and a title the page set itself comes
  // back exactly, rather than being left as whatever the feature wrote over it.
  assert.deepEqual(
    result.after.map((entry) => entry.title),
    result.before.map((entry) => entry.title),
    "destroy did not restore the original titles"
  );
  assert.ok(!result.after.some((entry) => entry.clean), "destroy left the av-link-clean class behind");
  assert.deepEqual(
    result.after.map((entry) => entry.classes),
    result.before.map((entry) => entry.classes),
    "destroy left a class list the page did not start with"
  );
});

test("hiding engagement counts hides the numbers and keeps the buttons", async () => {
  const result = await page.evaluate(() => {
    window.reset();
    document.body.innerHTML = `
      <article data-testid="tweet">
        <button data-testid="reply"><span data-testid="app-text-transition-container">12</span></button>
        <button data-testid="retweet"><span data-testid="app-text-transition-container">34</span></button>
        <button data-testid="like"><span data-testid="app-text-transition-container">56</span></button>
        <a href="/alice/status/1/analytics"><span data-testid="app-text-transition-container">78</span></a>
      </article>`;
    const shown = (selector) => {
      const node = document.querySelector(selector);
      const style = getComputedStyle(node);
      return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity) > 0;
    };
    const snapshot = () => ({
      replyButton: shown('[data-testid="reply"]'),
      replyCount: shown('[data-testid="reply"] [data-testid="app-text-transition-container"]'),
      likeCount: shown('[data-testid="like"] [data-testid="app-text-transition-container"]'),
      analyticsCount: shown('a[href$="/analytics"] [data-testid="app-text-transition-container"]')
    });

    const off = window.ctx();
    const on = window.ctx((settings) => {
      settings.appearance.hideCounts = true;
    });

    AviaryLifecycle.themeFeature.init(off);
    const before = snapshot();
    AviaryLifecycle.themeFeature.apply(on);
    const during = snapshot();
    AviaryLifecycle.themeFeature.destroy(on);
    return { before, during, after: snapshot() };
  });

  assert.equal(result.before.replyCount, true, "the fixture must start with visible counts");
  assert.equal(result.during.replyCount, false, "the reply count must go");
  assert.equal(result.during.likeCount, false);
  assert.equal(result.during.analyticsCount, false, "the analytics count is a count too");
  // Hiding the button as well would remove the ability to reply, which is not what was asked for.
  assert.equal(result.during.replyButton, true, "the action button itself must stay usable");
  assert.equal(result.after.replyCount, true, "destroy must bring the counts back");
});

test("every immediate appearance and layout key a preset writes changes the page", async () => {
  const unimplemented = await page.evaluate(() => {
    window.reset();
    // A fixture carrying every surface the appearance and layout features target, so a key that
    // drives nothing is visible as a page that did not change.
    document.body.innerHTML = `
      <main data-testid="primaryColumn">
        <div data-testid="cellInnerDiv"><article data-testid="tweet">
          <button data-testid="reply"><span data-testid="app-text-transition-container">12</span></button>
        </article></div>
        <div data-testid="tweetTextarea_0RichTextInputContainer">
          <div contenteditable="true" data-testid="tweetTextarea_0" tabindex="0"></div>
        </div>
      </main>
      <aside data-testid="sidebarColumn">
        <div data-testid="trend">trend</div>
        <div data-testid="sidebarColumn-grok">grok</div>
        <div data-testid="UserCell">who to follow</div>
      </aside>
      <nav>
        <a data-testid="AppTabBar_Home_Link">home</a>
        <a data-testid="AppTabBar_Explore_Link">explore</a>
        <div role="tablist" data-testid="ScrollSnap-List">
          <div role="tab" data-testid="HomeTab" aria-selected="true">For you</div>
          <div role="tab" data-testid="HomeTab" aria-selected="false">Following</div>
        </div>
      </nav>`;

    const fingerprint = () =>
      JSON.stringify([
        [...document.documentElement.classList].sort(),
        document.documentElement.dataset.avTheme ?? null,
        document.documentElement.dataset.avWidth ?? null,
        [...document.querySelectorAll("[data-testid]")].map((node) => {
          const style = getComputedStyle(node);
          return [style.display, style.visibility, style.opacity, style.width];
        })
      ]);

    const misses = [];
    // These two controls act only after a later scroll or Back navigation. Their own browser tests
    // drive those events; a static page fingerprint here cannot distinguish their enabled state.
    const eventDrivenLayoutKeys = new Set(["autoExpandPostText", "restoreTimelinePosition"]);
    for (const preset of AviaryLifecycle.PRESETS) {
      for (const group of ["appearance", "layout"]) {
        for (const [key, value] of Object.entries(preset.overrides[group] ?? {})) {
          if (group === "layout" && eventDrivenLayoutKeys.has(key)) continue;
          // The question is whether the key drives anything, not whether this preset's value
          // happens to differ from the default — several presets set a boolean to false that is
          // already false, which is a no-op by design rather than an unimplemented key.
          const other = typeof value === "boolean" ? !value : AviaryLifecycle.DEFAULT_SETTINGS[group][key];
          if (other === value) continue;

          const render = (setting) => {
            const ctx = window.ctx((settings) => {
              settings[group][key] = setting;
            });
            AviaryLifecycle.themeFeature.init(ctx);
            AviaryLifecycle.layoutDeclutterFeature.init(ctx);
            AviaryLifecycle.forceFollowingFeature.init(ctx);
            AviaryLifecycle.forceFollowingFeature.apply(ctx, document);
            const shot = fingerprint();
            AviaryLifecycle.themeFeature.destroy(ctx);
            AviaryLifecycle.layoutDeclutterFeature.destroy(ctx);
            AviaryLifecycle.forceFollowingFeature.destroy(ctx);
            return shot;
          };

          if (render(value) === render(other)) {
            misses.push(`${group}.${key} (${JSON.stringify(value)} vs ${JSON.stringify(other)})`);
          }
        }
      }
    }
    return [...new Set(misses)];
  });

  // A preset that flips a key nothing reads reports a change it cannot deliver.
  assert.deepEqual(unimplemented, [], "these preset keys changed nothing on the page");
});

test("an account note shows on that account's posts only, and destroy takes it back off", async () => {
  const result = await page.evaluate(async () => {
    window.reset();
    document.body.innerHTML = `
      <main data-testid="primaryColumn">
        <article data-testid="tweet" id="noted">
          <div data-testid="User-Name"><a href="/alice"><span>@alice</span></a></div>
        </article>
        <article data-testid="tweet" id="other">
          <div data-testid="User-Name"><a href="/bob"><span>@bob</span></a></div>
        </article>
      </main>`;

    const ctx = window.ctx();
    ctx.storage = {
      async get(key, fallback) {
        // A note keyed on the normalized handle, which is how the store writes it.
        return String(key).includes("userNotes") ? { notes: { alice: "met at a conference" } } : fallback;
      },
      async set() {},
      async remove() {}
    };

    const badges = () =>
      [...document.querySelectorAll("[data-av-note-badge]")].map((badge) => ({
        on: badge.closest("article")?.id,
        text: badge.textContent
      }));

    const before = badges().length;
    await AviaryLifecycle.userNotesFeature.init(ctx);
    const during = badges();
    const badge = document.querySelector("[data-av-note-badge]");
    const shown = {
      // The visible text is a short label; the note itself remains in the accessible name, so the
      // badge survives a screen reader and a monochrome display without opening a hover bubble.
      label: badge?.textContent ?? "",
      title: badge?.getAttribute("title") ?? "",
      accessibleName: badge?.getAttribute("aria-label") ?? "",
      role: badge?.getAttribute("role") ?? ""
    };

    AviaryLifecycle.userNotesFeature.destroy(ctx);
    return {
      before,
      during,
      shown,
      after: badges().length,
      markers: document.querySelectorAll("[data-av-note-processed]").length,
      style: Boolean(document.getElementById("av-user-notes"))
    };
  });

  assert.equal(result.before, 0, "the fixture must start clean");
  assert.deepEqual(
    result.during.map((badge) => badge.on),
    ["noted"],
    "the note must land on the account it was written for, and only that one"
  );
  assert.equal(result.shown.role, "note");
  assert.ok(result.shown.label.trim().length > 0, "the badge must be visible as more than colour");
  assert.equal(result.shown.title, "", "the note badge must not open a native hover tooltip");
  assert.match(
    result.shown.accessibleName,
    /@alice: met at a conference/,
    "and must reach a screen reader, naming the account it belongs to"
  );
  assert.equal(result.after, 0, "destroy left a badge behind");
  assert.equal(result.markers, 0, "destroy left its processed marker on the post");
  assert.equal(result.style, false, "destroy must take its stylesheet with it");
});

test("the locale feature sets reading direction and the locale it set, and clears both", async () => {
  const result = await page.evaluate(() => {
    window.reset();
    const html = document.documentElement;
    const read = () => ({
      rtl: html.classList.contains("av-rtl"),
      ltr: html.classList.contains("av-ltr"),
      locale: html.dataset.avLocale ?? null
    });

    const arabic = window.ctx((settings) => {
      settings.i18n.locale = "ar";
    });
    const english = window.ctx((settings) => {
      settings.i18n.locale = "en";
    });

    AviaryLifecycle.i18nFeature.init(arabic);
    const withArabic = read();
    // Switching back must clear the direction, not leave the page reading right-to-left.
    AviaryLifecycle.i18nFeature.apply(english, document);
    const withEnglish = read();
    AviaryLifecycle.i18nFeature.destroy(english);
    return { withArabic, withEnglish, afterDestroy: read() };
  });

  assert.equal(result.withArabic.rtl, true, "Arabic must set right-to-left");
  assert.equal(result.withArabic.locale, "ar", "the page must record which locale is applied");
  assert.equal(result.withEnglish.rtl, false, "switching to English must clear right-to-left");
  assert.equal(result.withEnglish.locale, "en");
  assert.equal(result.afterDestroy.rtl, false, "destroy must leave no direction class behind");
  assert.equal(result.afterDestroy.ltr, false);
  assert.equal(result.afterDestroy.locale, null, "and no locale marker");
});

test("the media layout class follows the setting and is removed on destroy", async () => {
  const result = await page.evaluate(() => {
    window.reset();
    document.body.innerHTML = `
      <main data-testid="primaryColumn">
        <article data-testid="tweet">
          <div data-testid="tweetPhoto"><img src="https://pbs.twimg.com/media/a?format=jpg" alt=""></div>
        </article>
      </main>`;
    const layoutClasses = () =>
      [...document.documentElement.classList].filter((name) => name.startsWith("av-media-layout-"));

    const grid = window.ctx((settings) => {
      settings.media.layout = "grid";
    });
    AviaryLifecycle.mediaPresentationFeature.init(grid);
    const asGrid = layoutClasses();

    const stack = window.ctx((settings) => {
      settings.media.layout = "stacked";
    });
    AviaryLifecycle.mediaPresentationFeature.apply(stack, document);
    const asStack = layoutClasses();

    AviaryLifecycle.mediaPresentationFeature.destroy(stack);
    return { asGrid, asStack, afterDestroy: layoutClasses() };
  });

  // Exactly one layout class at a time: two would leave the losing rule fighting the winner.
  assert.deepEqual(result.asGrid, ["av-media-layout-grid"]);
  assert.deepEqual(result.asStack, ["av-media-layout-stacked"], "changing the setting must swap the class");
  assert.deepEqual(result.afterDestroy, [], "destroy must remove every class it set");
});

/**
 * A resumed feature must not leave its old subscription behind.
 *
 * The bisect search suspends and resumes features by calling their own `destroy` and `init`. The
 * page bridge had no unsubscribe, and the three features that listen to it dropped only a guard
 * variable in `destroy`, so every round left another live closure. One GraphQL response was then
 * processed once per accumulated handler: the session payload and byte budgets burned N times
 * faster and stopped capture early, the panel reported an inflated capture count, and the Trust
 * page's blocked-beacon counters multiplied.
 */
test("suspending and resuming a feature does not multiply its page-bridge handlers", async () => {
  const { networkCaptureFeature } = await import(
    new URL("../src/features/export/network-capture.ts", import.meta.url).href
  );

  const handlers = new Map();
  const bridge = {
    status: () => "connected",
    reason: () => "",
    configure() {},
    on(kind, handler) {
      const set = handlers.get(kind) ?? new Set();
      set.add(handler);
      handlers.set(kind, set);
    },
    off(kind, handler) {
      handlers.get(kind)?.delete(handler);
    },
    destroy() {}
  };

  const ctx = {
    settings: { export: { preserveRawPayloads: true } },
    route: { surface: "home", href: "https://x.com/home", path: "/home" },
    storage: { get: async (_key, fallback) => fallback, set: async () => {} },
    diagnostics: { info() {}, warn() {}, error() {} },
    auditLog: { record() {} },
    pageBridge: bridge,
    requestApply() {}
  };

  await networkCaptureFeature.init(ctx);
  assert.equal(handlers.get("graphql")?.size ?? 0, 1, "init subscribes once");

  for (let round = 0; round < 5; round += 1) {
    await networkCaptureFeature.destroy(ctx);
    await networkCaptureFeature.init(ctx);
  }

  assert.equal(
    handlers.get("graphql")?.size ?? 0,
    1,
    "five suspend/resume rounds must still leave exactly one subscriber"
  );

  await networkCaptureFeature.destroy(ctx);
  assert.equal(
    handlers.get("graphql")?.size ?? 0,
    0,
    "destroy must leave nothing subscribed"
  );
});

/**
 * The mobile path, driven rather than read.
 *
 * Two tests touched this feature and neither exercised what it does: one read the file as text to
 * check its selectors were scoped, and one asserted hit-target sizes under a coarse-pointer
 * emulation. Nothing drove `apply` against a touch-shaped page, so a regression in what it
 * actually changes -- or in `destroy` failing to put it back, which is the contract every feature
 * here is held to -- would have been caught only by the size assertion happening to move.
 */
test("the mobile feature marks a coarse-pointer page and destroy puts it back", async () => {
  const before = await page.evaluate(() => {
    window.reset();
    document.getElementById("av-mobile-touch")?.remove();
    return {
      classes: document.documentElement.className,
      style: document.getElementById("av-mobile-touch") !== null
    };
  });
  assert.equal(before.style, false, "the page must start without the feature's stylesheet");

  // A coarse pointer on a narrow viewport, which is the case the feature exists for.
  const narrow = await browser.newPage({
    viewport: { width: 420, height: 900 },
    hasTouch: true,
    isMobile: true
  });
  // Without a viewport meta an emulated mobile page still lays out at 980px, so the narrow
  // media query would not match and the test would be measuring the wrong thing.
  await narrow.setContent(
    '<!doctype html><meta charset=utf-8><meta name="viewport" content="width=device-width"><body></body>'
  );
  await narrow.addScriptTag({ path: bundle });

  const result = await narrow.evaluate(() => {
    const ctx = {
      settings: AviaryLifecycle.cloneSettings(AviaryLifecycle.DEFAULT_SETTINGS),
      route: { surface: "home", path: "/home" },
      diagnostics: { info() {}, warn() {}, error() {} }
    };

    AviaryLifecycle.mobileTouchFeature.init(ctx);
    const applied = {
      touch: document.documentElement.classList.contains("av-touch"),
      mobile: document.documentElement.classList.contains("av-mobile"),
      styles: document.querySelectorAll("#av-mobile-touch").length,
      coarse: window.matchMedia("(pointer: coarse)").matches
    };

    // Applying twice must not stack a second stylesheet.
    AviaryLifecycle.mobileTouchFeature.apply(ctx);
    const reapplied = document.querySelectorAll("#av-mobile-touch").length;

    AviaryLifecycle.mobileTouchFeature.destroy(ctx);
    const destroyed = {
      touch: document.documentElement.classList.contains("av-touch"),
      mobile: document.documentElement.classList.contains("av-mobile"),
      styles: document.querySelectorAll("#av-mobile-touch").length
    };

    return { applied, reapplied, destroyed };
  });

  await narrow.close();

  assert.equal(result.applied.coarse, true, "the emulation has to be coarse for this to mean anything");
  assert.equal(result.applied.touch, true, "a coarse pointer must be marked on the root element");
  assert.equal(result.applied.mobile, true, "and so must a narrow viewport");
  assert.equal(result.applied.styles, 1, "the feature's stylesheet must be on the page");
  assert.equal(result.reapplied, 1, "applying twice must not stack a second stylesheet");

  assert.deepEqual(
    result.destroyed,
    { touch: false, mobile: false, styles: 0 },
    "destroy must leave the page as X rendered it"
  );
});

/**
 * And on a desktop pointer it marks nothing, so the page is untouched.
 */
test("the mobile feature leaves a fine-pointer page alone", async () => {
  const result = await page.evaluate(() => {
    window.reset();
    document.getElementById("av-mobile-touch")?.remove();
    const ctx = window.ctx();
    AviaryLifecycle.mobileTouchFeature.init(ctx);
    const state = {
      touch: document.documentElement.classList.contains("av-touch"),
      mobile: document.documentElement.classList.contains("av-mobile"),
      styles: document.querySelectorAll("#av-mobile-touch").length
    };
    AviaryLifecycle.mobileTouchFeature.destroy(ctx);
    return { state, stylesAfter: document.querySelectorAll("#av-mobile-touch").length };
  });

  assert.equal(result.state.touch, false, "a fine pointer must not be marked as touch");
  assert.equal(result.state.mobile, false, "a wide viewport must not be marked as mobile");
  // The stylesheet still ships, because its rules are all behind those two classes.
  assert.equal(result.state.styles, 1);
  assert.equal(result.stylesAfter, 0, "and destroy still takes it away");
});
